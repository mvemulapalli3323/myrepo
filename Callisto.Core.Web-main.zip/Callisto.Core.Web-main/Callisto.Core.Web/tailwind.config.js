/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "selector",
  theme: {
    extend: {
      colors: {
        dark: "#000",
        goldenrod: "#FCB414",
        "medium-orange": "#F6893C",
        "dark-orange": "#E96847",
        "light-gray": "#93979D",
        "medium-gray": "#757B82",
        "dark-gray": "#5B5C61",
        "lime-green": "#90C96A",
        "teal-blue": "#36BEBC",
        "navy-blue": "#395072",
        "taupe-gold": "#958F72",
      },
    },
  },
  plugins: [],
};
