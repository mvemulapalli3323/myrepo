import { Outlet } from "react-router-dom";
import {
  MsalAuthenticationTemplate,
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  MsalAuthenticationResult,
} from "@azure/msal-react";
import { InteractionType } from "@azure/msal-browser";
import Navigation from "./components/Navigation";

import { Card, Stack, Typography, Box } from "@mui/material";

const authProgressComponent = () => {
  return (
    <Box sx={{ display: "flex", justifyContent: "center", my: 6 }}>
      <Card
        elevation={3}
        sx={{
          padding: 4,
          width: "600px",
          borderRadius: 2,
          bgcolor: "primary.main",
        }}
      >
        <Stack spacing={2} sx={{ alignItems: "center" }}>
          <img
            src="/3DLogo.svg"
            alt="3D Logo"
            style={{ width: "300px", height: "auto" }}
          />
          <Typography variant="h6" sx={{ mb: 2, color: "white" }}>
            Authentication in progress...
          </Typography>
        </Stack>
      </Card>
    </Box>
  );
};

//this was an attempt to determine why the MSALAuthenticationTemplate never seems to display the errorComponent
//revisit the routing and ./components/AuthenticationError.tsx component later
const authErrorComponent = ({ error }: MsalAuthenticationResult) => {
  return (
    <Box sx={{ display: "flex", justifyContent: "center", my: 6 }}>
      <Card
        elevation={3}
        sx={{
          padding: 4,
          width: "600px",
          borderRadius: 2,
          bgcolor: "primary.main",
        }}
      >
        <Stack spacing={2} sx={{ alignItems: "center" }}>
          <img
            src="/3DLogo.svg"
            alt="3D Logo"
            style={{ width: "300px", height: "auto" }}
          />
          <Typography variant="h6" sx={{ mb: 2, color: "white" }}>
            Authentication Error
          </Typography>
          <Typography variant="body1" sx={{ color: "white" }}>
            {error?.errorMessage ||
              "An unknown error occurred during authentication."}
          </Typography>
        </Stack>
      </Card>
    </Box>
  );
};

export default function Layout() {
  return (
    <>
      <MsalAuthenticationTemplate
        interactionType={InteractionType.Redirect}
        errorComponent={authErrorComponent}
        loadingComponent={authProgressComponent}
      >
        <AuthenticatedTemplate>
          <Navigation />
          <Outlet />
        </AuthenticatedTemplate>
        {/* TODO: implement logout functionality and test UnauthenticatedTemplate */}
        <UnauthenticatedTemplate>
          <Box sx={{ display: "flex", justifyContent: "center", my: 6 }}>
            <Card
              elevation={3}
              sx={{
                padding: 4,
                width: "600px",
                borderRadius: 2,
                bgcolor: "primary.main",
              }}
            >
              <Stack spacing={2} sx={{ alignItems: "center" }}>
                <img
                  src="/3DLogo.svg"
                  alt="3D Logo"
                  style={{ width: "300px", height: "auto" }}
                />
                <Typography variant="h6" sx={{ mb: 2, color: "white" }}>
                  Not Authorized
                </Typography>
                <Typography variant="h6" sx={{ mb: 2, color: "white" }}>
                  If you require access, please contact the 3D help desk!
                </Typography>
              </Stack>
            </Card>
          </Box>
        </UnauthenticatedTemplate>
      </MsalAuthenticationTemplate>
    </>
  );
}
