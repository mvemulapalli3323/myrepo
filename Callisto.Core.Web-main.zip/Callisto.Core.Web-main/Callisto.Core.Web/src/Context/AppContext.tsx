import { createContext, useState, ReactNode, FC } from "react";

interface AppContextType {
  data: unknown[];
  setData: (value: unknown[]) => void;
  open: boolean;
  setOpen: (value: boolean) => void;
}

export const Context = createContext<AppContextType | undefined>(undefined);

export const Provider: FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<unknown[]>([]);
  const [open, setOpen] = useState<boolean>(false);
  
  return (
    <Context.Provider value={{ 
      data, 
      setData, 
      open, 
      setOpen 
    }}>
      {children}
    </Context.Provider>
  );
};
