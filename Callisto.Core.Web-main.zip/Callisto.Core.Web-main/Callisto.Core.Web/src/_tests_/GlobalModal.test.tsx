import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import GlobalModalComponent from "../components/SharedComponents/Modals/globalModal";
import { ModalDataType } from "../api/services/receipts-services/ServicesInterfaces";

vi.mock("../components/SearchPosition/Index", () => ({
  default: function MockSearchPosition() {
    return <div data-testid="search-position">Search Position Component</div>;
  },
}));

vi.mock("../components/SearchPosition/ProductSearch", () => ({
  default: function MockProductSearch() {
    return <div data-testid="product-search">Product Search Component</div>;
  },
}));

vi.mock("../components/SearchPosition/EditPosition", () => ({
  default: function MockEditPosition() {
    return <div data-testid="edit-position">Edit Position Component</div>;
  },
}));

describe("GlobalModalComponent", () => {
  const mockHandleClose = vi.fn();

  const defaultProps = {
    open: true,
    handleClose: mockHandleClose,
    modelData: {
      title: "Test Modal",
      content1: "Test content",
      cancelBtn: "Cancel",
      confirmBtn: "Confirm",
    } as ModalDataType,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Basic Modal Functionality", () => {
    it("renders modal with title and content", () => {
      render(<GlobalModalComponent {...defaultProps} />);

      expect(screen.getByText("Test Modal")).toBeInTheDocument();
      expect(screen.getByText("Test content")).toBeInTheDocument();
      expect(screen.getByText("Cancel")).toBeInTheDocument();
      expect(screen.getByText("Confirm")).toBeInTheDocument();
    });

    it("calls handleClose when close button is clicked", () => {
      render(<GlobalModalComponent {...defaultProps} />);

      const closeButton = screen.getByRole("button", { name: /close/i });
      fireEvent.click(closeButton);

      expect(mockHandleClose).toHaveBeenCalledWith("close");
    });

    it("calls handleClose when cancel button is clicked", () => {
      render(<GlobalModalComponent {...defaultProps} />);

      const cancelButton = screen.getByText("Cancel");
      fireEvent.click(cancelButton);

      expect(mockHandleClose).toHaveBeenCalledWith("cancel");
    });

    it("calls handleClose when confirm button is clicked", () => {
      render(<GlobalModalComponent {...defaultProps} />);

      const confirmButton = screen.getByText("Confirm");
      fireEvent.click(confirmButton);

      expect(mockHandleClose).toHaveBeenCalledWith("confirm");
    });
  });

  describe("Checkbox Functionality", () => {
    it("does not render checkbox when checkbox property is false", () => {
      const propsWithoutCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: false,
        },
      };

      render(<GlobalModalComponent {...propsWithoutCheckbox} />);

      expect(screen.queryByRole("checkbox")).not.toBeInTheDocument();
    });

    it("renders checkbox when checkbox property is true", () => {
      const propsWithCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: true,
        },
      };

      render(<GlobalModalComponent {...propsWithCheckbox} />);

      const checkbox = screen.getByRole("checkbox");
      expect(checkbox).toBeInTheDocument();
      expect(checkbox).not.toBeChecked();
    });

    it("displays correct label for checkbox", () => {
      const propsWithCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: true,
        },
      };

      render(<GlobalModalComponent {...propsWithCheckbox} />);

      expect(
        screen.getByText(
          /At least one product is Green-E and requires confirmation to proceed/
        )
      ).toBeInTheDocument();
    });

    it("checkbox starts unchecked", () => {
      const propsWithCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: true,
        },
      };

      render(<GlobalModalComponent {...propsWithCheckbox} />);

      const checkbox = screen.getByRole("checkbox");
      expect(checkbox).not.toBeChecked();
    });

    it("checkbox can be checked and unchecked", () => {
      const propsWithCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: true,
        },
      };

      render(<GlobalModalComponent {...propsWithCheckbox} />);

      const checkbox = screen.getByRole("checkbox");
      fireEvent.click(checkbox);
      expect(checkbox).toBeChecked();
      fireEvent.click(checkbox);
      expect(checkbox).not.toBeChecked();
    });

    it("confirm button is disabled when checkbox is unchecked", () => {
      const propsWithCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: true,
        },
      };

      render(<GlobalModalComponent {...propsWithCheckbox} />);

      const confirmButton = screen.getByText("Confirm");
      expect(confirmButton).toBeDisabled();
    });

    it("confirm button is enabled when checkbox is checked", () => {
      const propsWithCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: true,
        },
      };

      render(<GlobalModalComponent {...propsWithCheckbox} />);

      const checkbox = screen.getByRole("checkbox");
      const confirmButton = screen.getByText("Confirm");

      // Initially disabled
      expect(confirmButton).toBeDisabled();

      // Check the checkbox
      fireEvent.click(checkbox);
      expect(confirmButton).toBeEnabled();
    });

    it("checkbox resets to unchecked when modal opens", async () => {
      const propsWithCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: true,
        },
      };

      const { rerender } = render(
        <GlobalModalComponent {...propsWithCheckbox} />
      );

      const checkbox = screen.getByRole("checkbox");

      // Check the checkbox
      fireEvent.click(checkbox);
      expect(checkbox).toBeChecked();

      // Close modal by setting open to false
      rerender(<GlobalModalComponent {...propsWithCheckbox} open={false} />);

      // Reopen modal by setting open to true
      rerender(<GlobalModalComponent {...propsWithCheckbox} open={true} />);

      const newCheckbox = screen.getByRole("checkbox");
      expect(newCheckbox).not.toBeChecked();
    });

    it("checkbox state is independent of other modal content", () => {
      const propsWithCheckbox = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          checkbox: true,
          content1: "First content",
          content2: "Second content",
        },
      };

      render(<GlobalModalComponent {...propsWithCheckbox} />);

      expect(screen.getByText("First content")).toBeInTheDocument();
      expect(screen.getByText("Second content")).toBeInTheDocument();

      const checkbox = screen.getByRole("checkbox");
      expect(checkbox).not.toBeChecked();

      // Check the checkbox
      fireEvent.click(checkbox);
      expect(checkbox).toBeChecked();
    });
  });

  describe("Form Type Modals", () => {
    it("renders form type modal correctly", () => {
      const formProps = {
        ...defaultProps,
        modelData: {
          type: "form",
          btn: "chooseproduct",
        },
      };

      render(<GlobalModalComponent {...formProps} />);

      expect(screen.getByTestId("product-search")).toBeInTheDocument();
    });

    it("renders edit product form correctly", () => {
      const formProps = {
        ...defaultProps,
        modelData: {
          type: "form",
          btn: "editproduct",
        },
      };

      render(<GlobalModalComponent {...formProps} />);

      expect(screen.getByTestId("edit-position")).toBeInTheDocument();
    });
  });

  describe("Number Input Form", () => {
    it("renders number input when form type is number", () => {
      const numberFormProps = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          form: {
            type: "number" as const,
            label: "Quantity",
            data: {
              number: 5,
              quantity: 10,
            },
          },
        },
      };

      render(<GlobalModalComponent {...numberFormProps} />);

      expect(screen.getByLabelText("Quantity")).toBeInTheDocument();
      expect(screen.getByDisplayValue("5")).toBeInTheDocument();
      expect(screen.getByText("/10")).toBeInTheDocument();
    });

    it("handles number input changes", () => {
      const numberFormProps = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          form: {
            type: "number" as const,
            label: "Quantity",
            data: {
              number: 5,
              quantity: 10,
            },
          },
        },
      };

      render(<GlobalModalComponent {...numberFormProps} />);

      const input = screen.getByLabelText("Quantity");
      fireEvent.change(input, { target: { value: "7" } });

      expect(input).toHaveValue("7");
    });

    it("calls handleClose with quantity when confirm is clicked for number form", () => {
      const numberFormProps = {
        ...defaultProps,
        modelData: {
          ...defaultProps.modelData,
          form: {
            type: "number" as const,
            label: "Quantity",
            data: {
              number: 5,
              quantity: 10,
            },
          },
        },
      };

      render(<GlobalModalComponent {...numberFormProps} />);

      const confirmButton = screen.getByText("Confirm");
      fireEvent.click(confirmButton);

      expect(mockHandleClose).toHaveBeenCalledWith({ quantity: 5 });
    });
  });

  describe("Modal Sizing", () => {
    it("uses correct maxWidth for edit product form", () => {
      const editFormProps = {
        ...defaultProps,
        modelData: {
          type: "form",
          btn: "editproduct",
        },
      };

      render(<GlobalModalComponent {...editFormProps} />);

      const dialog = screen.getByRole("dialog");
      expect(dialog).toBeInTheDocument();
    });

    it("uses correct maxWidth for regular form", () => {
      const formProps = {
        ...defaultProps,
        modelData: {
          type: "form",
          btn: "chooseproduct",
        },
      };

      render(<GlobalModalComponent {...formProps} />);

      const dialog = screen.getByRole("dialog");
      expect(dialog).toBeInTheDocument();
    });
  });

  describe("Content Component", () => {
    it("renders custom content component when provided", () => {
      const customContent = (
        <div data-testid="custom-content">Custom Content</div>
      );
      const propsWithContent = {
        ...defaultProps,
        contentComponent: customContent,
      };

      render(<GlobalModalComponent {...propsWithContent} />);

      expect(screen.getByTestId("custom-content")).toBeInTheDocument();
      expect(screen.queryByText("Test content")).not.toBeInTheDocument();
    });
  });

  describe("Edge Cases", () => {
    it("handles modal with minimal data", () => {
      const minimalProps = {
        open: true,
        handleClose: mockHandleClose,
        modelData: {},
      };

      render(<GlobalModalComponent {...minimalProps} />);

      expect(screen.getByRole("dialog")).toBeInTheDocument();
    });

    it("handles modal with only title", () => {
      const titleOnlyProps = {
        ...defaultProps,
        modelData: {
          title: "Title Only",
        },
      };

      render(<GlobalModalComponent {...titleOnlyProps} />);

      expect(screen.getByText("Title Only")).toBeInTheDocument();
      expect(screen.queryByText("Cancel")).not.toBeInTheDocument();
      expect(screen.queryByText("Confirm")).not.toBeInTheDocument();
    });

    it("handles modal with only confirm button", () => {
      const confirmOnlyProps = {
        ...defaultProps,
        modelData: {
          title: "Title",
          confirmBtn: "Confirm Only",
        },
      };

      render(<GlobalModalComponent {...confirmOnlyProps} />);

      expect(screen.getByText("Confirm Only")).toBeInTheDocument();
      expect(screen.queryByText("Cancel")).not.toBeInTheDocument();
    });
  });
});
