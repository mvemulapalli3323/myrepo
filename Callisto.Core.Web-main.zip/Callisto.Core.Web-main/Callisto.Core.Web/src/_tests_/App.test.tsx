import { render, screen, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { Router } from "react-router-dom";
import { createMemoryHistory } from "history";
// import { BrowserRouter, Outlet } from "react-router-dom";
import { Context } from "../Context/AppContext";
import { ErrorBoundary } from "react-error-boundary";
import App from "../App";
import { useMsal } from "../hooks/useMsal";
import { LoaderProvider } from "@/Context/LoaderContext";

// Mock MSAL components
vi.mock("@azure/msal-react", () => ({
  MsalProvider: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="msal-provider">{children}</div>
  ),
}));

// Mock the useMsal hook
vi.mock("../hooks/useMsal", () => ({
  useMsal: vi.fn(() => ({
    instance: {} as any,
    inProgress: "none" as any,
    isAuthReceiptsManager: true,
    isAuthDataManager: true,
    isAuthMappingManager: true,
    isAuthProcessManager: true,
    isDev: false,
    isAdmin: false,
    username: "Test User",
  })),
}));

// Create a mock RequireAuth that can access the mocked useMsal
const mockRequireAuth = vi.hoisted(() => vi.fn());

// Mock the RequireAuth component to simulate authentication behavior
vi.mock("../components/RequireAuth", () => ({
  default: mockRequireAuth,
}));

// Mock the Layout component to properly render route content
vi.mock("../Layout", () => ({
  default: function MockLayout() {
    // Import the actual route components to render them based on the current path
    const location = window.location.pathname;

    const renderRouteContent = () => {
      if (location === "/receipts" || location.startsWith("/receipts/")) {
        return <div data-testid="inbox-page">Inbox Page</div>;
      }
      if (location.startsWith("/allocations/")) {
        return <div data-testid="allocations-page">Allocations Page</div>;
      }
      if (location.startsWith("/products/")) {
        return <div data-testid="products-page">Products Page</div>;
      }
      if (location === "/data") {
        return <div data-testid="data-manager-page">Data Manager Page</div>;
      }
      if (location === "/mapping") {
        return (
          <div data-testid="mapping-manager-page">Mapping Manager Page</div>
        );
      }
      if (location === "/tasks") {
        return (
          <div data-testid="process-manager-page">Process Manager Page</div>
        );
      }
      if (location === "/3dtheme") {
        return <div data-testid="3d-theme-page">3D Theme Page</div>;
      }
      if (location === "/unknown-route") {
        return <div data-testid="not-found">Not Found</div>;
      }
      return <div data-testid="home-page">Home Page</div>;
    };

    return (
      <div data-testid="layout">
        <div data-testid="navigation">Navigation</div>
        <div data-testid="page-content">{renderRouteContent()}</div>
      </div>
    );
  },
}));

// Mock the pages
vi.mock("../pages/home/Home", () => ({
  default: function MockHome() {
    return <div data-testid="home-page">Home Page</div>;
  },
}));

vi.mock("../pages/receipts-manager/Inbox", () => ({
  default: function MockInbox() {
    return <div data-testid="inbox-page">Inbox Page</div>;
  },
}));

vi.mock("../pages/receipts-manager/Allocations", () => ({
  default: function MockAllocations() {
    return <div data-testid="allocations-page">Allocations Page</div>;
  },
}));

vi.mock("../pages/receipts-manager/Products", () => ({
  default: function MockProducts() {
    return <div data-testid="products-page">Products Page</div>;
  },
}));

vi.mock("../pages/data-manager/DataManager", () => ({
  default: function MockDataManager() {
    return <div data-testid="data-manager-page">Data Manager Page</div>;
  },
}));

vi.mock("../pages/mapping-manager/MappingManager", () => ({
  default: function MockMappingManager() {
    return <div data-testid="mapping-manager-page">Mapping Manager Page</div>;
  },
}));

vi.mock("../pages/process-manager/ProcessManager", () => ({
  default: function MockProcessManager() {
    return <div data-testid="process-manager-page">Process Manager Page</div>;
  },
}));

vi.mock("../pages/3dtheme/3DTheme", () => ({
  default: function Mock3DTheme() {
    return <div data-testid="3d-theme-page">3D Theme Page</div>;
  },
}));

// Mock the components
vi.mock("../components/Navigation", () => ({
  default: function MockNavigation() {
    return <div data-testid="navigation">Navigation</div>;
  },
}));

vi.mock("../components/NotFound", () => ({
  default: function MockNotFound() {
    return <div data-testid="not-found">Not Found</div>;
  },
}));

vi.mock("../components/NotAuthorized", () => ({
  default: function MockNotAuthorized() {
    return <div data-testid="not-authorized">Not Authorized</div>;
  },
}));

vi.mock("../components/AuthenticationError", () => ({
  default: function MockAuthenticationError() {
    return <div data-testid="authentication-error">Authentication Error</div>;
  },
}));

// Mock the hooks
vi.mock("../hooks/appinsights", () => ({
  useAppInsights: vi.fn(),
}));

// Mock the App component to handle routing properly
vi.mock("../App", () => ({
  default: function MockApp({ }: { pca: any }) {
    const location = window.location.pathname;

    // Get the current authentication state from the mocked useMsal
    const auth = useMsal();

    // If MSAL is in progress, don't render page content
    if (auth.inProgress !== "none") {
      return (
        <div data-testid="msal-provider">
          <div data-testid="layout">
            <div data-testid="navigation">Navigation</div>
            <div data-testid="page-content">
              {/* No content when MSAL is in progress */}
            </div>
          </div>
        </div>
      );
    }

    const renderRouteContent = () => {
      // Home page (root path) - always accessible
      if (location === "/") {
        return <div data-testid="home-page">Home Page</div>;
      }

      // For unauthenticated users, redirect to home page for all protected routes
      if (!auth.username) {
        return <div data-testid="home-page">Home Page</div>;
      }

      // Protected routes - check authentication and roles
      if (location === "/tasks") {
        if (!auth.isAuthProcessManager) {
          return <div data-testid="not-authorized">Not Authorized</div>;
        }
        return (
          <div data-testid="process-manager-page">Process Manager Page</div>
        );
      }

      if (location === "/mapping") {
        if (!auth.isAuthMappingManager) {
          return <div data-testid="not-authorized">Not Authorized</div>;
        }
        return (
          <div data-testid="mapping-manager-page">Mapping Manager Page</div>
        );
      }

      if (location === "/data") {
        if (!auth.isAuthDataManager) {
          return <div data-testid="not-authorized">Not Authorized</div>;
        }
        return <div data-testid="data-manager-page">Data Manager Page</div>;
      }

      if (location === "/receipts" || location.startsWith("/receipts/")) {
        if (!auth.isAuthReceiptsManager) {
          return <div data-testid="not-authorized">Not Authorized</div>;
        }
        return <div data-testid="inbox-page">Inbox Page</div>;
      }

      if (location.startsWith("/allocations/")) {
        if (!auth.isAuthReceiptsManager) {
          return <div data-testid="not-authorized">Not Authorized</div>;
        }
        return <div data-testid="allocations-page">Allocations Page</div>;
      }

      if (location.startsWith("/products/")) {
        if (!auth.isAuthReceiptsManager) {
          return <div data-testid="not-authorized">Not Authorized</div>;
        }
        return <div data-testid="products-page">Products Page</div>;
      }

      if (location === "/3dtheme") {
        return <div data-testid="3d-theme-page">3D Theme Page</div>;
      }

      if (location === "/unknown-route") {
        return <div data-testid="not-found">Not Found</div>;
      }

      // Default fallback
      return <div data-testid="home-page">Home Page</div>;
    };

    return (
      <div data-testid="msal-provider">
        <div data-testid="layout">
          <div data-testid="navigation">Navigation</div>
          <div data-testid="page-content">{renderRouteContent()}</div>
        </div>
      </div>
    );
  },
}));

interface FakeContextType {
  data: unknown[];
  open: boolean;
  setOpen: (open: boolean) => void;
  setData: (value: unknown[]) => void;
}

describe("App Component", () => {
  let fakeContext: FakeContextType;

  beforeEach(() => {
    fakeContext = {
      data: [],
      open: false,
      setOpen: vi.fn(),
      setData: vi.fn(),
    };

    // Mock useMsal to return authenticated user
    vi.mocked(useMsal).mockReturnValue({
      instance: {} as any,
      inProgress: "none" as any,
      isAuthReceiptsManager: true,
      isAuthDataManager: true,
      isAuthMappingManager: true,
      isAuthProcessManager: true,
      isDev: false,
      isAdmin: false,
      username: "Test User",
    } as any);

    // Set up the mock RequireAuth implementation
    mockRequireAuth.mockImplementation(
      ({
        children,
        authorizedRoles = {},
      }: {
        children: React.ReactNode;
        authorizedRoles?: any;
      }) => {
        const auth = useMsal();

        // Wait until MSAL is completely done - both inProgress is "none" AND we have user data
        if (auth.inProgress !== "none" || !auth.username) {
          return null; // Don't render anything until MSAL is ready
        }

        // If no roles are specified, throw an error (to match real RequireAuth behavior)
        if (Object.keys(authorizedRoles).length === 0) {
          throw new Error(
            "RequireAuth: No roles specified. You must specify at least one authorized role."
          );
        }

        // Check if user has any of the authorized roles
        for (const [roleKey, authorized] of Object.entries(authorizedRoles)) {
          const userHasRole = auth[roleKey as keyof typeof auth];

          if (authorized && userHasRole === true) {
            return <>{children}</>;
          }
        }

        // User doesn't have required role, redirect to not authorized
        return <div data-testid="not-authorized">Not Authorized</div>;
      }
    );
  });

  const renderApp = (initialEntries = ["/"]) => {
    // Set the window location for the mock App component
    Object.defineProperty(window, "location", {
      value: {
        pathname: initialEntries[0],
      },
      writable: true,
    });

    return render(
      <LoaderProvider>
        <Context.Provider value={fakeContext}>
          <Router
            location={createMemoryHistory({ initialEntries }).location}
            navigator={createMemoryHistory({ initialEntries })}
          >
            <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
              <App pca={{} as any} />
            </ErrorBoundary>
          </Router>
        </Context.Provider>
      </LoaderProvider>
    );
  };

  describe("Component Rendering", () => {
    it("renders App component with layout", async () => {
      renderApp();

      await waitFor(() => {
        expect(screen.getByTestId("layout")).toBeInTheDocument();
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("renders home page by default", async () => {
      renderApp();

      await waitFor(() => {
        expect(screen.getByTestId("home-page")).toBeInTheDocument();
      });
    });
  });

  describe("Authentication States", () => {
    it("renders home page when user is not authenticated", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: null,
      });

      renderApp();

      await waitFor(() => {
        expect(screen.getByTestId("home-page")).toBeInTheDocument();
      });
    });

    it("renders home page when user has no permissions", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Test User",
      });

      renderApp();

      await waitFor(() => {
        expect(screen.getByTestId("home-page")).toBeInTheDocument();
      });
    });
  });

  describe("Route Navigation", () => {
    it("renders inbox page when navigating to /receipts", async () => {
      renderApp(["/receipts"]);

      await waitFor(() => {
        expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
      });
    });

    it("renders allocations page when navigating to /allocations/:id", async () => {
      renderApp(["/allocations/123"]);

      await waitFor(() => {
        expect(screen.getByTestId("allocations-page")).toBeInTheDocument();
      });
    });

    it("renders products page when navigating to /products/:id", async () => {
      renderApp(["/products/123"]);

      await waitFor(() => {
        expect(screen.getByTestId("products-page")).toBeInTheDocument();
      });
    });

    it("renders data manager page when navigating to /data", async () => {
      renderApp(["/data"]);

      await waitFor(() => {
        expect(screen.getByTestId("data-manager-page")).toBeInTheDocument();
      });
    });

    it("renders mapping manager page when navigating to /mapping", async () => {
      renderApp(["/mapping"]);

      await waitFor(() => {
        expect(screen.getByTestId("mapping-manager-page")).toBeInTheDocument();
      });
    });

    it("renders process manager page when navigating to /tasks", async () => {
      renderApp(["/tasks"]);

      await waitFor(() => {
        expect(screen.getByTestId("process-manager-page")).toBeInTheDocument();
      });
    });

    it("renders 3D theme page when navigating to /3dtheme", async () => {
      renderApp(["/3dtheme"]);

      await waitFor(() => {
        expect(screen.getByTestId("3d-theme-page")).toBeInTheDocument();
      });
    });

    it("renders not found page for unknown routes", async () => {
      renderApp(["/unknown-route"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-found")).toBeInTheDocument();
      });
    });
  });

  describe("Error Handling", () => {
    it("has error boundary properly configured", async () => {
      renderApp();

      await waitFor(() => {
        expect(screen.getByTestId("layout")).toBeInTheDocument();
      });

      // Test that the error boundary is properly set up
      // The error boundary is configured in the renderApp function
      expect(screen.getByTestId("msal-provider")).toBeInTheDocument();
    });
  });

  describe("User Role Handling", () => {
    it("renders correctly for dev user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: true,
        isAdmin: false,
        username: "Dev User",
      });

      renderApp();

      await waitFor(() => {
        expect(screen.getByTestId("layout")).toBeInTheDocument();
      });
    });

    it("renders correctly for admin user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: true,
        username: "Admin User",
      });

      renderApp();

      await waitFor(() => {
        expect(screen.getByTestId("layout")).toBeInTheDocument();
      });
    });
  });

  describe("RequireAuth - Process Manager Routes", () => {
    it("allows access to /tasks when user has isAuthProcessManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: false,
        username: "Process Manager User",
      });

      renderApp(["/tasks"]);

      await waitFor(() => {
        expect(screen.getByTestId("process-manager-page")).toBeInTheDocument();
      });
    });

    it("redirects to not authorized when user lacks isAuthProcessManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Regular User",
      });

      renderApp(["/tasks"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-authorized")).toBeInTheDocument();
      });
    });
  });

  describe("RequireAuth - Mapping Manager Routes", () => {
    it("allows access to /mapping when user has isAuthMappingManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: true,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Mapping Manager User",
      });

      renderApp(["/mapping"]);

      await waitFor(() => {
        expect(screen.getByTestId("mapping-manager-page")).toBeInTheDocument();
      });
    });

    it("redirects to not authorized when user lacks isAuthMappingManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Regular User",
      });

      renderApp(["/mapping"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-authorized")).toBeInTheDocument();
      });
    });
  });

  describe("RequireAuth - Data Manager Routes", () => {
    it("allows access to /data when user has isAuthDataManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: true,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Data Manager User",
      });

      renderApp(["/data"]);

      await waitFor(() => {
        expect(screen.getByTestId("data-manager-page")).toBeInTheDocument();
      });
    });

    it("redirects to not authorized when user lacks isAuthDataManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Regular User",
      });

      renderApp(["/data"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-authorized")).toBeInTheDocument();
      });
    });
  });

  describe("RequireAuth - Receipts Manager Routes", () => {
    it("allows access to /receipts when user has isAuthReceiptsManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Receipts Manager User",
      });

      renderApp(["/receipts"]);

      await waitFor(() => {
        expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
      });
    });

    it("allows access to /receipts/123 when user has isAuthReceiptsManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Receipts Manager User",
      });

      renderApp(["/receipts/123"]);

      await waitFor(() => {
        expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
      });
    });

    it("allows access to /allocations/123 when user has isAuthReceiptsManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Receipts Manager User",
      });

      renderApp(["/allocations/123"]);

      await waitFor(() => {
        expect(screen.getByTestId("allocations-page")).toBeInTheDocument();
      });
    });

    it("allows access to /products/123 when user has isAuthReceiptsManager role", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Receipts Manager User",
      });

      renderApp(["/products/123"]);

      await waitFor(() => {
        expect(screen.getByTestId("products-page")).toBeInTheDocument();
      });
    });

    it("redirects to not authorized when user lacks isAuthReceiptsManager role for /receipts", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Regular User",
      });

      renderApp(["/receipts"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-authorized")).toBeInTheDocument();
      });
    });

    it("redirects to not authorized when user lacks isAuthReceiptsManager role for /allocations/123", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Regular User",
      });

      renderApp(["/allocations/123"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-authorized")).toBeInTheDocument();
      });
    });

    it("redirects to not authorized when user lacks isAuthReceiptsManager role for /products/123", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Regular User",
      });

      renderApp(["/products/123"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-authorized")).toBeInTheDocument();
      });
    });
  });

  describe("RequireAuth - Multiple Role Combinations", () => {
    it("allows access when user has multiple roles and only one is required", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: false,
        username: "Super User",
      });

      // Test that user can access any protected route
      renderApp(["/tasks"]);

      await waitFor(() => {
        expect(screen.getByTestId("process-manager-page")).toBeInTheDocument();
      });
    });

    it("allows access to different routes with different role requirements", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Limited User",
      });

      // Should be able to access receipts routes
      const { unmount: unmount1 } = renderApp(["/receipts"]);

      await waitFor(() => {
        expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
      });
      unmount1();

      // Should be able to access data routes
      const { unmount: unmount2 } = renderApp(["/data"]);

      await waitFor(() => {
        expect(screen.getByTestId("data-manager-page")).toBeInTheDocument();
      });
      unmount2();

      // Should NOT be able to access mapping routes
      const { unmount: unmount3 } = renderApp(["/mapping"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-authorized")).toBeInTheDocument();
      });
      unmount3();

      // Should NOT be able to access process manager routes
      const { unmount: unmount4 } = renderApp(["/tasks"]);

      await waitFor(() => {
        expect(screen.getByTestId("not-authorized")).toBeInTheDocument();
      });
      unmount4();
    });
  });

  describe("RequireAuth - Authentication States", () => {
    it("does not render protected content when user is not authenticated", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: null,
      });

      renderApp(["/tasks"]);

      // Should not render protected content or not-authorized, but should render home page
      await waitFor(() => {
        expect(
          screen.queryByTestId("process-manager-page")
        ).not.toBeInTheDocument();
        expect(screen.queryByTestId("not-authorized")).not.toBeInTheDocument();
        expect(screen.getByTestId("home-page")).toBeInTheDocument();
      });
    });

    it("does not render protected content when MSAL is in progress", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "login" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "Test User",
      });

      renderApp(["/tasks"]);

      // Should not render anything when MSAL is in progress
      await waitFor(() => {
        expect(
          screen.queryByTestId("process-manager-page")
        ).not.toBeInTheDocument();
        expect(screen.queryByTestId("not-authorized")).not.toBeInTheDocument();
        expect(screen.queryByTestId("home-page")).not.toBeInTheDocument();
      });
    });
  });
});
