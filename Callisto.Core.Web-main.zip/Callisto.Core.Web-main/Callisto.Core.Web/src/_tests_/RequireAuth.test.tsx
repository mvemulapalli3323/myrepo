import { render, screen } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import RequireAuth from "../components/RequireAuth";
import { useMsal } from "../hooks/useMsal";

// Mock the useMsal hook
vi.mock("../hooks/useMsal");

// Mock the NotAuthorized component
vi.mock("../components/NotAuthorized", () => ({
  default: function MockNotAuthorized() {
    return <div data-testid="not-authorized">Not Authorized</div>;
  },
}));

// Mock react-router-dom to avoid navigation issues
vi.mock("react-router-dom", () => ({
  Navigate: ({ to }: { to: string }) => (
    <div data-testid="navigate" data-to={to}>
      Navigate to {to}
    </div>
  ),
  useLocation: () => ({ pathname: "/test" }),
}));

const mockUseMsal = vi.mocked(useMsal);

describe("RequireAuth Component", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders children when user has authorized role", () => {
    mockUseMsal.mockReturnValue({
      isAuthProcessManager: true,
      isAuthReceiptsManager: false,
      isAuthDataManager: false,
      isAuthMappingManager: false,
      isDev: false,
      isAdmin: false,
      username: "testuser",
      instance: {} as any,
      inProgress: "none" as any,
    });

    render(
      <RequireAuth authorizedRoles={{ isAuthProcessManager: true }}>
        <div data-testid="protected-content">Protected Content</div>
      </RequireAuth>
    );

    expect(screen.getByTestId("protected-content")).toBeInTheDocument();
    expect(screen.queryByTestId("navigate")).not.toBeInTheDocument();
  });

  it("renders NotAuthorized component when user lacks authorized role", () => {
    mockUseMsal.mockReturnValue({
      isAuthProcessManager: false,
      isAuthReceiptsManager: false,
      isAuthDataManager: false,
      isAuthMappingManager: false,
      isDev: false,
      isAdmin: false,
      username: "testuser",
      instance: {} as any,
      inProgress: "none" as any,
    });

    render(
      <RequireAuth authorizedRoles={{ isAuthProcessManager: true }}>
        <div data-testid="protected-content">Protected Content</div>
      </RequireAuth>
    );

    expect(screen.getByTestId("navigate")).toBeInTheDocument();
    expect(screen.getByTestId("navigate")).toHaveAttribute(
      "data-to",
      "/notauthorized"
    );
    expect(screen.queryByTestId("protected-content")).not.toBeInTheDocument();
  });

  it("renders children when user has any authorized role", () => {
    mockUseMsal.mockReturnValue({
      isAuthProcessManager: true,
      isAuthReceiptsManager: false,
      isAuthDataManager: false,
      isAuthMappingManager: false,
      isDev: false,
      isAdmin: false,
      username: "testuser",
      instance: {} as any,
      inProgress: "none" as any,
    });

    render(
      <RequireAuth
        authorizedRoles={{
          isAuthProcessManager: true,
          isAuthReceiptsManager: true,
          isDev: true,
        }}
      >
        <div data-testid="admin-content">Admin Content</div>
      </RequireAuth>
    );

    expect(screen.getByTestId("admin-content")).toBeInTheDocument();
    expect(screen.queryByTestId("navigate")).not.toBeInTheDocument();
  });

  it("renders NotAuthorized component when user lacks all authorized roles", () => {
    mockUseMsal.mockReturnValue({
      isAuthProcessManager: false,
      isAuthReceiptsManager: false,
      isAuthDataManager: false,
      isAuthMappingManager: false,
      isDev: false,
      isAdmin: false,
      username: "testuser",
      instance: {} as any,
      inProgress: "none" as any,
    });

    render(
      <RequireAuth
        authorizedRoles={{
          isAuthProcessManager: true,
          isAuthReceiptsManager: true,
          isDev: true,
        }}
      >
        <div data-testid="admin-content">Admin Content</div>
      </RequireAuth>
    );

    expect(screen.getByTestId("navigate")).toBeInTheDocument();
    expect(screen.getByTestId("navigate")).toHaveAttribute(
      "data-to",
      "/notauthorized"
    );
    expect(screen.queryByTestId("admin-content")).not.toBeInTheDocument();
  });

  it("demonstrates OR logic - user needs only ONE of the authorized roles", () => {
    // User has only isAuthReceiptsManager, but authorizedRoles includes multiple roles
    mockUseMsal.mockReturnValue({
      isAuthProcessManager: false,
      isAuthReceiptsManager: true, // Only has this role
      isAuthDataManager: false,
      isAuthMappingManager: false,
      isDev: false,
      isAdmin: false,
      username: "testuser",
      instance: {} as any,
      inProgress: "none" as any,
    });

    render(
      <RequireAuth
        authorizedRoles={{
          isAuthProcessManager: true,
          isAuthReceiptsManager: true, // User has this one
          isDev: true,
        }}
      >
        <div data-testid="or-logic-content">OR Logic Content</div>
      </RequireAuth>
    );

    // Should allow access because user has isAuthReceiptsManager
    expect(screen.getByTestId("or-logic-content")).toBeInTheDocument();
    expect(screen.queryByTestId("navigate")).not.toBeInTheDocument();
  });

  it("throws error when no roles are specified", () => {
    mockUseMsal.mockReturnValue({
      isAuthProcessManager: false,
      isAuthReceiptsManager: false,
      isAuthDataManager: false,
      isAuthMappingManager: false,
      isDev: false,
      isAdmin: false,
      username: "testuser",
      instance: {} as any,
      inProgress: "none" as any,
    });

    // Suppress console.error for this test since we expect an error
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    expect(() => {
      render(
        <RequireAuth authorizedRoles={{}}>
          <div data-testid="content">Content</div>
        </RequireAuth>
      );
    }).toThrow("RequireAuth: authorizedRoles must contain at least one role");

    consoleSpy.mockRestore();
  });
});
