import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, test, expect, vi, beforeEach } from "vitest";
import { useParams } from "react-router-dom";
import EditPosition from "../components/SearchPosition/EditPosition";
import { Context } from "../Context/AppContext";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import * as productService from "../api/services/receipts-services/ProductService";
import dayjs from "dayjs";
import { AxiosResponse } from "axios";

vi.mock("@mui/x-date-pickers/DatePicker", () => ({
  DatePicker: ({ value, onChange, label }: any) => {
    let testId = "date-picker";
    if (label === "Vintage Date") {
      testId = "vintage-date-picker";
    } else if (label === "Vintage Date End") {
      testId = "vintage-date-end-picker";
    } else if (label === "Delivery Date") {
      testId = "delivery-date-picker";
    }

    return (
      <input
        data-testid={testId}
        type="date"
        value={value ? dayjs(value).format("YYYY-MM-DD") : ""}
        onChange={(e) => onChange(dayjs(e.target.value))}
      />
    );
  },
}));

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual("react-router-dom");
  return {
    ...actual,
    useParams: vi.fn(),
  };
});

vi.mock("../api/services/receipts-services/ProductService", () => ({
  getVintages: vi.fn(),
  productSelectionUpdate: vi.fn(),
}));

vi.mock("@mui/material/Autocomplete", () => ({
  __esModule: true,
  default: ({ options, value, onChange, renderInput }: any) => {
    const TextField = renderInput({
      inputProps: {
        "data-testid": "vintage-input",
        value: value?.label || "",
        onChange: (e: any) => {
          const option = options.find(
            (opt: any) => opt.label === e.target.value
          );
          onChange(null, option);
        },
      },
    });
    return (
      <div data-testid="vintage-autocomplete">
        {TextField}
        <div data-testid="vintage-options">
          {options.map((option: any) => (
            <div
              key={option.value}
              data-testid={`vintage-option-${option.value}`}
              onClick={() => onChange(null, option)}
            >
              {option.label}
            </div>
          ))}
        </div>
      </div>
    );
  },
}));

describe("EditPosition Component", () => {
  const mockSetOpen = vi.fn();
  const mockSetData = vi.fn();
  const mockParams = { id: "123" };

  const mockVintageOptions = [
    { value: 1, label: "Vintage 1" },
    { value: 2, label: "Vintage 2" },
  ];

  const mockFormData = [
    {
      id: 123,
      product: "Test Product",
      productId: "456",
      vintageId: 1,
      deliveredFlag: false,
      deliveryDateUtc: "2024-03-20",
      vintage: "2024",
    },
  ];

  const mockContext = {
    data: mockFormData,
    setOpen: mockSetOpen,
    setData: mockSetData,
    open: false,
  };

  const createMockAxiosResponse = <T,>(data: T): AxiosResponse<T> => ({
    data,
    status: 200,
    statusText: "OK",
    headers: {},
    config: {} as any,
  });

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(useParams).mockReturnValue(mockParams);
    vi.mocked(productService.getVintages).mockResolvedValue(
      createMockAxiosResponse(mockVintageOptions)
    );
    vi.mocked(productService.productSelectionUpdate).mockResolvedValue(
      createMockAxiosResponse(mockFormData)
    );
  });

  const renderComponent = () => {
    return render(
      <Context.Provider value={mockContext}>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <EditPosition />
        </LocalizationProvider>
      </Context.Provider>
    );
  };

  test("renders the component correctly", async () => {
    renderComponent();

    expect(screen.getByText("Edit Position")).toBeInTheDocument();
    expect(screen.getByLabelText("Vintage")).toBeInTheDocument();
    expect(screen.getByTestId("delivery-date-picker")).toBeInTheDocument();
    expect(screen.getByText("Delivered Flag")).toBeInTheDocument();
    expect(screen.getByText("Save")).toBeInTheDocument();
  });

  test("loads vintage options on mount", async () => {
    renderComponent();

    await waitFor(() => {
      expect(productService.getVintages).toHaveBeenCalled();
    });
  });

  test("handles delivery date selection", async () => {
    renderComponent();

    const dateInput = screen.getByTestId("delivery-date-picker");
    const testDate = "2024-03-20";

    fireEvent.change(dateInput, { target: { value: testDate } });

    await waitFor(() => {
      expect(dateInput).toHaveValue(testDate);
    });
  });

  test("handles delivered flag toggle", async () => {
    renderComponent();

    const deliveredFlagCheckbox = screen.getByLabelText("Delivered Flag");
    expect(deliveredFlagCheckbox).not.toBeChecked();

    fireEvent.click(deliveredFlagCheckbox);

    await waitFor(() => {
      expect(deliveredFlagCheckbox).toBeChecked();
    });
  });

  test("handles form submission", async () => {
    renderComponent();

    const submitButton = screen.getByText("Save");
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(productService.productSelectionUpdate).toHaveBeenCalledWith(
        expect.arrayContaining([
          expect.objectContaining({
            id: 123,
            product: "Test Product",
            productId: "456",
          }),
        ]),
        "123"
      );
      expect(mockSetData).toHaveBeenCalledWith(mockFormData);
      expect(mockSetOpen).toHaveBeenCalledWith(false);
    });
  });

  test("handles close button click", async () => {
    renderComponent();

    const closeButton = screen.getByLabelText("close");
    fireEvent.click(closeButton);

    expect(mockSetOpen).toHaveBeenCalledWith(false);
  });

  test("handles multiple product updates", async () => {
    const multipleProductsData = [
      {
        id: "123",
        product: "Product 1",
        productId: "456",
        vintageId: 1,
        deliveredFlag: false,
        deliveryDateUtc: "2024-03-20",
        vintage: "2024",
      },
      {
        id: "124",
        product: "Product 2",
        productId: "457",
        vintageId: 2,
        deliveredFlag: true,
        deliveryDateUtc: "2024-03-21",
        vintage: "2024",
      },
    ];

    render(
      <Context.Provider value={{ ...mockContext, data: multipleProductsData }}>
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <EditPosition />
        </LocalizationProvider>
      </Context.Provider>
    );

    const submitButton = screen.getByText("Save");
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(productService.productSelectionUpdate).toHaveBeenCalledWith(
        expect.arrayContaining([
          expect.objectContaining({
            id: "123",
            product: "Product 1",
          }),
          expect.objectContaining({
            id: "124",
            product: "Product 2",
          }),
        ]),
        "123"
      );
    });
  });

  test("handles API error gracefully", async () => {
    vi.mocked(productService.getVintages).mockRejectedValue(
      new Error("API Error")
    );
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    renderComponent();

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalled();
    });

    consoleSpy.mockRestore();
  });
});
