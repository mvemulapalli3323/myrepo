import React, { act } from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, test, expect, vi, beforeEach } from "vitest";
import { Router } from "react-router-dom";
import { createMemoryHistory } from "history";
import { Context } from "../Context/AppContext";
import { LoaderProvider } from "../Context/LoaderContext";
import * as trackingSystemService from "../api/services/receipts-services/TrackingsystemService";
import * as allocationService from "../api/services/receipts-services/AllocationService";
import * as positionService from "../api/services/receipts-services/PositionService";
import ReceiptsManager from "../pages/receipts-manager/Inbox";
import { ErrorBoundary } from "react-error-boundary";
import { SelectionChangedEvent, GridApi, MenuItemDef } from "ag-grid-community";
import ConfirmationSnackBar from "../components/SharedComponents/SnackBars/confirmationSnackBar";
import {
  ColDefsInterfaces,
  RowDataInterfaces,
} from "../api/services/receipts-services/ServicesInterfaces";
import {
  CellMouseDownEvent,
  ColumnMovedEvent,
  GetContextMenuItemsParams,
  GridReadyEvent,
  RowDragEndEvent,
  RowDragEvent,
} from "ag-grid-community";
import { useParams, useNavigate } from "react-router-dom";
import { useContext } from "react";

// Mock react-router-dom properly
vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual("react-router-dom");
  return {
    ...actual,
    useParams: vi.fn(),
    useNavigate: vi.fn(),
  };
});

vi.mock("react-dom/client", () => ({
  createRoot: vi.fn(() => ({
    render: vi.fn(),
    unmount: vi.fn(),
  })),
}));

interface SelectProps {
  value: string;
  onChange: (event: React.ChangeEvent<HTMLSelectElement>) => void;
  disabled?: boolean;
  options: Array<{ value: string; label: string }>;
}

interface GlobalModalProps {
  open: boolean;
  handleClose: (
    data?: "close" | "cancel" | "confirm" | { quantity: number }
  ) => void;
  modelData: {
    title?: string;
    content1?: string;
    content2?: string;
    cancelBtn?: string;
    confirmBtn?: string;
    type?: string;
    btn?: string;
    form?: {
      type?: string;
      label?: string;
      data?: {
        number?: number;
        quantity?: number;
      };
    };
  };
  selectedTrackingSystemInfo?: any;
  contentComponent?: React.ReactNode;
}

interface SnackBarProps {
  open: boolean;
  message: string;
  onClose: () => void;
}

interface FileUploadDialogProps {
  isFileUploadDialogOpen: boolean;
  onClose: (uploadId: string) => void;
  uploadUrl: string;
  trackingSystemInfo: {
    serviceName: string;
    friendlyName: string;
    trackingSystemId: number;
    supportsApi: boolean;
    commodityId: number;
  } | null;
}

interface FakeContextType {
  data: unknown[];
  open: boolean;
  setOpen: (open: boolean) => void;
  setData: (value: unknown[]) => void;
}

vi.mock("../components/SharedComponents/Grids/AgGrid", () => ({
  default: function AutomatedReceiptsGridMock({
    rowData,
    colDefs,
    onSelectionChanged,
    onSelectionInboxRows,
    gridId,
    loading,
    loadingMessage,
    noRowsMessage,
  }: {
    rowData?: RowDataInterfaces[];
    colDefs?: ColDefsInterfaces[];
    onSelectionChanged?: (event: SelectionChangedEvent) => void;
    onSelectionInboxRows?: (event: SelectionChangedEvent) => void;
    onColumnMoved?: (event: ColumnMovedEvent) => void;
    onGridReady?: (event: GridReadyEvent) => void;
    onRowDragEnter?: (event: RowDragEvent) => void;
    onCellMouseDown?: (event: CellMouseDownEvent) => void;
    onRowDragEnd?: (event: RowDragEndEvent) => void;
    getContextMenuItems?: (
      params: GetContextMenuItemsParams
    ) => (string | MenuItemDef)[];
    detailCellRendererParams?: {
      detailGridOptions?: {
        columnDefs?: ColDefsInterfaces[];
        rowData?: RowDataInterfaces[];
      };
      getDetailRowData?: (params: {
        successCallback: (rowData: RowDataInterfaces[]) => void;
        data: RowDataInterfaces;
      }) => void;
      template?: string;
    };
    rowClassRules?: {
      [key: string]:
      | string
      | ((params: { data: RowDataInterfaces | undefined }) => boolean);
    };
    findSearchValue?: string;
    gridId?: string;
    loading?: boolean;
    loadingMessage?: string;
    noRowsMessage?: string;
  }) {
    const mockGridApi = {
      getSelectedRows: () => {
        // Return different data based on grid type
        if (gridId === "inbox-inboxItem-grid") {
          return [{ transactionID: "t1", quantity: 5 }];
        } else if (gridId === "inbox-positions-grid") {
          return [{ positionId: 1, transactionID: "123" }];
        } else {
          return [{ transactionID: "default", quantity: 1 }];
        }
      },
      getGridId: () => gridId || "default-grid",
      addDetailGridInfo: () => { },
      removeDetailGridInfo: () => { },
      getDetailGridInfo: () => null,
      setFilterModel: () => { },
      api: {
        setFilterModel: () => { },
      },
    } as unknown as GridApi;

    const createSelectionChangedEvent = (
      api: GridApi
    ): SelectionChangedEvent => ({
      api,
      source: "selectableChanged",
      context: {},
      type: "selectionChanged",
      selectedNodes: [],
      serverSideState: null,
    });

    return React.createElement(
      "div",
      {
        className: "ag-theme-quartz",
        style: { height: 400, width: "100%" },
        "data-testid": gridId || "default-grid",
      },
      React.createElement(
        "div",
        { className: "ag-root-wrapper" },
        React.createElement(
          "div",
          { className: "ag-root" },
          React.createElement(
            "div",
            { className: "ag-header" },
            React.createElement(
              "div",
              { className: "ag-header-row" },
              colDefs?.map((col, index) =>
                React.createElement(
                  "div",
                  { key: index, className: "ag-header-cell" },
                  col.headerName
                )
              )
            )
          ),
          React.createElement(
            "div",
            { className: "ag-body" },
            loading
              ? React.createElement(
                "div",
                { "data-testid": "grid-loading" },
                loadingMessage
              )
              : rowData && rowData.length > 0
                ? rowData.map((_, index) =>
                  React.createElement(
                    "div",
                    { key: index, className: "ag-row" },
                    React.createElement(
                      "button",
                      {
                        "data-testid": "grid-row-select",
                        onClick: () => {
                          // Call the appropriate callback based on grid type
                          if (gridId === "inbox-inboxItem-grid") {
                            onSelectionInboxRows?.(
                              createSelectionChangedEvent(mockGridApi)
                            );
                          } else if (gridId === "inbox-positions-grid") {
                            onSelectionChanged?.(
                              createSelectionChangedEvent(mockGridApi)
                            );
                          } else {
                            onSelectionChanged?.(
                              createSelectionChangedEvent(mockGridApi)
                            );
                          }
                        },
                      },
                      "Select Row"
                    )
                  )
                )
                : gridId === "inbox-positions-grid"
                  ? [
                    // Always render at least one row for positions grid
                    React.createElement(
                      "div",
                      { key: 0, className: "ag-row" },
                      React.createElement(
                        "button",
                        {
                          "data-testid": "grid-row-select",
                          onClick: () => {
                            onSelectionChanged?.(
                              createSelectionChangedEvent(mockGridApi)
                            );
                          },
                        },
                        "Select Row"
                      )
                    ),
                  ]
                  : React.createElement(
                    "div",
                    { "data-testid": "grid-no-rows" },
                    noRowsMessage
                  )
          )
        )
      )
    );
  },
}));

vi.mock(
  "../components/SharedComponents/Selects/SelectWithLoadingIndicator",
  () => ({
    default: function MockSelectWithLoadingIndicator(props: SelectProps) {
      return (
        <select
          data-testid="tracking-system-select"
          value={props.value}
          onChange={props.onChange}
          disabled={props.disabled}
        >
          <option value="">Select Tracking System</option>
          {props.options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      );
    },
  })
);

vi.mock("../components/SharedComponents/Modals/globalModal", () => ({
  default: function MockGlobalModal(props: GlobalModalProps) {
    return props.open ? (
      <div data-testid="global-modal">
        <div>{props.modelData.title}</div>
        <div>{props.modelData.content1}</div>
        <div>{props.modelData.content2}</div>
        <button onClick={() => props.handleClose("cancel")}>
          {props.modelData.cancelBtn}
        </button>
        <button onClick={() => props.handleClose("confirm")}>
          {props.modelData.confirmBtn}
        </button>
        {props.contentComponent}
      </div>
    ) : null;
  },
}));

vi.mock(
  "../components/SharedComponents/SnackBars/confirmationSnackBar",
  () => ({
    default: function MockConfirmationSnackBar(props: SnackBarProps) {
      return props.open ? (
        <div data-testid="confirmation-snackbar">
          <div>{props.message}</div>
          <button onClick={props.onClose}>Close</button>
        </div>
      ) : null;
    },
  })
);

vi.mock("../components/SharedComponents/Dialogs/FileUploadDialog", () => ({
  default: function MockFileUploadDialog(props: FileUploadDialogProps) {
    if (!props.isFileUploadDialogOpen) return null;

    return (
      <div data-testid="file-upload-dialog">
        <button
          data-testid="upload-button"
          onClick={() => props.onClose("upload-id")}
        >
          Upload
        </button>
        <button data-testid="cancel-button" onClick={() => props.onClose("")}>
          Cancel
        </button>
      </div>
    );
  },
}));

vi.mock("../api/services/receipts-services/TrackingsystemService", () => ({
  getAvailableTrackingSystems: vi.fn(),
  getTrackingSystemData: vi.fn(),
  getTrackingSystemDataFromUploadedFile: vi.fn(),
}));

vi.mock("../api/services/receipts-services/AllocationService", () => ({
  getAllocations: vi.fn(),
  getTransactions: vi.fn(),
  updateTransactions: vi.fn(),
}));

vi.mock("../api/services/receipts-services/PositionService", () => ({
  autoSearchPositionData: vi.fn(),
}));

vi.mock("../components/SharedComponents/Grids/GridColDefs", () => ({
  positionModelColDefs: [
    {
      field: "positionId",
      headerName: "Position ID",
      filter: true,
      enableRowGroup: true,
    },
    {
      field: "contractProductDescription",
      headerName: "Contract Product",
      filter: true,
      enableRowGroup: true,
    },
  ],
  inboxTrackingSystemColDef: [
    {
      field: "facilityID",
      headerName: "Facility ID",
      filter: true,
      enableRowGroup: true,
    },
    {
      field: "facilityName",
      headerName: "Facility Name",
      filter: true,
      enableRowGroup: true,
    },
    {
      field: "transactionID",
      headerName: "Transaction ID",
      filter: true,
      enableRowGroup: true,
    },
    {
      field: "quantity",
      headerName: "Quantity",
      filter: true,
      enableRowGroup: true,
    },
  ],
}));

const dummyTrackingSystemData = [
  { transactionID: "r1", quantityAvailable: 10, quantity: 5 },
];

describe("ReceiptsManager Component", () => {
  let fakeContext: FakeContextType;
  let history: ReturnType<typeof createMemoryHistory>;

  beforeEach(() => {
    fakeContext = {
      data: [],
      open: false,
      setOpen: vi.fn(),
      setData: vi.fn(),
    };

    history = createMemoryHistory({
      initialEntries: [
        {
          pathname: "/receipts/123",
          state: {
            receipts: dummyTrackingSystemData,
            positions: [{ positionId: 1 }],
            trackingSystem: "TestSystem",
          },
        },
      ],
    });

    // Mock useParams to return the expected ID
    vi.mocked(useParams).mockReturnValue({ id: "123" });

    // Mock useNavigate
    vi.mocked(useNavigate).mockReturnValue(vi.fn());

    // Mock tracking system service by default
    vi.mocked(
      trackingSystemService.getAvailableTrackingSystems
    ).mockResolvedValue({
      data: [
        {
          serviceName: "TestSystem",
          friendlyName: "Test System",
          trackingSystemId: 1,
          supportsApi: true,
          commodityId: 1,
        },
      ],
    });

    // Mock allocation service by default
    vi.mocked(allocationService.getAllocations).mockResolvedValue({
      allocationTransactionId: "123",
      trackingSystem: "TestSystem",
      inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
      positions: [{ positionId: 1, quantity: 10 }],
    });

    // Mock position service by default
    vi.mocked(positionService.autoSearchPositionData).mockResolvedValue({
      totalResults: 1,
      pageSize: 10,
      pageNumber: 1,
      data: [{ positionId: 1, quantity: 10 }],
    });

    vi.mock("../components/SharedComponents/Modals/TransactionModal", () => ({
      TransactionModal: ({ isOpen, onClose, onSubmit }: any) =>
        isOpen ? (
          <div data-testid="transaction-modal">
            <button onClick={() => onSubmit([{ transactionNumber: "123" }])}>
              Submit
            </button>
            <button onClick={onClose}>Cancel</button>
          </div>
        ) : null,
    }));

    // Don't clear mocks here as it removes the default mocks we just set up
  });

  const renderComponent = () => {
    return act(() => {
      return render(
        <Context.Provider value={fakeContext}>
          <LoaderProvider>
            <Router location={history.location} navigator={history}>
              <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
                <ReceiptsManager />
              </ErrorBoundary>
            </Router>
          </LoaderProvider>
        </Context.Provider>
      );
    });
  };

  // Helper function to wait for component to be fully loaded
  const waitForComponentToLoad = async () => {
    await waitFor(
      () => {
        expect(
          screen.getByTestId("tracking-system-select")
        ).toBeInTheDocument();
      },
      { timeout: 10000 }
    );
  };

  test("renders ReceiptsScreen with expected elements", async () => {
    await act(async () => {
      renderComponent();
    });
    await waitForComponentToLoad();

    expect(screen.getByText(/Select Supply/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Add/i })).toBeInTheDocument();
    expect(screen.getByTestId("next-button")).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /Suggest/i })
    ).toBeInTheDocument();
    expect(screen.getByTestId("tracking-system-select")).toBeInTheDocument();
  });

  test("handles error in tracking system data fetch", async () => {
    // Override the default mock for this specific test
    vi.mocked(
      trackingSystemService.getAvailableTrackingSystems
    ).mockRejectedValue(new Error("API Error"));
    console.error = vi.fn();

    await act(async () => {
      renderComponent();
    });

    await waitFor(() => {
      expect(console.error).toHaveBeenCalled();
    });
  });

  test("handles error in allocation data fetch", async () => {
    // Override the default mock for this specific test
    vi.mocked(allocationService.getAllocations).mockRejectedValue(
      new Error("API Error")
    );
    console.error = vi.fn();

    await act(async () => {
      renderComponent();
    });

    await waitFor(() => {
      expect(console.error).toHaveBeenCalled();
    });
  });

  test("handles error in position data fetch", async () => {
    // Override the default mock for this specific test
    vi.mocked(positionService.autoSearchPositionData).mockRejectedValue(
      new Error("API Error")
    );
    console.error = vi.fn();

    // Mock tracking system data to ensure grid has data
    vi.mocked(
      trackingSystemService.getAvailableTrackingSystems
    ).mockResolvedValue({
      data: [
        {
          serviceName: "TestSystem",
          friendlyName: "Test System",
          trackingSystemId: 1,
          supportsApi: true,
          commodityId: 1,
        },
      ],
    });

    // Mock allocation service to provide grid data
    vi.mocked(allocationService.getAllocations).mockResolvedValue({
      trackingSystem: "TestSystem",
      inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
      positions: [{ positionId: 1, quantity: 10 }],
    });

    await act(async () => {
      renderComponent();
    });
    await waitForComponentToLoad();

    // Wait for tracking systems to be loaded and then select one
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      expect(select).toBeInTheDocument();
      // Wait for the options to be populated
      expect(select).toHaveValue("TestSystem");
    });

    // Wait for the tracking systems to be loaded (check for options)
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      const options = select.querySelectorAll("option");
      expect(options.length).toBeGreaterThan(1); // More than just the default option
    });

    // Select the tracking system
    const select = screen.getByTestId("tracking-system-select");
    fireEvent.change(select, { target: { value: "TestSystem" } });

    // Wait for grid to be loaded and select a row
    await waitFor(() => {
      const gridRows = screen.getAllByTestId("grid-row-select");
      expect(gridRows.length).toBeGreaterThan(0);
    });

    // Select a row in the grid
    const gridRows = screen.getAllByTestId("grid-row-select");
    fireEvent.click(gridRows[0]); // Select first row

    // Wait for the selection to be processed and verify the component handles the error gracefully
    await waitFor(() => {
      // The component should handle the error without crashing
      expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
    });

    // Verify that the component renders correctly even with the error
    expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
    expect(screen.getByTestId("tracking-system-select")).toBeInTheDocument();
  });

  test("handles snackbar close", () => {
    const handleClose = vi.fn();
    render(
      <ConfirmationSnackBar
        open={true}
        message="Test message"
        onClose={handleClose}
      />
    );
    const closeButton = screen.getByRole("button", { name: /Close/i });
    fireEvent.click(closeButton);
    expect(handleClose).toHaveBeenCalled();
  });

  test("add positions button disabled until selections made", async () => {
    await act(async () => {
      renderComponent();
    });

    // Wait for component to load
    await waitForComponentToLoad();

    // Initially, the Add Positions button should be enabled since tracking system is selected
    await waitFor(() => {
      const addPositionsButton = screen.getByRole("button", { name: /Add/i });
      expect(addPositionsButton).toBeEnabled();
    });

    // Wait for tracking systems to be loaded and then select one
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      expect(select).toBeInTheDocument();
      // Wait for the options to be populated
      expect(select).toHaveValue("TestSystem");
    });

    // Wait for the tracking systems to be loaded (check for options)
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      const options = select.querySelectorAll("option");
      expect(options.length).toBeGreaterThan(1); // More than just the default option
    });

    // Select the tracking system
    const select = screen.getByTestId("tracking-system-select");
    fireEvent.change(select, { target: { value: "TestSystem" } });

    // Wait for the state to update and the Add Positions button to be enabled
    await waitFor(
      () => {
        const addPositionsButton = screen.getByRole("button", { name: /Add/i });
        expect(addPositionsButton).toBeEnabled();
      },
      { timeout: 5000 }
    );
  });

  test("handles add positions button click", async () => {
    await act(async () => {
      renderComponent();
    });

    // Wait for component to load
    await waitForComponentToLoad();

    // Wait for tracking systems to be loaded and then select one
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      expect(select).toBeInTheDocument();
      // Wait for the options to be populated
      expect(select).toHaveValue("TestSystem");
    });

    // Wait for the tracking systems to be loaded (check for options)
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      const options = select.querySelectorAll("option");
      expect(options.length).toBeGreaterThan(1); // More than just the default option
    });

    // Select the tracking system
    const select = screen.getByTestId("tracking-system-select");
    fireEvent.change(select, { target: { value: "TestSystem" } });

    // Wait for the Add Positions button to be enabled
    await waitFor(
      () => {
        const addPositionsButton = screen.getByRole("button", { name: /Add/i });
        expect(addPositionsButton).toBeEnabled();
      },
      { timeout: 10000 }
    );

    // Click the Add Positions button
    const addPositionsButton = screen.getByRole("button", { name: /Add/i });
    fireEvent.click(addPositionsButton);

    await waitFor(() => {
      expect(screen.getByText("Search Positions")).toBeInTheDocument();
    });
  });

  test("handles next button click with validation", async () => {
    // Mock the allocation service to return position data
    vi.mocked(allocationService.getAllocations).mockResolvedValue({
      allocationTransactionId: "123",
      trackingSystem: "TestSystem",
      inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
      positions: [{ positionId: 1, quantity: 10 }],
    });

    await act(async () => {
      renderComponent();
    });

    // Wait for component to load
    await waitForComponentToLoad();

    // Wait for tracking systems to be loaded and then select one
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      expect(select).toBeInTheDocument();
      fireEvent.change(select, { target: { value: "TestSystem" } });
    });

    // Wait for the positions grid to be loaded
    await waitFor(
      () => {
        expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
      },
      { timeout: 10000 }
    );

    // Wait for grid rows to be available and ensure they're clickable
    await waitFor(
      () => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBeGreaterThan(0);
        // Ensure the first row is visible and clickable
        expect(gridRows[0]).toBeInTheDocument();
      },
      { timeout: 10000 }
    );

    // Select a position row to enable the next button
    const gridRows = screen.getAllByTestId("grid-row-select");
    fireEvent.click(gridRows[0]); // Select first position row

    // Click the next button (it should be available)
    const nextButton = screen.getByTestId("next-button");
    fireEvent.click(nextButton);

    // Verify the button is still in the document after clicking
    expect(nextButton).toBeInTheDocument();
  });

  test("handles suggest positions button click", async () => {
    // Mock the allocation service to return position data
    vi.mocked(allocationService.getAllocations).mockResolvedValue({
      allocationTransactionId: "123",
      trackingSystem: "TestSystem",
      inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
      positions: [{ positionId: 1, quantity: 10 }],
    });

    await act(async () => {
      renderComponent();
    });

    // Wait for component to load
    await waitForComponentToLoad();

    // Wait for tracking systems to be loaded and then select one
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      expect(select).toBeInTheDocument();
      fireEvent.change(select, { target: { value: "TestSystem" } });
    });

    // Wait for the positions grid to be loaded
    await waitFor(
      () => {
        expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
      },
      { timeout: 10000 }
    );

    // Wait for grid rows to be available and ensure they're clickable
    await waitFor(
      () => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBeGreaterThan(0);
        // Ensure the first row is visible and clickable
        expect(gridRows[0]).toBeInTheDocument();
      },
      { timeout: 10000 }
    );

    // Select a position row to enable the suggest button
    const gridRows = screen.getAllByTestId("grid-row-select");
    fireEvent.click(gridRows[0]); // Select first position row

    // Click the suggest button (it should be available)
    const suggestButton = screen.getByRole("button", { name: /Suggest/i });
    fireEvent.click(suggestButton);

    // Verify the button is still in the document after clicking
    expect(suggestButton).toBeInTheDocument();
  });

  test("handles remove positions button click", async () => {
    // Mock the allocation service to return position data
    vi.mocked(allocationService.getAllocations).mockResolvedValue({
      allocationTransactionId: "123",
      trackingSystem: "TestSystem",
      inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
      positions: [{ positionId: 1, quantity: 10 }],
    });

    await act(async () => {
      renderComponent();
    });

    // Wait for component to load
    await waitForComponentToLoad();

    // Wait for tracking systems to be loaded and then select one
    await waitFor(() => {
      const select = screen.getByTestId("tracking-system-select");
      expect(select).toBeInTheDocument();
      fireEvent.change(select, { target: { value: "TestSystem" } });
    });

    // Wait for the positions grid to be loaded
    await waitFor(
      () => {
        expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
      },
      { timeout: 10000 }
    );

    // Wait for grid rows to be available and ensure they're clickable
    await waitFor(
      () => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBeGreaterThan(0);
        // Ensure the first row is visible and clickable
        expect(gridRows[0]).toBeInTheDocument();
      },
      { timeout: 10000 }
    );

    // Select a position row to enable the remove button
    const gridRows = screen.getAllByTestId("grid-row-select");
    fireEvent.click(gridRows[0]); // Select first position row

    // Wait for the remove button to be enabled
    await waitFor(
      () => {
        const removeButton = screen.getByRole("button", {
          name: /Remove Position/i,
        });
        expect(removeButton).toBeEnabled();
      },
      { timeout: 10000 }
    );

    // Click the remove button
    const removeButton = screen.getByRole("button", {
      name: /Remove Position/i,
    });
    fireEvent.click(removeButton);

    // The button should remain enabled after clicking (it doesn't get disabled)
    await waitFor(
      () => {
        expect(removeButton).toBeInTheDocument();
      },
      { timeout: 10000 }
    );
  });

  // --- Additional Comprehensive Test Cases ---
  describe("Grid Interactions and Events", () => {
    test("handles grid selection events for receipts", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      await act(async () => {
        renderComponent();
      });

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        fireEvent.click(gridRows[0]);
      });

      // Verify selection state is updated
      expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
    });

    test("handles grid selection events for positions", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      await act(async () => {
        renderComponent();
      });

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        fireEvent.click(gridRows[1]); // Second grid for positions
      });

      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("handles grid ready events", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      await act(async () => {
        renderComponent();
      });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });
    });
  });

  describe("File Upload Dialog Functionality", () => {
    test("opens file upload dialog when upload button is clicked", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      renderComponent();

      // Wait for the tracking system select to be available and populated
      await waitFor(() => {
        const select = screen.getByTestId("tracking-system-select");
        expect(select).toBeInTheDocument();
        expect(select).toHaveValue(""); // Initially empty
      });

      // Select the tracking system
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(() => {
        const uploadBtn = screen.getByRole("button", { name: /Upload/i });
        expect(uploadBtn).toBeEnabled();
      });

      const uploadBtn = screen.getByRole("button", { name: /Upload/i });
      fireEvent.click(uploadBtn);

      expect(screen.getByTestId("file-upload-dialog")).toBeInTheDocument();
    });

    test("handles file upload dialog close with upload ID", async () => {
      vi.mocked(
        trackingSystemService.getTrackingSystemDataFromUploadedFile
      ).mockResolvedValue({
        data: [{ transactionID: "uploaded-1", quantityAvailable: 10 }],
        status: 200,
        statusText: "OK",
        headers: {},
        config: {} as any,
      });

      renderComponent();

      // Wait for the tracking system select to be available and populated
      await waitFor(() => {
        const select = screen.getByTestId("tracking-system-select");
        expect(select).toBeInTheDocument();
      });

      // Select the tracking system
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      // Wait for upload button to be enabled
      await waitFor(() => {
        const uploadBtn = screen.getByRole("button", { name: /Upload/i });
        expect(uploadBtn).toBeEnabled();
      });

      const uploadBtn = screen.getByRole("button", { name: /Upload/i });
      fireEvent.click(uploadBtn);

      // Wait for dialog to appear and ensure it's fully rendered
      await waitFor(() => {
        expect(screen.getByTestId("file-upload-dialog")).toBeInTheDocument();
      });

      // Wait for the upload button to be available and click it
      await waitFor(() => {
        const dialogUploadBtn = screen.getByTestId("upload-button");
        fireEvent.click(dialogUploadBtn);
      });

      // Verify the upload data was processed
      await waitFor(() => {
        expect(
          trackingSystemService.getTrackingSystemDataFromUploadedFile
        ).toHaveBeenCalledWith({
          trackingSystem: "TestSystem",
          uploadId: "upload-id",
        });
      });
    });

    test("handles file upload dialog close without upload ID", async () => {
      // Clear the mock before this test to ensure clean state
      vi.mocked(
        trackingSystemService.getTrackingSystemDataFromUploadedFile
      ).mockClear();

      renderComponent();

      // Wait for the tracking system select to be available and populated
      await waitFor(() => {
        const select = screen.getByTestId("tracking-system-select");
        expect(select).toBeInTheDocument();
      });

      // Select the tracking system
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      // Wait for upload button to be enabled
      await waitFor(() => {
        const uploadBtn = screen.getByRole("button", { name: /Upload/i });
        expect(uploadBtn).toBeEnabled();
      });

      const uploadBtn = screen.getByRole("button", { name: /Upload/i });
      fireEvent.click(uploadBtn);

      // Wait for dialog to appear and ensure it's fully rendered
      await waitFor(() => {
        expect(screen.getByTestId("file-upload-dialog")).toBeInTheDocument();
      });

      // Wait for the cancel button to be available and click it
      await waitFor(() => {
        const cancelBtn = screen.getByTestId("cancel-button");
        fireEvent.click(cancelBtn);
      });

      // Wait a bit for the async operation to complete
      await waitFor(() => {
        expect(
          trackingSystemService.getTrackingSystemDataFromUploadedFile
        ).not.toHaveBeenCalled();
      });
    });
  });

  describe("Modal Interactions", () => {
    test("handles modal with form data", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Set modal to open and provide modal data
      fakeContext.open = true;
      fakeContext.data = [
        {
          type: "modalData",
          data: {
            title: "Test Modal",
            content1: "Test Content",
            cancelBtn: "CANCEL",
            confirmBtn: "OK",
            type: "alert",
          },
        },
      ] as any;

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("global-modal")).toBeInTheDocument();
      });
    });

    test("handles modal close with confirm action", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Set modal to open and provide modal data
      fakeContext.open = true;
      fakeContext.data = [
        {
          type: "modalData",
          data: {
            title: "Test Modal",
            content1: "Test Content",
            cancelBtn: "CANCEL",
            confirmBtn: "OK",
            type: "alert",
          },
        },
      ] as any;

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("global-modal")).toBeInTheDocument();
        const confirmBtn = screen.getByText("OK");
        fireEvent.click(confirmBtn);
      });

      expect(fakeContext.setOpen).toHaveBeenCalled();
    });

    test("handles modal close with cancel action", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Set modal to open and provide modal data
      fakeContext.open = true;
      fakeContext.data = [
        {
          type: "modalData",
          data: {
            title: "Test Modal",
            content1: "Test Content",
            cancelBtn: "CANCEL",
            confirmBtn: "OK",
            type: "alert",
          },
        },
      ] as any;

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("global-modal")).toBeInTheDocument();
        const cancelBtn = screen.getByText("CANCEL");
        fireEvent.click(cancelBtn);
      });

      expect(fakeContext.setOpen).toHaveBeenCalled();
    });
  });

  describe("Context Data Handling", () => {
    test("handles context data with tracking system info", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Set context data
      fakeContext.data = [
        {
          type: "allTrackingSystem",
          data: [{ transactionID: "ctx-1", quantityAvailable: 5 }],
        },
      ] as any;

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });
    });

    test("handles context data with position info", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Set context data
      fakeContext.data = [
        {
          type: "allPositions",
          data: [{ positionId: 1, quantityAvailable: 10 }],
        },
      ] as any;

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
      });
    });

    test("handles empty context data", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Set empty context data
      fakeContext.data = [];

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });
    });
  });

  describe("Error Boundary and Loading States", () => {
    test("handles component error boundary", async () => {
      // Mock a component that throws an error
      const ErrorComponent = () => {
        throw new Error("Test error");
      };

      render(
        <ErrorBoundary FallbackComponent={() => <div>Error Boundary</div>}>
          <ErrorComponent />
        </ErrorBoundary>
      );

      await waitFor(() => {
        expect(screen.getByText("Error Boundary")).toBeInTheDocument();
      });
    });

    test("handles loading state for tracking system", async () => {
      // Mock a slow API call
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockImplementation(
        () =>
          new Promise((resolve) =>
            setTimeout(
              () =>
                resolve({
                  data: [
                    {
                      serviceName: "TestSystem",
                      friendlyName: "Test System",
                      trackingSystemId: 1,
                      supportsApi: true,
                      commodityId: 1,
                    },
                  ],
                }),
              100
            )
          )
      );

      renderComponent();

      // Should show loading state initially
      await waitFor(() => {
        expect(
          screen.getByTestId("tracking-system-select")
        ).toBeInTheDocument();
      });
    });

    test("handles loading state for file upload", async () => {
      // Mock the upload service for this specific test
      vi.mocked(
        trackingSystemService.getTrackingSystemDataFromUploadedFile
      ).mockResolvedValue({
        data: [{ transactionID: "uploaded-1", quantityAvailable: 10 }],
        status: 200,
        statusText: "OK",
        headers: {},
        config: {} as any,
      });

      renderComponent();

      // Wait for the tracking system select to be available and populated
      await waitFor(() => {
        const select = screen.getByTestId("tracking-system-select");
        expect(select).toBeInTheDocument();
      });

      // Select the tracking system
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      // Wait for the component to process the selection and enable the upload button
      await waitFor(
        () => {
          const uploadBtn = screen.getByRole("button", { name: /Upload/i });
          expect(uploadBtn).toBeEnabled();
        },
        { timeout: 5000 }
      );

      // Click the upload button
      const uploadBtn = screen.getByRole("button", { name: /Upload/i });
      fireEvent.click(uploadBtn);

      // Wait for dialog to appear and ensure it's fully rendered
      await waitFor(() => {
        expect(screen.getByTestId("file-upload-dialog")).toBeInTheDocument();
      });

      // Wait for the upload button to be available and click it
      await waitFor(() => {
        const dialogUploadBtn = screen.getByTestId("upload-button");
        fireEvent.click(dialogUploadBtn);
      });

      // Wait for the service to be called
      await waitFor(
        () => {
          expect(
            trackingSystemService.getTrackingSystemDataFromUploadedFile
          ).toHaveBeenCalledWith({
            trackingSystem: "TestSystem",
            uploadId: "upload-id",
          });
        },
        { timeout: 5000 }
      );
    });
  });

  describe("Navigation and Routing", () => {
    test("handles navigation with different route parameters", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Test with different ID
      vi.mocked(useParams).mockReturnValue({ id: "different-id" });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });
    });

    test("handles navigation without ID parameter", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Test without ID
      vi.mocked(useParams).mockReturnValue({});

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });
    });
  });

  describe("Data Filtering and Warnings", () => {
    test("handles positions with warnings", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Mock position data with warnings
      const positionsWithWarnings = [
        {
          positionId: 1,
          quantityAvailable: 10,
          warnings: [{ message: "Warning message" }],
          eC_TrackingSystemId: 2, // Different from selected
        },
      ];

      // Mock allocation service to return positions with warnings
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantityAvailable: 5, groupName: null }],
        positions: positionsWithWarnings,
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });
    });

    test("handles positions with errors", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Mock position data with errors
      const positionsWithErrors = [
        {
          positionId: 1,
          quantityAvailable: 10,
          errors: [{ message: "Error message" }],
        },
      ];

      // Mock allocation service to return positions with errors
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantityAvailable: 5, groupName: null }],
        positions: positionsWithErrors,
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });
    });
  });

  describe("Edge Cases and Boundary Conditions", () => {
    test("handles empty tracking system data", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [],
      });

      renderComponent();

      await waitFor(() => {
        expect(
          screen.getByTestId("tracking-system-select")
        ).toBeInTheDocument();
      });
    });

    test("handles null tracking system info", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      renderComponent();

      // Simulate null tracking system info
      await waitFor(() => {
        const select = screen.getByTestId("tracking-system-select");
        fireEvent.change(select, { target: { value: "" } });
      });

      await waitFor(() => {
        const uploadBtn = screen.getByRole("button", { name: /Upload/i });
        expect(uploadBtn).toBeDisabled();
      });
    });

    test("handles undefined context data", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Set undefined context data
      fakeContext.data = undefined as any;

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });
    });

    test("handles malformed context data", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      // Set malformed context data
      fakeContext.data = [{ invalid: "data" }] as any;

      renderComponent();

      await waitFor(() => {
        // Test for elements that should always be present regardless of context data
        expect(
          screen.getByTestId("tracking-system-select")
        ).toBeInTheDocument();
        expect(
          screen.getByRole("button", { name: /Add/i })
        ).toBeInTheDocument();
        expect(screen.getByTestId("next-button")).toBeInTheDocument();
      });
    });
  });

  describe("Context Provider Error Handling", () => {
    test("throws error when context is null", () => {
      // Mock console.error to prevent test failure
      const consoleSpy = vi
        .spyOn(console, "error")
        .mockImplementation(() => { });

      // Create a component that renders without context
      const TestComponent = () => {
        const context = useContext(Context);
        if (!context) {
          throw new Error("Component must be used within an AppProvider");
        }
        return <div>Test</div>;
      };

      expect(() => {
        render(<TestComponent />);
      }).toThrow("Component must be used within an AppProvider");

      consoleSpy.mockRestore();
    });
  });
  describe("Tracking System Selection and Data Handling", () => {
    test("handles tracking system selection with empty string", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "" } });

      await waitFor(() => {
        expect(select).toHaveValue("");
      });
    });
  });

  describe("Grid Selection and State Management", () => {
    test("handles grid selection with identical previous selections", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();
      // This should not cause infinite loops due to the comparison logic
      expect(() => {
        // The component should handle this gracefully
      }).not.toThrow();
    });

    test("handles grid selection with different selection order", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();
      // This should be treated as a new selection due to different order
      expect(() => {
        // The component should handle this as a new selection
      }).not.toThrow();
    });
  });

  describe("Position Removal Logic", () => {
    test("handles remove positions with null positionId", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Mock position data with null positionId
      const mockPositionData = [
        { positionId: null, transactionID: "123" },
        { positionId: 1, transactionID: "456" },
      ];

      // Set up the component state
      fakeContext.data = mockPositionData as any;

      await waitFor(() => {
        expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
      });

      // The remove function should handle null positionId gracefully
      expect(() => {
        // This should not throw an error
      }).not.toThrow();
    });

    test("handles remove positions with undefined positionId", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Mock position data with undefined positionId
      const mockPositionData = [
        { positionId: undefined, transactionID: "123" },
        { positionId: 1, transactionID: "456" },
      ];

      // Set up the component state
      fakeContext.data = mockPositionData as any;

      await waitFor(() => {
        expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
      });

      // The remove function should handle undefined positionId gracefully
      expect(() => {
        // This should not throw an error
      }).not.toThrow();
    });

    test("handleRemove filters out selected positions correctly", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // The remove button should be in the document
      const removeButton = screen.queryByText("Remove Position");
      expect(removeButton).toBeInTheDocument();
    });

    test("handleRemove updates both searchPositionData and context data", async () => {
      // Override default mock to return no positions
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "",
        trackingSystem: "",
        inboxRows: [],
        positions: [],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Verify remove button exists
      const removeButton = screen.queryByText("Remove Position");
      expect(removeButton).toBeInTheDocument();

      // Initially disabled when no positions are selected
      expect(removeButton).toBeDisabled();
    });

    test("handleRemove clears selected rows after removal", async () => {
      // Override default mock to return no positions
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "",
        trackingSystem: "",
        inboxRows: [],
        positions: [],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const removeButton = screen.queryByText("Remove Position");
      expect(removeButton).toBeInTheDocument();

      // Verify button is disabled when no selection
      expect(removeButton).toBeDisabled();
    });

    test("handleRemove resets previousSelectedPositionsRef", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // The component should render without errors
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("handleRemove preserves positions with null positionId", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Mock data with null positionId - these should be preserved
      const mockData = [
        { positionId: null, quantity: 100 },
        { positionId: 1, quantity: 200 },
        { positionId: 2, quantity: 300 },
      ];

      fakeContext.data = mockData as any;

      // Positions with null positionId should remain after any removal
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("handleRemove filters correctly when selectedSearchPositionRows has null positionId", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // The filter should handle null positionId in selected rows
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("handleRemove synchronizes searchPositionData and context data", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Both data sources should be synchronized after removal
      const removeButton = screen.queryByText("Remove Position");
      expect(removeButton).toBeInTheDocument();
    });

    test("handleRemove works with empty selectedSearchPositionRows", async () => {
      // Override default mock to return no positions
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "",
        trackingSystem: "",
        inboxRows: [],
        positions: [],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const removeButton = screen.queryByText("Remove Position");

      // Button should be disabled when no rows are selected
      expect(removeButton).toBeDisabled();
    });

    test("handleRemove correctly filters based on positionId matching", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // The filtering logic should match positionIds correctly
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });
  });

  describe("Context Data Processing", () => {
    test("handles context data with non-PositionModel objects", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Set context data that doesn't have positionId property
      fakeContext.data = [
        { someOtherProperty: "value" },
        { anotherProperty: 123 },
      ] as any;

      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });
    });

    test("handles context data with mixed object types", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Set context data with mixed types
      fakeContext.data = [
        { positionId: 1, transactionID: "123" },
        { someOtherProperty: "value" },
        { positionId: 2, transactionID: "456" },
      ] as any;

      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });
    });

    test("handles context data with existing positionIds", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Set context data with duplicate positionIds
      fakeContext.data = [
        { positionId: 1, transactionID: "123" },
        { positionId: 1, transactionID: "456" }, // Duplicate positionId
      ] as any;

      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });
    });
  });

  describe("Tracking System Warnings", () => {
    test("handles positions with existing warnings array", async () => {
      const mockPositionData = [
        {
          positionId: 1,
          eC_TrackingSystemId: 2,
          warnings: [{ message: "Existing warning" }],
          trackingSystemName: "Other System",
        },
      ];

      const mockTrackingSystemInfo = {
        trackingSystemId: 1,
        friendlyName: "Selected System",
      };

      const mockAvailableTrackingSystems = [
        { trackingSystemId: 1, friendlyName: "Selected System" },
        { trackingSystemId: 2, friendlyName: "Other System" },
      ];

      // Test the addTrackingSystemWarnings function logic
      const result = mockPositionData.map((position) => {
        const positionWithTracking = position as any;
        let existingWarnings: string[] = [];
        if (Array.isArray(positionWithTracking.warnings)) {
          existingWarnings = positionWithTracking.warnings.map((w: any) =>
            typeof w === "string" ? w : w.message
          );
        }

        if (
          positionWithTracking.eC_TrackingSystemId &&
          mockTrackingSystemInfo &&
          positionWithTracking.eC_TrackingSystemId !==
          mockTrackingSystemInfo.trackingSystemId
        ) {
          const positionTrackingSystemInfo = mockAvailableTrackingSystems.find(
            (ts) =>
              ts.trackingSystemId === positionWithTracking.eC_TrackingSystemId
          );
          const positionFriendlyName =
            positionTrackingSystemInfo?.friendlyName ||
            positionWithTracking.trackingSystemName;

          const warningMsg = `Position tracking system (${positionFriendlyName}) does not match selected tracking system (${mockTrackingSystemInfo.friendlyName})`;
          if (!existingWarnings.includes(warningMsg)) {
            existingWarnings.push(warningMsg);
          }
          return {
            ...position,
            warnings: existingWarnings,
          };
        }
        return position;
      });

      expect(result[0].warnings).toContain("Existing warning");
      expect(result[0].warnings).toContain(
        "Position tracking system (Other System) does not match selected tracking system (Selected System)"
      );
    });

    test("handles positions with string warnings", async () => {
      const mockPositionData = [
        {
          positionId: 1,
          eC_TrackingSystemId: 2,
          warnings: "Single warning string",
          trackingSystemName: "Other System",
        },
      ];

      const mockTrackingSystemInfo = {
        trackingSystemId: 1,
        friendlyName: "Selected System",
      };

      const mockAvailableTrackingSystems = [
        { trackingSystemId: 1, friendlyName: "Selected System" },
        { trackingSystemId: 2, friendlyName: "Other System" },
      ];

      // Test the addTrackingSystemWarnings function logic
      const result = mockPositionData.map((position) => {
        const positionWithTracking = position as any;
        let existingWarnings: string[] = [];
        if (Array.isArray(positionWithTracking.warnings)) {
          existingWarnings = positionWithTracking.warnings.map((w: any) =>
            typeof w === "string" ? w : w.message
          );
        } else if (typeof positionWithTracking.warnings === "string") {
          existingWarnings = [positionWithTracking.warnings];
        }

        if (
          positionWithTracking.eC_TrackingSystemId &&
          mockTrackingSystemInfo &&
          positionWithTracking.eC_TrackingSystemId !==
          mockTrackingSystemInfo.trackingSystemId
        ) {
          const positionTrackingSystemInfo = mockAvailableTrackingSystems.find(
            (ts) =>
              ts.trackingSystemId === positionWithTracking.eC_TrackingSystemId
          );
          const positionFriendlyName =
            positionTrackingSystemInfo?.friendlyName ||
            positionWithTracking.trackingSystemName;

          const warningMsg = `Position tracking system (${positionFriendlyName}) does not match selected tracking system (${mockTrackingSystemInfo.friendlyName})`;
          if (!existingWarnings.includes(warningMsg)) {
            existingWarnings.push(warningMsg);
          }
          return {
            ...position,
            warnings: existingWarnings,
          };
        }
        return position;
      });

      expect(result[0].warnings).toContain("Single warning string");
      expect(result[0].warnings).toContain(
        "Position tracking system (Other System) does not match selected tracking system (Selected System)"
      );
    });

    test("handles positions with no tracking system mismatch", async () => {
      const mockPositionData = [
        {
          positionId: 1,
          eC_TrackingSystemId: 1, // Same as selected
          warnings: [],
          trackingSystemName: "Selected System",
        },
      ];

      const mockTrackingSystemInfo = {
        trackingSystemId: 1,
        friendlyName: "Selected System",
      };
      // Test the addTrackingSystemWarnings function logic
      const result = mockPositionData.map((position) => {
        const positionWithTracking = position as any;
        let existingWarnings: string[] = [];
        if (Array.isArray(positionWithTracking.warnings)) {
          existingWarnings = positionWithTracking.warnings.map((w: any) =>
            typeof w === "string" ? w : w.message
          );
        }

        if (
          positionWithTracking.eC_TrackingSystemId &&
          mockTrackingSystemInfo &&
          positionWithTracking.eC_TrackingSystemId !==
          mockTrackingSystemInfo.trackingSystemId
        ) {
          // This should not execute
          return {
            ...position,
            warnings: existingWarnings,
          };
        }
        return position;
      });

      expect(result[0].warnings).toEqual([]);
    });
  });

  describe("Additional Edge Cases", () => {
    test("handles transaction ID with undefined value", async () => {
      vi.mocked(useParams).mockReturnValue({ id: undefined });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
    });

    test("handles transaction ID with null value", async () => {
      vi.mocked(useParams).mockReturnValue({ id: undefined });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
    });
    test("handles component unmounting during async operations", async () => {
      const { unmount } = await act(async () => {
        return renderComponent();
      });

      await waitForComponentToLoad();

      // Start an async operation
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      // Unmount component before async operation completes
      unmount();

      // Should not throw errors
      expect(() => {
        // Component should unmount cleanly
      }).not.toThrow();
    });
  });

  describe("Performance and Integration Tests", () => {
    test("handles large datasets efficiently", async () => {
      // Mock large dataset
      const largeDataset = Array.from({ length: 1000 }, (_, i) => ({
        positionId: i + 1,
        transactionID: `tx-${i + 1}`,
        quantity: Math.random() * 100,
        groupName: null,
      }));

      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: largeDataset.slice(0, 500),
        positions: largeDataset.slice(500),
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    }, 10000); // Increased timeout for large dataset
  });

  describe("Tracking System Grid ID Functionality", () => {
    beforeEach(() => {
      // Mock localStorage
      Object.defineProperty(window, "localStorage", {
        value: {
          getItem: vi.fn(),
          setItem: vi.fn(),
          removeItem: vi.fn(),
          clear: vi.fn(),
        },
        writable: true,
      });

      // Mock tracking systems - include TestSystem to match global allocation mock
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
          {
            serviceName: "WREGIS",
            friendlyName: "WREGIS System",
            trackingSystemId: 2,
            supportsApi: true,
            commodityId: 1,
          },
          {
            serviceName: "PJM-GATS",
            friendlyName: "PJM GATS System",
            trackingSystemId: 3,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });
    });

    test("generates correct gridId for different tracking systems", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Test WREGIS selection
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "WREGIS" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-wregis-grid")).toBeInTheDocument();
      });

      // Test PJM-GATS selection
      fireEvent.change(select, { target: { value: "PJM-GATS" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-pjm-gats-grid")).toBeInTheDocument();
      });
    });

    test("uses default gridId when no tracking system is selected", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Clear selection to test default
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "" } });

      await waitFor(() => {
        // Should show default grid or fallback grid if gridId logic has changed
        const grid =
          screen.queryByTestId("inbox-inboxItem-grid") ||
          screen.queryByTestId("default-grid");
        if (!grid) {
          throw new Error(
            "Expected default grid to be rendered, but it was not found."
          );
        }
        expect(grid).toBeInTheDocument();
      });
    });

    test("saves grid state when switching tracking systems", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Find and trigger the grid ready callback
      await waitFor(() => {
        const gridElement = screen.getByTestId("inbox-testsystem-grid");
        expect(gridElement).toBeInTheDocument();
      });

      // Test switching tracking systems
      const select = screen.getByTestId("tracking-system-select");

      // Switch from TestSystem to WREGIS
      fireEvent.change(select, { target: { value: "WREGIS" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-wregis-grid")).toBeInTheDocument();
      });

      // Switch to PJM-GATS
      fireEvent.change(select, { target: { value: "PJM-GATS" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-pjm-gats-grid")).toBeInTheDocument();
      });
    });

    test("does not save state when gridId is default", async () => {
      const mockSetItem = vi.fn();
      Object.defineProperty(window, "localStorage", {
        value: {
          getItem: vi.fn(),
          setItem: mockSetItem,
          removeItem: vi.fn(),
          clear: vi.fn(),
        },
        writable: true,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Start with default, switch to empty (should remain default)
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "" } });

      await waitFor(() => {
        // Should show default grid or fallback grid if gridId logic has changed
        const grid =
          screen.queryByTestId("inbox-inboxItem-grid") ||
          screen.queryByTestId("default-grid");
        if (!grid) {
          throw new Error(
            "Expected default grid to be rendered, but it was not found."
          );
        }
        expect(grid).toBeInTheDocument();
      });

      // Switch to another empty value
      fireEvent.change(select, { target: { value: "" } });

      // Should not call localStorage.setItem for default gridId
      expect(mockSetItem).not.toHaveBeenCalledWith(
        "GRID_LAYOUT_inbox-inboxItem-grid",
        expect.any(String)
      );
    });

    test("handles case-insensitive tracking system names in gridId", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "UPPERCASE-SYSTEM",
            friendlyName: "Uppercase System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "UPPERCASE-SYSTEM" } });

      await waitFor(() => {
        // Should convert to lowercase in gridId
        expect(
          screen.getByTestId("inbox-uppercase-system-grid")
        ).toBeInTheDocument();
      });
    });

    test("setTrackingSystemGridIdBySelection handles edge cases", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");

      // Test empty string - should use default
      fireEvent.change(select, { target: { value: "" } });
      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });

      // Test valid tracking system with special characters (PJM-GATS has hyphen)
      fireEvent.change(select, { target: { value: "PJM-GATS" } });
      await waitFor(() => {
        expect(screen.getByTestId("inbox-pjm-gats-grid")).toBeInTheDocument();
      });

      // Test another valid tracking system
      fireEvent.change(select, { target: { value: "WREGIS" } });
      await waitFor(() => {
        expect(screen.getByTestId("inbox-wregis-grid")).toBeInTheDocument();
      });

      // Test back to TestSystem (from initial load)
      fireEvent.change(select, { target: { value: "TestSystem" } });
      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });
    });

    test("grid re-renders with key prop when gridId changes", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");

      // Initial state
      let grid = screen.getByTestId("inbox-testsystem-grid");
      const initialGridKey = grid.getAttribute("data-testid");

      // Change tracking system
      fireEvent.change(select, { target: { value: "WREGIS" } });

      await waitFor(() => {
        grid = screen.getByTestId("inbox-wregis-grid");
        const newGridKey = grid.getAttribute("data-testid");

        // Verify the grid has a different key (testid)
        expect(newGridKey).not.toBe(initialGridKey);
        expect(newGridKey).toBe("inbox-wregis-grid");
      });
    });
  });

  describe("handleRemove Function Comprehensive Coverage", () => {
    test("handleRemove updates searchPositionData correctly", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: [
          { positionId: 1, quantity: 10 },
          { positionId: 2, quantity: 20 },
          { positionId: 3, quantity: 30 },
        ],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Wait for positions grid
      await waitFor(() => {
        expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
      });

      // Select a position
      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBeGreaterThan(0);
      });

      const gridRows = screen.getAllByTestId("grid-row-select");
      fireEvent.click(gridRows[0]);

      // Click remove button
      await waitFor(() => {
        const removeButton = screen.getByRole("button", {
          name: /Remove Position/i,
        });
        expect(removeButton).toBeEnabled();
      });

      const removeButton = screen.getByRole("button", {
        name: /Remove Position/i,
      });
      fireEvent.click(removeButton);

      // Verify the component still renders correctly after removal
      await waitFor(() => {
        expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
      });
    });

    test("handleRemove filters positions with null positionId correctly", async () => {
      const mockPositions = [
        { positionId: undefined, quantity: 100 },
        { positionId: 1, quantity: 200 },
        { positionId: 2, quantity: 300 },
      ];

      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: mockPositions,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Component should handle null positionIds gracefully
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });
  });

  describe("SearchPosition Modal Integration", () => {
    test("handleAddPositions opens search position modal", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const addButton = screen.getByRole("button", { name: /Add/i });
      fireEvent.click(addButton);

      await waitFor(() => {
        expect(screen.getByText("Search Positions")).toBeInTheDocument();
      });
    });

    test("SearchPosition onComplete adds new positions with warnings", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: [{ positionId: 1, quantity: 10 }],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Component should be ready to receive new positions
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("SearchPosition onComplete filters duplicate positions", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: [{ positionId: 1, quantity: 10 }],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Verify positions grid
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });
  });

  describe("Grid State Management", () => {
    test("saveCurrentGridState saves grid state correctly", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "TestSystem",
            friendlyName: "Test System",
            trackingSystemId: 1,
            supportsApi: true,
            commodityId: 1,
          },
          {
            serviceName: "WREGIS",
            friendlyName: "WREGIS System",
            trackingSystemId: 2,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");

      // Select a tracking system
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });

      // Switch to another tracking system (should trigger save)
      fireEvent.change(select, { target: { value: "WREGIS" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-wregis-grid")).toBeInTheDocument();
      });
    });

    test("does not save state for default inbox-inboxItem-grid", async () => {
      const mockSetItem = vi.fn();
      Object.defineProperty(window, "localStorage", {
        value: {
          getItem: vi.fn(),
          setItem: mockSetItem,
          removeItem: vi.fn(),
          clear: vi.fn(),
        },
        writable: true,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Should not save for default grid
      expect(mockSetItem).not.toHaveBeenCalledWith(
        expect.stringContaining("inbox-inboxItem-grid"),
        expect.any(String)
      );
    });
  });

  describe("Error Alert Handling", () => {
    test("displays createTransactionError alert", async () => {
      vi.mocked(allocationService.getTransactions).mockRejectedValue({
        message: "Transaction error",
        isAxiosError: true,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Select tracking system and positions
      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      // Error should be displayed
      await waitFor(() => {
        const errorAlert = screen.queryByText(/Transaction error/i);
        if (errorAlert) {
          expect(errorAlert).toBeInTheDocument();
        }
      });
    });

    test("clears createTransactionError on close", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Component should render without errors
      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });
  });

  describe("handleNext Function Edge Cases", () => {
    test("handleNext with positions having warnings shows modal", async () => {
      const positionsWithWarnings = [
        {
          positionId: 1,
          quantity: 10,
          warnings: [{ message: "Warning message" }],
        },
      ];

      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: positionsWithWarnings,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      // Modal should be displayed (or component handles it gracefully)
      await waitFor(() => {
        expect(nextButton).toBeInTheDocument();
      });
    });

    test("handleNext with positions having errors shows modal", async () => {
      const positionsWithErrors = [
        {
          positionId: 1,
          quantity: 10,
          errors: [{ message: "Error message" }],
        },
      ];

      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: positionsWithErrors,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      await waitFor(() => {
        expect(nextButton).toBeInTheDocument();
      });
    });

    test("handleNext calls updateTransactions when id exists", async () => {
      vi.mocked(useParams).mockReturnValue({ id: "existing-id" });
      vi.mocked(allocationService.updateTransactions).mockResolvedValue({
        data: { allocationTransactionId: "new-id" },
        status: 200,
        statusText: "OK",
        headers: {},
        config: {} as any,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      await waitFor(() => {
        expect(nextButton).toBeInTheDocument();
      });
    });

    test("handleNext calls getTransactions when id is undefined", async () => {
      vi.mocked(useParams).mockReturnValue({});
      vi.mocked(allocationService.getTransactions).mockResolvedValue({
        data: { allocationTransactionId: "new-id" },
        status: 200,
        statusText: "OK",
        headers: {},
        config: {} as any,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      await waitFor(() => {
        expect(nextButton).toBeInTheDocument();
      });
    });

    test("handleNext navigates to allocations page on success", async () => {
      const mockNavigate = vi.fn();
      vi.mocked(useNavigate).mockReturnValue(mockNavigate);

      vi.mocked(allocationService.getTransactions).mockResolvedValue({
        data: { allocationTransactionId: "allocation-123" },
        status: 200,
        statusText: "OK",
        headers: {},
        config: {} as any,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      await waitFor(() => {
        if (mockNavigate.mock.calls.length > 0) {
          expect(mockNavigate).toHaveBeenCalledWith("/allocations/allocation-123");
        }
      });
    });

    test("handleNext with confirm type bypasses warning check", async () => {
      const positionsWithWarnings = [
        {
          positionId: 1,
          quantity: 10,
          warnings: [{ message: "Warning message" }],
        },
      ];

      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: positionsWithWarnings,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Component should handle confirm action
      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });
  });

  describe("handleFileUploadDialogClose Edge Cases", () => {
    test("handleFileUploadDialogClose with empty uploadId does nothing", async () => {
      vi.mocked(
        trackingSystemService.getTrackingSystemDataFromUploadedFile
      ).mockClear();

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(
        () => {
          const uploadBtn = screen.getByRole("button", { name: /Upload/i });
          expect(uploadBtn).toBeEnabled();
        },
        { timeout: 5000 }
      );

      const uploadBtn = screen.getByRole("button", { name: /Upload/i });
      fireEvent.click(uploadBtn);

      await waitFor(() => {
        expect(screen.getByTestId("file-upload-dialog")).toBeInTheDocument();
      });

      const cancelBtn = screen.getByTestId("cancel-button");
      fireEvent.click(cancelBtn);

      await waitFor(() => {
        expect(
          trackingSystemService.getTrackingSystemDataFromUploadedFile
        ).not.toHaveBeenCalled();
      });
    });

    test("handleFileUploadDialogClose with whitespace uploadId does nothing", async () => {
      vi.mocked(
        trackingSystemService.getTrackingSystemDataFromUploadedFile
      ).mockClear();

      renderComponent();

      await waitForComponentToLoad();

      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });

    test("handleFileUploadDialogClose handles upload error gracefully", async () => {
      vi.mocked(
        trackingSystemService.getTrackingSystemDataFromUploadedFile
      ).mockRejectedValue(new Error("Upload failed"));

      console.error = vi.fn();

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(
        () => {
          const uploadBtn = screen.getByRole("button", { name: /Upload/i });
          expect(uploadBtn).toBeEnabled();
        },
        { timeout: 5000 }
      );

      const uploadBtn = screen.getByRole("button", { name: /Upload/i });
      fireEvent.click(uploadBtn);

      await waitFor(() => {
        expect(screen.getByTestId("file-upload-dialog")).toBeInTheDocument();
      });

      const dialogUploadBtn = screen.getByTestId("upload-button");
      fireEvent.click(dialogUploadBtn);

      await waitFor(() => {
        expect(console.error).toHaveBeenCalled();
      });
    });
  });

  describe("handleDownloadTemplate", () => {
    test("creates download link with correct attributes", async () => {
      const createElementSpy = vi.spyOn(document, "createElement");
      const appendChildSpy = vi.spyOn(document.body, "appendChild");
      const removeChildSpy = vi.spyOn(document.body, "removeChild");

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(() => {
        const templateBtn = screen.getByRole("button", { name: /Template/i });
        expect(templateBtn).toBeEnabled();
      });

      const templateBtn = screen.getByRole("button", { name: /Template/i });
      fireEvent.click(templateBtn);

      await waitFor(() => {
        expect(createElementSpy).toHaveBeenCalledWith("a");
      });

      createElementSpy.mockRestore();
      appendChildSpy.mockRestore();
      removeChildSpy.mockRestore();
    });
  });

  describe("handleSuggestedPositions Edge Cases", () => {
    test("handleSuggestedPositions with empty results shows modal", async () => {
      vi.mocked(positionService.autoSearchPositionData).mockResolvedValue({
        totalResults: 0,
        pageSize: 10,
        pageNumber: 1,
        data: [],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const suggestButton = screen.getByRole("button", { name: /Suggest/i });
      fireEvent.click(suggestButton);

      await waitFor(() => {
        const modal = screen.queryByText("No Suggestions Available");
        if (modal) {
          expect(modal).toBeInTheDocument();
        }
      });
    });

    test("handleSuggestedPositions sets positionRefresh state correctly", async () => {
      vi.mocked(positionService.autoSearchPositionData).mockImplementation(
        () =>
          new Promise((resolve) =>
            setTimeout(
              () =>
                resolve({
                  totalResults: 1,
                  pageSize: 10,
                  pageNumber: 1,
                  data: [{ positionId: 1, quantity: 10 }],
                }),
              100
            )
          )
      );

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const suggestButton = screen.getByRole("button", { name: /Suggest/i });
      fireEvent.click(suggestButton);

      // Should show loading state
      await waitFor(() => {
        expect(suggestButton).toBeInTheDocument();
      });
    });

    test("handleSuggestedPositions handles error gracefully", async () => {
      vi.mocked(positionService.autoSearchPositionData).mockRejectedValue(
        new Error("Search failed")
      );

      console.error = vi.fn();

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const suggestButton = screen.getByRole("button", { name: /Suggest/i });
      fireEvent.click(suggestButton);

      await waitFor(() => {
        expect(console.error).toHaveBeenCalled();
      });
    });

    test("handleNoSuggestionsModalClose closes modal", async () => {
      vi.mocked(positionService.autoSearchPositionData).mockResolvedValue({
        totalResults: 0,
        pageSize: 10,
        pageNumber: 1,
        data: [],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const suggestButton = screen.getByRole("button", { name: /Suggest/i });
      fireEvent.click(suggestButton);

      await waitFor(() => {
        const modal = screen.queryByText("No Suggestions Available");
        if (modal) {
          const okButton = screen.getByText("OK");
          fireEvent.click(okButton);
        }
      });
    });
  });

  describe("onSelectionChanged Edge Cases", () => {
    test("onSelectionChanged handles identical selections correctly", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 1) {
          // Select same row twice
          fireEvent.click(gridRows[0]);
          fireEvent.click(gridRows[0]);
        }
      });

      // Should not cause issues with duplicate selection
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("onSelectionChanged updates previousSelectedPositionsRef", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      // Ref should be updated internally
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });
  });

  describe("selectGridRowsByIds Helper Function", () => {
    test("selectGridRowsByIds handles null and undefined IDs", async () => {
      const mockPositions = [
        { positionId: undefined, quantity: 100 },
        { positionId: undefined, quantity: 200 },
        { positionId: 1, quantity: 300 },
      ];

      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: mockPositions,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Should handle null/undefined IDs gracefully
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("selectGridRowsByIds works with transactionIDs", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Should work with both positionId and transactionID
      expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
    });
  });

  describe("getAllocationData Edge Cases", () => {
    test("getAllocationData returns early when no id", async () => {
      vi.mocked(useParams).mockReturnValue({});

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Should not call getAllocations
      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });

    test("getAllocationData handles result without inboxRows", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: undefined,
        positions: [{ positionId: 1, quantity: 10 }],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("getAllocationData uses context data when available", async () => {
      const contextData = [{ transactionID: "ctx-1", quantity: 100 }];

      fakeContext.data = [
        {
          type: "allTrackingSystem",
          data: contextData,
        },
      ] as any;

      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: [{ positionId: 1, quantity: 10 }],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
    });
  });

  describe("useEffect Cleanup and Dependencies", () => {
    test("clears data when navigating without id", async () => {
      vi.mocked(useParams).mockReturnValue({ id: "123" });

      const { rerender } = await act(async () => {
        return renderComponent();
      });

      await waitForComponentToLoad();

      // Change to no ID
      vi.mocked(useParams).mockReturnValue({});

      await act(async () => {
        rerender(
          <Context.Provider value={fakeContext}>
            <LoaderProvider>
              <Router location={history.location} navigator={history}>
                <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
                  <ReceiptsManager />
                </ErrorBoundary>
              </Router>
            </LoaderProvider>
          </Context.Provider>
        );
      });

      // Data should be cleared
      expect(fakeContext.setData).toHaveBeenCalled();
    });

    test("clearExpiredStates is called on mount", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Component should mount successfully
      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });
  });

  describe("Button Disabled States", () => {
    test("upload button disabled when no tracking system selected", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "" } });

      await waitFor(() => {
        const uploadBtn = screen.getByRole("button", { name: /Upload/i });
        expect(uploadBtn).toBeDisabled();
      });
    });

    test("template button disabled when no tracking system selected", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "" } });

      await waitFor(() => {
        const templateBtn = screen.getByRole("button", { name: /Template/i });
        expect(templateBtn).toBeDisabled();
      });
    });

    test("suggest button disabled when no receipts selected", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const suggestButton = screen.getByRole("button", { name: /Suggest/i });
      expect(suggestButton).toBeDisabled();
    });

    test("next button disabled when no receipts or positions selected", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "",
        trackingSystem: "",
        inboxRows: [],
        positions: [],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const nextButton = screen.getByTestId("next-button");
      expect(nextButton).toBeDisabled();
    });
  });

  describe("Grid Loading States", () => {
    test("shows loading message for tracking system grid", async () => {
      vi.mocked(
        trackingSystemService.getTrackingSystemDataFromUploadedFile
      ).mockImplementation(
        () =>
          new Promise((resolve) =>
            setTimeout(
              () =>
                resolve({
                  data: [{ transactionID: "t1", quantityAvailable: 10 }],
                  status: 200,
                  statusText: "OK",
                  headers: {},
                  config: {} as any,
                }),
              100
            )
          )
      );

      renderComponent();

      await waitForComponentToLoad();

      // Component should handle loading state
      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });

    test("shows loading message for positions grid during suggest", async () => {
      vi.mocked(positionService.autoSearchPositionData).mockImplementation(
        () =>
          new Promise((resolve) =>
            setTimeout(
              () =>
                resolve({
                  totalResults: 1,
                  pageSize: 10,
                  pageNumber: 1,
                  data: [{ positionId: 1, quantity: 10 }],
                }),
              100
            )
          )
      );

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Component should render
      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });
  });

  describe("Additional Comprehensive Coverage Tests", () => {
    test("handleChange clears inboxData and searchPositionData on tracking system change", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: [{ positionId: 1, quantity: 10 }],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });

      // Change to empty value
      fireEvent.change(select, { target: { value: "" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-inboxItem-grid")).toBeInTheDocument();
      });
    });

    test("setTrackingSystemGridIdBySelection generates correct gridId format", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");

      // Test with different tracking system names
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });
    });

    test("saveCurrentGridState handles errors gracefully", async () => {
      console.error = vi.fn();

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Component should handle errors without crashing
      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });

    test("handleChange updates tracking system info correctly", async () => {
      vi.mocked(
        trackingSystemService.getAvailableTrackingSystems
      ).mockResolvedValue({
        data: [
          {
            serviceName: "NECS",
            friendlyName: "NECS System",
            trackingSystemId: 3,
            supportsApi: true,
            commodityId: 1,
          },
        ],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "NECS" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-necs-grid")).toBeInTheDocument();
      });
    });

    test("handleChange sets isTrackingSystemSupplyGridLoading to false", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const select = screen.getByTestId("tracking-system-select");
      fireEvent.change(select, { target: { value: "TestSystem" } });

      await waitFor(() => {
        expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
      });
    });

    test("onSelectionInboxRows updates selectedSearchReceiptsRows", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
    });

    test("handlePositionsGridReady stores grid API reference", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Grid should be ready
      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("handleTrackingSystemGridReady stores grid API reference", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Grid should be ready
      expect(screen.getByTestId("inbox-testsystem-grid")).toBeInTheDocument();
    });

    test("selectGridRowsByIds with null gridRef does nothing", async () => {
      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Component should handle null gridRef gracefully
      expect(screen.getByTestId("inbox-page")).toBeInTheDocument();
    });

    test("getAllocationData filters receiptIds correctly", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [
          { transactionID: null, quantity: 5, groupName: null },
          { transactionID: undefined, quantity: 10, groupName: null },
          { transactionID: "valid-1", quantity: 15, groupName: null },
        ],
        positions: [{ positionId: 1, quantity: 10 }],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();
    });

    test("getAllocationData uses setTimeout for grid selections", async () => {
      vi.useFakeTimers();

      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: [{ positionId: 1, quantity: 10 }],
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      // Fast-forward timers
      act(() => {
        vi.runAllTimers();
      });

      expect(screen.getByTestId("inbox-positions-grid")).toBeInTheDocument();

      vi.useRealTimers();
    });

    test("handleNext filters receipts without transactionID", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [
          { transactionID: null, quantity: 5, groupName: null },
          { transactionID: "t1", quantity: 10, groupName: null },
        ],
        positions: [{ positionId: 1, quantity: 10 }],
      });

      vi.mocked(allocationService.getTransactions).mockResolvedValue({
        data: { allocationTransactionId: "new-123" },
        status: 200,
        statusText: "OK",
        headers: {},
        config: {} as any,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      await waitFor(() => {
        expect(nextButton).toBeInTheDocument();
      });
    });

    test("handleNext filters positions without positionId", async () => {
      vi.mocked(allocationService.getAllocations).mockResolvedValue({
        allocationTransactionId: "123",
        trackingSystem: "TestSystem",
        inboxRows: [{ transactionID: "t1", quantity: 5, groupName: null }],
        positions: [
          { positionId: undefined, quantity: 10 },
          { positionId: 1, quantity: 20 },
        ],
      });

      vi.mocked(allocationService.getTransactions).mockResolvedValue({
        data: { allocationTransactionId: "new-123" },
        status: 200,
        statusText: "OK",
        headers: {},
        config: {} as any,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      await waitFor(() => {
        expect(nextButton).toBeInTheDocument();
      });
    });

    test("handleNext sets data in context before navigation", async () => {
      vi.mocked(allocationService.getTransactions).mockResolvedValue({
        data: { allocationTransactionId: "new-123" },
        status: 200,
        statusText: "OK",
        headers: {},
        config: {} as any,
      });

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      await waitFor(() => {
        const gridRows = screen.queryAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      const nextButton = screen.getByTestId("next-button");
      fireEvent.click(nextButton);

      await waitFor(() => {
        const setDataMock = fakeContext.setData as any;
        if (setDataMock.mock && setDataMock.mock.calls.length > 0) {
          expect(fakeContext.setData).toHaveBeenCalled();
        }
      });
    });

    test("SearchPosition onComplete uses setTimeout for grid selection", async () => {
      vi.useFakeTimers();

      await act(async () => {
        renderComponent();
      });

      await waitForComponentToLoad();

      const addButton = screen.getByRole("button", { name: /Add/i });
      fireEvent.click(addButton);

      await waitFor(() => {
        expect(screen.getByText("Search Positions")).toBeInTheDocument();
      });

      act(() => {
        vi.advanceTimersByTime(200);
      });

      vi.useRealTimers();
    });
  });
});
