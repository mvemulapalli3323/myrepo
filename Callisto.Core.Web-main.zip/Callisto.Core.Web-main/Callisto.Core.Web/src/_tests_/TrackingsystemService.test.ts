import { describe, expect, vi, beforeEach, test } from "vitest";
import "@testing-library/jest-dom";
import * as TrackingsystemService from "../api/services/receipts-services/TrackingsystemService";
import { TrackingSystemData } from "../api/services/receipts-services/ServicesInterfaces";
import { AxiosResponse } from "axios";

vi.mock("../api/services/receipts-services/TrackingsystemService", () => ({
  getAvailableTrackingSystems: vi.fn(),
  getTrackingSystemData: vi.fn(),
  getTrackingSystemDataFromUploadedFile: vi.fn(),
}));

const createMockAxiosResponse = <T>(data: T): AxiosResponse<T> => ({
  data,
  status: 200,
  statusText: "OK",
  headers: {},
  config: {} as any,
});

describe("TrackingsystemService", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  test("should get available tracking systems successfully", async () => {
    const mockResponse = { data: [] };
    vi.mocked(TrackingsystemService.getAvailableTrackingSystems).mockResolvedValueOnce(
      mockResponse,
    );

    const result = await TrackingsystemService.getAvailableTrackingSystems();
    expect(result).toEqual(mockResponse);
    expect(TrackingsystemService.getAvailableTrackingSystems).toHaveBeenCalled();
  });

  test("should handle errors when getting available tracking systems", async () => {
    const mockError = new Error("API Error");
    vi.mocked(TrackingsystemService.getAvailableTrackingSystems).mockRejectedValueOnce(
      mockError,
    );

    await expect(TrackingsystemService.getAvailableTrackingSystems()).rejects.toThrow(
      "API Error",
    );
    expect(TrackingsystemService.getAvailableTrackingSystems).toHaveBeenCalled();
  });

  test("should get tracking system data successfully", async () => {
    const mockParams: TrackingSystemData = {
      trackingSystem: "system1",
    };
    const mockResponse = createMockAxiosResponse({ data: [] });
    vi.mocked(
      TrackingsystemService.getTrackingSystemData,
    ).mockResolvedValueOnce(mockResponse);

    const result =
      await TrackingsystemService.getTrackingSystemData(mockParams);
    expect(result).toEqual(mockResponse);
    expect(TrackingsystemService.getTrackingSystemData).toHaveBeenCalledWith(
      mockParams,
    );
  });

  test("should handle errors when getting tracking system data", async () => {
    const mockParams: TrackingSystemData = {
      trackingSystem: "system1",
    };
    const mockError = new Error("API Error");
    vi.mocked(
      TrackingsystemService.getTrackingSystemData,
    ).mockRejectedValueOnce(mockError);

    await expect(
      TrackingsystemService.getTrackingSystemData(mockParams),
    ).rejects.toThrow("API Error");
    expect(TrackingsystemService.getTrackingSystemData).toHaveBeenCalledWith(
      mockParams,
    );
  });

  test("should handle empty tracking system data", async () => {
    const mockParams: TrackingSystemData = {
      trackingSystem: "system1",
    };
    const mockResponse = createMockAxiosResponse({ data: [] });
    vi.mocked(
      TrackingsystemService.getTrackingSystemData,
    ).mockResolvedValueOnce(mockResponse);

    const result =
      await TrackingsystemService.getTrackingSystemData(mockParams);
    expect(result).toEqual(mockResponse);
    expect(TrackingsystemService.getTrackingSystemData).toHaveBeenCalledWith(
      mockParams,
    );
  });

  test("should get tracking system data from uploaded file successfully", async () => {
    const mockParams: TrackingSystemData = {
      trackingSystem: "system1",
      uploadId: "upload123",
    };
    const mockResponse = createMockAxiosResponse({ data: [] });
    vi.mocked(
      TrackingsystemService.getTrackingSystemDataFromUploadedFile,
    ).mockResolvedValueOnce(mockResponse);

    const result =
      await TrackingsystemService.getTrackingSystemDataFromUploadedFile(
        mockParams,
      );
    expect(result).toEqual(mockResponse);
    expect(
      TrackingsystemService.getTrackingSystemDataFromUploadedFile,
    ).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when getting tracking system data from uploaded file", async () => {
    const mockParams: TrackingSystemData = {
      trackingSystem: "system1",
      uploadId: "upload123",
    };
    const mockError = new Error("API Error");
    vi.mocked(
      TrackingsystemService.getTrackingSystemDataFromUploadedFile,
    ).mockRejectedValueOnce(mockError);

    await expect(
      TrackingsystemService.getTrackingSystemDataFromUploadedFile(mockParams),
    ).rejects.toThrow("API Error");
    expect(
      TrackingsystemService.getTrackingSystemDataFromUploadedFile,
    ).toHaveBeenCalledWith(mockParams);
  });

  test("should handle empty data from uploaded file", async () => {
    const mockParams: TrackingSystemData = {
      trackingSystem: "system1",
      uploadId: "upload123",
    };
    const mockResponse = createMockAxiosResponse({ data: [] });
    vi.mocked(
      TrackingsystemService.getTrackingSystemDataFromUploadedFile,
    ).mockResolvedValueOnce(mockResponse);

    const result =
      await TrackingsystemService.getTrackingSystemDataFromUploadedFile(
        mockParams,
      );
    expect(result).toEqual(mockResponse);
    expect(
      TrackingsystemService.getTrackingSystemDataFromUploadedFile,
    ).toHaveBeenCalledWith(mockParams);
  });
});
