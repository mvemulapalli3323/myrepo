import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import SplitButton from "../components/SharedComponents/Buttons/SplitButton";

describe("SplitButton Component", () => {
  const defaultProps = {
    mainButtonIcon: <span>Icon</span>,
    menuItems: [
      { text: "Option 1", onClick: vi.fn() },
      { text: "Option 2", onClick: vi.fn() },
      { text: "Option 3", onClick: vi.fn() },
    ],
    disabled: false,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Component Rendering", () => {
    it("renders SplitButton component with main button", () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      expect(buttons).toHaveLength(2); // Main button + dropdown button
    });

    it("renders with menu item text", () => {
      render(<SplitButton {...defaultProps} />);

      expect(screen.getByText("Option 1")).toBeInTheDocument();
    });

    it("renders with icon", () => {
      render(<SplitButton {...defaultProps} />);

      expect(screen.getByText("Icon")).toBeInTheDocument();
    });
  });

  describe("Menu Functionality", () => {
    it("opens menu when dropdown button is clicked", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1]; // Second button is the dropdown
      fireEvent.click(dropdownButton);

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });
    });

    it("closes menu when clicking outside", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1];
      fireEvent.click(dropdownButton);

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });

      // Test that menu is open and functional
      expect(screen.getAllByRole("menuitem")).toHaveLength(3);
    });

    it("closes menu when menu item is clicked", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1];
      fireEvent.click(dropdownButton);

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });

      const menuItems = screen.getAllByRole("menuitem");
      fireEvent.click(menuItems[0]);

      await waitFor(() => {
        expect(screen.queryAllByRole("menuitem")).toHaveLength(0);
      });
    });
  });

  describe("Menu Item Interactions", () => {
    it("changes selection when menu item is clicked but does not call onClick", async () => {
      const mockOnClick = vi.fn();
      const props = {
        ...defaultProps,
        menuItems: [
          { text: "Option 1", onClick: vi.fn() },
          { text: "Test Option", onClick: mockOnClick },
        ],
      };

      render(<SplitButton {...props} />);

      // Initially should show first option
      const buttons = screen.getAllByRole("button");
      const mainButton = buttons[0];
      expect(mainButton).toHaveTextContent("Option 1");

      const dropdownButton = buttons[1];
      fireEvent.click(dropdownButton);

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(2);
      });

      const menuItems = screen.getAllByRole("menuitem");
      fireEvent.click(menuItems[1]); // Click second menu item

      // Menu item click should not call onClick immediately
      expect(mockOnClick).toHaveBeenCalledTimes(0);

      // But the main button text should change to reflect the selection
      expect(mainButton).toHaveTextContent("Test Option");
    });

    it("calls onClick when main button is clicked after menu selection", async () => {
      const mockOnClick1 = vi.fn();
      const mockOnClick2 = vi.fn();
      const props = {
        ...defaultProps,
        menuItems: [
          { text: "Option 1", onClick: mockOnClick1 },
          { text: "Option 2", onClick: mockOnClick2 },
        ],
      };

      render(<SplitButton {...props} />);

      // Initially, clicking main button should call first option
      const buttons = screen.getAllByRole("button");
      const mainButton = buttons[0];
      fireEvent.click(mainButton);
      expect(mockOnClick1).toHaveBeenCalledTimes(1);

      // Open menu and select second option
      const dropdownButton = buttons[1];
      fireEvent.click(dropdownButton);

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(2);
      });

      const menuItems = screen.getAllByRole("menuitem");
      fireEvent.click(menuItems[1]); // Select second option

      // Menu click should not call onClick
      expect(mockOnClick2).toHaveBeenCalledTimes(0);

      // But clicking main button should now call second option
      fireEvent.click(mainButton);
      expect(mockOnClick2).toHaveBeenCalledTimes(1);
    });
  });

  describe("Disabled State", () => {
    it("disables buttons when disabled prop is true", () => {
      render(<SplitButton {...defaultProps} disabled={true} />);

      const buttons = screen.getAllByRole("button");
      expect(buttons[0]).toBeDisabled();
      expect(buttons[1]).toBeDisabled();
    });

    it("enables buttons when disabled prop is false", () => {
      render(<SplitButton {...defaultProps} disabled={false} />);

      const buttons = screen.getAllByRole("button");
      expect(buttons[0]).not.toBeDisabled();
      expect(buttons[1]).not.toBeDisabled();
    });

    it("does not open menu when disabled", async () => {
      render(<SplitButton {...defaultProps} disabled={true} />);

      const buttons = screen.getAllByRole("button");
      fireEvent.click(buttons[1]);

      // Wait a bit to ensure no menu opens
      await new Promise((resolve) => setTimeout(resolve, 100));

      expect(screen.queryByRole("menuitem")).not.toBeInTheDocument();
    });
  });

  describe("Empty Menu Items", () => {
    it("renders without menu items", () => {
      const props = {
        ...defaultProps,
        menuItems: [],
      };

      render(<SplitButton {...props} />);

      // Component should not render when menuItems is empty
      expect(screen.queryByRole("button")).not.toBeInTheDocument();
    });

    it("does not show dropdown arrow when no menu items", () => {
      const props = {
        ...defaultProps,
        menuItems: [],
      };

      render(<SplitButton {...props} />);

      // Component should not render when menuItems is empty
      expect(screen.queryByRole("button")).not.toBeInTheDocument();
    });
  });

  describe("Keyboard Navigation", () => {
    it("opens menu on Enter key", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1];
      fireEvent.keyDown(dropdownButton, { key: "Enter" });

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });
    });

    it("opens menu on Space key", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1];
      fireEvent.keyDown(dropdownButton, { key: " " });

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });
    });

    it("closes menu on Escape key", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1];
      fireEvent.click(dropdownButton);

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });

      fireEvent.keyDown(document, { key: "Escape" });

      await waitFor(() => {
        expect(screen.queryAllByRole("menuitem")).toHaveLength(0);
      });
    });
  });

  describe("Accessibility", () => {
    it("has proper ARIA attributes", () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      expect(buttons).toHaveLength(2);
    });

    it("updates ARIA attributes when menu is open", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1];
      fireEvent.click(dropdownButton);

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });
    });

    it("has proper role for menu items", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1];
      fireEvent.click(dropdownButton);

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });
    });
  });

  describe("Styling and Theme", () => {
    it("applies custom styling", () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      expect(buttons).toHaveLength(2);
    });

    it("applies theme colors correctly", () => {
      render(<SplitButton {...defaultProps} color="primary" />);

      const buttons = screen.getAllByRole("button");
      expect(buttons).toHaveLength(2);
    });

    it("applies size variants", () => {
      render(<SplitButton {...defaultProps} size="large" />);

      const buttons = screen.getAllByRole("button");
      expect(buttons).toHaveLength(2);
    });
  });

  describe("Error Handling", () => {
    it("handles onClick errors gracefully", async () => {
      const mockOnClick = vi.fn().mockImplementation(() => {
        throw new Error("Test error");
      });

      const props = {
        ...defaultProps,
        menuItems: [{ text: "Error Option", onClick: mockOnClick }],
      };

      render(<SplitButton {...props} />);

      const buttons = screen.getAllByRole("button");
      const mainButton = buttons[0];

      // Wrap the main button click in a try-catch to handle the expected error
      try {
        fireEvent.click(mainButton);
      } catch (error) {
        // Expected error, test passes
      }

      expect(mockOnClick).toHaveBeenCalledTimes(1);
    });

    it("handles missing menu items gracefully", () => {
      const props = {
        mainButtonIcon: <span>Icon</span>,
        menuItems: [] as any,
      };

      expect(() => {
        render(<SplitButton {...props} />);
      }).not.toThrow();
    });
  });

  describe("Performance", () => {
    it("renders efficiently with many menu items", () => {
      const manyMenuItems = Array.from({ length: 100 }, (_, i) => ({
        text: `Option ${i}`,
        onClick: vi.fn(),
      }));

      const props = {
        ...defaultProps,
        menuItems: manyMenuItems,
      };

      const startTime = performance.now();
      render(<SplitButton {...props} />);
      const endTime = performance.now();

      expect(endTime - startTime).toBeLessThan(100); // Should render in under 100ms
    });

    it("handles rapid clicks efficiently", async () => {
      render(<SplitButton {...defaultProps} />);

      const buttons = screen.getAllByRole("button");
      const dropdownButton = buttons[1];

      // Rapid clicks
      for (let i = 0; i < 10; i++) {
        fireEvent.click(dropdownButton);
      }

      await waitFor(() => {
        const menuItems = screen.getAllByRole("menuitem");
        expect(menuItems).toHaveLength(3);
      });
    });
  });
});
