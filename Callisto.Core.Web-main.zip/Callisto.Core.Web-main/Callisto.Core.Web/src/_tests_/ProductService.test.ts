import { describe, expect, vi, beforeEach, test } from "vitest";
import "@testing-library/jest-dom";
import * as ProductService from "../api/services/receipts-services/ProductService";
import {
  Allocations,
  bulkParams,
  productsearchParams,
  ProductSearchSelectionParams,
  EditFormData,
} from "../api/services/receipts-services/ServicesInterfaces";
import { AxiosResponse } from "axios";

vi.mock("../api/services/receipts-services/ProductService", () => ({
  getProducts: vi.fn(),
  getSearchProducts: vi.fn(),
  productSearchSelection: vi.fn(),
  productSearchSelectionBulk: vi.fn(),
  getVintages: vi.fn(),
  productSelectionUpdate: vi.fn(),
}));

const createMockAxiosResponse = <T>(data: T): AxiosResponse<T> => ({
  data,
  status: 200,
  statusText: "OK",
  headers: {},
  config: {} as any,
});

describe("ProductService", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  test("should fetch products successfully", async () => {
    const mockParams: Allocations = {
      allocationTransactionId: "123",
    };
    const mockResponse = createMockAxiosResponse({ products: [] });
    vi.mocked(ProductService.getProducts).mockResolvedValueOnce(mockResponse);

    const result = await ProductService.getProducts(mockParams);
    expect(result).toEqual(mockResponse);
    expect(ProductService.getProducts).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when fetching products", async () => {
    const mockParams: Allocations = {
      allocationTransactionId: "123",
    };
    const mockError = new Error("API Error");
    vi.mocked(ProductService.getProducts).mockRejectedValueOnce(mockError);

    await expect(ProductService.getProducts(mockParams)).rejects.toThrow(
      "API Error"
    );
    expect(ProductService.getProducts).toHaveBeenCalledWith(mockParams);
  });

  test("should handle empty response when fetching products", async () => {
    const mockParams: Allocations = {
      allocationTransactionId: "123",
    };
    const mockResponse = createMockAxiosResponse(null);
    vi.mocked(ProductService.getProducts).mockResolvedValueOnce(mockResponse);

    const result = await ProductService.getProducts(mockParams);
    expect(result).toEqual(mockResponse);
    expect(ProductService.getProducts).toHaveBeenCalledWith(mockParams);
  });

  test("should fetch search products successfully", async () => {
    const mockParams: productsearchParams = {
      SearchTerm: "test",
      PageNumber: 1,
      PageSize: 10,
      PaginationType: "page",
    };
    const mockResponse = createMockAxiosResponse({ products: [] });
    vi.mocked(ProductService.getSearchProducts).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.getSearchProducts(mockParams);
    expect(result).toEqual(mockResponse);
    expect(ProductService.getSearchProducts).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when fetching search products", async () => {
    const mockParams: productsearchParams = {
      SearchTerm: "test",
      PageNumber: 1,
      PageSize: 10,
      PaginationType: "page",
    };
    const mockError = new Error("API Error");
    vi.mocked(ProductService.getSearchProducts).mockRejectedValueOnce(
      mockError
    );

    await expect(ProductService.getSearchProducts(mockParams)).rejects.toThrow(
      "API Error"
    );
    expect(ProductService.getSearchProducts).toHaveBeenCalledWith(mockParams);
  });

  test("should handle empty search results", async () => {
    const mockParams: productsearchParams = {
      SearchTerm: "",
      PageNumber: 1,
      PageSize: 10,
      PaginationType: "page",
    };
    const mockResponse = createMockAxiosResponse({ products: [] });
    vi.mocked(ProductService.getSearchProducts).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.getSearchProducts(mockParams);
    expect(result).toEqual(mockResponse);
    expect(ProductService.getSearchProducts).toHaveBeenCalledWith(mockParams);
  });

  test("should submit product search selection successfully", async () => {
    const mockParams: ProductSearchSelectionParams = {
      positionId: "pos1",
      inboxTransactionId: "inbox1",
      quantity: 10,
      errors: [],
      warnings: [],
      id: 1,
      vintageId: 1,
      productId: 1,
      product: "Test Product",
      deliveryDateUtc: "2024-03-20",
      allocationTransactionId: "alloc1",
      deliveredFlag: false,
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(ProductService.productSearchSelection).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.productSearchSelection(mockParams);
    expect(result).toEqual(mockResponse);
    expect(ProductService.productSearchSelection).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle errors when submitting product search selection", async () => {
    const mockParams: ProductSearchSelectionParams = {
      positionId: "pos1",
      inboxTransactionId: "inbox1",
      quantity: 10,
      errors: [],
      warnings: [],
      id: 1,
      vintageId: 1,
      productId: 1,
      product: "Test Product",
      deliveryDateUtc: "2024-03-20",
      allocationTransactionId: "alloc1",
      deliveredFlag: false,
    };
    const mockError = new Error("API Error");
    vi.mocked(ProductService.productSearchSelection).mockRejectedValueOnce(
      mockError
    );

    await expect(
      ProductService.productSearchSelection(mockParams)
    ).rejects.toThrow("API Error");
    expect(ProductService.productSearchSelection).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle validation errors in product search selection", async () => {
    const mockParams: ProductSearchSelectionParams = {
      positionId: "pos1",
      inboxTransactionId: "inbox1",
      quantity: 0,
      errors: ["Invalid quantity"],
      warnings: [],
      id: 1,
      vintageId: 1,
      productId: 1,
      product: "Test Product",
      deliveryDateUtc: "2024-03-20",
      allocationTransactionId: "alloc1",
      deliveredFlag: false,
    };
    const mockResponse = createMockAxiosResponse({
      success: false,
      errors: ["Invalid quantity"],
    });
    vi.mocked(ProductService.productSearchSelection).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.productSearchSelection(mockParams);
    expect(result).toEqual(mockResponse);
    expect(ProductService.productSearchSelection).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should submit bulk product search selection successfully", async () => {
    const mockParams: bulkParams = {
      allocationIds: ["id1", "id2"],
      productId: 1,
      product: "Test Product",
      allocationTransactionId: "alloc1",
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(ProductService.productSearchSelectionBulk).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.productSearchSelectionBulk(mockParams);
    expect(result).toEqual(mockResponse);
    expect(ProductService.productSearchSelectionBulk).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle errors when submitting bulk product search selection", async () => {
    const mockParams: bulkParams = {
      allocationIds: ["id1", "id2"],
      productId: 1,
      product: "Test Product",
      allocationTransactionId: "alloc1",
    };
    const mockError = new Error("API Error");
    vi.mocked(ProductService.productSearchSelectionBulk).mockRejectedValueOnce(
      mockError
    );

    await expect(
      ProductService.productSearchSelectionBulk(mockParams)
    ).rejects.toThrow("API Error");
    expect(ProductService.productSearchSelectionBulk).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle empty allocation IDs", async () => {
    const mockParams: bulkParams = {
      allocationIds: [],
      productId: 1,
      product: "Test Product",
      allocationTransactionId: "alloc1",
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(ProductService.productSearchSelectionBulk).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.productSearchSelectionBulk(mockParams);
    expect(result).toEqual(mockResponse);
    expect(ProductService.productSearchSelectionBulk).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should fetch vintages successfully", async () => {
    const mockResponse = createMockAxiosResponse({ vintages: [] });
    vi.mocked(ProductService.getVintages).mockResolvedValueOnce(mockResponse);

    const result = await ProductService.getVintages();
    expect(result).toEqual(mockResponse);
    expect(ProductService.getVintages).toHaveBeenCalled();
  });

  test("should handle errors when fetching vintages", async () => {
    const mockError = new Error("API Error");
    vi.mocked(ProductService.getVintages).mockRejectedValueOnce(mockError);

    await expect(ProductService.getVintages()).rejects.toThrow("API Error");
    expect(ProductService.getVintages).toHaveBeenCalled();
  });

  test("should handle empty vintages response", async () => {
    const mockResponse = createMockAxiosResponse({ vintages: [] });
    vi.mocked(ProductService.getVintages).mockResolvedValueOnce(mockResponse);

    const result = await ProductService.getVintages();
    expect(result).toEqual(mockResponse);
    expect(ProductService.getVintages).toHaveBeenCalled();
  });

  test("should update product selection successfully", async () => {
    const mockParams: EditFormData[] = [
      {
        id: "id1",
        vintage: "2024",
        vintageId: 1,
        product: "Test Product",
        productId: 1,
        deliveredFlag: false,
        deliveryDateUtc: "2024-03-20",
      },
    ];
    const allocationId = "alloc1";
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(ProductService.productSelectionUpdate).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.productSelectionUpdate(
      mockParams,
      allocationId
    );
    expect(result).toEqual(mockResponse);
    expect(ProductService.productSelectionUpdate).toHaveBeenCalledWith(
      mockParams,
      allocationId
    );
  });

  test("should handle errors when updating product selection", async () => {
    const mockParams: EditFormData[] = [
      {
        id: "id1",
        vintage: "2024",
        vintageId: 1,
        product: "Test Product",
        productId: 1,
        deliveredFlag: false,
        deliveryDateUtc: "2024-03-20",
      },
    ];
    const allocationId = "alloc1";
    const mockError = new Error("API Error");
    vi.mocked(ProductService.productSelectionUpdate).mockRejectedValueOnce(
      mockError
    );

    await expect(
      ProductService.productSelectionUpdate(mockParams, allocationId)
    ).rejects.toThrow("API Error");
    expect(ProductService.productSelectionUpdate).toHaveBeenCalledWith(
      mockParams,
      allocationId
    );
  });

  test("should handle empty update data", async () => {
    const mockParams: EditFormData[] = [];
    const allocationId = "alloc1";
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(ProductService.productSelectionUpdate).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.productSelectionUpdate(
      mockParams,
      allocationId
    );
    expect(result).toEqual(mockResponse);
    expect(ProductService.productSelectionUpdate).toHaveBeenCalledWith(
      mockParams,
      allocationId
    );
  });

  test("should handle partial update data", async () => {
    const mockParams: EditFormData[] = [
      {
        id: "id1",
        vintage: "2024",
      },
    ];
    const allocationId = "alloc1";
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(ProductService.productSelectionUpdate).mockResolvedValueOnce(
      mockResponse
    );

    const result = await ProductService.productSelectionUpdate(
      mockParams,
      allocationId
    );
    expect(result).toEqual(mockResponse);
    expect(ProductService.productSelectionUpdate).toHaveBeenCalledWith(
      mockParams,
      allocationId
    );
  });
});
