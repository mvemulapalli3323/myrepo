import { render, screen, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { BrowserRouter } from "react-router-dom";
import { Context } from "../Context/AppContext";
import { ErrorBoundary } from "react-error-boundary";
import Home from "../pages/home/Home";
import { useMsal } from "../hooks/useMsal";

// Mock the useMsal hook
vi.mock("../hooks/useMsal", () => ({
  useMsal: vi.fn(),
}));

// Mock the components
vi.mock("../components/SharedComponents/Grids/AgGrid", () => ({
  default: function MockAgGrid() {
    return <div data-testid="home-grid">Home Grid</div>;
  },
}));

vi.mock("../components/SharedComponents/Modals/globalModal", () => ({
  default: function MockGlobalModal() {
    return <div data-testid="global-modal">Global Modal</div>;
  },
}));

vi.mock("../components/SharedComponents/Buttons/SplitButton", () => ({
  default: function MockSplitButton() {
    return <div data-testid="split-button">Split Button</div>;
  },
}));

// Mock the services
vi.mock("../api/services/receipts-services/AllocationService", () => ({
  getAllocations: vi.fn(),
}));

interface FakeContextType {
  data: unknown[];
  open: boolean;
  setOpen: (open: boolean) => void;
  setData: (value: unknown[]) => void;
}

describe("Home Component", () => {
  let fakeContext: FakeContextType;

  beforeEach(() => {
    fakeContext = {
      data: [],
      open: false,
      setOpen: vi.fn(),
      setData: vi.fn(),
    };

    // Mock useMsal to return authenticated user
    vi.mocked(useMsal).mockReturnValue({
      instance: { pca: {} } as any,
      inProgress: "none" as any,
      isAuthReceiptsManager: true,
      isAuthDataManager: true,
      isAuthMappingManager: true,
      isAuthProcessManager: true,
      isDev: false,
      isAdmin: false,
      username: "Test User",
    });
  });

  const renderHome = () => {
    return render(
      <Context.Provider value={fakeContext}>
        <BrowserRouter>
          <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
            <Home />
          </ErrorBoundary>
        </BrowserRouter>
      </Context.Provider>
    );
  };

  describe("Component Rendering", () => {
    it("renders Home component with expected elements", async () => {
      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });

    it("renders with proper layout", async () => {
      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });
  });

  describe("Authentication States", () => {
    it("renders correctly for authenticated user", async () => {
      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });

    it("renders correctly for unauthenticated user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: null,
      });

      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });
  });

  describe("User Role Handling", () => {
    it("renders correctly for dev user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: true,
        isAdmin: false,
        username: "Dev User",
      });

      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });

    it("renders correctly for admin user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: true,
        username: "Admin User",
      });

      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });
  });

  describe("Access Control", () => {
    it("handles receipts manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });

    it("handles data manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: true,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });

    it("handles mapping manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: true,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });

    it("handles process manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });
  });

  describe("Error Handling", () => {
    it("handles component errors gracefully", async () => {
      // Test that the component renders without errors under normal conditions
      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });
  });

  describe("Context Integration", () => {
    it("integrates with context correctly", async () => {
      renderHome();

      await waitFor(() => {
        expect(screen.getByTestId("home-grid")).toBeInTheDocument();
      });
    });

    it("handles context changes", async () => {
      renderHome();

      // Simulate context change
      fakeContext.setOpen(true);

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });
  });
});
