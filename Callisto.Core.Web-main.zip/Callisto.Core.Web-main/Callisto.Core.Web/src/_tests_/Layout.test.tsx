import { render, screen, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { BrowserRouter } from "react-router-dom";
import { Context } from "../Context/AppContext";
import { ErrorBoundary } from "react-error-boundary";
import Layout from "../Layout";
import { useMsal } from "../hooks/useMsal";

// Mock the useMsal hook
vi.mock("../hooks/useMsal", () => ({
  useMsal: vi.fn(),
}));

// Mock the Navigation component
vi.mock("../components/Navigation", () => ({
  default: function MockNavigation() {
    return <div data-testid="navigation">Navigation</div>;
  },
}));

// Mock the Drawer component
vi.mock("../components/Drawer", () => ({
  default: function MockDrawer({
    open,
    onClose,
  }: {
    open: boolean;
    onClose: () => void;
  }) {
    if (!open) return null;
    return (
      <div data-testid="drawer">
        <button onClick={onClose}>Close Drawer</button>
      </div>
    );
  },
}));

// Mock the Spinner component
vi.mock("../components/Spinner", () => ({
  default: function MockSpinner() {
    return <div data-testid="spinner">Loading...</div>;
  },
}));

// Mock MSAL components
vi.mock("@azure/msal-react", () => ({
  MsalAuthenticationTemplate: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="msal-auth">{children}</div>
  ),
  AuthenticatedTemplate: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="authenticated">{children}</div>
  ),
  UnauthenticatedTemplate: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="unauthenticated">{children}</div>
  ),
}));

interface FakeContextType {
  data: unknown[];
  open: boolean;
  setOpen: (open: boolean) => void;
  setData: (value: unknown[]) => void;
}

describe("Layout Component", () => {
  let fakeContext: FakeContextType;

  beforeEach(() => {
    fakeContext = {
      data: [],
      open: false,
      setOpen: vi.fn(),
      setData: vi.fn(),
    };

    // Mock useMsal to return authenticated user
    vi.mocked(useMsal).mockReturnValue({
      instance: { pca: {} } as any,
      inProgress: "none" as any,
      isAuthReceiptsManager: true,
      isAuthDataManager: true,
      isAuthMappingManager: true,
      isAuthProcessManager: true,
      isDev: false,
      isAdmin: false,
      username: "Test User",
    });
  });

  const renderLayout = () => {
    return render(
      <Context.Provider value={fakeContext}>
        <BrowserRouter>
          <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
            <div data-testid="layout">
              <Layout />
            </div>
          </ErrorBoundary>
        </BrowserRouter>
      </Context.Provider>
    );
  };

  describe("Component Rendering", () => {
    it("renders Layout component with all expected elements", async () => {
      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("msal-auth")).toBeInTheDocument();
        expect(screen.getByTestId("authenticated")).toBeInTheDocument();
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("renders with proper MSAL authentication wrapper", async () => {
      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("msal-auth")).toBeInTheDocument();
      });
    });
  });

  describe("Context Integration", () => {
    it("passes context values correctly", async () => {
      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles context changes", async () => {
      renderLayout();

      // Simulate context change
      fakeContext.setOpen(true);

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });
  });

  describe("Error Handling", () => {
    it("handles component errors gracefully", async () => {
      // Test that the error boundary is properly set up
      // Since the Layout component doesn't actually throw errors,
      // we'll test that the error boundary fallback is rendered when needed
      renderLayout();

      // The error boundary should be present but not showing an error
      expect(screen.getByTestId("layout")).toBeInTheDocument();
      expect(screen.getByTestId("msal-auth")).toBeInTheDocument();
    });
  });

  describe("User Authentication States", () => {
    it("renders correctly for authenticated user", async () => {
      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("renders correctly for unauthenticated user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: null,
      });

      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });

  describe("Loading States", () => {
    it("handles loading state correctly", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "startup" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: null,
      });

      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });

  describe("User Role Handling", () => {
    it("renders correctly for dev user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: true,
        isAdmin: false,
        username: "Dev User",
      });

      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("renders correctly for admin user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: true,
        username: "Admin User",
      });

      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });

  describe("Access Control", () => {
    it("handles receipts manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles data manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: true,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles mapping manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: true,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles process manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderLayout();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });
});
