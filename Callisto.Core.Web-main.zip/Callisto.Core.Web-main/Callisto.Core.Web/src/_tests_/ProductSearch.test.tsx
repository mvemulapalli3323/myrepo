import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import ProductSearch from "../components/SearchPosition/ProductSearch";
import { Context } from "../Context/AppContext";
import { vi, describe, beforeEach, expect, test } from "vitest";
import "@testing-library/jest-dom";
import {
  productSearchSelection,
  productSearchSelectionBulk,
} from "../api/services/receipts-services/ProductService";

vi.mock("../api/services/receipts-services/ProductService", () => ({
  productSearchSelection: vi.fn(() =>
    Promise.resolve({ data: [{ id: "single-product" }] }),
  ),
  productSearchSelectionBulk: vi.fn(() =>
    Promise.resolve({ data: [{ id: "bulk-product" }] }),
  ),
}));

// Mock the correct grid component
vi.mock("../components/SharedComponents/Grids/AgGrid", () => ({
  __esModule: true,
  default: ({ onSelectionChanged }: any) => (
    <div
      data-testid="product-grid"
      onClick={() => {
        onSelectionChanged({
          api: {
            getSelectedRows: () => [
              {
                productId: "123",
                productDescription: "Product A",
                positionId: 1,
                inboxTransactionId: "inbox-123",
                quantity: 10,
                errors: "",
                warnings: "",
                deliveryDateUtc: "2023-01-01",
                vintageId: 1,
              },
            ],
          },
        });
      }}
    >
      Mocked Grid
    </div>
  ),
}));

vi.mock("../../components/SharedComponents/Inputs/Input", () => ({
  __esModule: true,
  default: ({ label, value, onChange, placeholder }: any) => (
    <div data-testid="input">
      <label>{label}</label>
      <input value={value} onChange={onChange} placeholder={placeholder} />
    </div>
  ),
}));

vi.mock("../../components/SharedComponents/Grids/Grid", () => ({
  __esModule: true,
  default: ({ rowData }: any) => (
    <div data-testid="grid">{JSON.stringify(rowData)}</div>
  ),
}));

describe("ProductSearch Component", () => {
  const mockSetOpen = vi.fn();
  const mockSetData = vi.fn();
  const sampleData = [
    { id: 1, name: "Product A", searchText: "Product A" },
    { id: 2, name: "Product B", searchText: "Product B" },
  ];

  const contextValue = {
    data: sampleData,
    setData: mockSetData,
    setOpen: mockSetOpen,
    open: true,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  test("renders the title and input", () => {
    render(
      <Context.Provider value={contextValue}>
        <ProductSearch />
      </Context.Provider>,
    );
    expect(screen.getByText("Product Search")).toBeInTheDocument();
    expect(
      screen.getByPlaceholderText("Enter search text..."),
    ).toBeInTheDocument();
  });

  test("renders grid with row data", () => {
    render(
      <Context.Provider value={contextValue}>
        <ProductSearch />
      </Context.Provider>,
    );
    expect(screen.getByTestId("product-grid")).toBeInTheDocument();
  });

  test("handles input change correctly", () => {
    render(
      <Context.Provider value={contextValue}>
        <ProductSearch />
      </Context.Provider>,
    );
    const input = screen.getByPlaceholderText("Enter search text...");
    fireEvent.change(input, { target: { value: "Test Product" } });
    expect(input).toHaveValue("Test Product");
  });

  test("calls setOpen(false) when Close icon is clicked", () => {
    render(
      <Context.Provider value={contextValue}>
        <ProductSearch />
      </Context.Provider>,
    );
    const closeBtn = screen.getByLabelText("close");
    fireEvent.click(closeBtn);
    expect(mockSetOpen).toHaveBeenCalledWith(false);
  });

  test("throws error if used without context", () => {
    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<ProductSearch />)).toThrow(
      "ProductSearch must be used within an AppProvider",
    );
    errorSpy.mockRestore();
  });

  test("disables Assign button if no data selected", () => {
    render(
      <Context.Provider
        value={{ ...contextValue, data: [], setData: mockSetData }}
      >
        <ProductSearch />
      </Context.Provider>,
    );
    const okBtn = screen.getByRole("button", { name: "Assign Product" });
    expect(okBtn).toBeDisabled();
  });

  test("shows placeholder text in input", () => {
    render(
      <Context.Provider value={contextValue}>
        <ProductSearch />
      </Context.Provider>,
    );
    const input = screen.getByPlaceholderText("Enter search text...");
    expect(input).toBeInTheDocument();
  });

  test("does not call service when data is empty and Assign clicked", async () => {
    render(
      <Context.Provider value={{ ...contextValue, data: [] }}>
        <ProductSearch />
      </Context.Provider>,
    );

    const okBtn = screen.getByRole("button", { name: "Assign Product" });
    fireEvent.click(okBtn);

    await waitFor(() => {
      expect(productSearchSelection).not.toHaveBeenCalled();
    });
  });

  test("does not call API if no rows selected", async () => {
    render(
      <Context.Provider value={{ ...contextValue, data: [] }}>
        <ProductSearch />
      </Context.Provider>,
    );

    const okBtn = screen.getByRole("button", { name: "Assign Product" });
    fireEvent.click(okBtn);

    await waitFor(() => {
      expect(productSearchSelection).not.toHaveBeenCalled();
      expect(productSearchSelectionBulk).not.toHaveBeenCalled();
    });
  });
  test("calls productSearchSelection for single product", async () => {
    const singleData = [
      {
        id: "123",
        searchText: "Product A",
        positionId: 1,
        inboxTransactionId: "inbox-123",
        quantity: 10,
        errors: "",
        warnings: "",
        deliveryDateUtc: "2023-01-01",
        vintageId: 1,
      },
    ];

    render(
      <Context.Provider value={{ ...contextValue, data: singleData }}>
        <ProductSearch />
      </Context.Provider>,
    );

    // First click to select a row
    const grid = screen.getByTestId("product-grid");
    fireEvent.click(grid);

    const okBtn = screen.getByRole("button", { name: "Assign Product" });
    expect(okBtn).not.toBeDisabled();

    fireEvent.click(okBtn);

    await waitFor(() => {
      expect(productSearchSelection).toHaveBeenCalled();
      expect(mockSetData).toHaveBeenCalledWith([{ id: "single-product" }]);
      expect(mockSetOpen).toHaveBeenCalledWith(false);
    });
  });

  test("calls productSearchSelectionBulk for multiple products", async () => {
    const multiData = [
      { id: "123", searchText: "Product A" },
      { id: "456", searchText: "Product B" },
    ];
    render(
      <Context.Provider value={{ ...contextValue, data: multiData }}>
        <ProductSearch />
      </Context.Provider>,
    );

    const grid = screen.getByTestId("product-grid");
    fireEvent.click(grid);

    const okBtn = screen.getByRole("button", { name: "Assign Product" });
    expect(okBtn).not.toBeDisabled();

    fireEvent.click(okBtn);

    await waitFor(() => {
      expect(productSearchSelectionBulk).toHaveBeenCalled();
      expect(mockSetData).toHaveBeenCalledWith([{ id: "bulk-product" }]);
      expect(mockSetOpen).toHaveBeenCalledWith(false);
    });
  });
  test("logs error when productSearchSelection fails", async () => {
    const singleData = [
      {
        id: "123",
        searchText: "Product A",
        positionId: 1,
        inboxTransactionId: "inbox-123",
        quantity: 10,
        errors: "",
        warnings: "",
        deliveryDateUtc: "2023-01-01",
        vintageId: 1,
      },
    ];

    render(
      <Context.Provider value={{ ...contextValue, data: singleData }}>
        <ProductSearch />
      </Context.Provider>,
    );

    // First click to select a row
    const grid = screen.getByTestId("product-grid");
    fireEvent.click(grid);

    const okBtn = screen.getByRole("button", { name: "Assign Product" });
    expect(okBtn).not.toBeDisabled();

    fireEvent.click(okBtn);

    await waitFor(() => {
      expect(productSearchSelection).toHaveBeenCalled();
    });
  });
});
