import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import {
  gridStateManager,
  useGridStateManager,
} from "../utils/gridStateManager";

describe("GridStateManager", () => {
  let mockLocalStorage: { [key: string]: string };

  beforeEach(() => {
    // Reset localStorage mock before each test
    mockLocalStorage = {};

    // Mock localStorage methods
    Object.defineProperty(window, "localStorage", {
      value: {
        getItem: vi.fn((key: string) => mockLocalStorage[key] || null),
        setItem: vi.fn((key: string, value: string) => {
          mockLocalStorage[key] = value;
        }),
        removeItem: vi.fn((key: string) => {
          delete mockLocalStorage[key];
        }),
        clear: vi.fn(() => {
          mockLocalStorage = {};
        }),
        get length() {
          return Object.keys(mockLocalStorage).length;
        },
        key: vi.fn((index: number) => {
          const keys = Object.keys(mockLocalStorage);
          return keys[index] || null;
        }),
      },
      writable: true,
    });

    // Clear any existing states
    gridStateManager.clearExpiredStates(0);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("saveState", () => {
    it("should save grid state to localStorage with correct structure", () => {
      const gridId = "test-grid";
      const testState = {
        columnState: [{ colId: "col1", width: 100 }],
        filterState: { col1: { type: "text", filter: "test" } },
      };

      gridStateManager.saveState(gridId, testState);

      const savedData = localStorage.getItem("GRID_LAYOUT_test-grid");
      expect(savedData).toBeTruthy();

      const parsed = JSON.parse(savedData!);
      expect(parsed).toHaveProperty("state", testState);
      expect(parsed).toHaveProperty("timestamp");
      expect(parsed).toHaveProperty("version", "1.0");
      expect(typeof parsed.timestamp).toBe("number");
    });

    it("should handle saving complex state objects", () => {
      const gridId = "complex-grid";
      const complexState = {
        columnState: [
          { colId: "col1", width: 100, sort: "asc" },
          { colId: "col2", width: 200, hide: true },
        ],
        filterState: {
          col1: { type: "text", filter: "test" },
          col2: { type: "number", filter: 42 },
        },
        sortState: [{ colId: "col1", sort: "desc" }],
        groupState: { openByDefault: true },
      };

      gridStateManager.saveState(gridId, complexState);

      const savedData = localStorage.getItem("GRID_LAYOUT_complex-grid");
      const parsed = JSON.parse(savedData!);
      expect(parsed.state).toEqual(complexState);
    });

    it("should handle localStorage errors gracefully", () => {
      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

      // Mock localStorage.setItem to throw an error
      vi.mocked(localStorage.setItem).mockImplementationOnce(() => {
        throw new Error("localStorage is full");
      });

      const gridId = "error-grid";
      const testState = { test: "data" };

      // Should not throw an error
      expect(() => {
        gridStateManager.saveState(gridId, testState);
      }).not.toThrow();

      expect(consoleSpy).toHaveBeenCalledWith(
        `Failed to save grid state for ${gridId}:`,
        expect.any(Error)
      );

      consoleSpy.mockRestore();
    });

    it("should handle null and undefined states", () => {
      gridStateManager.saveState("null-grid", null);
      gridStateManager.saveState("undefined-grid", undefined);

      const nullData = localStorage.getItem("GRID_LAYOUT_null-grid");
      const undefinedData = localStorage.getItem("GRID_LAYOUT_undefined-grid");

      expect(JSON.parse(nullData!).state).toBeNull();
      expect(JSON.parse(undefinedData!).state).toBeUndefined();
    });

    it("should handle empty string gridId", () => {
      const state = { test: "data" };

      gridStateManager.saveState("", state);
      const loadedState = gridStateManager.loadState("");

      expect(loadedState).toEqual(state);
    });

    it("should handle very long gridId", () => {
      const longId = "a".repeat(1000);
      const state = { test: "data" };

      gridStateManager.saveState(longId, state);
      const loadedState = gridStateManager.loadState(longId);

      expect(loadedState).toEqual(state);
    });

    it("should handle special characters in gridId", () => {
      const specialId =
        "grid-with-special-chars!@#$%^&*()_+-={}[]|\\:\";'<>?,./";
      const state = { test: "data" };

      gridStateManager.saveState(specialId, state);
      const loadedState = gridStateManager.loadState(specialId);

      expect(loadedState).toEqual(state);
    });
  });

  describe("loadState", () => {
    it("should load previously saved state", () => {
      const gridId = "load-test-grid";
      const testState = {
        columnState: [{ colId: "col1", width: 150 }],
        filterState: { col1: { type: "text", filter: "loaded" } },
      };

      gridStateManager.saveState(gridId, testState);
      const loadedState = gridStateManager.loadState(gridId);

      expect(loadedState).toEqual(testState);
    });

    it("should return null for non-existent grid state", () => {
      const loadedState = gridStateManager.loadState("non-existent-grid");
      expect(loadedState).toBeNull();
    });

    it("should return null and remove state for version mismatch", () => {
      const gridId = "version-mismatch-grid";

      // Manually create a state with old version
      const oldVersionState = {
        state: { test: "data" },
        timestamp: Date.now(),
        version: "0.9", // Old version
      };

      localStorage.setItem(
        "GRID_LAYOUT_version-mismatch-grid",
        JSON.stringify(oldVersionState)
      );

      const loadedState = gridStateManager.loadState(gridId);
      expect(loadedState).toBeNull();

      // Should have removed the old state
      expect(
        localStorage.getItem("GRID_LAYOUT_version-mismatch-grid")
      ).toBeNull();
    });

    it("should handle corrupted data gracefully", () => {
      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
      const gridId = "corrupted-grid";

      // Set corrupted JSON data
      localStorage.setItem("GRID_LAYOUT_corrupted-grid", "invalid-json-data");

      const loadedState = gridStateManager.loadState(gridId);
      expect(loadedState).toBeNull();

      // Should have cleaned up corrupted data
      expect(localStorage.getItem("GRID_LAYOUT_corrupted-grid")).toBeNull();
      expect(consoleSpy).toHaveBeenCalledWith(
        `Failed to load grid state for ${gridId}:`,
        expect.any(Error)
      );

      consoleSpy.mockRestore();
    });

    it("should handle localStorage.getItem errors", () => {
      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

      // Mock localStorage.getItem to throw an error
      vi.mocked(localStorage.getItem).mockImplementationOnce(() => {
        throw new Error("localStorage access denied");
      });

      const loadedState = gridStateManager.loadState("error-grid");
      expect(loadedState).toBeNull();
      expect(consoleSpy).toHaveBeenCalled();

      consoleSpy.mockRestore();
    });
  });

  describe("removeState", () => {
    it("should remove specific grid state", () => {
      const gridId = "remove-test-grid";
      const testState = { test: "data" };

      gridStateManager.saveState(gridId, testState);
      expect(localStorage.getItem("GRID_LAYOUT_remove-test-grid")).toBeTruthy();

      gridStateManager.removeState(gridId);
      expect(localStorage.getItem("GRID_LAYOUT_remove-test-grid")).toBeNull();
    });

    it("should handle removing non-existent state gracefully", () => {
      expect(() => {
        gridStateManager.removeState("non-existent-grid");
      }).not.toThrow();
    });

    it("should handle localStorage.removeItem errors gracefully", () => {
      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

      // Mock localStorage.removeItem to throw an error
      vi.mocked(localStorage.removeItem).mockImplementationOnce(() => {
        throw new Error("Cannot remove item");
      });

      expect(() => {
        gridStateManager.removeState("error-grid");
      }).not.toThrow();

      expect(consoleSpy).toHaveBeenCalledWith(
        "Failed to remove grid state for error-grid:",
        expect.any(Error)
      );

      consoleSpy.mockRestore();
    });
  });

  describe("clearStatesForContext", () => {
    it("should clear all states matching context prefix", () => {
      // Save multiple states with different contexts
      gridStateManager.saveState("search-positions-grid-1", { test: "data1" });
      gridStateManager.saveState("search-positions-grid-2", { test: "data2" });
      gridStateManager.saveState("search-receipts-grid-1", { test: "data3" });
      gridStateManager.saveState("other-grid", { test: "data4" });

      // Clear only search-positions context
      gridStateManager.clearStatesForContext("search-positions-grid");

      // Should remove search-positions grids but keep others
      expect(
        localStorage.getItem("GRID_LAYOUT_search-positions-grid-1")
      ).toBeNull();
      expect(
        localStorage.getItem("GRID_LAYOUT_search-positions-grid-2")
      ).toBeNull();
      expect(
        localStorage.getItem("GRID_LAYOUT_search-receipts-grid-1")
      ).toBeTruthy();
      expect(localStorage.getItem("GRID_LAYOUT_other-grid")).toBeTruthy();
    });

    it("should handle empty context gracefully", () => {
      gridStateManager.saveState("test-grid", { test: "data" });

      expect(() => {
        gridStateManager.clearStatesForContext("");
      }).not.toThrow();

      // Empty context will match all keys (since every string includes ''),
      // so the grid state will be removed
      expect(localStorage.getItem("GRID_LAYOUT_test-grid")).toBeNull();
    });

    it("should handle non-matching context", () => {
      gridStateManager.saveState("test-grid", { test: "data" });

      gridStateManager.clearStatesForContext("non-matching-context");

      // Should not remove anything
      expect(localStorage.getItem("GRID_LAYOUT_test-grid")).toBeTruthy();
    });

    it("should handle localStorage iteration errors gracefully", () => {
      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

      // Mock localStorage.length to throw an error
      Object.defineProperty(localStorage, "length", {
        get: () => {
          throw new Error("Cannot access localStorage");
        },
      });

      expect(() => {
        gridStateManager.clearStatesForContext("test-context");
      }).not.toThrow();

      expect(consoleSpy).toHaveBeenCalledWith(
        "Failed to clear states for context test-context:",
        expect.any(Error)
      );

      consoleSpy.mockRestore();
    });
  });

  describe("clearExpiredStates", () => {
    it("should clear states older than maxAge", () => {
      const now = Date.now();
      const oneWeekAgo = now - 8 * 24 * 60 * 60 * 1000; // 8 days ago
      const oneDayAgo = now - 1 * 24 * 60 * 60 * 1000; // 1 day ago

      // Create expired state manually
      const expiredState = {
        state: { test: "expired" },
        timestamp: oneWeekAgo,
        version: "1.0",
      };

      // Create fresh state manually
      const freshState = {
        state: { test: "fresh" },
        timestamp: oneDayAgo,
        version: "1.0",
      };

      localStorage.setItem(
        "GRID_LAYOUT_expired-grid",
        JSON.stringify(expiredState)
      );
      localStorage.setItem(
        "GRID_LAYOUT_fresh-grid",
        JSON.stringify(freshState)
      );

      // Clear states older than 7 days (default)
      gridStateManager.clearExpiredStates();

      expect(localStorage.getItem("GRID_LAYOUT_expired-grid")).toBeNull();
      expect(localStorage.getItem("GRID_LAYOUT_fresh-grid")).toBeTruthy();
    });

    it("should use custom maxAge parameter", () => {
      const now = Date.now();
      const twoHoursAgo = now - 2 * 60 * 60 * 1000; // 2 hours ago
      const oneHourAgo = now - 1 * 60 * 60 * 1000; // 1 hour ago

      const oldState = {
        state: { test: "old" },
        timestamp: twoHoursAgo,
        version: "1.0",
      };

      const recentState = {
        state: { test: "recent" },
        timestamp: oneHourAgo,
        version: "1.0",
      };

      localStorage.setItem("GRID_LAYOUT_old-grid", JSON.stringify(oldState));
      localStorage.setItem(
        "GRID_LAYOUT_recent-grid",
        JSON.stringify(recentState)
      );

      // Clear states older than 1.5 hours
      const maxAge = 1.5 * 60 * 60 * 1000;
      gridStateManager.clearExpiredStates(maxAge);

      expect(localStorage.getItem("GRID_LAYOUT_old-grid")).toBeNull();
      expect(localStorage.getItem("GRID_LAYOUT_recent-grid")).toBeTruthy();
    });

    it("should remove corrupted state entries", () => {
      localStorage.setItem("GRID_LAYOUT_corrupted-1", "invalid-json");
      localStorage.setItem("GRID_LAYOUT_corrupted-2", '{"incomplete": true'); // Missing closing brace - truly corrupted JSON

      const validState = {
        state: { test: "valid" },
        timestamp: Date.now(),
        version: "1.0",
      };
      localStorage.setItem(
        "GRID_LAYOUT_valid-grid",
        JSON.stringify(validState)
      );

      gridStateManager.clearExpiredStates();

      // Corrupted entries should be removed
      expect(localStorage.getItem("GRID_LAYOUT_corrupted-1")).toBeNull();
      expect(localStorage.getItem("GRID_LAYOUT_corrupted-2")).toBeNull();
      // Valid entry should remain
      expect(localStorage.getItem("GRID_LAYOUT_valid-grid")).toBeTruthy();
    });

    it("should handle localStorage access errors gracefully", () => {
      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

      // Mock localStorage.length to throw an error
      Object.defineProperty(localStorage, "length", {
        get: () => {
          throw new Error("Cannot access localStorage");
        },
      });

      expect(() => {
        gridStateManager.clearExpiredStates();
      }).not.toThrow();

      expect(consoleSpy).toHaveBeenCalledWith(
        "Failed to clear expired grid states:",
        expect.any(Error)
      );

      consoleSpy.mockRestore();
    });

    it("should not clear states without timestamp property", () => {
      const stateWithoutTimestamp = {
        state: { test: "no-timestamp" },
        version: "1.0",
        // missing timestamp
      };

      localStorage.setItem(
        "GRID_LAYOUT_no-timestamp",
        JSON.stringify(stateWithoutTimestamp)
      );

      gridStateManager.clearExpiredStates();

      // Should NOT be removed because it parses successfully but timestamp is undefined
      // and (now - undefined) = NaN which is not > maxAge
      expect(localStorage.getItem("GRID_LAYOUT_no-timestamp")).toBeTruthy();
    });

    it("should remove states with invalid timestamp values", () => {
      const stateWithInvalidTimestamp = {
        state: { test: "invalid-timestamp" },
        version: "1.0",
        timestamp: "not-a-number",
      };

      localStorage.setItem(
        "GRID_LAYOUT_invalid-timestamp",
        JSON.stringify(stateWithInvalidTimestamp)
      );

      gridStateManager.clearExpiredStates();

      // Should NOT be removed because it still parses successfully
      // and (now - 'not-a-number') = NaN which is not > maxAge
      expect(
        localStorage.getItem("GRID_LAYOUT_invalid-timestamp")
      ).toBeTruthy();
    });
  });

  describe("useGridStateManager hook", () => {
    it("should return the gridStateManager instance", () => {
      const manager = useGridStateManager();
      expect(manager).toBe(gridStateManager);
      expect(manager).toHaveProperty("saveState");
      expect(manager).toHaveProperty("loadState");
      expect(manager).toHaveProperty("removeState");
      expect(manager).toHaveProperty("clearStatesForContext");
      expect(manager).toHaveProperty("clearExpiredStates");
    });

    it("should return consistent instance across multiple calls", () => {
      const manager1 = useGridStateManager();
      const manager2 = useGridStateManager();
      expect(manager1).toBe(manager2);
    });
  });

  describe("Integration scenarios", () => {
    it("should handle complete save/load/remove cycle", () => {
      const gridId = "integration-grid";
      const originalState = {
        columnState: [
          { colId: "name", width: 200, sort: "asc" },
          { colId: "age", width: 100, hide: false },
        ],
        filterState: {
          name: { type: "text", filter: "John" },
          age: { type: "number", filter: 25 },
        },
      };

      // Save state
      gridStateManager.saveState(gridId, originalState);

      // Load and verify
      const loadedState = gridStateManager.loadState(gridId);
      expect(loadedState).toEqual(originalState);

      // Remove state
      gridStateManager.removeState(gridId);

      // Verify removal
      const removedState = gridStateManager.loadState(gridId);
      expect(removedState).toBeNull();
    });

    it("should handle multiple grids independently", () => {
      const grid1State = { grid: "one", data: [1, 2, 3] };
      const grid2State = { grid: "two", data: ["a", "b", "c"] };

      gridStateManager.saveState("grid-1", grid1State);
      gridStateManager.saveState("grid-2", grid2State);

      expect(gridStateManager.loadState("grid-1")).toEqual(grid1State);
      expect(gridStateManager.loadState("grid-2")).toEqual(grid2State);

      // Remove one should not affect the other
      gridStateManager.removeState("grid-1");
      expect(gridStateManager.loadState("grid-1")).toBeNull();
      expect(gridStateManager.loadState("grid-2")).toEqual(grid2State);
    });

    it("should handle real-world AgGrid state structure", () => {
      const agGridState = {
        columnState: [
          {
            colId: "athlete",
            width: 150,
            hide: false,
            pinned: null,
            sort: "asc",
            sortIndex: 0,
            aggFunc: null,
            pivot: false,
            pivotIndex: null,
            rowGroup: false,
            rowGroupIndex: null,
          },
          {
            colId: "age",
            width: 90,
            hide: false,
            pinned: null,
            sort: null,
            sortIndex: null,
            aggFunc: null,
            pivot: false,
            pivotIndex: null,
            rowGroup: false,
            rowGroupIndex: null,
          },
        ],
        groupState: {
          openByDefault: false,
          expandedGroupIds: ["Australia"],
        },
        filterState: {
          athlete: {
            filterType: "text",
            type: "contains",
            filter: "Michael",
          },
        },
        pivotState: {
          pivotMode: false,
          rowGroupColumns: [],
          valueColumns: [],
          pivotColumns: [],
        },
      };

      const gridId = "ag-grid-example";
      gridStateManager.saveState(gridId, agGridState);
      const loadedState = gridStateManager.loadState(gridId);

      expect(loadedState).toEqual(agGridState);
      expect(loadedState.columnState).toHaveLength(2);
      expect(loadedState.columnState[0].sort).toBe("asc");
      expect(loadedState.filterState.athlete.filter).toBe("Michael");
    });

    it("should handle very large state objects", () => {
      const largeState = {
        columnState: Array.from({ length: 100 }, (_, i) => ({
          colId: `col-${i}`,
          width: 100 + i,
          hide: i % 2 === 0,
          sort: i % 3 === 0 ? "asc" : i % 3 === 1 ? "desc" : null,
        })),
        filterState: Object.fromEntries(
          Array.from({ length: 50 }, (_, i) => [
            `col-${i}`,
            { type: "text", filter: `filter-${i}` },
          ])
        ),
      };

      const gridId = "large-state-grid";
      gridStateManager.saveState(gridId, largeState);
      const loadedState = gridStateManager.loadState(gridId);

      expect(loadedState).toEqual(largeState);
      expect(loadedState.columnState).toHaveLength(100);
      expect(Object.keys(loadedState.filterState)).toHaveLength(50);
    });

    it("should handle rapid state changes without losing data", () => {
      const gridId = "rapid-changes-grid";
      const states = [
        { columnState: [{ colId: "col1", width: 100 }] },
        { columnState: [{ colId: "col1", width: 150 }] },
        { columnState: [{ colId: "col1", width: 200 }] },
      ];

      // Save states rapidly
      states.forEach((state) => {
        gridStateManager.saveState(gridId, state);
      });

      const finalState = gridStateManager.loadState(gridId);
      expect(finalState).toEqual(states[states.length - 1]);
    });

    it("should maintain state consistency across context operations", () => {
      // Save states in different contexts
      gridStateManager.saveState("context-a-grid-1", { context: "a", grid: 1 });
      gridStateManager.saveState("context-a-grid-2", { context: "a", grid: 2 });
      gridStateManager.saveState("context-b-grid-1", { context: "b", grid: 1 });

      // Clear one context
      gridStateManager.clearStatesForContext("context-a");

      // Verify correct states were cleared
      expect(gridStateManager.loadState("context-a-grid-1")).toBeNull();
      expect(gridStateManager.loadState("context-a-grid-2")).toBeNull();
      expect(gridStateManager.loadState("context-b-grid-1")).toBeTruthy();
    });
  });

  describe("Edge cases and boundary conditions", () => {
    it("should handle concurrent access patterns", () => {
      const gridId = "concurrent-grid";
      const state1 = { version: 1, data: "first" };
      const state2 = { version: 2, data: "second" };

      // Simulate concurrent saves
      gridStateManager.saveState(gridId, state1);
      gridStateManager.saveState(gridId, state2);

      const finalState = gridStateManager.loadState(gridId);
      expect(finalState).toEqual(state2); // Last write wins
    });

    it("should handle localStorage quota exceeded gracefully", () => {
      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

      // Mock setItem to throw quota exceeded error
      vi.mocked(localStorage.setItem).mockImplementation(() => {
        const error = new Error("QuotaExceededError");
        error.name = "QuotaExceededError";
        throw error;
      });

      expect(() => {
        gridStateManager.saveState("quota-test", { large: "data" });
      }).not.toThrow();

      expect(consoleSpy).toHaveBeenCalled();
      consoleSpy.mockRestore();
    });

    it("should handle circular reference objects", () => {
      const circularObj: any = { name: "test" };
      circularObj.self = circularObj;

      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});

      expect(() => {
        gridStateManager.saveState("circular-test", circularObj);
      }).not.toThrow();

      expect(consoleSpy).toHaveBeenCalled();
      consoleSpy.mockRestore();
    });

    it("should handle malformed localStorage data during iteration", () => {
      // Add some malformed data directly to localStorage
      mockLocalStorage["GRID_LAYOUT_malformed1"] = "not-json";
      mockLocalStorage["GRID_LAYOUT_malformed2"] = '{"incomplete":';
      mockLocalStorage["other-key"] = "should-be-ignored";

      expect(() => {
        gridStateManager.clearExpiredStates();
      }).not.toThrow();

      // Malformed grid data should be cleaned up
      expect(mockLocalStorage["GRID_LAYOUT_malformed1"]).toBeUndefined();
      expect(mockLocalStorage["GRID_LAYOUT_malformed2"]).toBeUndefined();
      // Non-grid data should remain
      expect(mockLocalStorage["other-key"]).toBe("should-be-ignored");
    });
  });
});
