import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { Router } from "react-router-dom";
import { createMemoryHistory } from "history";
import { Context } from "../Context/AppContext";
import { ErrorBoundary } from "react-error-boundary";
import Products from "../pages/receipts-manager/Products";
import GlobalModalComponent from "../components/SharedComponents/Modals/globalModal";
import { ModalDataType } from "../api/services/receipts-services/ServicesInterfaces";
import * as productService from "../api/services/receipts-services/ProductService";
import * as allocationService from "../api/services/receipts-services/AllocationService";
import { useParams, useNavigate } from "react-router-dom";
import { SelectionChangedEvent, GridApi } from "ag-grid-community";
import { RowDataInterfaces } from "../api/services/receipts-services/ServicesInterfaces";

// Mock react-router-dom
vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual("react-router-dom");
  return {
    ...actual,
    useParams: vi.fn(),
    useNavigate: vi.fn(),
  };
});

// Mock the SearchPosition components
vi.mock("../components/SearchPosition", () => ({
  default: function MockSearchPosition() {
    return <div data-testid="search-position">Search Position Component</div>;
  },
}));

vi.mock("../components/SearchPosition/ProductSearch", () => ({
  default: function MockProductSearch() {
    return <div data-testid="product-search">Product Search Component</div>;
  },
}));

vi.mock("../components/SearchPosition/EditPosition", () => ({
  default: function MockEditPosition() {
    return <div data-testid="edit-position">Edit Position Component</div>;
  },
}));

// Mock the AgGrid component
vi.mock("../components/SharedComponents/Grids/AgGrid", () => ({
  default: function MockAgGrid({
    rowData,
    onSelectionChanged,
    loading,
    loadingMessage,
    noRowsMessage,
  }: {
    rowData?: RowDataInterfaces[];
    onSelectionChanged?: (event: SelectionChangedEvent) => void;
    loading?: boolean;
    loadingMessage?: string;
    noRowsMessage?: string;
  }) {
    const mockGridApi = {
      getSelectedRows: () => rowData?.slice(0, 2) || [],
      getSelectedNodes: () =>
        (rowData?.slice(0, 2) || []).map((data) => ({
          data,
          group: false,
          allLeafChildren: [],
        })),
    } as unknown as GridApi;

    const createSelectionChangedEvent = (): SelectionChangedEvent => ({
      api: mockGridApi,
      source: "selectableChanged",
      context: {},
      type: "selectionChanged",
      selectedNodes: [],
      serverSideState: null,
    });

    return (
      <div data-testid="products-grid">
        {loading ? (
          <div data-testid="grid-loading">{loadingMessage}</div>
        ) : rowData && rowData.length > 0 ? (
          <div>
            {rowData.map((_, index) => (
              <button
                key={index}
                data-testid="grid-row-select"
                onClick={() =>
                  onSelectionChanged?.(createSelectionChangedEvent())
                }
              >
                Select Row {index + 1}
              </button>
            ))}
          </div>
        ) : (
          <div data-testid="grid-no-rows">{noRowsMessage}</div>
        )}
      </div>
    );
  },
}));

// Mock the SplitButton component
vi.mock("../components/SharedComponents/Buttons/SplitButton", () => ({
  default: function MockSplitButton({
    menuItems,
    disabled,
  }: {
    mainButtonIcon: React.ReactNode;
    menuItems: Array<{ text: string; onClick: () => void }>;
    disabled?: boolean;
  }) {
    return (
      <div data-testid="split-button">
        <button
          data-testid="main-button"
          disabled={disabled}
          onClick={menuItems[0]?.onClick}
        >
          Create Receipt
        </button>
        {menuItems.map((item, index) => (
          <button
            key={index}
            data-testid={`menu-item-${index}`}
            onClick={item.onClick}
          >
            {item.text}
          </button>
        ))}
      </div>
    );
  },
}));

// Mock the AnimationPopover component to avoid lottie dependency issues
vi.mock("../components/animations/AnimationPopover", () => ({
  default: function MockAnimationPopover({
    open,
    onClose,
  }: {
    open: boolean;
    anchorEl: HTMLElement | null;
    onClose: () => void;
  }) {
    if (!open) return null;
    return (
      <div data-testid="animation-popover">
        <button onClick={onClose}>Close Animation</button>
      </div>
    );
  },
}));

// Mock GlobalModalComponent
vi.mock("../components/SharedComponents/Modals/globalModal", () => ({
  default: function MockGlobalModal(props: any) {
    const [checkboxChecked, setCheckboxChecked] = React.useState(false);

    return props.open ? (
      <div data-testid="global-modal">
        <div>{props.modelData?.title}</div>
        <div>{props.modelData?.content1}</div>
        <div>{props.modelData?.content2}</div>
        {props.modelData?.checkbox && (
          <label>
            <input
              type="checkbox"
              data-testid="modal-checkbox"
              checked={checkboxChecked}
              onChange={(e) => setCheckboxChecked(e.target.checked)}
            />
            At least one product is Green-E and requires confirmation to
            proceed.
          </label>
        )}
        <button
          data-testid="modal-cancel"
          onClick={() => props.handleClose("cancel")}
        >
          {props.modelData?.cancelBtn}
        </button>
        <button
          data-testid="modal-confirm"
          disabled={props.modelData?.checkbox && !checkboxChecked}
          onClick={() => props.handleClose("confirm")}
        >
          {props.modelData?.confirmBtn}
        </button>
        {props.contentComponent}
      </div>
    ) : null;
  },
}));

// Mock services
vi.mock("../api/services/receipts-services/ProductService", () => ({
  getProducts: vi.fn(),
  createReceipt: vi.fn(),
}));

vi.mock("../api/services/receipts-services/AllocationService", () => ({
  getAllocationMini: vi.fn(),
}));

// Mock ModalData function
vi.mock("../components/SharedComponents/Grids/CommonUtils", () => ({
  ModalData: vi.fn().mockImplementation((messageType) => {
    console.log("ModalData called with:", messageType); // Debug log
    if (messageType === "chooseProduct") {
      // ModalMessageType.PRODUCT_CHOOSEBUTTON
      return Promise.resolve({
        type: "form",
        btn: "chooseproduct",
      });
    }
    if (messageType === "positionback") {
      // ModalMessageType.PRODUCT_BACK
      return Promise.resolve({
        title: "Go Back?",
        content1: "Are you sure you want to leave this screen?",
        content2:
          "You'll lose any work that you've done here and be returned to the previous step in the Receipt process.",
        cancelBtn: "NO, KEEP WORKING",
        confirmBtn: "YES, GO BACK",
        type: "alert",
      });
    }
    if (messageType === "positioncancel") {
      // ModalMessageType.PRODUCT_CANCEL
      return Promise.resolve({
        title: "Cancel Receipt?",
        content1: "Are you sure you want to cancel entire Receipt?",
        content2:
          "This will take you back to the Receipt home page. No changes made to Artemis or the Tracking System.",
        cancelBtn: "NO, KEEP WORKING",
        confirmBtn: "YES, CANCEL RECEIPT",
        type: "alert",
      });
    }
    // Default response for other cases
    return Promise.resolve({
      title: "Test Modal",
      content1: "Test Content",
      cancelBtn: "CANCEL",
      confirmBtn: "OK",
      type: "alert",
    });
  }),
}));

interface FakeContextType {
  data: unknown[];
  open: boolean;
  setOpen: (open: boolean) => void;
  setData: (value: unknown[]) => void;
}

describe("Products Component", () => {
  let fakeContext: FakeContextType;
  let history: ReturnType<typeof createMemoryHistory>;

  beforeEach(() => {
    fakeContext = {
      data: [],
      open: false,
      setOpen: vi.fn(),
      setData: vi.fn(),
    };

    history = createMemoryHistory({
      initialEntries: ["/products/123"],
    });

    // Mock useParams
    vi.mocked(useParams).mockReturnValue({ id: "123" });

    // Mock useNavigate
    vi.mocked(useNavigate).mockReturnValue(vi.fn());

    // Mock default service responses
    vi.mocked(allocationService.getAllocationMini).mockResolvedValue({
      allocationTransactionId: "123",
      receiptId: null,
    });

    vi.mocked(productService.getProducts).mockResolvedValue({
      data: [
        {
          id: "1",
          positionId: 1,
          productId: 1,
          product: "Test Product 1",
          quantity: 10,
          isManuallySelected: false,
          suggestedProducts: [],
          isConfirmationRequired: false,
        },
        {
          id: "2",
          positionId: 2,
          productId: 2,
          product: "Test Product 2",
          quantity: 20,
          isManuallySelected: false,
          suggestedProducts: [],
          isConfirmationRequired: true,
        },
      ],
    } as any);

    vi.mocked(productService.createReceipt).mockResolvedValue({
      data: "RECEIPT-123",
    } as any);
  });

  const renderComponent = () => {
    return render(
      <Context.Provider value={fakeContext}>
        <Router location={history.location} navigator={history}>
          <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
            <Products />
          </ErrorBoundary>
        </Router>
      </Context.Provider>
    );
  };

  describe("Component Rendering", () => {
    it("renders Products component with expected elements", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByText("Assign Products")).toBeInTheDocument();
        expect(screen.getByText("Assign Product")).toBeInTheDocument();
        expect(screen.getByText("Edit Positions")).toBeInTheDocument();
        expect(screen.getByText("Back")).toBeInTheDocument();
        expect(screen.getByText("Cancel")).toBeInTheDocument();
        expect(screen.getByText("Hide Rows with Products")).toBeInTheDocument();
      });
    });

    it("renders products grid", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("products-grid")).toBeInTheDocument();
      });
    });

    it("shows loading state initially", async () => {
      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("grid-loading")).toBeInTheDocument();
        expect(screen.getByText("Loading Allocations ...")).toBeInTheDocument();
      });
    });
  });

  describe("Button Interactions", () => {
    it("enables Assign Product button when products are selected", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBeGreaterThan(0);
      });

      const gridRows = screen.getAllByTestId("grid-row-select");
      fireEvent.click(gridRows[0]);

      await waitFor(() => {
        const assignButton = screen.getByText("Assign Product");
        expect(assignButton).toBeEnabled();
      });
    });

    it("enables Edit Positions button when products are selected", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBeGreaterThan(0);
      });

      const gridRows = screen.getAllByTestId("grid-row-select");
      fireEvent.click(gridRows[0]);

      await waitFor(() => {
        const editButton = screen.getByText("Edit Positions");
        expect(editButton).toBeEnabled();
      });
    });

    it("disables buttons when receipt is created", async () => {
      // Mock allocation service to return a receipt ID
      vi.mocked(allocationService.getAllocationMini).mockResolvedValue({
        allocationTransactionId: "123",
        receiptId: "RECEIPT-123",
      });

      renderComponent();

      await waitFor(() => {
        const assignButton = screen.getByText("Assign Product");
        const editButton = screen.getByText("Edit Positions");
        const backButton = screen.getByText("Back");
        const cancelButton = screen.getByText("Cancel");

        expect(assignButton).toBeDisabled();
        expect(editButton).toBeDisabled();
        expect(backButton).toBeDisabled();
        expect(cancelButton).toBeDisabled();
      });
    });
  });

  describe("Modal Interactions", () => {
    it("renders back button and can be clicked", async () => {
      renderComponent();

      await waitFor(() => {
        const backButton = screen.getByText("Back");
        expect(backButton).toBeInTheDocument();
      });

      const backButton = screen.getByText("Back");
      expect(backButton).toBeInTheDocument();
      fireEvent.click(backButton);
    });

    it("renders cancel button and can be clicked", async () => {
      renderComponent();

      await waitFor(() => {
        const cancelButton = screen.getByText("Cancel");
        expect(cancelButton).toBeInTheDocument();
      });

      const cancelButton = screen.getByText("Cancel");
      expect(cancelButton).toBeInTheDocument();
      fireEvent.click(cancelButton);
    });

    it("renders create receipt button and can be clicked", async () => {
      renderComponent();

      await waitFor(() => {
        const createButton = screen.getByTestId("main-button");
        expect(createButton).toBeInTheDocument();
      });

      const createButton = screen.getByTestId("main-button");
      expect(createButton).toBeInTheDocument();
      fireEvent.click(createButton);
    });
  });

  describe("Grid Functionality", () => {
    it("displays products in grid", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBe(2);
      });
    });

    it("handles product selection", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        fireEvent.click(gridRows[0]);
      });

      // Verify selection was handled
      expect(screen.getByTestId("products-grid")).toBeInTheDocument();
    });

    it("shows no rows message when no products available", async () => {
      vi.mocked(productService.getProducts).mockResolvedValue({
        data: [],
      } as any);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("grid-no-rows")).toBeInTheDocument();
        expect(
          screen.getByText("No Allocations Available")
        ).toBeInTheDocument();
      });
    });
  });

  describe("Receipt Creation", () => {
    it("creates partial receipt successfully", async () => {
      renderComponent();

      await waitFor(() => {
        const partialButton = screen.getByTestId("menu-item-0");
        fireEvent.click(partialButton);
      });

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });

    it("creates full receipt successfully", async () => {
      renderComponent();

      await waitFor(() => {
        const fullButton = screen.getByTestId("menu-item-1");
        fireEvent.click(fullButton);
      });

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });

    it("shows success alert when receipt is created", async () => {
      vi.mocked(allocationService.getAllocationMini).mockResolvedValue({
        allocationTransactionId: "123",
        receiptId: "RECEIPT-123",
      });

      renderComponent();

      await waitFor(() => {
        expect(
          screen.getByText("Artemis Receipt 'RECEIPT-123' created!")
        ).toBeInTheDocument();
      });
    });
  });

  describe("Error Handling", () => {
    it("handles API error gracefully", async () => {
      vi.mocked(productService.getProducts).mockRejectedValue(
        new Error("API Error")
      );

      renderComponent();

      // The error boundary should catch the error and show the error component
      await waitFor(() => {
        expect(screen.getByText("Error")).toBeInTheDocument();
      });
    });

    it("handles create receipt error gracefully", async () => {
      vi.mocked(productService.createReceipt).mockRejectedValue(
        new Error("Create failed")
      );

      renderComponent();

      await waitFor(() => {
        const createButton = screen.getByTestId("main-button");
        expect(createButton).toBeInTheDocument();
      });

      const createButton = screen.getByTestId("main-button");
      expect(createButton).toBeInTheDocument();
      fireEvent.click(createButton);
    });
  });

  describe("Context Integration", () => {
    it("handles product selection in grid", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBeGreaterThan(0);
      });

      const gridRows = screen.getAllByTestId("grid-row-select");
      fireEvent.click(gridRows[0]);

      // Verify grid interaction works
      expect(screen.getByTestId("products-grid")).toBeInTheDocument();
    });

    it("loads products on component mount", async () => {
      renderComponent();

      // Verify that products are loaded on mount
      await waitFor(() => {
        expect(productService.getProducts).toHaveBeenCalled();
      });
    });
  });

  describe("Additional Coverage Tests", () => {
    it("handles hideRowsWithProducts toggle correctly", async () => {
      renderComponent();

      await waitFor(() => {
        const hideSwitch = screen.getByLabelText(/Hide Rows with Products/i);
        expect(hideSwitch).toBeInTheDocument();
        expect(hideSwitch).not.toBeChecked();
      });

      const hideSwitch = screen.getByLabelText(/Hide Rows with Products/i);
      fireEvent.click(hideSwitch);
      expect(hideSwitch).toBeChecked();

      fireEvent.click(hideSwitch);
      expect(hideSwitch).not.toBeChecked();
    });

    it("handles product assignment modal opening", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        fireEvent.click(gridRows[0]);
      });

      const assignButton = screen.getByText("Assign Product");
      fireEvent.click(assignButton);

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });

    it("handles edit positions modal opening", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        fireEvent.click(gridRows[0]);
      });

      const editButton = screen.getByText("Edit Positions");
      fireEvent.click(editButton);

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });

    it("handles create receipt with confirmation", async () => {
      renderComponent();

      // First select a product (this might be required for the function to work)
      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        if (gridRows.length > 0) {
          fireEvent.click(gridRows[0]);
        }
      });

      await waitFor(() => {
        const createButton = screen.getByTestId("main-button");
        fireEvent.click(createButton);
      });

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });

    it("handles modal close with confirm", async () => {
      fakeContext.open = true;
      renderComponent();

      const modal = screen.getByTestId("global-modal");
      expect(modal).toBeInTheDocument();

      const confirmButton = screen.getByTestId("modal-confirm");
      fireEvent.click(confirmButton);

      expect(fakeContext.setOpen).toHaveBeenCalledWith(false);
    });

    it("handles modal close with cancel", async () => {
      fakeContext.open = true;
      renderComponent();

      const modal = screen.getByTestId("global-modal");
      expect(modal).toBeInTheDocument();

      const cancelButton = screen.getByTestId("modal-cancel");
      fireEvent.click(cancelButton);

      expect(fakeContext.setOpen).toHaveBeenCalledWith(false);
    });

    it("handles create receipt with partial selection", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        fireEvent.click(gridRows[0]);
      });

      const partialButton = screen.getByTestId("menu-item-0");
      fireEvent.click(partialButton);

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });

    it("handles create receipt with full selection", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        fireEvent.click(gridRows[0]);
      });

      const fullButton = screen.getByTestId("menu-item-1");
      fireEvent.click(fullButton);

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });

    it("handles loading state correctly", async () => {
      vi.mocked(productService.getProducts).mockImplementation(
        () => new Promise(() => { }) // Never resolves
      );

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("grid-loading")).toBeInTheDocument();
        expect(screen.getByText("Loading Allocations ...")).toBeInTheDocument();
      });
    });

    it("handles empty products array", async () => {
      vi.mocked(productService.getProducts).mockResolvedValue({
        data: [],
      } as any);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("grid-no-rows")).toBeInTheDocument();
        expect(
          screen.getByText("No Allocations Available")
        ).toBeInTheDocument();
      });
    });

    it("handles products with confirmation required", async () => {
      vi.mocked(productService.getProducts).mockResolvedValue({
        data: [
          {
            id: "1",
            positionId: 1,
            productId: 1,
            product: "Test Product 1",
            quantity: 10,
            isManuallySelected: false,
            suggestedProducts: [],
            isConfirmationRequired: true,
          },
        ],
      } as any);

      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBe(1);
      });
    });

    it("handles products with suggested products", async () => {
      vi.mocked(productService.getProducts).mockResolvedValue({
        data: [
          {
            id: "1",
            positionId: 1,
            productId: 1,
            product: "Test Product 1",
            quantity: 10,
            isManuallySelected: false,
            suggestedProducts: [
              {
                productId: 2,
                product: "Suggested Product",
                quantity: 5,
              },
            ],
            isConfirmationRequired: false,
          },
        ],
      } as any);

      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBe(1);
      });
    });

    it("handles products with manual selection", async () => {
      vi.mocked(productService.getProducts).mockResolvedValue({
        data: [
          {
            id: "1",
            positionId: 1,
            productId: 1,
            product: "Test Product 1",
            quantity: 10,
            isManuallySelected: true,
            suggestedProducts: [],
            isConfirmationRequired: false,
          },
        ],
      } as any);

      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBe(1);
      });
    });

    it("handles grid selection changes", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBe(2);
      });

      const gridRows = screen.getAllByTestId("grid-row-select");
      fireEvent.click(gridRows[0]);

      // Verify selection was handled
      expect(screen.getByTestId("products-grid")).toBeInTheDocument();
    });

    it("handles multiple grid selections", async () => {
      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBe(2);
      });

      const gridRows = screen.getAllByTestId("grid-row-select");
      fireEvent.click(gridRows[0]);
      fireEvent.click(gridRows[1]);

      // Verify multiple selections were handled
      expect(screen.getByTestId("products-grid")).toBeInTheDocument();
    });

    it("handles grid selection with no onSelectionChanged callback", async () => {
      // Mock AgGrid without onSelectionChanged using vi.mock
      vi.doMock("../components/SharedComponents/Grids/AgGrid", () => ({
        default: ({ rowData, loading, loadingMessage, noRowsMessage }: any) => {
          return (
            <div data-testid="products-grid">
              {loading ? (
                <div data-testid="grid-loading">{loadingMessage}</div>
              ) : rowData && rowData.length > 0 ? (
                <div>
                  {rowData.map((_: any, index: number) => (
                    <button
                      key={index}
                      data-testid="grid-row-select"
                      onClick={() => { }} // No callback
                    >
                      Select Row {index + 1}
                    </button>
                  ))}
                </div>
              ) : (
                <div data-testid="grid-no-rows">{noRowsMessage}</div>
              )}
            </div>
          );
        },
      }));

      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBe(2);
      });

      const gridRows = screen.getAllByTestId("grid-row-select");
      fireEvent.click(gridRows[0]);

      // Should not throw error
      expect(screen.getByTestId("products-grid")).toBeInTheDocument();
    });

    it("handles error boundary fallback", async () => {
      // Create a component that throws an error
      const ErrorThrowingComponent = () => {
        throw new Error("Test error");
      };

      // Render with the error-throwing component instead of the normal Products component
      render(
        <Context.Provider value={fakeContext}>
          <Router location={history.location} navigator={history}>
            <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
              <ErrorThrowingComponent />
            </ErrorBoundary>
          </Router>
        </Context.Provider>
      );

      await waitFor(() => {
        expect(screen.getByText("Error")).toBeInTheDocument();
      });
    });

    it("handles missing allocation data", async () => {
      vi.mocked(allocationService.getAllocationMini).mockResolvedValue({
        allocationTransactionId: "123",
        receiptId: null,
      });

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("products-grid")).toBeInTheDocument();
      });
    });

    it("handles allocation data with receipt ID", async () => {
      vi.mocked(allocationService.getAllocationMini).mockResolvedValue({
        allocationTransactionId: "123",
        receiptId: "RECEIPT-123",
      });

      renderComponent();

      await waitFor(() => {
        expect(
          screen.getByText("Artemis Receipt 'RECEIPT-123' created!")
        ).toBeInTheDocument();
      });
    });

    it("handles product service error", async () => {
      vi.mocked(productService.getProducts).mockRejectedValue(
        new Error("Product service error")
      );

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText("Error")).toBeInTheDocument();
      });
    });

    it("handles allocation service error", async () => {
      vi.mocked(allocationService.getAllocationMini).mockRejectedValue(
        new Error("Allocation service error")
      );

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText("Error")).toBeInTheDocument();
      });
    });

    it("handles create receipt service error", async () => {
      vi.mocked(productService.createReceipt).mockRejectedValue(
        new Error("Create receipt error")
      );

      renderComponent();

      await waitFor(() => {
        const createButton = screen.getByTestId("main-button");
        fireEvent.click(createButton);
      });

      // Should handle error gracefully
      expect(screen.getByTestId("products-grid")).toBeInTheDocument();
    });
  });

  describe("Edge Cases and Error Scenarios", () => {
    it("handles undefined product data", async () => {
      vi.mocked(productService.getProducts).mockResolvedValue({
        data: undefined,
      } as any);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("grid-no-rows")).toBeInTheDocument();
      });
    });

    it("handles null product data", async () => {
      vi.mocked(productService.getProducts).mockResolvedValue({
        data: null,
      } as any);

      renderComponent();

      await waitFor(() => {
        expect(screen.getByTestId("grid-no-rows")).toBeInTheDocument();
      });
    });

    it("handles malformed product data", async () => {
      vi.mocked(productService.getProducts).mockResolvedValue({
        data: [
          {
            // Missing required fields
            id: "1",
          },
        ],
      } as any);

      renderComponent();

      await waitFor(() => {
        const gridRows = screen.getAllByTestId("grid-row-select");
        expect(gridRows.length).toBe(1);
      });
    });

    it("handles network timeout", async () => {
      vi.mocked(productService.getProducts).mockImplementation(
        () =>
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error("Network timeout")), 100)
          )
      );

      renderComponent();

      await waitFor(() => {
        expect(screen.getByText("Error")).toBeInTheDocument();
      });
    });

    it("handles concurrent API calls", async () => {
      let callCount = 0;
      vi.mocked(productService.getProducts).mockImplementation(
        () =>
          new Promise((resolve) => {
            callCount++;
            setTimeout(
              () =>
                resolve({
                  data: [
                    {
                      id: `${callCount}`,
                      positionId: callCount,
                      productId: callCount,
                      product: `Product ${callCount}`,
                      quantity: 10,
                      isManuallySelected: false,
                      suggestedProducts: [],
                      isConfirmationRequired: false,
                    },
                  ],
                } as any),
              50
            );
          })
      );

      renderComponent();
      renderComponent(); // Render twice to trigger concurrent calls

      await waitFor(() => {
        expect(callCount).toBe(2);
      });
    });
  });
});

describe("GlobalModalComponent - Checkbox Functionality", () => {
  const mockHandleClose = vi.fn();

  const defaultProps = {
    open: true,
    handleClose: mockHandleClose,
    modelData: {
      title: "Create Receipt?",
      content1: "Are you sure you want to create a new Receipt?",
      cancelBtn: "NO, KEEP WORKING",
      confirmBtn: "YES, CREATE RECEIPT",
      checkbox: true,
    } as ModalDataType,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders checkbox when checkbox property is true", () => {
    render(<GlobalModalComponent {...defaultProps} />);

    const checkbox = screen.getByRole("checkbox");
    expect(checkbox).toBeInTheDocument();
    expect(checkbox).not.toBeChecked();
  });

  it("displays correct label for checkbox", () => {
    render(<GlobalModalComponent {...defaultProps} />);

    expect(
      screen.getByText(
        /At least one product is Green-E and requires confirmation to proceed/
      )
    ).toBeInTheDocument();
  });

  it("checkbox can be checked and unchecked", () => {
    render(<GlobalModalComponent {...defaultProps} />);
    const checkbox = screen.getByRole("checkbox");
    fireEvent.click(checkbox);
    expect(checkbox).toBeChecked();
    fireEvent.click(checkbox);
    expect(checkbox).not.toBeChecked();
  });

  it("confirm button is disabled when checkbox is unchecked", () => {
    render(<GlobalModalComponent {...defaultProps} />);

    const confirmButton = screen.getByText("YES, CREATE RECEIPT");
    expect(confirmButton).toBeDisabled();
  });

  it("confirm button is enabled when checkbox is checked", () => {
    render(<GlobalModalComponent {...defaultProps} />);
    const checkbox = screen.getByRole("checkbox");
    const confirmButton = screen.getByText("YES, CREATE RECEIPT");
    expect(confirmButton).toBeDisabled();
    fireEvent.click(checkbox);
    expect(confirmButton).toBeEnabled();
  });

  it("calls handleClose with confirm when confirm button is clicked with checked checkbox", () => {
    render(<GlobalModalComponent {...defaultProps} />);

    const checkbox = screen.getByRole("checkbox");
    const confirmButton = screen.getByText("YES, CREATE RECEIPT");
    fireEvent.click(checkbox);
    fireEvent.click(confirmButton);
    expect(mockHandleClose).toHaveBeenCalledWith("confirm");
  });

  it("does not call handleClose when confirm button is clicked without checking checkbox", () => {
    render(<GlobalModalComponent {...defaultProps} />);

    const confirmButton = screen.getByText("YES, CREATE RECEIPT");
    expect(confirmButton).toBeDisabled();
    fireEvent.click(confirmButton);
    expect(mockHandleClose).not.toHaveBeenCalled();
  });

  it("does not render checkbox when checkbox property is false", () => {
    const propsWithoutCheckbox = {
      ...defaultProps,
      modelData: {
        ...defaultProps.modelData,
        checkbox: false,
      },
    };

    render(<GlobalModalComponent {...propsWithoutCheckbox} />);

    expect(screen.queryByRole("checkbox")).not.toBeInTheDocument();
  });

  it("shows correct modal title and content", () => {
    render(<GlobalModalComponent {...defaultProps} />);

    expect(screen.getByText("Create Receipt?")).toBeInTheDocument();
    expect(
      screen.getByText("Are you sure you want to create a new Receipt?")
    ).toBeInTheDocument();
  });
});
