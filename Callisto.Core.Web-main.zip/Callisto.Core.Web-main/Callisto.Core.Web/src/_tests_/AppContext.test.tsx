import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { Context, Provider as AppProvider } from "../Context/AppContext";
import { ErrorBoundary } from "react-error-boundary";

describe("AppContext", () => {
  describe("AppProvider Component", () => {
    it("renders children correctly", async () => {
      render(
        <AppProvider>
          <div data-testid="test-child">Test Child</div>
        </AppProvider>
      );

      await waitFor(() => {
        expect(screen.getByTestId("test-child")).toBeInTheDocument();
      });
    });

    it("provides context values", async () => {
      let contextValue: any = null;
      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) throw new Error("Context not found");
        contextValue = context;
        return <div data-testid="test-component">Test</div>;
      };

      render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      await waitFor(() => {
        expect(contextValue).toBeDefined();
        expect(contextValue.data).toEqual([]);
        expect(contextValue.open).toBe(false);
        expect(typeof contextValue.setOpen).toBe("function");
        expect(typeof contextValue.setData).toBe("function");
      });
    });

    it("handles setOpen function", async () => {
      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) return <div>No Context</div>;
        return (
          <div>
            <button
              data-testid="set-open-button"
              onClick={() => context.setOpen(true)}
            >
              Set Open
            </button>
            <div data-testid="open-value">{context.open.toString()}</div>
          </div>
        );
      };

      render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      await waitFor(() => {
        expect(screen.getByTestId("open-value")).toHaveTextContent("false");
      });

      const setOpenButton = screen.getByTestId("set-open-button");
      fireEvent.click(setOpenButton);

      await waitFor(() => {
        expect(screen.getByTestId("open-value")).toHaveTextContent("true");
      });
    });

    it("handles setData function", async () => {
      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) return <div>No Context</div>;
        return (
          <div>
            <button
              data-testid="set-data-button"
              onClick={() => context.setData([1, 2, 3])}
            >
              Set Data
            </button>
            <div data-testid="data-value">{context.data.length}</div>
          </div>
        );
      };

      render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      await waitFor(() => {
        expect(screen.getByTestId("data-value")).toHaveTextContent("0");
      });

      const setDataButton = screen.getByTestId("set-data-button");
      fireEvent.click(setDataButton);

      await waitFor(() => {
        expect(screen.getByTestId("data-value")).toHaveTextContent("3");
      });
    });

    it("maintains state across re-renders", async () => {
      let contextValue: any = null;

      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) return <div>No Context</div>;
        contextValue = context;
        return (
          <div>
            <button
              data-testid="set-open-button"
              onClick={() => context.setOpen(true)}
            >
              Set Open
            </button>
            <button
              data-testid="set-data-button"
              onClick={() => context.setData(["test"])}
            >
              Set Data
            </button>
            <div data-testid="open-value">{context.open.toString()}</div>
            <div data-testid="data-value">{context.data.length}</div>
          </div>
        );
      };

      render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      // Set both values
      fireEvent.click(screen.getByTestId("set-open-button"));
      fireEvent.click(screen.getByTestId("set-data-button"));

      await waitFor(() => {
        expect(screen.getByTestId("open-value")).toHaveTextContent("true");
        expect(screen.getByTestId("data-value")).toHaveTextContent("1");
      });

      // Verify context value is updated
      expect(contextValue.open).toBe(true);
      expect(contextValue.data).toEqual(["test"]);
    });

    it("handles multiple state updates", async () => {
      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) return <div>No Context</div>;
        return (
          <div>
            <button
              data-testid="update-button"
              onClick={() => {
                context.setOpen(true);
                context.setData([1, 2, 3]);
              }}
            >
              Update Both
            </button>
            <div data-testid="open-value">{context.open.toString()}</div>
            <div data-testid="data-value">{context.data.length}</div>
          </div>
        );
      };

      render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      fireEvent.click(screen.getByTestId("update-button"));

      await waitFor(() => {
        expect(screen.getByTestId("open-value")).toHaveTextContent("true");
        expect(screen.getByTestId("data-value")).toHaveTextContent("3");
      });
    });

    it("handles complex data types", async () => {
      let contextValue: any = null;

      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) return <div>No Context</div>;
        contextValue = context;
        return (
          <div>
            <button
              data-testid="set-complex-data-button"
              onClick={() =>
                context.setData([
                  { id: 1, name: "Item 1" },
                  { id: 2, name: "Item 2" },
                ])
              }
            >
              Set Complex Data
            </button>
            <div data-testid="data-value">{context.data.length}</div>
          </div>
        );
      };

      render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      fireEvent.click(screen.getByTestId("set-complex-data-button"));

      await waitFor(() => {
        expect(screen.getByTestId("data-value")).toHaveTextContent("2");
      });

      expect(contextValue.data).toEqual([
        { id: 1, name: "Item 1" },
        { id: 2, name: "Item 2" },
      ]);
    });

    it("handles empty data array", async () => {
      let contextValue: any = null;

      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) return <div>No Context</div>;
        contextValue = context;
        return (
          <div>
            <button
              data-testid="set-empty-data-button"
              onClick={() => context.setData([])}
            >
              Set Empty Data
            </button>
            <div data-testid="data-value">{context.data.length}</div>
          </div>
        );
      };

      render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      fireEvent.click(screen.getByTestId("set-empty-data-button"));

      await waitFor(() => {
        expect(screen.getByTestId("data-value")).toHaveTextContent("0");
      });

      expect(contextValue.data).toEqual([]);
    });

    it("handles null data", async () => {
      let contextValue: any = null;

      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) return <div>No Context</div>;
        contextValue = context;
        return (
          <div>
            <button
              data-testid="set-null-data-button"
              onClick={() => context.setData(null as any)}
            >
              Set Null Data
            </button>
            <div data-testid="data-value">
              {context.data ? context.data.length : "null"}
            </div>
          </div>
        );
      };

      render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      fireEvent.click(screen.getByTestId("set-null-data-button"));

      await waitFor(() => {
        expect(screen.getByTestId("data-value")).toHaveTextContent("null");
      });

      expect(contextValue.data).toBeNull();
    });
  });

  describe("Context Usage", () => {
    it("handles undefined context gracefully", () => {
      const TestComponent = () => {
        const context = React.useContext(Context);
        if (!context) return <div>No Context</div>;
        return <div>Test</div>;
      };

      render(<TestComponent />);
      expect(screen.getByText("No Context")).toBeInTheDocument();
    });

    it("provides stable function references", async () => {
      let contextValue: any = null;
      let renderCount = 0;

      const TestComponent = () => {
        const context = React.useContext(Context);
        contextValue = context;
        renderCount++;
        return <div data-testid="test-component">Test</div>;
      };

      const { rerender } = render(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      const initialSetOpen = contextValue.setOpen;
      const initialSetData = contextValue.setData;

      // Force re-render
      rerender(
        <AppProvider>
          <TestComponent />
        </AppProvider>
      );

      await waitFor(() => {
        expect(contextValue.setOpen).toBe(initialSetOpen);
        expect(contextValue.setData).toBe(initialSetData);
      });
    });
  });

  describe("Error Boundary Integration", () => {
    it("handles errors in child components", async () => {
      const ErrorComponent = () => {
        throw new Error("Test error");
      };

      render(
        <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
          <AppProvider>
            <ErrorComponent />
          </AppProvider>
        </ErrorBoundary>
      );

      await waitFor(() => {
        expect(screen.getByText("Error")).toBeInTheDocument();
      });
    });
  });
});
