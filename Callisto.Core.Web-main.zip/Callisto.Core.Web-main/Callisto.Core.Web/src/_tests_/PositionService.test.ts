import { describe, expect, vi, beforeEach, test } from "vitest";
import "@testing-library/jest-dom";
import * as PositionService from "../api/services/receipts-services/PositionService";
import {
  PositionData,
  TrackingSystemRegistrys,
} from "../api/services/receipts-services/ServicesInterfaces";
import { AxiosResponse } from "axios";

vi.mock("../api/services/receipts-services/PositionService", () => ({
  getCommodity: vi.fn(),
  getTrackingSystemRegistrys: vi.fn(),
  getPositionData: vi.fn(),
}));

const createMockAxiosResponse = <T>(data: T): AxiosResponse<T> => ({
  data,
  status: 200,
  statusText: "OK",
  headers: {},
  config: {} as any,
});

describe("PositionService", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  test("should get commodity successfully", async () => {
    const mockResponse = createMockAxiosResponse({ commodities: [] });
    vi.mocked(PositionService.getCommodity).mockResolvedValueOnce(mockResponse);

    const result = await PositionService.getCommodity();
    expect(result).toEqual(mockResponse);
    expect(PositionService.getCommodity).toHaveBeenCalled();
  });

  test("should handle errors when getting commodity", async () => {
    const mockError = new Error("API Error");
    vi.mocked(PositionService.getCommodity).mockRejectedValueOnce(mockError);

    await expect(PositionService.getCommodity()).rejects.toThrow("API Error");
    expect(PositionService.getCommodity).toHaveBeenCalled();
  });

  test("should get tracking system registries successfully", async () => {
    const mockParams: TrackingSystemRegistrys = {
      commodityId: "123",
      commodityName: "Test Commodity",
    };
    const mockResponse = createMockAxiosResponse({ registries: [] });
    vi.mocked(PositionService.getTrackingSystemRegistrys).mockResolvedValueOnce(
      mockResponse
    );

    const result = await PositionService.getTrackingSystemRegistrys(mockParams);
    expect(result).toEqual(mockResponse);
    expect(PositionService.getTrackingSystemRegistrys).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle errors when getting tracking system registries", async () => {
    const mockParams: TrackingSystemRegistrys = {
      commodityId: "123",
      commodityName: "Test Commodity",
    };
    const mockError = new Error("API Error");
    vi.mocked(PositionService.getTrackingSystemRegistrys).mockRejectedValueOnce(
      mockError
    );

    await expect(
      PositionService.getTrackingSystemRegistrys(mockParams)
    ).rejects.toThrow("API Error");
    expect(PositionService.getTrackingSystemRegistrys).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle empty tracking system registries", async () => {
    const mockParams: TrackingSystemRegistrys = {
      commodityId: "123",
      commodityName: "Test Commodity",
    };
    const mockResponse = createMockAxiosResponse({ registries: [] });
    vi.mocked(PositionService.getTrackingSystemRegistrys).mockResolvedValueOnce(
      mockResponse
    );

    const result = await PositionService.getTrackingSystemRegistrys(mockParams);
    expect(result).toEqual(mockResponse);
    expect(PositionService.getTrackingSystemRegistrys).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should get position data successfully", async () => {
    const mockParams: PositionData = {
      PositionSide: "Buy",
      CommodityId: "123",
      DeliveryExpectationsMonth: 3,
      DeliveryStatus: "Pending",
      PageSize: 10,
      PageNumber: 1,
      PaginationType: "page",
    };
    const mockResponse = createMockAxiosResponse({}).data;
    vi.mocked(PositionService.getPositionData).mockResolvedValueOnce(
      mockResponse
    );

    const result = await PositionService.getPositionData(mockParams);
    expect(result).toEqual(mockResponse);
    expect(PositionService.getPositionData).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when getting position data", async () => {
    const mockParams: PositionData = {
      PositionSide: "Buy",
      CommodityId: "123",
      DeliveryExpectationsMonth: 3,
      DeliveryStatus: "Pending",
      PageSize: 10,
      PageNumber: 1,
      PaginationType: "page",
    };
    const mockError = new Error("API Error");
    vi.mocked(PositionService.getPositionData).mockRejectedValueOnce(mockError);

    await expect(PositionService.getPositionData(mockParams)).rejects.toThrow(
      "API Error"
    );
    expect(PositionService.getPositionData).toHaveBeenCalledWith(mockParams);
  });

  test("should handle empty position data", async () => {
    const mockParams: PositionData = {
      PositionSide: "Buy",
      CommodityId: "123",
      DeliveryExpectationsMonth: 3,
      DeliveryStatus: "Pending",
      PageSize: 10,
      PageNumber: 1,
      PaginationType: "page",
    };
    const mockResponse = createMockAxiosResponse({}).data;
    vi.mocked(PositionService.getPositionData).mockResolvedValueOnce(
      mockResponse
    );

    const result = await PositionService.getPositionData(mockParams);
    expect(result).toEqual(mockResponse);
    expect(PositionService.getPositionData).toHaveBeenCalledWith(mockParams);
  });

  test("should handle partial position data parameters", async () => {
    const mockParams: PositionData = {
      PositionSide: "Buy",
      CommodityId: "123",
      DeliveryExpectationsMonth: 3,
      DeliveryStatus: "Pending",
      PageSize: 10,
      PageNumber: 1,
      PaginationType: "page",
    };
    const mockResponse = createMockAxiosResponse({}).data;
    vi.mocked(PositionService.getPositionData).mockResolvedValueOnce(
      mockResponse
    );

    const result = await PositionService.getPositionData(mockParams);
    expect(result).toEqual(mockResponse);
    expect(PositionService.getPositionData).toHaveBeenCalledWith(mockParams);
  });
});
