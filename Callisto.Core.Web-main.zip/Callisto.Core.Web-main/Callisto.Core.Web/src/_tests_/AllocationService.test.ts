import { describe, expect, vi, beforeEach, test } from "vitest";
import "@testing-library/jest-dom";
import * as AllocationService from "../api/services/receipts-services/AllocationService";
import {
  AllocationPositions,
  Allocations,
  CreateandRemoveItems,
  SuggestPositions,
  UpdateTransactions,
} from "../api/services/receipts-services/ServicesInterfaces";
import { AxiosResponse } from "axios";
import { AllocationSuggestResponse } from "@/api/types/receipts-types";

vi.mock("../api/services/receipts-services/AllocationService", () => ({
  getTransactions: vi.fn(),
  suggestPositions: vi.fn(),
  updateTransactions: vi.fn(),
  assignPositions: vi.fn(),
  positionsUndo: vi.fn(),
  getAllocations: vi.fn(),
  removeAllocations: vi.fn(),
}));

const createMockAxiosResponse = <T>(data: T): AxiosResponse<T> => ({
  data,
  status: 200,
  statusText: "OK",
  headers: {},
  config: {} as any,
});

describe("AllocationService", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  test("should get transactions successfully", async () => {
    const mockParams: CreateandRemoveItems = {
      positionIds: [1, 2],
      inboxTransactionIds: ["inbox1", "inbox2"],
      trackingSystem: "system1",
      allocationTransactionId: "alloc1",
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(AllocationService.getTransactions).mockResolvedValueOnce(
      mockResponse
    );

    const result = await AllocationService.getTransactions(mockParams);
    expect(result).toEqual(mockResponse);
    expect(AllocationService.getTransactions).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when getting transactions", async () => {
    const mockParams: CreateandRemoveItems = {
      positionIds: [1, 2],
      inboxTransactionIds: ["inbox1", "inbox2"],
      trackingSystem: "system1",
      allocationTransactionId: "alloc1",
    };
    const mockError = new Error("API Error");
    vi.mocked(AllocationService.getTransactions).mockRejectedValueOnce(
      mockError
    );

    await expect(AllocationService.getTransactions(mockParams)).rejects.toThrow(
      "API Error"
    );
    expect(AllocationService.getTransactions).toHaveBeenCalledWith(mockParams);
  });

  test("should suggest positions successfully", async () => {
    const mockParams: SuggestPositions = {
      allocationTransactionId: "alloc1",
      inboxTransactionIds: ["inbox1", "inbox2"],
    };
    const mockResponse: AllocationSuggestResponse = createMockAxiosResponse({
      inboxTransactionId: "inbox1",
      positionId: [1],
    }).data;
    vi.mocked(AllocationService.suggestPositions).mockResolvedValueOnce(
      mockResponse
    );

    const result = await AllocationService.suggestPositions(mockParams);
    expect(result).toEqual(mockResponse);
    expect(AllocationService.suggestPositions).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when suggesting positions", async () => {
    const mockParams: SuggestPositions = {
      allocationTransactionId: "alloc1",
      inboxTransactionIds: ["inbox1", "inbox2"],
    };
    const mockError = new Error("API Error");
    vi.mocked(AllocationService.suggestPositions).mockRejectedValueOnce(
      mockError
    );

    await expect(
      AllocationService.suggestPositions(mockParams)
    ).rejects.toThrow("API Error");
    expect(AllocationService.suggestPositions).toHaveBeenCalledWith(mockParams);
  });

  test("should update transactions successfully", async () => {
    const mockParams: UpdateTransactions = {
      transactionid: "trans1",
      positionIds: [1, 2],
      inboxTransactionIds: ["inbox1", "inbox2"],
      trackingSystem: "system1",
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(AllocationService.updateTransactions).mockResolvedValueOnce(
      mockResponse
    );

    const result = await AllocationService.updateTransactions(mockParams);
    expect(result).toEqual(mockResponse);
    expect(AllocationService.updateTransactions).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle errors when updating transactions", async () => {
    const mockParams: UpdateTransactions = {
      transactionid: "trans1",
      positionIds: [1, 2],
      inboxTransactionIds: ["inbox1", "inbox2"],
      trackingSystem: "system1",
    };
    const mockError = new Error("API Error");
    vi.mocked(AllocationService.updateTransactions).mockRejectedValueOnce(
      mockError
    );

    await expect(
      AllocationService.updateTransactions(mockParams)
    ).rejects.toThrow("API Error");
    expect(AllocationService.updateTransactions).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should assign positions successfully", async () => {
    const mockParams: AllocationPositions = {
      allocationTransactionId: "alloc1",
      assignedData: [
        {
          positionId: 1,
          inboxTransactionid: "inbox1",
          quantity: 10,
        },
      ],
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(AllocationService.assignPositions).mockResolvedValueOnce(
      mockResponse
    );

    const result = await AllocationService.assignPositions(mockParams);
    expect(result).toEqual(mockResponse);
    expect(AllocationService.assignPositions).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when assigning positions", async () => {
    const mockParams: AllocationPositions = {
      allocationTransactionId: "alloc1",
      assignedData: [
        {
          positionId: 1,
          inboxTransactionid: "inbox1",
          quantity: 10,
        },
      ],
    };
    const mockError = new Error("API Error");
    vi.mocked(AllocationService.assignPositions).mockRejectedValueOnce(
      mockError
    );

    await expect(AllocationService.assignPositions(mockParams)).rejects.toThrow(
      "API Error"
    );
    expect(AllocationService.assignPositions).toHaveBeenCalledWith(mockParams);
  });

  test("should undo positions successfully", async () => {
    const mockParams: Allocations = {
      allocationTransactionId: "alloc1",
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(AllocationService.positionsUndo).mockResolvedValueOnce(
      mockResponse
    );

    const result = await AllocationService.positionsUndo(mockParams);
    expect(result).toEqual(mockResponse);
    expect(AllocationService.positionsUndo).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when undoing positions", async () => {
    const mockParams: Allocations = {
      allocationTransactionId: "alloc1",
    };
    const mockError = new Error("API Error");
    vi.mocked(AllocationService.positionsUndo).mockRejectedValueOnce(mockError);

    await expect(AllocationService.positionsUndo(mockParams)).rejects.toThrow(
      "API Error"
    );
    expect(AllocationService.positionsUndo).toHaveBeenCalledWith(mockParams);
  });

  test("should get allocations successfully", async () => {
    const mockParams: Allocations = {
      allocationTransactionId: "alloc1",
    };
    const mockResponse = createMockAxiosResponse({}).data;
    vi.mocked(AllocationService.getAllocations).mockResolvedValueOnce(
      mockResponse
    );

    const result = await AllocationService.getAllocations(mockParams);
    expect(result).toEqual(mockResponse);
    expect(AllocationService.getAllocations).toHaveBeenCalledWith(mockParams);
  });

  test("should handle errors when getting allocations", async () => {
    const mockParams: Allocations = {
      allocationTransactionId: "alloc1",
    };
    const mockError = new Error("API Error");
    vi.mocked(AllocationService.getAllocations).mockRejectedValueOnce(
      mockError
    );

    await expect(AllocationService.getAllocations(mockParams)).rejects.toThrow(
      "API Error"
    );
    expect(AllocationService.getAllocations).toHaveBeenCalledWith(mockParams);
  });

  test("should remove allocations successfully", async () => {
    const mockParams: CreateandRemoveItems = {
      allocationTransactionId: "alloc1",
      positionIds: [1, 2],
      inboxTransactionIds: ["inbox1", "inbox2"],
      trackingSystem: "system1",
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(AllocationService.removeAllocations).mockResolvedValueOnce(
      mockResponse
    );

    const result = await AllocationService.removeAllocations(mockParams);
    expect(result).toEqual(mockResponse);
    expect(AllocationService.removeAllocations).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle errors when removing allocations", async () => {
    const mockParams: CreateandRemoveItems = {
      allocationTransactionId: "alloc1",
      positionIds: [1, 2],
      inboxTransactionIds: ["inbox1", "inbox2"],
      trackingSystem: "system1",
    };
    const mockError = new Error("API Error");
    vi.mocked(AllocationService.removeAllocations).mockRejectedValueOnce(
      mockError
    );

    await expect(
      AllocationService.removeAllocations(mockParams)
    ).rejects.toThrow("API Error");
    expect(AllocationService.removeAllocations).toHaveBeenCalledWith(
      mockParams
    );
  });

  test("should handle empty arrays in remove allocations", async () => {
    const mockParams: CreateandRemoveItems = {
      allocationTransactionId: "alloc1",
      positionIds: [],
      inboxTransactionIds: [],
      trackingSystem: "system1",
    };
    const mockResponse = createMockAxiosResponse({ success: true });
    vi.mocked(AllocationService.removeAllocations).mockResolvedValueOnce(
      mockResponse
    );

    const result = await AllocationService.removeAllocations(mockParams);
    expect(result).toEqual(mockResponse);
    expect(AllocationService.removeAllocations).toHaveBeenCalledWith(
      mockParams
    );
  });
});
