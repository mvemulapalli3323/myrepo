import { render, screen, waitFor } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { BrowserRouter } from "react-router-dom";
import { Context } from "../Context/AppContext";
import { ErrorBoundary } from "react-error-boundary";
import Navigation from "../components/Navigation";
import { useMsal } from "../hooks/useMsal";

// Mock the useMsal hook
vi.mock("../hooks/useMsal", () => ({
  useMsal: vi.fn(),
}));

// Mock the components
vi.mock("../components/SharedComponents/Modals/globalModal", () => ({
  default: function MockGlobalModal() {
    return <div data-testid="global-modal">Global Modal</div>;
  },
}));

vi.mock("../components/SharedComponents/Buttons/SplitButton", () => ({
  default: function MockSplitButton() {
    return <div data-testid="split-button">Split Button</div>;
  },
}));

// Mock react-router-dom
vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual("react-router-dom");
  return {
    ...actual,
    useNavigate: vi.fn(),
  };
});

import { useNavigate } from "react-router-dom";

interface FakeContextType {
  data: unknown[];
  open: boolean;
  setOpen: (open: boolean) => void;
  setData: (value: unknown[]) => void;
}

describe("Navigation Component", () => {
  let fakeContext: FakeContextType;
  let mockNavigate: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    fakeContext = {
      data: [],
      open: false,
      setOpen: vi.fn(),
      setData: vi.fn(),
    };

    mockNavigate = vi.fn();
    vi.mocked(useNavigate).mockReturnValue(mockNavigate);

    // Mock useMsal to return authenticated user
    vi.mocked(useMsal).mockReturnValue({
      instance: { pca: {} } as any,
      inProgress: "none" as any,
      isAuthReceiptsManager: true,
      isAuthDataManager: true,
      isAuthMappingManager: true,
      isAuthProcessManager: true,
      isDev: false,
      isAdmin: false,
      username: "Test User",
    });
  });

  const renderNavigation = () => {
    return render(
      <Context.Provider value={fakeContext}>
        <BrowserRouter>
          <ErrorBoundary FallbackComponent={() => <div>Error</div>}>
            <Navigation />
          </ErrorBoundary>
        </BrowserRouter>
      </Context.Provider>
    );
  };

  describe("Component Rendering", () => {
    it("renders Navigation component with expected elements", async () => {
      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("renders with proper layout", async () => {
      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });

  describe("Authentication States", () => {
    it("renders correctly for authenticated user", async () => {
      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("renders correctly for unauthenticated user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: null,
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });

  describe("User Role Handling", () => {
    it("renders correctly for dev user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: true,
        isAdmin: false,
        username: "Dev User",
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("renders correctly for admin user", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: true,
        isAuthMappingManager: true,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: true,
        username: "Admin User",
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });

  describe("Access Control", () => {
    it("handles receipts manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: true,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles data manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: true,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles mapping manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: true,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles process manager access", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "none" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: true,
        isDev: false,
        isAdmin: false,
        username: "User",
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });

  describe("Navigation Functionality", () => {
    it("handles navigation to different routes", async () => {
      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles logout functionality", async () => {
      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });

  describe("Error Handling", () => {
    it("handles component errors gracefully", async () => {
      // Mock a component to throw an error
      vi.mocked(useMsal).mockImplementation(() => {
        throw new Error("Test error");
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByText("Error")).toBeInTheDocument();
      });
    });
  });

  describe("Context Integration", () => {
    it("integrates with context correctly", async () => {
      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });

    it("handles context changes", async () => {
      renderNavigation();

      // Simulate context change
      fakeContext.setOpen(true);

      await waitFor(() => {
        expect(fakeContext.setOpen).toHaveBeenCalledWith(true);
      });
    });
  });

  describe("Loading States", () => {
    it("handles loading state correctly", async () => {
      vi.mocked(useMsal).mockReturnValue({
        instance: { pca: {} } as any,
        inProgress: "startup" as any,
        isAuthReceiptsManager: false,
        isAuthDataManager: false,
        isAuthMappingManager: false,
        isAuthProcessManager: false,
        isDev: false,
        isAdmin: false,
        username: null,
      });

      renderNavigation();

      await waitFor(() => {
        expect(screen.getByTestId("navigation")).toBeInTheDocument();
      });
    });
  });
});
