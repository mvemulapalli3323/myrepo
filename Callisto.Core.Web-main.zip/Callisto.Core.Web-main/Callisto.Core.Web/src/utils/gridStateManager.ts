/**
 * Centralized grid state management utility
 * Handles localStorage operations for AG Grid state persistence
 */

export interface GridStateManager {
    saveState(gridId: string, state: any): void;
    loadState(gridId: string): any | null;
    removeState(gridId: string): void;
    clearStatesForContext(contextPrefix: string): void;
    clearExpiredStates(maxAge?: number): void;
}

interface GridStateEntry {
    state: any;
    timestamp: number;
    version: string;
}

class LocalStorageGridStateManager implements GridStateManager {
    private readonly keyPrefix = 'GRID_LAYOUT_';
    private readonly version = '1.0';

    private getFullKey(gridId: string): string {
        return `${this.keyPrefix}${gridId}`;
    }

    saveState(gridId: string, state: any): void {
        try {
            const entry: GridStateEntry = {
                state,
                timestamp: Date.now(),
                version: this.version
            };

            const key = this.getFullKey(gridId);
            localStorage.setItem(key, JSON.stringify(entry));
        } catch (error) {
            console.warn(`Failed to save grid state for ${gridId}:`, error);
        }
    }

    loadState(gridId: string): any | null {
        try {
            const key = this.getFullKey(gridId);
            const stored = localStorage.getItem(key);

            if (!stored) return null;

            const entry: GridStateEntry = JSON.parse(stored);

            // Version check - if versions don't match, ignore the stored state
            if (entry.version !== this.version) {
                this.removeState(gridId);
                return null;
            }

            return entry.state;
        } catch (error) {
            console.warn(`Failed to load grid state for ${gridId}:`, error);
            this.removeState(gridId); // Clean up corrupted data
            return null;
        }
    }

    removeState(gridId: string): void {
        try {
            const key = this.getFullKey(gridId);
            localStorage.removeItem(key);
        } catch (error) {
            console.warn(`Failed to remove grid state for ${gridId}:`, error);
        }
    }

    clearStatesForContext(contextPrefix: string): void {
        try {
            const keysToRemove: string[] = [];

            // Find all localStorage keys that match our pattern and context
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && key.startsWith(this.keyPrefix) && key.includes(contextPrefix)) {
                    keysToRemove.push(key);
                }
            }

            // Remove the matched keys
            keysToRemove.forEach(key => localStorage.removeItem(key));
        } catch (error) {
            console.warn(`Failed to clear states for context ${contextPrefix}:`, error);
        }
    }

    clearExpiredStates(maxAge: number = 7 * 24 * 60 * 60 * 1000): void {
        try {
            const now = Date.now();
            const keysToRemove: string[] = [];

            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && key.startsWith(this.keyPrefix)) {
                    try {
                        const stored = localStorage.getItem(key);
                        if (stored) {
                            const entry: GridStateEntry = JSON.parse(stored);
                            if (now - entry.timestamp > maxAge) {
                                keysToRemove.push(key);
                            }
                        }
                    } catch {
                        // If we can't parse it, it's probably corrupted - remove it
                        keysToRemove.push(key);
                    }
                }
            }

            keysToRemove.forEach(key => localStorage.removeItem(key));
        } catch (error) {
            console.warn('Failed to clear expired grid states:', error);
        }
    }
}

// Export singleton instance
export const gridStateManager: GridStateManager = new LocalStorageGridStateManager();

// Helper hook for React components
export function useGridStateManager() {
    return gridStateManager;
} 