import React from "react";
import { Box } from "@mui/material";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";

interface AnimationComponent extends React.FC {
  animationLength: number;
  message: string;
}

const Bee2: AnimationComponent = () => {
  return (
    <Box>
      <DotLottieReact
        src="/animations/bee_2.lottie"
        autoplay
        speed={1}
        style={{
          width: 600,
          height: 300,
        }}
      />
    </Box>
  );
};

// Static metadata for this animation
Bee2.animationLength = 5;
Bee2.message = "You're a busy receipt bee!";

export default Bee2;
