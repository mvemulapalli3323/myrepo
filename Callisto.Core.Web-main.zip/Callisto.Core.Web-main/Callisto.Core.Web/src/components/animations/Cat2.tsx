import React from "react";
import { Box } from "@mui/material";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";

interface AnimationComponent extends React.FC {
  animationLength: number;
  message: string;
}

const Cat2: AnimationComponent = () => {
  return (
    <Box>
      <DotLottieReact
        src="/animations/cat_2.lottie"
        autoplay
        style={{
          width: 400,
          height: 300,
        }}
      />
    </Box>
  );
};

Cat2.animationLength = 8;
Cat2.message = "Rolling those receipts along!";

export default Cat2;
