import React, { useState, useEffect } from "react";
import { Box, Typography, LinearProgress, Popover } from "@mui/material";
import Bee1 from "./Bee1";
import Bee2 from "./Bee2";
import Cat1 from "./Cat1";
import Cat2 from "./Cat2";
import Cat3 from "./Cat3";

export interface AnimationPopoverProps {
  /** Whether the popover is visible */
  open: boolean;
  /** Anchor element for the popover */
  anchorEl: HTMLElement | null;
  /** Callback when popover closes */
  onClose: () => void;
  /** Anchor origin for the popover */
  anchorOrigin?: {
    vertical: "top" | "center" | "bottom";
    horizontal: "left" | "center" | "right";
  };
  /** Transform origin for the popover */
  transformOrigin?: {
    vertical: "top" | "center" | "bottom";
    horizontal: "left" | "center" | "right";
  };
}

/**
 * AnimationPopover Component
 *
 * A reusable popover component that displays a randomly selected animation with a countdown progress indicator.
 */
const AnimationPopover: React.FC<AnimationPopoverProps> = ({
  open,
  anchorEl,
  onClose,
  anchorOrigin = {
    vertical: "bottom",
    horizontal: "center",
  },
  transformOrigin = {
    vertical: "top",
    horizontal: "center",
  },
}) => {
  const [selectedAnimation, setSelectedAnimation] =
    useState<React.ComponentType | null>(null);
  const [animationLength, setAnimationLength] = useState(10);
  const [message, setMessage] = useState("");

  // Randomly select animation when popover opens
  useEffect(() => {
    if (open) {
      const animations = [Bee1, Bee2, Cat1, Cat2, Cat3];
      const randomAnimation =
        animations[Math.floor(Math.random() * animations.length)];
      setSelectedAnimation(() => randomAnimation);

      // Extract metadata from the selected animation
      const animationLength = randomAnimation.animationLength || 10;
      const message = (randomAnimation as any).message || "";
      setAnimationLength(animationLength);
      setMessage(message);
    }
  }, [open]);

  const [timeRemaining, setTimeRemaining] = useState(animationLength);

  // Timer effect for countdown with auto-close
  useEffect(() => {
    if (open) {
      setTimeRemaining(animationLength + 2);

      const startTime = Date.now();
      const timer = setInterval(() => {
        const elapsed = (Date.now() - startTime) / 1000;
        const remaining = Math.max(0, animationLength - elapsed);

        if (remaining <= 0) {
          onClose();
          return;
        }

        setTimeRemaining(remaining);
      }, 50);
      return () => {
        clearInterval(timer);
      };
    }
  }, [open, onClose, animationLength]);

  return (
    <Popover
      open={open}
      anchorEl={anchorEl}
      onClose={onClose}
      anchorOrigin={anchorOrigin}
      transformOrigin={transformOrigin}
      slotProps={{
        paper: {
          sx: {
            borderRadius: 2,
            backgroundColor: (theme) => theme.palette.background.paper,
            boxShadow: 3,
            p: 3,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            minWidth: 400,
          },
        },
      }}
    >
      {selectedAnimation && React.createElement(selectedAnimation)}
      {message && (
        <Typography variant="h6" color="text.primary" sx={{ mt: 2 }}>
          {message}
        </Typography>
      )}
      <Box
        sx={{
          width: "33.33%",
          mt: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <LinearProgress
          variant="determinate"
          value={Math.max(
            0,
            Math.min(100, (timeRemaining / animationLength) * 100)
          )}
          sx={{ mb: 1, width: "100%" }}
        />
      </Box>
    </Popover>
  );
};

export default AnimationPopover;
