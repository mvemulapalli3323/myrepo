import React from "react";
import { Box } from "@mui/material";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";

interface AnimationComponent extends React.FC {
  animationLength: number;
  message: string;
}

const Cat1: AnimationComponent = () => {
  return (
    <Box>
      <DotLottieReact
        src="/animations/cat_1.lottie"
        loop={true}
        autoplay
        style={{
          width: 500,
          height: 250,
        }}
      />
    </Box>
  );
};

Cat1.animationLength = 6;
Cat1.message = "Congratulations! You've won a cat in a box!";

export default Cat1;
