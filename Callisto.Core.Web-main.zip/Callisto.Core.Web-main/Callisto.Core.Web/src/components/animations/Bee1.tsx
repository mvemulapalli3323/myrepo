import React from "react";
import { Box } from "@mui/material";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";

interface AnimationComponent extends React.FC {
  animationLength: number;
  message: string;
}

const Bee1: AnimationComponent = () => {
  return (
    <Box>
      <DotLottieReact
        src="/animations/bee_1.lottie"
        autoplay
        loop={true}
        style={{
          width: 600,
          height: 300,
        }}
      />
    </Box>
  );
};

Bee1.animationLength = 5;
Bee1.message = "I see a new artemis receipt!";

export default Bee1;
