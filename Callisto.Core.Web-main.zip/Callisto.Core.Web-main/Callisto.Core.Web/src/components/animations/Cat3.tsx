import React from "react";
import { Box } from "@mui/material";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";

interface AnimationComponent extends React.FC {
  animationLength: number;
  message: string;
}

const Cat3: AnimationComponent = () => {
  return (
    <Box>
      <DotLottieReact
        src="/animations/cat_3.lottie"
        autoplay
        loop={true}
        style={{
          width: 400,
          height: 300,
        }}
      />
    </Box>
  );
};

// Static metadata for this animation
Cat3.animationLength = 6;
Cat3.message = "You are now authorized to dance!";

export default Cat3;
