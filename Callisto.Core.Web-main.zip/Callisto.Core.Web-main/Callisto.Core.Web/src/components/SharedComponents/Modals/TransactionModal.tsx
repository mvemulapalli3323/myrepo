import React, { useState, useEffect, useRef } from "react";
import ModalComponent from "./ModalComponent";
import {
  DialogActions,
  DialogContent,
  DialogTitle,
  Button,
  Alert,
  Box,
} from "@mui/material";
import AutomatedReceiptsGrid from "../Grids/AgGrid";
import { transactionColDefs } from "../Grids/GridColDefs";
import { getTransactionsForTrackingSystem } from "../../../api/services/receipts-services/TransactionService";
import { TrackingSystemInfo } from "@/api/services/receipts-services/ServicesInterfaces";
import { AxiosError } from "axios";

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (selectedRow: any) => Promise<void>;
  selectedTrackingSystemInfo: TrackingSystemInfo | null;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  selectedTrackingSystemInfo,
}) => {
  const [TransactionRowData, setTransactionRowData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedRow, setSelectedRow] = useState<any | null>(null);
  const [error, setError] = useState<string>("");

  const gridApiRef = useRef<any>(null);

  const onOkClick = async () => {
    setLoading(true);
    setError("");
    const allNodes: any[] = [];
    gridApiRef.current.forEachNode((node: any) => allNodes.push(node));
    const selectedRow = allNodes
      .filter((node) => node.isSelected())
      .map((node) => node.data);
    try {
      await onSubmit(selectedRow);
      setLoading(false);
      onClose();
    } catch (err) {
      let errorMessage = "Unable to proceed";
      if (err instanceof AxiosError) {
        errorMessage = err.message || err.response?.data || "Unable to proceed";
      }
      setError(errorMessage);
      setLoading(false);
    }
  };

  // Handle selection changes in the grid
  const onSelectionChanged = () => {
    if (gridApiRef.current) {
      const selected = gridApiRef.current.getSelectedRows();
      setSelectedRow(selected);
    }
  };

  useEffect(() => {
    const fetchTransactions = async () => {
      if (!isOpen) {
        return;
      }

      setLoading(true);
      setTransactionRowData([]);

      if (!selectedTrackingSystemInfo?.serviceName) {
        setLoading(false);
        return;
      }

      try {
        const response = await getTransactionsForTrackingSystem(
          selectedTrackingSystemInfo.serviceName
        );
        setTransactionRowData(response);
      } catch (err) {
        let errorMessage = "Unable to proceed";
        if (err instanceof AxiosError) {
          errorMessage =
            err.message || err.response?.data || "Unable to proceed";
        }
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [isOpen, selectedTrackingSystemInfo]);

  const rowClassRules = {
    "ag-row-selected": (params: any) => params.node.isSelected(),
  };

  useEffect(() => {
    if (gridApiRef.current) {
      gridApiRef.current.deselectAll();
      setSelectedRow(null);
    }
    if (isOpen) {
      setError("");
    }
  }, [TransactionRowData, isOpen]);

  const onGridReady = (params: any) => {
    gridApiRef.current = params.api;
    params.api.deselectAll();
    setSelectedRow(null);
  };

  return (
    <ModalComponent open={isOpen} onClose={onClose} draggable={true}>
      <DialogTitle
        sx={{ m: 0, p: 2, backgroundColor: "primary.main", color: "white" }}
        id="draggable-dialog-title"
      >
        Transactions
      </DialogTitle>
      <DialogContent sx={{ mt: 1 }}>
        <AutomatedReceiptsGrid
          data-testid="transactions-selection-grid"
          onColumnMoved={() => {}}
          onGridReady={onGridReady}
          rowData={TransactionRowData}
          colDefs={transactionColDefs}
          onSelectionChanged={onSelectionChanged}
          detailCellRendererParams={undefined}
          rowClassRules={rowClassRules}
          gridId="transactions-selection-grid"
          isRowSelectable={() => true}
          loadingMessage="Loading..."
          loading={loading}
        />
      </DialogContent>
      <DialogActions
        sx={{
          mr: 1,
          mb: 1,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        {error && (
          <Alert
            severity="error"
            onClose={() => setError("")}
            sx={{
              borderRadius: 2,
              backgroundColor: "error.main",
              color: "white",
              "& .MuiAlert-icon": {
                color: "white",
              },
              "& .MuiAlert-action": {
                color: "white",
              },
            }}
          >
            {error}
          </Alert>
        )}
        <Box sx={{ display: "flex", gap: 1, ml: "auto" }}>
          <Button variant="outlined" onClick={onClose} color="secondary">
            Cancel
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={onOkClick}
            disabled={selectedRow === null || selectedRow.length === 0}
          >
            Ok
          </Button>
        </Box>
      </DialogActions>
    </ModalComponent>
  );
};
