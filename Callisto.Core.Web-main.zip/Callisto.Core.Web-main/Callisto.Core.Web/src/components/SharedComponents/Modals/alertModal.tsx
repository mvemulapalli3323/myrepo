import React from "react";
import {
  Box,
  Button,
  Dialog,
  IconButton,
  Modal,
  styled,
  Theme,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

const style = {
  position: "absolute" as const,
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 200,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};
const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));
interface AlertModalComponentProps {
  open: boolean;
  handleClose: () => void;
}

const AlertModalComponent: React.FC<AlertModalComponentProps> = ({
  open,
  handleClose,
}) => {
  return (
    <BootstrapDialog
      onClose={handleClose}
      aria-labelledby="customized-dialog-title"
      open={open}
      maxWidth="xl"
      fullWidth={true}
    >
      <Modal
        open={open}
        // onClose={handleClose}
        aria-labelledby="modal-title"
        aria-describedby="modal-description"
        className="alert-modal"
        onClose={(_e, reason) => {
          if (reason !== "backdropClick") {
            handleClose();
          }
        }}
      >
        <Box sx={style}>
          {/* <CloseIcon /> */}
          <div className="" style={{ color: "#7578a0" }}>
            <div style={{ position: "relative" }}>
              <h3 className="mb-4" style={{ fontSize: "18px" }}>
                Reject Transfer
              </h3>
              <IconButton
                aria-label="close"
                onClick={handleClose}
                sx={(theme: Theme) => ({
                  position: "absolute",
                  right: -10,
                  top: -10,
                  color: theme.palette.grey[900],
                })}
              >
                <CloseIcon />
              </IconButton>
            </div>
            <div className="ps-3">
              <p className="mb-0" style={{ fontSize: "14px" }}>
                <b>Are you sure you want to reject this transfer?</b>
              </p>
              <p className="mb-0 mt-1" style={{ fontSize: "14px" }}>
                This will remove supply from the Tracking System and Return it
                to the sender.
              </p>
            </div>

            <div className="text-end mt-4">
              <Button
                className="gray-bg me-2"
                variant="contained"
                onClick={handleClose}
              >
                CANCEL
              </Button>
              <Button
                className="orange-bg"
                variant="contained"
                onClick={handleClose}
              >
                YES, REJECT THIS TRANSFER
              </Button>
            </div>
          </div>
        </Box>
      </Modal>
    </BootstrapDialog>
  );
};

export default AlertModalComponent;
