import React, { useEffect, useState } from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  styled,
  TextField,
  FormControlLabel,
  Checkbox,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import CheckIcon from "@mui/icons-material/Check";
import { ModalDataType } from "../../../api/services/receipts-services/ServicesInterfaces";
import ProductSearch from "../../SearchPosition/ProductSearch";
import EditPosition from "../../SearchPosition/EditPosition";

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
}));

/**
 * @deprecated Use ModalComponent instead.
 * @see {@link ModalComponent}
 */
interface GlobalModalComponentProps {
  open: boolean;
  handleClose: (
    data?: "close" | "cancel" | "confirm" | { quantity: number }
  ) => void;
  modelData: ModalDataType;
  contentComponent?: React.ReactNode;
}

/**
 * @deprecated Use ModalComponent instead.
 * @see {@link ModalComponent}
 */
const GlobalModalComponent: React.FC<GlobalModalComponentProps> = ({
  open,
  handleClose,
  modelData,
  contentComponent,
}) => {
  const [localData, setLocalData] = useState(modelData?.form?.data);
  const [checkboxChecked, setCheckboxChecked] = useState(false);

  useEffect(() => {
    setLocalData(modelData?.form?.data);
    setCheckboxChecked(false);
  }, [modelData, open]);

  const handleChange = (value: number) => {
    setLocalData({ number: value, quantity: modelData?.form?.data?.quantity });
  };

  return (
    <BootstrapDialog
      onClose={(_e, reason) => {
        if (reason !== "backdropClick") {
          handleClose("close");
        }
      }}
      aria-labelledby="customized-dialog-title"
      open={open}
      maxWidth={
        modelData?.type === "form" && modelData.btn === "editproduct"
          ? "sm"
          : modelData?.type === "form"
            ? "xl"
            : "sm"
      }
      fullWidth={true}
      className="alert-modal"
    >
      {modelData?.type === "form" &&
        (modelData.btn === "chooseproduct" ? (
          <ProductSearch />
        ) : (
          <EditPosition />
        ))}
      {modelData?.type !== "form" && (
        <>
          <DialogTitle
            component="h6"
            sx={{
              m: 0,
              ml: -1,
              bgcolor: "primary.main",
              color: "primary.contrastText",
            }}
            id="customized-dialog-title"
            data-testid="modal-title"
          >
            {modelData?.title}
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={() => handleClose("close")}
            sx={(theme) => ({
              position: "absolute",
              right: 8,
              top: 8,
              color: theme.palette.primary.contrastText,
            })}
          >
            <CloseIcon sx={{ fontSize: 24 }} />
          </IconButton>
          <DialogContent>
            <div className="">
              {contentComponent ? (
                contentComponent
              ) : (
                <>
                  {modelData?.content1 && (
                    <p className="mb-0 mb-1" style={{ fontSize: "16px" }}>
                      <b>{modelData.content1}</b>
                    </p>
                  )}
                  {modelData?.content2 && (
                    <p className="mb-0 mb-2" style={{ fontSize: "16px" }}>
                      {modelData.content2}
                    </p>
                  )}
                  {modelData?.form?.type === "number" && (
                    <>
                      <TextField
                        className="w-100"
                        label={modelData.form.label}
                        value={localData?.number}
                        error={false}
                        helperText=""
                        onChange={(e) => handleChange(Number(e.target.value))}
                        type="text"
                        variant="standard"
                      />
                      <p className="m-0">/{modelData.form.data?.quantity}</p>
                    </>
                  )}
                  {modelData?.checkbox && (
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={checkboxChecked}
                          onChange={(e) => setCheckboxChecked(e.target.checked)}
                          color="primary"
                        />
                      }
                      label="At least one product is Green-E and requires confirmation to proceed."
                      sx={{ mt: 2, alignItems: "flex-start" }}
                      labelPlacement="end"
                    />
                  )}
                </>
              )}
            </div>
          </DialogContent>
          <DialogActions>
            {modelData.cancelBtn && (
              <Button
                variant="outlined"
                color="secondary"
                onClick={() => handleClose("cancel")}
                sx={{ mr: 1 }}
              >
                {modelData.cancelBtn}
              </Button>
            )}
            {modelData?.form?.type === "number" && modelData?.confirmBtn && (
              <Button
                variant="contained"
                startIcon={<CheckIcon />}
                onClick={() =>
                  handleClose({
                    quantity:
                      localData?.number ?? modelData.form?.data?.quantity ?? 0,
                  })
                }
              >
                {modelData?.confirmBtn}
              </Button>
            )}
            {modelData?.form?.type !== "number" && modelData?.confirmBtn && (
              <Button
                variant="contained"
                startIcon={<CheckIcon />}
                onClick={() => handleClose("confirm")}
                disabled={modelData?.checkbox && !checkboxChecked}
              >
                {modelData?.confirmBtn}
              </Button>
            )}
          </DialogActions>
        </>
      )}
    </BootstrapDialog>
  );
};

/**
 * @deprecated Use ModalComponent instead.
 * @see {@link ModalComponent}
 */
export default GlobalModalComponent;
