export enum ModalMessageType {
  REJECT = "reject",
  POSITION_ERROR_ALERT = "positionErrorAlert",
  CONFIRM = "confirm",
  PRODUCT_BACK = "positionback",
  PRODUCT_CANCEL = "positioncancel",
  PRODUCT_CHOOSEBUTTON = "chooseProduct",
  ADD_POSITIONS = "addPositions",
  CREATE_RECEIPT = "createReceipt",
  ALLOCATE_QUANTITY = "allocateQuantity",
}
