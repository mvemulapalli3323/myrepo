import React from "react";
import { Dialog, styled, Paper } from "@mui/material";
import { createPortal } from "react-dom";
import Draggable from "react-draggable";

const MuiDialog = styled(Dialog)(({ theme }) => ({
  "& .MuiDialogContent-root": {
    padding: theme.spacing(2),
  },
  "& .MuiDialogActions-root": {
    padding: theme.spacing(1),
  },
  "& #draggable-dialog-title": {
    cursor: "move",
    userSelect: "none",
    "&:hover": {
      cursor: "grab",
    },
  },
}));

function PaperComponent(props: any) {
  return (
    <Draggable
      handle="#draggable-dialog-title"
      cancel={'[class*="MuiDialogContent-root"]'}
    >
      <Paper {...props} style={{ cursor: "default" }} />
    </Draggable>
  );
}

interface ModalComponentProps {
  open: boolean;
  onClose: () => void;
  children: JSX.Element | string | React.ReactNode;
  draggable?: boolean;
}

const ModalComponent: React.FC<ModalComponentProps> = ({
  open,
  onClose: handleClose,
  children,
  draggable = false,
}) => {
  return (
    <>
      {createPortal(
        <MuiDialog
          onClose={(_e, reason) => {
            if (reason !== "backdropClick") {
              handleClose();
            }
          }}
          aria-labelledby="customized-dialog-title"
          open={open}
          maxWidth="xl"
          fullWidth={true}
          PaperComponent={draggable ? PaperComponent : undefined}
        >
          {children}
        </MuiDialog>,
        document.body
      )}
    </>
  );
};

export default ModalComponent;
