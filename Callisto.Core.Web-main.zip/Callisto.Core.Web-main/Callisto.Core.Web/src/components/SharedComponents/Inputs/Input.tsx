import React from "react";
import { TextField } from "@mui/material";

interface InputFieldProps {
  label: string;
  value: string;
  placeholder: string;
  error: boolean;
  errorText?: string;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onKeyPress?: (event: React.KeyboardEvent<HTMLInputElement>) => void;
}

const InputField: React.FC<InputFieldProps> = ({
  label,
  value,
  placeholder,
  error,
  errorText,
  onChange,
  onKeyPress,
}) => {
  return (
    <TextField
      label={label}
      value={value}
      error={error}
      helperText={error ? errorText : ""}
      onChange={onChange}
      onKeyPress={onKeyPress}
      variant="outlined"
      fullWidth
      placeholder={placeholder}
      inputProps={{
        inputMode: "text",
      }}
    />
  );
};

export default InputField;
