import React, { useState } from "react";
import { TextField } from "@mui/material";

interface NumberInputProps {
  label: string;
  value?: number | null;
  min?: number;
  max?: number;
  step?: number;
  error: boolean;
  errorText: string;
  onChange: (value: number) => void;
}

const NumberInput: React.FC<NumberInputProps> = ({
  label,
  value = 0,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  error,
  errorText,
}) => {
  const [inputValue, setInputValue] = useState<number>(value ?? 0);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = Number(e.target.value);
    setInputValue(newValue);
    onChange(newValue);
  };

  return (
    <TextField
      label={label}
      type="number"
      value={inputValue}
      inputProps={{ min, max, step }}
      onChange={handleInputChange}
      error={error}
      helperText={error ? errorText : ""}
      variant="outlined"
      fullWidth
    />
  );
};

export default NumberInput;
