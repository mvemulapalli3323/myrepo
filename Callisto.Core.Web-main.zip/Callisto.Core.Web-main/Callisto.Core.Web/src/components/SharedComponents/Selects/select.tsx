import * as React from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { FormHelperText } from "@mui/material";
import { DataTag } from "../../../api/services/receipts-services/ServicesInterfaces";

interface Option {
  value: number | string;
  label: React.ReactNode;
  dataTags?: DataTag[];
}

interface SelectVariantsProps {
  options: Option[];
  value: number | string | null;
  label: string;
  error: boolean;
  inputLabel: string;
  errorText: string;
  disabled: boolean;
  onChange: (
    event: SelectChangeEvent<number | string>,
    dataTags?: DataTag[],
  ) => void;
}

const SelectVariants: React.FC<SelectVariantsProps> = ({
  options,
  value,
  label,
  inputLabel,
  onChange,
  error,
  disabled,
  errorText,
}) => {
  const handleChange = (event: SelectChangeEvent<number | string>) => {
    const selectedOption = options.find(
      (opt) => opt.value === event.target.value,
    );
    onChange(event, selectedOption?.dataTags);
  };

  return (
    <div>
      <FormControl
        error={error}
        disabled={disabled}
        variant="standard"
        className="w-full"
      >
        <InputLabel id="demo-simple-select-standard-label">
          {inputLabel}
        </InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={value ?? ""}
          onChange={handleChange}
          label={label}
          data-selected-value={value ?? ""}
          {...(options
            .find((opt) => opt.value === value)
            ?.dataTags?.reduce(
              (acc, tag) => ({
                ...acc,
                [`data-${tag.key}`]: tag.value,
              }),
              {},
            ) || {})}
        >
          {options.map((option) => (
            <MenuItem
              key={option.value}
              value={option.value}
              {...(option.dataTags?.reduce(
                (acc, tag) => ({
                  ...acc,
                  [`data-${tag.key}`]: tag.value,
                }),
                {},
              ) || {})}
            >
              {option.label}
            </MenuItem>
          ))}
        </Select>
        {error && <FormHelperText>{errorText}</FormHelperText>}
      </FormControl>
    </div>
  );
};

export default SelectVariants;
