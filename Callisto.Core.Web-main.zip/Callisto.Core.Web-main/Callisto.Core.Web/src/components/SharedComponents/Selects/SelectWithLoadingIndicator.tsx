import React from "react";
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Typography,
  Box,
} from "@mui/material";
import { SelectChangeEvent } from "@mui/material/Select";

interface SelectWithLoadingIndicatorProps {
  labelId: string;
  id: string;
  value: string | number;
  label: string;
  onChange: (event: SelectChangeEvent<string | number>) => void;
  disabled?: boolean;
  loading?: boolean;
  loadingMessage?: string;
  options: Array<{ value: string; label: string }>;
  fullWidth?: boolean;
  size?: "small" | "medium";
}

const SelectWithLoadingIndicator: React.FC<SelectWithLoadingIndicatorProps> = ({
  labelId,
  id,
  value,
  label,
  onChange,
  disabled = false,
  loading = false,
  loadingMessage = "Loading...",
  options,
  fullWidth = true,
  size = "small",
}) => {
  return (
    <Box sx={{ position: 'relative', width: fullWidth ? '100%' : undefined }}>
      <FormControl fullWidth={fullWidth} size={size}>
        <InputLabel id={labelId}>{label}</InputLabel>
        <Select
          labelId={labelId}
          id={id}
          value={loading ? "__loading__" : value}
          label={label}
          onChange={onChange}
          disabled={disabled || loading}
          IconComponent={loading ? () => null : undefined}
        >
          {loading ? (
            <MenuItem value="__loading__" disabled>
              <Box sx={{ display: "flex", alignItems: "center", width: "100%", justifyContent: "space-between" }}>
                <Typography variant="body1" color="text.secondary">
                  {loadingMessage}
                </Typography>
                <CircularProgress size={18} thickness={4} sx={{ mr: '-20px' }} />
              </Box>
            </MenuItem>
          ) : (
            options.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))
          )}
        </Select>
      </FormControl>
    </Box>
  );
};

export default SelectWithLoadingIndicator; 