import React, { useState, useRef } from "react";
import {
  Button,
  ButtonGroup,
  ClickAwayListener,
  Grow,
  Paper,
  Popper,
  MenuList,
  MenuItem,
} from "@mui/material";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";

interface MenuItemData {
  text: string;
  onClick: () => void;
  icon?: React.ReactNode;
}

interface SplitButtonProps {
  mainButtonIcon?: React.ReactNode;
  menuItems: MenuItemData[];
  disabled?: boolean;
  variant?: "text" | "outlined" | "contained";
  color?:
    | "inherit"
    | "primary"
    | "secondary"
    | "success"
    | "error"
    | "info"
    | "warning";
  size?: "small" | "medium" | "large";
}

const SplitButton: React.FC<SplitButtonProps> = ({
  mainButtonIcon,
  menuItems,
  disabled = false,
  variant = "contained",
  color = "primary",
  size = "medium",
}) => {
  const [open, setOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const anchorRef = useRef<HTMLDivElement>(null);

  // Handle empty menuItems gracefully
  if (!menuItems || menuItems.length === 0) {
    return null;
  }

  const handleToggle = () => {
    if (disabled) return;
    setOpen((prevOpen) => !prevOpen);
  };

  const handleClose = (event: Event) => {
    if (
      anchorRef.current &&
      anchorRef.current.contains(event.target as HTMLElement)
    ) {
      return;
    }
    setOpen(false);
  };

  const handleMenuItemClick = (index: number) => {
    setSelectedIndex(index);
    setOpen(false);
    // Menu item clicks now only change selection, don't execute actions
  };

  // Handle keyboard events
  React.useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && open) {
        setOpen(false);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [open]);

  return (
    <>
      <ButtonGroup
        variant={variant}
        color={color}
        ref={anchorRef}
        disabled={disabled}
        size={size}
        disableElevation
      >
        <Button
          onClick={() => {
            // Execute the selected menu item's onClick when main button is clicked
            try {
              menuItems[selectedIndex].onClick();
            } catch (error) {
              // Log error but don't let it crash the component
              console.error("Error in main button onClick:", error);
            }
          }}
          startIcon={menuItems[selectedIndex].icon || mainButtonIcon}
        >
          {menuItems[selectedIndex].text}
        </Button>
        <Button
          size={"small"}
          onClick={handleToggle}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              handleToggle();
            }
          }}
        >
          <ArrowDropDownIcon fontSize="medium" />
        </Button>
      </ButtonGroup>
      <Popper
        sx={{
          zIndex: 1,
        }}
        open={open}
        anchorEl={anchorRef.current}
        placement="top-end"
        transition
        disablePortal
      >
        {({ TransitionProps, placement }) => (
          <Grow
            {...TransitionProps}
            style={{
              transformOrigin:
                placement === "bottom" ? "center top" : "center bottom",
            }}
          >
            <Paper>
              <ClickAwayListener onClickAway={handleClose}>
                <MenuList id="split-button-menu" autoFocusItem>
                  {menuItems.map((option, index) => (
                    <MenuItem
                      key={option.text}
                      selected={index === selectedIndex}
                      onClick={() => handleMenuItemClick(index)}
                    >
                      {option.text}
                    </MenuItem>
                  ))}
                </MenuList>
              </ClickAwayListener>
            </Paper>
          </Grow>
        )}
      </Popper>
    </>
  );
};

export default SplitButton;
