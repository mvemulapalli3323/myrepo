﻿import ErrorImg from "../../../Images/Error.png";
import WarningImg from "../../../Images/Warning.png";
import CheckImg from "../../../Images/Check.png";
import {
  ModalDataType,
  RowInterafaceforValidations,
} from "../../../api/services/receipts-services/ServicesInterfaces";
import { ModalMessageType } from "../Modals/ModalMessageType";
import { ValueFormatterParams } from "ag-grid-enterprise";

export const renderCellContent = (
  row: RowInterafaceforValidations,
  icon: boolean
) => {
  const getImageProps = () => {
    if (row?.errors?.length)
      return {
        src: ErrorImg,
        alt: "Error",
        title: row.errors.map((e) => e.message).join(" | "),
      };
    if (row?.warnings?.length)
      return {
        src: WarningImg,
        alt: "Warning",
        title: Array.isArray(row.warnings)
          ? row.warnings
              .map((w) => (typeof w === "string" ? w : w.message))
              .join(" | ")
          : typeof row.warnings === "string"
            ? row.warnings
            : "",
      };
    if (row?.allocations?.length || icon)
      return {
        src: CheckImg,
        alt: "Check",
        title: "This row has no warnings or errors.",
      };
    return null;
  };

  const imageProps = getImageProps();

  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      {imageProps && (
        <img
          {...imageProps}
          alt=""
          style={{ width: "20px", height: "20px", marginTop: "10px" }}
        />
      )}
      <span
        style={{ paddingLeft: imageProps ? 0 : "25px", alignItems: "center" }}
      ></span>
    </div>
  );
};
export const ModalData = (
  message: ModalMessageType,
  quantity?: number
): ModalDataType => {
  if (message === ModalMessageType.POSITION_ERROR_ALERT) {
    return {
      title: "Confirmation",
      content2: "Some of the selected positions have errors/warnings.",
      content1: "Are you sure you would like to continue?",
      cancelBtn: "CANCEL",
      confirmBtn: "OK",
    };
  } else if (message === ModalMessageType.ALLOCATE_QUANTITY) {
    return {
      title: "Assign Quantity",
      content2: "How much quantity do you want to assign to this Position?",
      cancelBtn: "CANCEL",
      confirmBtn: "ACCEPT",
      form: {
        type: "number" as const,
        label: "Quantity",
        data: { quantity },
        number: 0,
      },
    };
  }

  return {};
};
export const formatCurrency = (params: ValueFormatterParams) => {
  const currency = params.data?.currencyShortName;
  if (!currency) {
    return params.value?.toString() || "";
  }

  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency,
    }).format(params.value);
  } catch (error) {
    // Fallback if currency code is invalid
    return params.value?.toString() || "";
  }
};
