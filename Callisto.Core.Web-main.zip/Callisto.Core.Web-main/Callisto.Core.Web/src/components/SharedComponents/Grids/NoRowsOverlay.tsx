import React from "react";
import { Box, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";

interface NoRowsOverlayProps {
  message?: string;
}

const NoRowsOverlay: React.FC<NoRowsOverlayProps> = ({
  message = "No Data To Display",
}) => {
  const theme = useTheme();

  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: "100%",
        width: "100%",
      }}
    >
      <Typography
        variant="h6"
        sx={{
          color: theme.palette.text.secondary,
        }}
      >
        {message}
      </Typography>
    </Box>
  );
};

export default NoRowsOverlay;
