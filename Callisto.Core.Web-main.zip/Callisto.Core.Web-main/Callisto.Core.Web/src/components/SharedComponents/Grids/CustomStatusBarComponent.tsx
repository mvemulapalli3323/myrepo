import { AllocationAssignmentModel } from "@/api/types/receipts-types";
import { GridApi, IStatusPanelParams } from "ag-grid-community";
import { useEffect, useState } from "react";

interface CustomStatusBarComponentProps extends IStatusPanelParams {
  quantityAvailablePriority: boolean;
}

export const CustomStatusBarComponent = (
  props: CustomStatusBarComponentProps
) => {
  const [quantitySum, setQuantitySum] = useState<number>(0);
  const [rowCount, setRowCount] = useState<number>(0);

  const updateTotals = (
    api: GridApi<{
      quantityAvailable: number;
      quantity: number;
      allocations?: AllocationAssignmentModel[];
    }>,
    quantityAvailablePriority: boolean
  ) => {
    let selectedRowQuantity = 0;
    let selectedRows = 0;

    api.forEachNode((node) => {
      if (node.data && node.isSelected()) {
        if (quantityAvailablePriority) {
          // when allocations are present, use QuantityAllocated
          if (node.data.allocations != null) {
            selectedRowQuantity +=
              (node.data.quantity ?? 0) - (node.data.quantityAvailable ?? 0);
          } else {
            // otherwise, quantityAvailable
            selectedRowQuantity +=
              (node.data.quantityAvailable ?? node.data.quantity) || 0;
          }
        } else {
          selectedRowQuantity +=
            (node.data.quantity ?? node.data.quantityAvailable) || 0;
        }
        selectedRows += 1;
      }
    });

    setQuantitySum(selectedRowQuantity);
    setRowCount(selectedRows);
  };

  useEffect(() => {
    console.log(props);
    props.api.addEventListener("selectionChanged", (event) => {
      updateTotals(event.api, props.quantityAvailablePriority || false);
    });

    props.api.addEventListener("modelUpdated", (event) => {
      updateTotals(event.api, props.quantityAvailablePriority || false);
    });

    return () => {
      props.api.removeEventListener("selectionChanged", () => {});
      props.api.removeEventListener("modelUpdated", () => {});
    };
  }, []);

  return (
    <div className="ag-status-name-value">
      {rowCount > 0 && (
        <span>
          Selected Sum:{" "}
          {Intl.NumberFormat("en-US", { maximumFractionDigits: 6 }).format(
            quantitySum
          )}
        </span>
      )}
    </div>
  );
};
