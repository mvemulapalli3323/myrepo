﻿import React, { useCallback, useEffect, useMemo, useRef } from "react";
import { AgGridReact } from "ag-grid-react";
import { threeDTheme } from "./threeDTheme";
import "ag-grid-community/styles/ag-theme-quartz.css";
import isGreenE from "../../../Images/isGreenE-img.png";
import {
  ColDefsInterfaces,
  GridParamsTypes,
  RowDataInterfaces,
} from "../../../api/services/receipts-services/ServicesInterfaces";
import { renderCellContent } from "./CommonUtils";
import { IRowNode, ColDef } from "ag-grid-community";
import {
  CellMouseDownEvent,
  ColumnMovedEvent,
  DefaultMenuItem,
  GetContextMenuItemsParams,
  GridReadyEvent,
  GridState,
  ITooltipParams,
  MenuItemDef,
  RowDragEndEvent,
  RowDragEvent,
  SelectAllMode,
  SelectionChangedEvent,
  StateUpdatedEvent,
  Theme,
} from "ag-grid-enterprise";
import { SearchProducts } from "./GridColDefs";
import { PositionModel } from "@/api/types/receipts-types";
import { TrackingSystemAllocationModelSubRow } from "@/api/types/receipts-types-extensions";
import LoadingOverlay from "./LoadingOverlay";
import NoRowsOverlay from "./NoRowsOverlay";
import { CustomStatusBarComponent } from "./CustomStatusBarComponent";
import { gridStateManager } from "../../../utils/gridStateManager";
interface ARGridProps {
  rowData: RowDataInterfaces[] | PositionModel[];
  colDefs: ColDefsInterfaces[];
  onColumnMoved?: (event: ColumnMovedEvent) => void;
  onSelectionChanged?: (event: SelectionChangedEvent) => void;
  onGridReady?: (event: GridReadyEvent) => void;
  detailCellRendererParams?: {
    detailGridOptions?: {
      columnDefs?: ColDefsInterfaces[];
      rowData?: TrackingSystemAllocationModelSubRow[];
    };
    getDetailRowData?: (params: {
      successCallback: (rowData: TrackingSystemAllocationModelSubRow[]) => void;
      data: TrackingSystemAllocationModelSubRow;
    }) => void;
    template?: string;
  };
  rowClassRules: {
    [key: string]:
      | string
      | ((params: {
          data: RowDataInterfaces | PositionModel | undefined;
        }) => boolean);
  };
  onRowDragEnter?: (event: RowDragEvent) => void;
  onRowDragEnd?: (event: RowDragEndEvent) => void;
  onCellMouseDown?: (event: CellMouseDownEvent) => void;
  customContextMenuItems?: (params: GetContextMenuItemsParams) => MenuItemDef[];
  findSearchValue?: string;
  theme?: Theme;
  rowSelection?: {
    mode: "multiRow" | "singleRow";
    headerCheckbox?: boolean;
    checkboxes?: boolean;
    selectAll?: SelectAllMode;
  };
  loading?: boolean;
  loadingMessage?: string;
  noRowsMessage?: string;
  /** if gridId is set, grid state will be saved **/
  gridId?: string;
  /** Height of the grid. If not provided, defaults to 400px. Use '100%' to fill container. */
  height?: string | number;
  /** Page size for pagination. If not provided, defaults to 30. */
  paginationPageSize?: number;
  isRowSelectable?: (
    rowNode: IRowNode<RowDataInterfaces | PositionModel>
  ) => boolean;
  disabledRowIds?: (string | number)[];
  groupDisplayType?:
    | "singleColumn"
    | "multipleColumns"
    | "groupRows"
    | "custom";
  autoGroupColumnDef?: ColDef;
  groupByFields?: string[];
  groupDefaultExpanded?: number;
  showRowGroup?: boolean;
}

const AutomatedReceiptsGrid: React.FC<ARGridProps> = ({
  rowData,
  colDefs,
  onSelectionChanged,
  onColumnMoved,
  onGridReady,
  onRowDragEnter,
  onCellMouseDown,
  onRowDragEnd,
  customContextMenuItems,
  detailCellRendererParams,
  rowClassRules,
  findSearchValue,
  theme,
  rowSelection,
  loading,
  loadingMessage,
  noRowsMessage,
  gridId,
  height = 400,
  paginationPageSize = 30,
  isRowSelectable,
  groupDisplayType,
  autoGroupColumnDef,
  groupByFields,
  groupDefaultExpanded,
}) => {
  const gridRef = useRef<AgGridReact<RowDataInterfaces | PositionModel>>(null);
  const [initialState, setInitialState] = React.useState<GridState | null>(
    null
  );

  const CustomLoadingOverlay = () => (
    <LoadingOverlay message={loadingMessage} />
  );

  const CustomNoRowsOverlay = () => <NoRowsOverlay message={noRowsMessage} />;

  const sideBar = {
    toolPanels: [
      {
        id: "columns",
        labelDefault: "Columns",
        labelKey: "columns",
        iconKey: "columns",
        toolPanel: "agColumnsToolPanel",
        toolPanelParams: {
          suppressRowGroup: true,
          suppressValues: true,
          suppressPivotMode: true,
        },
      },
      {
        id: "filters",
        labelDefault: "Filters",
        labelKey: "filters",
        iconKey: "filter",
        toolPanel: "agFiltersToolPanel",
        toolPanelParams: {
          suppressExpandAll: false,
          suppressFilterSearch: false,
        },
      },
    ],
  };

  const getRowId = (params: { data: RowDataInterfaces | PositionModel }) => {
    if (!params.data) return "";
    const dataString = JSON.stringify(params.data);
    const hash = dataString.split("").reduce((acc, char) => {
      return ((acc << 5) - acc + char.charCodeAt(0)) | 0;
    }, 0);

    return `row_${Math.abs(hash)}`;
  };

  useEffect(() => {
    if (gridRef.current) {
      gridRef.current.api.setFilterModel({
        quickFilter: findSearchValue ? { filter: findSearchValue } : null,
      });
    }
  }, [findSearchValue]);

  useEffect(() => {
    // AG Grid will ONLY load the initialState once -- if it loads as {}, it will not
    // refresh itself when initialState is changed later.

    let baseState: GridState = {};

    if (gridId) {
      const loadedState = gridStateManager.loadState(gridId);
      if (loadedState) {
        baseState = loadedState;
      }
    }

    // Apply grouping configuration if provided (overrides saved state)
    if (groupByFields && groupByFields.length > 0) {
      baseState = {
        ...baseState,
        rowGroup: {
          groupColIds: groupByFields,
        },
      };
    }

    setInitialState(baseState);
  }, [gridId, groupByFields]);

  const defaultColDefs = useMemo(
    () => ({
      tooltipValueGetter: (params: ITooltipParams) => {
        return params.valueFormatted ?? params.value;
      },
    }),
    []
  );

  const updatedColDefs = useMemo(() => {
    if (findSearchValue) {
      return SearchProducts(findSearchValue);
    }
    return colDefs
      .map((col) => {
        if (col.field === "actions") {
          return {
            ...col,
            cellRenderer: detailCellRendererParams
              ? "agGroupCellRenderer"
              : (params: GridParamsTypes) =>
                  renderCellContent(params.data, false),
            cellRendererParams: detailCellRendererParams && {
              innerRenderer: (params: { data: RowDataInterfaces }) =>
                renderCellContent(params.data, false),
            },
          };
        }

        if (col.field === "isGreenE") {
          return {
            ...col,
            cellRenderer: (params: GridParamsTypes) =>
              params.data?.isGreenE ? (
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    height: "100%",
                  }}
                >
                  <img
                    src={isGreenE}
                    alt="icon"
                    style={{
                      width: "20px",
                      height: "20px",
                      marginRight: "5px",
                    }}
                  />
                </div>
              ) : (
                ""
              ),
          };
        }

        if (col.field === "contractProductDescription") {
          if (detailCellRendererParams) {
            return {
              ...col,
              cellRenderer: (params: GridParamsTypes) =>
                params.data?.isGreenE ? (
                  <div style={{ display: "flex", alignItems: "center" }}>
                    <img
                      src={isGreenE}
                      alt="icon"
                      style={{
                        width: "20px",
                        height: "20px",
                        marginRight: "5px",
                        flexShrink: 0,
                      }}
                    />
                    <span>{params.data.contractProductDescription}</span>
                  </div>
                ) : (
                  params.data.contractProductDescription
                ),
            };
          }
        }

        return col;
      })
      .filter((f) => f.field !== "warnings");
  }, [colDefs, detailCellRendererParams, findSearchValue]);

  const getContextMenuItems = useCallback(
    (
      params: GetContextMenuItemsParams
    ): (
      | MenuItemDef<RowDataInterfaces | PositionModel, any>
      | DefaultMenuItem
    )[] => {
      const customItems = customContextMenuItems
        ? customContextMenuItems(params)
        : [];
      return [
        "copy",
        "copyWithHeaders",
        "copyWithGroupHeaders",
        ...customItems,
      ];
    },
    [customContextMenuItems]
  );

  const onStateUpdated = useCallback(
    (event: StateUpdatedEvent) => {
      if (!gridId) return;

      // Handle state updates here
      const state = event.api.getState();
      gridStateManager.saveState(gridId, state);
    },
    [gridId]
  );

  const statusBar = useMemo(() => {
    return {
      statusPanels: [
        {
          statusPanel: CustomStatusBarComponent,
          align: "right",
          statusPanelParams: {
            // the calculation in the component has some difficulty determining when to use Quantity (inbox) or QuantityAvailable (allocations)...
            // this should help!
            quantityAvailablePriority:
              colDefs.filter((f) => f.field.includes("quantityAvailable"))
                .length > 0,
          },
        },
        { statusPanel: "agSelectedRowCountComponent" },
        {
          statusPanel: "agAggregationComponent",
          statusPanelParams: {
            aggFuncs: ["sum"],
          },
        },
        { statusPanel: "agTotalAndFilteredRowCountComponent" },
      ],
    };
  }, [colDefs]);

  return (
    <div
      className="ag-theme-quartz ag-grid-large-checkboxes"
      style={{ height: height, width: "100%" }}
      data-testid={gridId || "product-grid"}
    >
      {initialState === null ? (
        <LoadingOverlay message="Loading layout... "></LoadingOverlay>
      ) : (
        <AgGridReact<RowDataInterfaces | PositionModel>
          key={gridId} // CRITICAL: Force re-render when gridId changes for tracking-system specific layouts
          initialState={initialState}
          theme={theme || threeDTheme}
          columnDefs={updatedColDefs}
          defaultColDef={defaultColDefs}
          rowData={rowData}
          animateRows={true}
          getRowId={getRowId}
          rowSelection={
            rowSelection || {
              mode: "multiRow",
              headerCheckbox: true,
              checkboxes: true,
              selectAll: "filtered",
              isRowSelectable: isRowSelectable,
            }
          }
          sideBar={sideBar}
          pagination={true}
          onColumnMoved={onColumnMoved}
          paginationPageSize={paginationPageSize}
          paginationPageSizeSelector={[10, 20, 30, 40, 50, 100]}
          onSelectionChanged={onSelectionChanged}
          onGridReady={onGridReady}
          masterDetail={true}
          detailRowHeight={200}
          embedFullWidthRows={true}
          detailCellRendererParams={detailCellRendererParams}
          rowClassRules={rowClassRules}
          groupDisplayType={groupDisplayType}
          autoGroupColumnDef={autoGroupColumnDef}
          groupDefaultExpanded={groupDefaultExpanded}
          groupSelectsChildren={true}
          rowDragEntireRow={false}
          onRowDragEnter={onRowDragEnter}
          onRowDragEnd={onRowDragEnd}
          onCellMouseDown={onCellMouseDown}
          getContextMenuItems={getContextMenuItems}
          ensureDomOrder={true}
          suppressModelUpdateAfterUpdateTransaction={true}
          loading={loading}
          loadingOverlayComponent={CustomLoadingOverlay}
          noRowsOverlayComponent={CustomNoRowsOverlay}
          onStateUpdated={onStateUpdated}
          rowDragMultiRow={true}
          statusBar={statusBar}
          cellSelection={true}
          tooltipInteraction={true}
          tooltipShowMode="whenTruncated"
          tooltipShowDelay={500}
        />
      )}
    </div>
  );
};

export default AutomatedReceiptsGrid;
