import {
  ICellRendererParams,
  ITooltipParams,
  ValueGetterParams,
  ValueFormatterParams,
} from "ag-grid-enterprise";
import { formatCurrency, renderCellContent } from "./CommonUtils";
import {
  AllocationData,
  ProductRowData,
  RowDataInterfaces,
} from "../../../api/services/receipts-services/ServicesInterfaces";
import { Badge, Box, Button, Tooltip } from "@mui/material";
import HighlightCellRenderer from "./HighlightCellRenderer";
import EditSquareIcon from "@mui/icons-material/EditSquare";
import AssignmentAddIcon from "@mui/icons-material/AssignmentAdd";
import dayjs from "dayjs";

const quantityAvailableValueFormatter = (
  params: ValueFormatterParams<{
    quantity?: number;
    quantityAvailable?: number;
    allocations?: AllocationData[];
  }>
) => {
  const quantity = params.data?.quantity || 0;
  const quantityAvailable = params.data?.quantityAvailable || 0;
  // when allocations are present, use QuantityAllocated
  const quantityAllocated =
    params.data?.allocations != null
      ? (params.data.quantity ?? 0) - (params.data.quantityAvailable ?? 0)
      : null;
  if (quantity === 0 && (quantityAllocated ?? quantityAvailable) === 0) {
    return "";
  }

  return `${quantityAllocated ?? quantityAvailable} / ${quantity}`;
};
const quantityAvailableValueGetter = (
  params: ValueGetterParams<{
    quantity?: number;
    quantityAvailable?: number;
    allocations?: AllocationData[];
  }>
): number => {
  const quantity = params.data?.quantity;
  const quantityAvailable = params.data?.quantityAvailable;
  // when allocations are present, use QuantityAllocated
  const quantityAllocated =
    params.data?.allocations != null
      ? (params.data.quantity ?? 0) - (params.data.quantityAvailable ?? 0)
      : null;
  return quantityAllocated ?? quantityAvailable ?? quantity ?? 0;
};
const quantityAvailableComparator = (
  _valueA: string,
  _valueB: string,
  nodeA: {
    data: {
      quantityAvailable: number;
      quantity: number;
      allocations?: AllocationData[];
    };
  },
  nodeB: {
    data: {
      quantityAvailable: number;
      quantity: number;
      allocations?: AllocationData[];
    };
  }
) => {
  // when allocations are present, sort by QuantityAllocated instead of QuantityAvailable
  if (nodeA.data.allocations != null && nodeB.data.allocations != null) {
    return (
      (nodeA.data.quantity ?? 0) -
      (nodeA.data.quantityAvailable ?? 0) -
      ((nodeB.data.quantity ?? 0) - (nodeB.data.quantityAvailable ?? 0))
    );
  }

  return nodeA.data.quantityAvailable - nodeB.data.quantityAvailable;
};

export const positionModelColDefs = [
  {
    field: "actions",
    headerName: "",
    suppressColumnsToolPanel: true,
    width: 100,
    lockPosition: "left",
  },
  {
    field: "positionId",
    headerName: "Position ID",
    filter: true,
    enableRowGroup: true,
  },
  {
    field: "contractProductDescription",
    headerName: "Contract Product",
    filter: true,
    enableRowGroup: true,
  },
  {
    field: "confirmName",
    filter: true,
    headerName: "Confirm",
    enableRowGroup: true,
  },
  {
    field: "quantity",
    filter: true,
    headerName: "Quantity",
    enableRowGroup: true,
  },
  {
    field: "rate",
    filter: true,
    headerName: "Rate / Alt Rate",
    enableRowGroup: true,
    valueFormatter: (params: ValueFormatterParams<ProductRowData, number>) => {
      return formatCurrency(params);
    },
  },
  {
    field: "currencyShortName",
    filter: true,
    headerName: "Currency",
    enableRowGroup: true,
  },
  {
    field: "generationPeriodName",
    filter: true,
    headerName: "Period",
    enableRowGroup: true,
  },
  {
    field: "startDate - endDate",
    filter: true,
    headerName: "Start & End Date",
    enableRowGroup: true,
    valueFormatter: (
      params: ValueFormatterParams<{ startDate?: string; endDate?: string }>
    ) => {
      const startDate = params.data?.startDate || "";
      const endDate = params.data?.endDate || "";
      return `${startDate} - ${endDate}`;
    },
  },
  {
    field: "trackingSystemName",
    filter: true,
    headerName: "Tracking System Name",
    enableRowGroup: true,
  },
  {
    field: "earliestDeliveryDate",
    headerName: "Earliest Delivery Date",
    filter: true,
    enableRowGroup: true,
  },
  {
    field: "deliveryDeadline",
    filter: true,
    headerName: "Delivery Deadline",
    enableRowGroup: true,
  },
  {
    field: "counterpartyName",
    filter: true,
    headerName: "Counterparty",
    enableRowGroup: true,
  },
  {
    field: "unitContingentType",
    filter: true,
    headerName: "UC Type",
    enableRowGroup: true,
  },
  {
    field: "notes",
    filter: true,
    headerName: "Notes",
    enableRowGroup: true,
  },
];

export const positionAllocationModelColDef = [
  ...positionModelColDefs.slice(0, 3), // First 3 columns
  {
    ...positionModelColDefs[3],
    field: "quantity / quantityAvailable",
    headerName: "Quantity",
    cellClass: "ag-right-aligned-cell",
    width: 150,
    valueFormatter: quantityAvailableValueFormatter,
    valueGetter: quantityAvailableValueGetter,
    comparator: quantityAvailableComparator,
  },
  ...positionModelColDefs.slice(4), // Remaining columns
];

export const inboxTrackingSystemColDef = [
  {
    field: "facilityID",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility ID",
  },
  {
    field: "facilityName",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility Name",
  },
  {
    field: "fuelType",
    filter: true,
    enableRowGroup: true,
    headerName: "Fuel Type",
  },
  {
    field: "eligibility",
    filter: true,
    enableRowGroup: true,
    headerName: "Eligibility",
    valueFormatter: (
      params: ValueFormatterParams<RowDataInterfaces, string[]>
    ) => {
      const eligibility = params.value;
      if (eligibility === null || eligibility === undefined) {
        return "";
      }
      return Array.isArray(eligibility)
        ? eligibility.join(", ")
        : String(eligibility);
    },
  },
  {
    field: "vintageDate",
    filter: true,
    enableRowGroup: true,
    headerName: "Vintage Date",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: { value: string | number | Date }) => {
      return new Date(params.value).toLocaleDateString("en-US");
    },
  },
  {
    field: "vintageDateEnd",
    filter: true,
    enableRowGroup: true,
    headerName: "Vintage Date End",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },

    valueFormatter: (params: {
      data: RowDataInterfaces;
      value: string | number | Date;
    }) => {
      const lastDay = dayjs(params?.data?.vintageDate).endOf("month");
      if (!params.value) return lastDay.toDate().toLocaleDateString("en-US");
      return new Date(params.value).toLocaleDateString("en-US");
    },
    hide: true,
  },
  {
    field: "quantity",
    filter: true,
    enableRowGroup: true,
    headerName: "Quantity",
    cellClass: "ag-right-aligned-cell",
    width: 150,
  },
  {
    field: "transferDate",
    filter: true,
    enableRowGroup: true,
    headerName: "Transfer Date",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: { value: string | number | Date }) => {
      if (!params.value) return new Date().toLocaleDateString("en-US");
      return new Date(params.value).toLocaleDateString("en-US");
    },
  },
  { field: "from", filter: true, enableRowGroup: true, headerName: "From" },
  { field: "to", filter: true, enableRowGroup: true, headerName: "To" },
  {
    field: "transactionID",
    filter: true,
    headerName: "Transaction ID",
    enableRowGroup: true,
  },
  {
    field: "transactionNumber",
    filter: true,
    headerName: "Transaction Number",
    enableRowGroup: true,
  },
  {
    field: "location",
    filter: true,
    enableRowGroup: true,
    headerName: "Location",
  },
  {
    field: "rate",
    filter: true,
    enableRowGroup: true,
    headerName: "Rate",
  },
  {
    field: "notes",
    filter: true,
    enableRowGroup: true,
    headerName: "Notes",
  },
  {
    field: "supportFlag",
    filter: true,
    enableRowGroup: true,
    headerName: "Support Flag",
  },
  {
    field: "dateOperational",
    filter: true,
    enableRowGroup: true,
    headerName: "Date Operational",
  },
  {
    field: "electricalCapacityMW",
    filter: true,
    enableRowGroup: true,
    headerName: "Electrical Capacity (MW)",
  },
  {
    field: "pdCity",
    filter: true,
    enableRowGroup: true,
    headerName: "PD City",
  },
  {
    field: "pdPostCode",
    filter: true,
    enableRowGroup: true,
    headerName: "PD Post Code",
  },
  {
    field: "companyName",
    filter: true,
    enableRowGroup: true,
    headerName: "Company Name",
  },
];
export const trackingSystemColDefs = [
  {
    field: "tsActions",
    headerName: "",
    suppressColumnsToolPanel: true,
    rowDrag: true,
    width: 50,
    lockPosition: "left",
  },
  {
    field: "groupName",
    filter: true,
    enableRowGroup: true,
    headerName: "Group Name",
    hide: true,
  },
  {
    field: "facilityID",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility ID",
  },
  {
    field: "facilityName",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility Name",
  },
  {
    field: "fuelType",
    filter: true,
    enableRowGroup: true,
    headerName: "Fuel Type",
  },
  {
    field: "eligibility",
    filter: true,
    enableRowGroup: true,
    headerName: "Eligibility",
  },
  {
    field: "vintageDate",
    filter: true,
    enableRowGroup: true,
    headerName: "Vintage Date",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: { value: string | number | Date }) => {
      return params.value
        ? new Date(params.value).toLocaleDateString("en-US")
        : "";
    },
  },
  {
    field: "vintageDateEnd",
    filter: true,
    enableRowGroup: true,
    headerName: "Vintage Date End",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },

    valueFormatter: (params: {
      data: RowDataInterfaces;
      value: string | number | Date;
    }) => {
      const lastDay = dayjs(params?.data?.vintageDate).endOf("month");
      if (!params.value) return lastDay.toDate().toLocaleDateString("en-US");
      return new Date(params.value).toLocaleDateString("en-US");
    },
    hide: true,
  },
  {
    field: "quantity / quantityAvailable",
    filter: true,
    enableRowGroup: true,
    headerName: "Quantity",
    cellClass: "ag-right-aligned-cell",
    width: 150,
    valueGetter: quantityAvailableValueGetter,
    valueFormatter: quantityAvailableValueFormatter,
    comparator: quantityAvailableComparator,
  },
  {
    field: "transferDate",
    filter: true,
    enableRowGroup: true,
    headerName: "Transfer Date",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: { value: string | number | Date }) => {
      if (!params.value) return new Date().toLocaleDateString("en-US");
      return new Date(params.value).toLocaleDateString("en-US");
    },
  },
  { field: "from", filter: true, enableRowGroup: true, headerName: "From" },
  { field: "to", filter: true, enableRowGroup: true, headerName: "To" },
  {
    field: "transactionID",
    filter: true,
    headerName: "Transaction ID",
    enableRowGroup: true,
  },
  {
    field: "transactionNumber",
    filter: true,
    headerName: "Transaction Number",
    enableRowGroup: true,
  },
  {
    field: "location",
    filter: true,
    enableRowGroup: true,
    headerName: "Location",
  },
  {
    field: "rate",
    filter: true,
    enableRowGroup: true,
    headerName: "Rate",
  },
  {
    field: "notes",
    filter: true,
    enableRowGroup: true,
    headerName: "Notes",
  },
  {
    field: "supportFlag",
    filter: true,
    enableRowGroup: true,
    headerName: "Support Flag",
  },
  {
    field: "dateOperational",
    filter: true,
    enableRowGroup: true,
    headerName: "Date Operational",
  },
  {
    field: "electricalCapacityMW",
    filter: true,
    enableRowGroup: true,
    headerName: "Electrical Capacity (MW)",
  },
  {
    field: "pDCity",
    filter: true,
    enableRowGroup: true,
    headerName: "PD City",
  },
  {
    field: "pDPostCode",
    filter: true,
    enableRowGroup: true,
    headerName: "PD Post Code",
  },
  {
    field: "companyName",
    filter: true,
    enableRowGroup: true,
    headerName: "Company Name",
  },
];
export const subTrackingSystemColDefs = [
  {
    field: "stsActions",
    headerName: "",
    suppressColumnsToolPanel: true,
    cellRenderer: (params: ICellRendererParams) =>
      renderCellContent(params.data, true),
    width: 50,
    lockPosition: "left",
  },
  {
    field: "groupName",
    filter: true,
    enableRowGroup: true,
    headerName: "Group Name",
    hide: true,
  },
  {
    field: "facilityID",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility ID",
  },
  {
    field: "facilityName",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility Name",
  },
  {
    field: "fuelType",
    filter: true,
    enableRowGroup: true,
    headerName: "Fuel Type",
  },
  {
    field: "eligibility",
    filter: true,
    enableRowGroup: true,
    headerName: "Eligibility",
  },
  {
    field: "vintageDate",
    filter: true,
    enableRowGroup: true,
    headerName: "Vintage Date",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: { value: string | number | Date }) => {
      return new Date(params.value).toLocaleDateString("en-US");
    },
  },
  {
    field: "vintageDateEnd",
    filter: true,
    enableRowGroup: true,
    headerName: "Vintage Date End",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: {
      data: RowDataInterfaces;
      value: string | number | Date;
    }) => {
      const lastDay = dayjs(params?.data?.vintageDate).endOf("month");
      if (!params.value) return lastDay.toDate().toLocaleDateString("en-US");
      return new Date(params.value).toLocaleDateString("en-US");
    },
    hide: true,
  },
  {
    field: "quantity / quantityAvailable",
    filter: true,
    enableRowGroup: true,
    headerName: "Quantity",
    cellClass: "ag-right-aligned-cell",
    width: 150,
    valueGetter: (
      params: ValueGetterParams<{
        quantity?: number;
        quantityAllocated?: number;
      }>
    ) => {
      const quantity = params.data?.quantity || 0;
      const quantityAllocated = params.data?.quantityAllocated || 0;
      return `${quantityAllocated} / ${quantity}`;
    },
  },
  {
    field: "transferDate",
    filter: true,
    enableRowGroup: true,
    headerName: "Transfer Date",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: { value: string | number | Date }) => {
      if (!params.value) return new Date().toLocaleDateString("en-US");
      return new Date(params.value).toLocaleDateString("en-US");
    },
  },
  { field: "from", filter: true, enableRowGroup: true, headerName: "From" },
  { field: "to", filter: true, enableRowGroup: true, headerName: "To" },
  {
    field: "transactionID",
    filter: true,
    headerName: "Transaction ID",
    enableRowGroup: true,
  },
];
export const transactionColDefs = [
  {
    field: "transactionNumber",
    headerName: "Transaction Number",
    filter: true,
  },
  {
    field: "transactionVolume",
    headerName: "Transaction Volume",
    filter: true,
  },
  {
    field: "fromAccountName",
    headerName: "From Account Name",
    filter: true,
  },
  {
    field: "toAccountName",
    headerName: "To Account Name",
    filter: true,
  },
  {
    field: "completionDate",
    headerName: "Completion Date",
    filter: true,
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: { value: string | number | Date }) => {
      return new Date(params.value).toLocaleString("en-US");
    },
  },
  {
    field: "transactionType",
    headerName: "Transaction Type",
    filter: true,
  },
  {
    field: "fromAccountNumber",
    headerName: "From Account Number",
    filter: true,
  },
  {
    field: "toAccountNumber",
    headerName: "To Account Number",
    filter: true,
  },
  {
    field: "transactionStatus",
    headerName: "Transaction Status",
    filter: true,
  },
  {
    field: "description",
    headerName: "Description",
    filter: true,
  },
];
export const SearchProducts = (filterText: string | undefined) => [
  {
    field: "productId",
    filter: true,
    enableRowGroup: true,
    headerName: "Product Id",
    width: 350,
    cellRenderer: (params: { value: string }) => {
      return (
        <HighlightCellRenderer
          value={params.value}
          filterText={filterText || ""}
        />
      );
    },
    cellRendererParams: { suppressCount: true },
  },
  {
    field: "productDescription",
    filter: true,
    enableRowGroup: true,
    headerName: "Product Description",
    width: 900,
    cellRenderer: (params: { value: string }) => {
      return (
        <HighlightCellRenderer
          value={params.value}
          filterText={filterText || ""}
        />
      );
    },
    cellRendererParams: { suppressCount: true },
  },
];

export const productColDefs = (
  handleProducts: (row: ProductRowData, type: string) => void,
  receiptId?: string
) => [
  {
    field: "actions",
    headerName: "",
    suppressColumnsToolPanel: true,
    width: 100,
    lockPosition: "left",
  },
  {
    field: "quantity",
    filter: true,
    enableRowGroup: true,
    headerName: "Quantity",
    width: 150,
  },
  {
    field: "facilityName",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility Name",
    width: 180,
  },
  {
    field: "eligibility",
    filter: true,
    enableRowGroup: true,
    headerName: "Eligibility",
  },
  {
    field: "product",
    filter: true,
    enableRowGroup: true,
    headerName: "Product",
    tooltipValueGetter: (p: ITooltipParams) => p.value,
    cellRenderer: (params: ICellRendererParams<ProductRowData>) => {
      return (
        <span style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          {params.data?.isManuallySelected === false && (
            <Badge
              color={
                params.data?.suggestedProducts?.length ? "success" : "error"
              }
              badgeContent={params.data?.suggestedProducts?.length ?? 0}
              showZero
              sx={{ mr: 1 }}
            ></Badge>
          )}
          {params?.data?.product}
        </span>
      );
    },
    onCellDoubleClicked: (params: ICellRendererParams<ProductRowData>) => {
      handleProducts(params.data!, "form");
    },
  },
  {
    field: "vintage",
    filter: true,
    enableRowGroup: true,
    headerName: "Vintage",
    width: 100,
    onCellDoubleClicked: (params: ICellRendererParams<ProductRowData>) => {
      handleProducts(params.data!, "formEdit");
    },
  },
  {
    field: "generationPeriodStart",
    filter: true,
    enableRowGroup: true,
    headerName: "Generation",
    wrapText: true,
    width: 300,
    cellEditor: "agDateCellEditor",
    valueFormatter: (params: {
      value: string | number | Date;
      data?: ProductRowData;
    }) => {
      const genstartDate = params.data?.generationPeriodStart
        ? new Date(params.data.generationPeriodStart).toLocaleDateString(
            "en-US"
          )
        : "";
      const genendDate = params.data?.generationPeriodEnd
        ? new Date(params.data.generationPeriodEnd).toLocaleDateString("en-US")
        : "";
      return `Start: ${genstartDate} - End: ${genendDate}`;
    },
    onCellDoubleClicked: (params: ICellRendererParams<ProductRowData>) => {
      handleProducts(params.data!, "formEdit");
    },
  },
  {
    field: "deliveryDateUtc",
    filter: true,
    enableRowGroup: true,
    headerName: "Delivery Date",
    valueFormatter: (params: { value: string | number | Date }) => {
      return new Date(params.value).toLocaleDateString("en-US");
    },
    onCellDoubleClicked: (params: ICellRendererParams<ProductRowData>) => {
      handleProducts(params.data!, "formEdit");
    },
  },
  {
    field: "documentLocation",
    filter: true,
    enableRowGroup: false,
    headerName: "Document Location",
    width: 250,
    tooltipValueGetter: (p: ITooltipParams) => p.value,
    onCellDoubleClicked: (params: ICellRendererParams<ProductRowData>) => {
      handleProducts(params.data!, "formEdit");
    },
  },
  {
    field: "ucType",
    filter: true,
    enableRowGroup: true,
    headerName: "UC Type",
    width: 140,
  },
  {
    field: "contractProduct",
    filter: true,
    enableRowGroup: true,
    headerName: "Contract Product",
    tooltipValueGetter: (p: ITooltipParams) => p.value,
  },
  {
    field: "deliveredFlag",
    filter: true,
    enableRowGroup: true,
    headerName: "Delivered",
    cellRenderer: "agCheckboxCellRenderer",
    onCellDoubleClicked: (params: ICellRendererParams<ProductRowData>) => {
      handleProducts(params.data!, "formEdit");
    },
  },
  {
    field: "rate",
    filter: true,
    enableRowGroup: true,
    headerName: "Rate",
    width: 140,
    valueFormatter: (params: ValueFormatterParams<ProductRowData, number>) => {
      return formatCurrency(params);
    },
  },
  {
    field: "counterpartyName",
    filter: true,
    enableRowGroup: true,
    headerName: "Counterparty",
  },
  {
    field: "facilityId",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility ID",
  },
  {
    field: "notes",
    filter: true,
    enableRowGroup: true,
    headerName: "Notes",
  },
  {
    field: "",
    headerName: "Actions",
    width: 120,
    cellRenderer: (params: ICellRendererParams<ProductRowData>) => {
      return (
        <Box>
          <Tooltip
            title={
              !params.data?.product && !params.data?.productId
                ? "Choose Product"
                : "Change Product"
            }
          >
            <Button
              variant="contained"
              disabled={!!receiptId}
              sx={{
                minWidth: "auto",
                padding: "4px 8px",
                marginRight: "4px",
              }}
              onClick={(e: React.MouseEvent) => {
                handleProducts(params.data!, "form");
                e.stopPropagation();
              }}
            >
              <AssignmentAddIcon fontSize="small" />
            </Button>
          </Tooltip>
          <Tooltip title="Edit Position">
            <Button
              variant="contained"
              disabled={!!receiptId}
              sx={{
                minWidth: "auto",
                padding: "4px 8px",
              }}
              onClick={(e: React.MouseEvent) => {
                handleProducts(params.data!, "formEdit");
                e.stopPropagation();
              }}
            >
              <EditSquareIcon fontSize="small" />
            </Button>
          </Tooltip>
        </Box>
      );
    },
  },
];

export const productSubTrackingSystemColDefs = [
  {
    field: "facilityName",
    filter: true,
    enableRowGroup: true,
    headerName: "Facility Name",
  },
  {
    field: "fuelType",
    filter: true,
    enableRowGroup: true,
    headerName: "Fuel Type",
  },
  {
    field: "eligibility",
    filter: true,
    enableRowGroup: true,
    headerName: "Eligibility",
  },
  {
    field: "vintageDate",
    filter: true,
    enableRowGroup: true,
    headerName: "Vintage Date",
    cellClass: "ag-cell",
    cellStyle: { textAlign: "center" },
    valueFormatter: (params: { value: string | number | Date }) => {
      return new Date(params.value).toLocaleDateString("en-US");
    },
  },
  {
    field: "location",
    filter: true,
    enableRowGroup: true,
    headerName: "Location",
  },
  {
    field: "dateOperational",
    filter: true,
    enableRowGroup: true,
    headerName: "Date Operational",
  },
];
