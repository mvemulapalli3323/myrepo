import React from "react";
import { CircularProgress, Box, Typography } from "@mui/material";
import { useTheme } from "@mui/material/styles";

interface LoadingOverlayProps {
  message?: string;
}

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({
  message = "Loading...",
}) => {
  const theme = useTheme();

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100%",
        width: "100%",
        gap: 2,
      }}
    >
      <CircularProgress
        size={60}
        sx={{
          color: theme.palette.secondary.main,
        }}
      />
      <Typography
        variant="h6"
        sx={{
          mt: 2,
          color: theme.palette.text.secondary,          
        }}
      >
        {message}
      </Typography>
    </Box>
  );
};

export default LoadingOverlay;
