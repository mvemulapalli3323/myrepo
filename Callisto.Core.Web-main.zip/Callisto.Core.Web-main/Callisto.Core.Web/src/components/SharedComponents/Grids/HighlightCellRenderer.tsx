import React from "react";

interface HighlightCellRendererProps {
  value: string;
  filterText: string;
}

const HighlightCellRenderer: React.FC<HighlightCellRendererProps> = ({
  value,
  filterText,
}) => {
  if (!filterText) {
    return <>{value}</>;
  }

  const regex = new RegExp(`(${filterText})`, "gi");
  const parts =
    typeof value === "string" || typeof value === "number"
      ? value.toString().split(regex)
      : [];

  return (
    <>
      {parts.map((part, index) =>
        regex.test(part) ? (
          <span key={index} style={{ fontWeight: "bold", color: "red" }}>
            {part}
          </span>
        ) : (
          <span key={index}>{part}</span>
        ),
      )}
    </>
  );
};

export default HighlightCellRenderer;
