import { themeQuartz, iconSetMaterial } from "ag-grid-community";

const threeDTheme = themeQuartz.withPart(iconSetMaterial).withParams({
  accentColor: "#62BBBB",
  borderColor: "#42484A2E",
  browserColorScheme: "light",
  cellHorizontalPaddingScale: 0.9968749999,
  fontFamily: ["Montserrat", "sans-serif"],
  foregroundColor: "#08394B",
  headerBackgroundColor: "#F5F4EC",
  headerFontFamily: ["Montserrat", "sans-serif"],
  headerFontSize: 14,
  headerFontWeight: 800,
  headerRowBorder: true,
  headerTextColor: "#08394B",
  iconSize: 20,
  rowBorder: true,
  rowVerticalPaddingScale: 0.5,
  spacing: 5,
});

export { threeDTheme };
