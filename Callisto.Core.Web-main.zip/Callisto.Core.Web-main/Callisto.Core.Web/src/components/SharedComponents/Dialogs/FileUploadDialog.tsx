import { forwardRef, useState, useEffect } from "react";

import Container from "@mui/material/Container";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import LinearProgress from "@mui/material/LinearProgress";
import Button from "@mui/material/Button";
import { Box } from "@mui/material";

import Uploady, {
  useRequestPreSend,
  useItemFinishListener,
  useItemErrorListener,
  useUploady,
} from "@rpldy/uploady";
import UploadDropZone from "@rpldy/upload-drop-zone";
import { asUploadButton } from "@rpldy/upload-button";
import UploadIcon from "@mui/icons-material/Upload";
import ErrorIcon from "@mui/icons-material/Error";
import BackupTableIcon from "@mui/icons-material/BackupTable";
import DownloadIcon from "@mui/icons-material/Download";
import SplitButton from "../Buttons/SplitButton";
import { TrackingSystemInfo } from "../../../api/services/receipts-services/ServicesInterfaces";

export interface FileUploadDialogProps {
  isFileUploadDialogOpen: boolean;
  trackingSystemInfo: TrackingSystemInfo | null;
  uploadUrl: string;
  onClose: (value: string) => void;
}

// Mapping of tracking system names to their test file names (with extension)
const TEST_FILE_MAP: Record<string, string> = {
  nar: "NAR_test.csv",
  mrets: "M-RETS_test.csv",
  nepool: "NEPOOL_test.csv",
  pjmgats: "PJM-GATS_test.csv",
  wregis: "WREGIS_test.csv",
  necs: "NECS_test.xlsx",
  tge: "TGE_test.xlsx",
  ncrets: "NCRETS_test.csv",
  irec: "IREC_test.xlsm",
  tigrs: "TIGRS_test.xlsx",
  grex: "GREX_test.xlsx",
};

// Template test file name
const TEMPLATE_TEST_FILE = "TrackingSystemInboxItemTemplate_test.xlsx";

// Normalize tracking system service names to lookup keys
// Any serviceName starting with 'grex_' (or 'grex' plus anything) should map to 'grex'
const normalizeKey = (serviceName: string): string => {
  const lower = serviceName.toLowerCase();
  if (lower === "grex" || lower.startsWith("grex_")) return "grex";
  return lower;
};

export default function FileUploadDialog(props: FileUploadDialogProps) {
  const { isFileUploadDialogOpen, trackingSystemInfo, uploadUrl, onClose } =
    props;
  const displayName =
    trackingSystemInfo?.friendlyName ||
    trackingSystemInfo?.serviceName ||
    "Unknown Tracking System";

  const closeUploadDialog = () => {
    setErrorMessage("");
    setUploadedFile("");
    onClose(uploadId);
  };

  const IconUploadButton = asUploadButton(
    forwardRef<HTMLButtonElement, any>((props, ref) => (
      <Button
        ref={ref}
        variant="contained"
        startIcon={<UploadIcon />}
        disabled={uploadedFile.length != 0}
        {...props}
      >
        Upload
      </Button>
    ))
  );

  const [uploadedFile, setUploadedFile] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [testFileExists, setTestFileExists] = useState<boolean>(false);
  const [templateFileExists, setTemplateFileExists] = useState<boolean>(false);
  let uploadId: string = "";

  // Check if test file exists when dialog opens or trackingSystemInfo changes
  useEffect(() => {
    if (
      trackingSystemInfo?.serviceName &&
      import.meta.env.VITE_INCLUDE_TEST_DATA === "true"
    ) {
      const key = normalizeKey(trackingSystemInfo.serviceName);
      const testFileName = TEST_FILE_MAP[key];
      if (testFileName) {
        const testFilePath = `/TestData/TrackingSystemUploads/${testFileName}`;
        fetch(testFilePath, { method: "HEAD" })
          .then((res) => setTestFileExists(res.ok))
          .catch(() => setTestFileExists(false));
      } else {
        setTestFileExists(false);
      }

      // Check if template file exists
      const templateFilePath = `/TestData/TrackingSystemUploads/${TEMPLATE_TEST_FILE}`;
      fetch(templateFilePath, { method: "HEAD" })
        .then((res) => setTemplateFileExists(res.ok))
        .catch(() => setTemplateFileExists(false));
    } else {
      setTestFileExists(false);
      setTemplateFileExists(false);
    }
  }, [trackingSystemInfo, isFileUploadDialogOpen]);

  const UploadFinishListener = () => {
    useItemFinishListener((item) => {
      if (
        item.uploadStatus === 200 &&
        item.uploadResponse?.data.uploadId !== undefined
      ) {
        uploadId = item.uploadResponse.data.uploadId;
        closeUploadDialog();
      } else {
        setErrorMessage(`Upload failed! Contact Receipts Manager support.`);
      }
    });

    return null;
  };

  const UploadErrorListener = () => {
    useItemErrorListener((item) => {
      uploadId = "";
      const baseErrorMessage = "Processing error!";
      const responseMessage = item.uploadResponse?.data?.message;
      const customErrorMessage =
        baseErrorMessage +
        (responseMessage && responseMessage.length > 0
          ? " " + responseMessage
          : "") +
        " Contact Receipts Manager support.";
      setErrorMessage(customErrorMessage);
    });

    return null;
  };

  const UploadRequestPreSendListener = () => {
    uploadId = "";
    useRequestPreSend(({ items }) => {
      setUploadedFile(items[0].file.name);
      let params = { trackingSystemName: trackingSystemInfo?.serviceName };
      return {
        options: { params },
      };
    });

    return null;
  };

  // Helper component for the Test Template button, must be rendered inside <Uploady>
  // Note: Template test file must be placed in public/TestData/TrackingSystemUploads/
  // to be available when deployed as a static asset
  function TestTemplateButton({
    setUploadedFile,
    setErrorMessage,
    uploadedFile,
  }: {
    setUploadedFile: (name: string) => void;
    setErrorMessage: (msg: string) => void;
    uploadedFile: string;
  }) {
    const uploady = useUploady();

    const uploadTestTemplate = async () => {
      try {
        setUploadedFile(TEMPLATE_TEST_FILE);
        const response = await fetch(
          `/TestData/TrackingSystemUploads/${TEMPLATE_TEST_FILE}`
        );
        if (!response.ok) {
          throw new Error(
            `Failed to load template test file: ${response.status} ${response.statusText}`
          );
        }
        const fileData = await response.arrayBuffer();
        const file = new File([fileData], TEMPLATE_TEST_FILE);
        uploady.upload([file]);
      } catch (error) {
        console.error("Error loading template test data:", error);
        setErrorMessage(
          `Failed to load template test data: ${error instanceof Error ? error.message : "Unknown error"}. Please contact Receipts Manager support.`
        );
        setUploadedFile(""); // Reset the uploaded file state on error
      }
    };

    const downloadTestTemplate = () => {
      const templateFilePath = `/TestData/TrackingSystemUploads/${TEMPLATE_TEST_FILE}`;
      const link = document.createElement("a");
      link.href = templateFilePath;
      link.download = TEMPLATE_TEST_FILE;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };

    return (
      <SplitButton
        mainButtonIcon={<BackupTableIcon />}
        variant="contained"
        color="secondary"
        disabled={uploadedFile.length !== 0}
        menuItems={[
          {
            text: "Test Template",
            onClick: uploadTestTemplate,
            icon: <BackupTableIcon />,
          },
          {
            text: "Download Template",
            onClick: downloadTestTemplate,
            icon: <DownloadIcon />,
          },
        ]}
      />
    );
  }

  // Helper component for the Test button, must be rendered inside <Uploady>
  // Note: Test data file must be placed in public/TestData/TrackingSystemUploads/
  // to be available when deployed as a static asset
  function TestUploadButton({
    setUploadedFile,
    setErrorMessage,
    uploadedFile,
    testFileName,
    displayName,
  }: {
    setUploadedFile: (name: string) => void;
    setErrorMessage: (msg: string) => void;
    uploadedFile: string;
    testFileName: string;
    displayName: string;
  }) {
    const uploady = useUploady();

    const uploadTestData = async () => {
      try {
        setUploadedFile(testFileName);
        const response = await fetch(
          `/TestData/TrackingSystemUploads/${testFileName}`
        );
        if (!response.ok) {
          throw new Error(
            `Failed to load test data file: ${response.status} ${response.statusText}`
          );
        }
        const fileData = await response.arrayBuffer();
        const file = new File([fileData], testFileName);
        uploady.upload([file]);
      } catch (error) {
        console.error("Error loading test data:", error);
        setErrorMessage(
          `Failed to load test data: ${error instanceof Error ? error.message : "Unknown error"}. Please contact Receipts Manager support.`
        );
        setUploadedFile(""); // Reset the uploaded file state on error
      }
    };

    const downloadTestData = () => {
      const testFilePath = `/TestData/TrackingSystemUploads/${testFileName}`;
      const link = document.createElement("a");
      link.href = testFilePath;
      link.download = testFileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };

    return (
      <SplitButton
        mainButtonIcon={<UploadIcon />}
        variant="contained"
        color="secondary"
        disabled={uploadedFile.length !== 0}
        menuItems={[
          {
            text: `Test ${displayName} File`,
            onClick: uploadTestData,
            icon: <UploadIcon />,
          },
          {
            text: `Download ${displayName} File`,
            onClick: downloadTestData,
            icon: <DownloadIcon />,
          },
        ]}
      />
    );
  }

  return (
    <Dialog
      fullWidth={false}
      maxWidth="md"
      onClose={closeUploadDialog}
      open={isFileUploadDialogOpen}
    >
      <DialogTitle>Upload {displayName} File</DialogTitle>
      <DialogContent>
        <Uploady destination={{ url: uploadUrl }}>
          {errorMessage.length === 0 ? (
            <Box>
              {uploadedFile.length === 0 ? (
                <UploadDropZone>
                  <Container
                    style={{
                      height: "100px",
                      border: "1px dashed black",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                    }}
                  >
                    <span>
                      Click the 'Upload' Button or drag the tracking system file
                      here
                    </span>
                  </Container>
                </UploadDropZone>
              ) : (
                <Container
                  style={{
                    height: "100px",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Box>
                    <LinearProgress color="secondary" className="mx-5" />
                    <h5 className="mt-4">Uploading '{uploadedFile}'</h5>
                  </Box>
                </Container>
              )}
            </Box>
          ) : (
            <Container
              style={{
                height: "100px",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <ErrorIcon color="error" fontSize="large" />
              <h5 style={{ marginLeft: "12px" }}>{errorMessage}</h5>
            </Container>
          )}

          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              mt: 2,
              gap: 2,
            }}
          >
            <Box sx={{ display: "flex", gap: 2 }}>
              {templateFileExists && (
                <TestTemplateButton
                  setUploadedFile={setUploadedFile}
                  setErrorMessage={setErrorMessage}
                  uploadedFile={uploadedFile}
                />
              )}
              {testFileExists &&
                trackingSystemInfo?.serviceName &&
                (() => {
                  const key = normalizeKey(trackingSystemInfo.serviceName);
                  const file = TEST_FILE_MAP[key];
                  return file ? (
                    <TestUploadButton
                      setUploadedFile={setUploadedFile}
                      setErrorMessage={setErrorMessage}
                      uploadedFile={uploadedFile}
                      testFileName={file}
                      displayName={displayName}
                    />
                  ) : null;
                })()}
            </Box>
            <Box sx={{ display: "flex", gap: 2 }}>
              <Button
                variant="outlined"
                color="secondary"
                onClick={closeUploadDialog}
              >
                Cancel
              </Button>
              <IconUploadButton />
            </Box>
          </Box>
          <UploadErrorListener />
          <UploadRequestPreSendListener />
          <UploadFinishListener />
        </Uploady>
      </DialogContent>
    </Dialog>
  );
}
