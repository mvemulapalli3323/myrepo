import { Card, Stack, Typography, Box } from "@mui/material";
import WarningAmberOutlined from "@mui/icons-material/WarningAmberOutlined";

const NotFound = () => {
  return (
    <Box sx={{ display: "flex", justifyContent: "center", my: 6 }} data-testid="not-found-page">
      <Card
        elevation={3}
        sx={{
          padding: 4,
          width: "600px",
          borderRadius: 2,
          bgcolor: "primary.main",
        }}
      >
        <Stack spacing={2} sx={{ alignItems: "center" }}>
          <img
            src="/3DLogo.svg"
            alt="3D Logo"
            style={{ width: "300px", height: "auto" }}
          />
          <Stack direction={"row"} spacing={2} sx={{ alignItems: "center" }}>
            <WarningAmberOutlined
              sx={{
                fontSize: 50,
                color: (theme) => theme.palette.common.white,
              }}
            />
            <Typography variant="h5" sx={{ mb: 2, color: "white" }}>
              Not Found
            </Typography>
          </Stack>
          <Typography variant="caption" sx={{ mb: 2, color: "white" }}>
            This page you are looking for does not exist!
          </Typography>
        </Stack>
      </Card>
    </Box>
  );
};

export default NotFound;
