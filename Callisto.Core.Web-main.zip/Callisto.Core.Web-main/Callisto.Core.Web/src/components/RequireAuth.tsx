import { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useMsal, AuthRoles } from "../hooks/useMsal";

interface RequireAuthProps {
  children: ReactNode;
  authorizedRoles: Partial<AuthRoles>;
  fallbackPath?: string;
}

export default function RequireAuth({
  children,
  authorizedRoles,
  fallbackPath = "/notauthorized",
}: RequireAuthProps) {
  const auth = useMsal();
  const location = useLocation();

  // Don't render anything until MSAL is ready
  if (auth.inProgress !== "none" || !auth.username) {
    return null;
  }

  // Ensure at least one role is specified
  if (Object.keys(authorizedRoles).length === 0) {
    throw new Error(
      "RequireAuth: authorizedRoles must contain at least one role"
    );
  }

  // Check if user has any of the authorized roles
  const isAuthorized = Object.entries(authorizedRoles).some(
    ([roleKey, authorized]) =>
      authorized && auth[roleKey as keyof AuthRoles] === true
  );

  if (isAuthorized) {
    return <>{children}</>;
  }

  return (
    <Navigate to={fallbackPath} replace state={{ path: location.pathname }} />
  );
}
