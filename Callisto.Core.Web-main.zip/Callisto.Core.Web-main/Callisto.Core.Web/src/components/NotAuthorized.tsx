import { Card, Stack, Typography, Box } from "@mui/material";

const NotAuthorized = () => {
  return (
    <Box sx={{ display: "flex", justifyContent: "center", my: 6 }} data-testid="not-authorized-page">
      <Card
        elevation={3}
        sx={{
          padding: 4,
          width: "600px",
          borderRadius: 2,
          bgcolor: "primary.main",
        }}
      >
        <Stack spacing={2} sx={{ alignItems: "center" }}>
          <img
            src="/3DLogo.svg"
            alt="3D Logo"
            style={{ width: "300px", height: "auto" }}
          />
          <Typography variant="h6" sx={{ mb: 2, color: "white" }}>
            Not Authorized
          </Typography>
          <Typography variant="body1" sx={{ mb: 2, color: "white" }}>
            If you require access, please contact the 3D help desk!
          </Typography>
        </Stack>
      </Card>
    </Box>
  );
};

export default NotAuthorized;
