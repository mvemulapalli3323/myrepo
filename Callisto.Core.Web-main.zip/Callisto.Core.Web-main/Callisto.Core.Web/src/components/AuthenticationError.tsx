import { Paper, Stack, Typography, Box, Link } from "@mui/material";

const AuthenticationError = () => {
  return (
    <Box sx={{ display: "flex", justifyContent: "center", my: 6 }} data-testid="authentication-error-page">
      <Paper elevation={3} sx={{ padding: 4, width: "600px", borderRadius: 2 }}>
        <Stack spacing={2} sx={{ alignItems: "center" }}>
          <img
            src="/3DLogo.svg"
            alt="3D Logo"
            style={{ width: "300px", height: "auto" }}
          />
          <Typography variant="h6" sx={{ mb: 2 }}>
            Authentication configuration error!
          </Typography>
          <Typography variant="body1">
            Please{" "}
            <Link
              target="_blank"
              href="https://3degreesinc.atlassian.net/wiki/spaces/IT/pages/3702790/Helpdesk+Tool"
            >
              contact
            </Link>{" "}
            the 3D help desk!
          </Typography>
        </Stack>
      </Paper>
    </Box>
  );
};

export default AuthenticationError;
