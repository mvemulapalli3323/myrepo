import React, { useState, useContext, useCallback, useEffect } from "react";
import { Context } from "../../Context/AppContext";
import {
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Box,
  Typography,
  Badge,
  Tooltip,
} from "@mui/material";
import AssignmentAddIcon from "@mui/icons-material/AssignmentAdd";
import CloseIcon from "@mui/icons-material/Close";
import SearchIcon from "@mui/icons-material/Search";
import InputField from "../SharedComponents/Inputs/Input";
import AutomatedReceiptsGrid from "../SharedComponents/Grids/AgGrid";
import { SearchProducts } from "../SharedComponents/Grids/GridColDefs";
import {
  getSearchProducts,
  productSearchSelection,
  productSearchSelectionBulk,
} from "../../api/services/receipts-services/ProductService";
import { SelectionChangedEvent } from "ag-grid-enterprise";
import {
  ProductRowData,
  RowDataInterfaces,
  SearchRowData,
} from "../../api/services/receipts-services/ServicesInterfaces";
import { useParams } from "react-router-dom";
import "ag-grid-enterprise";

type Params = {
  id: string | undefined;
};

const ProductSearch: React.FC = () => {
  const { id } = useParams<Params>();

  const context = useContext(Context);
  if (!context) {
    throw new Error("ProductSearch must be used within an AppProvider");
  }
  const [formData, setFormData] = useState({
    searchText: "",
    positionId: 0,
    inboxTransactionId: "",
    quantity: 0,
    vintageId: 0,
    errors: "",
    warnings: "",
    id: 0,
    deliveryDateUtc: "",
    singleProduct: {
      positionId: 0,
      inboxTransactionId: "",
      quantity: 0,
      errors: "",
      warnings: "",
      id: 0,
      deliveryDateUtc: "",
      vintageId: 0,
      vintageDate: "",
      vintageDateEnd: "",
      deliveredFlag: false,
    },
  });
  const { data, setData, setOpen } = context;
  const [searchProductsData, setSearchProductsData] = useState<
    RowDataInterfaces[]
  >([]);
  const [searchSelectedRow, setSearchSelectedRow] = useState<SearchRowData[]>(
    []
  );
  const [refresh, setRefresh] = useState(false);
  const [originalReceiptCount, setOriginalReceiptCount] = useState<number>(0);

  const handleClose = () => {
    setOpen(false);
  };

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, searchText: event.target.value });
  };

  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      event.preventDefault();
      handleSearch();
    }
  };

  const onSelectionChanged = useCallback(
    async (event: SelectionChangedEvent) => {
      const selectedRowsData = event.api.getSelectedRows();
      setSearchSelectedRow(selectedRowsData);
    },
    []
  );

  const handleSubmit = async () => {
    if (!searchSelectedRow.length) return;
    const allocationIds: string[] = [];
    if (data.length > 1) {
      (data as ProductRowData[]).forEach((item: ProductRowData) => {
        if (item.id) {
          allocationIds.push(item.id);
        }
        console.log(item);
      });
      const bulkParams = {
        allocationIds,
        allocationTransactionId: id ?? "",
        productId: searchSelectedRow[0]?.productId ?? null,
        product: searchSelectedRow[0]?.productDescription ?? "",
      };
      try {
        const result = await productSearchSelectionBulk(bulkParams);
        setData(result.data);
        setOpen(false);
      } catch (err) {
        console.error(err);
      }
    } else {
      const searchSelection = {
        allocationTransactionId: id ?? "",
        positionId: formData.singleProduct.positionId.toString(),
        inboxTransactionId: formData.singleProduct.inboxTransactionId,
        quantity: formData.singleProduct.quantity,
        errors: Array.isArray(formData.singleProduct.errors)
          ? formData.singleProduct.errors
          : [formData.singleProduct.errors],
        warnings: Array.isArray(formData.singleProduct.warnings)
          ? formData.singleProduct.warnings
          : [formData.singleProduct.warnings],
        id: formData.singleProduct.id,
        vintageId: formData?.singleProduct.vintageId,
        productId: searchSelectedRow[0]?.productId ?? null,
        product: searchSelectedRow[0]?.productDescription ?? "",
        deliveryDateUtc: formData.singleProduct.deliveryDateUtc,
        vintageDate: formData.singleProduct.vintageDate || "",
        vintageDateEnd: formData.singleProduct.vintageDateEnd || "",
        deliveredFlag: formData.singleProduct.deliveredFlag || false,
      };

      try {
        const result = await productSearchSelection(searchSelection);
        setData(result.data);
        setOpen(false);
      } catch (err) {
        console.error(err);
      }
    }
  };

  useEffect(() => {
    if (data && data.length > 0) {
      setOriginalReceiptCount(data.length); // Store the original count
      const firstItem = data[0] as {
        suggestProducts: never[];
        searchText: string;
        positionId: number;
        inboxTransactionId: string;
        quantity: number;
        errors: string;
        warnings: string;
        id: number;
        deliveryDateUtc: string;
        vintageId: number;
        vintageDate?: string;
        vintageDateEnd?: string;
        deliveredFlag?: boolean;
      };

      setFormData((prev) => ({
        ...prev,
        ...data,
        singleProduct: {
          ...firstItem,
          vintageDate: firstItem.vintageDate || "",
          vintageDateEnd: firstItem.vintageDateEnd || "",
          deliveredFlag: firstItem.deliveredFlag || false,
        },
      }));

      const selectedSuggestProduct: ProductRowData[] = [];

      (data as ProductRowData[]).forEach((item: ProductRowData) => {
        if (item.suggestedProducts) {
          const suggestProducts =
            item.suggestedProducts as unknown as ProductRowData[];
          const uniqueProducts = suggestProducts.filter(
            (product) =>
              !selectedSuggestProduct.some(
                (existing) => existing.productId === product.productId
              )
          );
          selectedSuggestProduct.push(...uniqueProducts);
        }
      });

      setSearchProductsData(
        selectedSuggestProduct as unknown as RowDataInterfaces[]
      );
    }
  }, [data]);

  const handleSearch = async () => {
    if (formData.searchText.trim() !== "") {
      const productsearchParams = {
        SearchTerm: formData.searchText,
        PageSize: 50,
        PageNumber: 0,
        PaginationType: "Paged",
      };
      try {
        setRefresh(true);
        setSearchProductsData([]);
        const result = await getSearchProducts(productsearchParams);
        const rows = result?.data?.products?.data ?? [];
        setSearchProductsData([...rows]);
      } catch (err) {
        console.error(err);
      } finally {
        setRefresh(false);
      }
    }
  };

  return (
    <>
      <DialogTitle
        sx={{
          m: 0,
          p: 2,
          bgcolor: "primary.main",
          color: "primary.contrastText",
        }}
        id="customized-dialog-title"
        data-testid="modal-title"
      >
        <Typography variant="h6" sx={{ color: "inherit" }}>
          Product Search
        </Typography>
      </DialogTitle>
      <IconButton
        aria-label="close"
        onClick={handleClose}
        sx={(theme) => ({
          position: "absolute",
          right: 8,
          top: 8,
          color: theme.palette.grey[500],
        })}
      >
        <CloseIcon sx={{ fontSize: 24 }} />
      </IconButton>
      <DialogContent sx={{ p: 3 }}>
        <Box
          sx={{
            display: "flex",
            gap: 2,
            mb: 2,
            alignItems: "center",
            maxWidth: "50%",
          }}
        >
          <Box sx={{ flexGrow: 1 }}>
            <InputField
              label="Search Text"
              error={false}
              errorText=""
              value={formData.searchText}
              onChange={handleChange}
              onKeyPress={handleKeyPress}
              placeholder="Enter search text..."
            />
          </Box>
          <Button
            variant="contained"
            color="primary"
            size="large"
            onClick={handleSearch}
            disabled={refresh || !formData.searchText.trim()}
            startIcon={<SearchIcon />}
          >
            Search
          </Button>
        </Box>
        <AutomatedReceiptsGrid
          rowData={searchProductsData}
          colDefs={SearchProducts("")}
          onSelectionChanged={onSelectionChanged}
          detailCellRendererParams={undefined}
          rowClassRules={{}}
          findSearchValue={formData.searchText}
          loading={refresh}
          loadingMessage="Searching Products"
          noRowsMessage="No matching products found"
          gridId="productSearch-grid"
          rowSelection={{
            mode: "singleRow",
            headerCheckbox: false,
            checkboxes: true,
          }}
        />
      </DialogContent>
      <DialogActions sx={{ mr: 2, mb: 1 }}>
        <Box sx={{ display: "flex", gap: 2 }}>
          <Button variant="outlined" color="secondary" onClick={handleClose}>
            Cancel
          </Button>
          <Tooltip
            title={`Updating ${originalReceiptCount} Receipt Row${originalReceiptCount === 1 ? "" : "s"}`}
          >
            <Badge badgeContent={originalReceiptCount} color="info">
              <Button
                variant="contained"
                color="primary"
                onClick={handleSubmit}
                disabled={!searchSelectedRow.length}
                startIcon={<AssignmentAddIcon />}
              >
                Assign Product
              </Button>
            </Badge>
          </Tooltip>
        </Box>
      </DialogActions>
    </>
  );
};

export default ProductSearch;
