import React, { SyntheticEvent, useContext, useEffect, useState } from "react";
import {
  Autocomplete,
  AutocompleteRenderInputParams,
  Button,
  Checkbox,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControlLabel,
  IconButton,
  TextField,
  Theme,
  Badge,
  Tooltip,
  Box,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import SaveIcon from "@mui/icons-material/Save";
import { useParams } from "react-router-dom";
import { Context } from "../../Context/AppContext";
import {
  EditFormData,
  Params,
  VintageOption,
} from "../../api/services/receipts-services/ServicesInterfaces";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs, { Dayjs } from "dayjs";
import {
  getVintages,
  productSelectionUpdate,
} from "../../api/services/receipts-services/ProductService";

const EditPosition: React.FC = () => {
  const { id } = useParams() as unknown as Params;

  const context = useContext(Context);
  if (!context) {
    throw new Error("ProductSearch must be used within an AppProvider");
  }
  const { data, setData, setOpen } = context;
  const [formData, setFormData] = useState<EditFormData[]>([]);
  const [vintageOptions, setVintageOptions] = useState<
    { value: string | number; label: string | number }[]
  >([]);
  const [datePickerValue, setDatePickerValue] = useState<Dayjs | null>(null);
  const [deliveredFlag, setDeliveredFlag] = useState<boolean>(false);
  const [isDeliveredFlagDirty, setIsDeliveredFlagDirty] =
    useState<boolean>(false);
  const [SelectedVintage, setSelectedVintage] = useState<number | null>(null);
  const [vintageDate, setVintageDate] = useState<Dayjs | null>(null);
  const [vintageDateEnd, setVintageDateEnd] = useState<Dayjs | null>(null);
  const [deliveryDateError, setDeliveryDateError] = useState<string>("");
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isFormInitialized, setIsFormInitialized] = useState<boolean>(false);
  const [documentLocation, setDocumentLocation] = useState<string>("");
  const [documentLocationError, setDocumentLocationError] =
    useState<string>("");

  const MAX_DOCUMENT_LOCATION_LENGTH = 4096;

  useEffect(() => {
    const fetchData = async () => {
      if (
        data &&
        Array.isArray(data) &&
        data.length > 0 &&
        !isFormInitialized
      ) {
        setFormData(data as EditFormData[]);
        setIsFormInitialized(true);
        try {
          const result = await getVintages();
          const modifiedData = result.data.map((item: VintageOption) => ({
            value: item.generationPeriodId,
            label: item.generationPeriodName,
          }));
          setVintageOptions(modifiedData);
          const typedData = data as EditFormData[];
          const defaultVintage = typedData.map((item: EditFormData) => ({
            value: item.vintageId,
            label: item.vintage,
          }));
          if (typedData.length == 1) {
            setSelectedVintage(defaultVintage[0].value ?? null);
            setDeliveredFlag(typedData[0].deliveredFlag ?? false);
            setDatePickerValue(
              typedData[0].deliveryDateUtc &&
                dayjs(typedData[0].deliveryDateUtc).isValid()
                ? dayjs(typedData[0].deliveryDateUtc)
                : null
            );
            setVintageDate(
              typedData[0].vintageDate &&
                dayjs(typedData[0].vintageDate).isValid()
                ? dayjs(typedData[0].vintageDate)
                : null
            );
            setVintageDateEnd(
              typedData[0].vintageDateEnd &&
                dayjs(typedData[0].vintageDateEnd).isValid()
                ? dayjs(typedData[0].vintageDateEnd)
                : null
            );
            setDocumentLocation(typedData[0].documentLocation ?? "");
          }
        } catch (err) {
          console.error(err);
        }
      }
    };

    fetchData();
  }, [data, isFormInitialized]);
  const handleClose = () => {
    setOpen(false);
  };

  function handleChange(
    event: SyntheticEvent<Element, Event>,
    value: { value: string | number; label: string | number } | null
  ): void {
    console.log(event);
    const selectedValue = value?.value ?? null;
    setSelectedVintage(
      typeof selectedValue === "number" ? selectedValue : null
    );
  }
  const handleSubmit = async () => {
    if (!Array.isArray(formData) || formData.length === 0) {
      return;
    }

    // Validate delivery date is not in the future
    if (datePickerValue && datePickerValue.isAfter(dayjs(), "day")) {
      setDeliveryDateError("Delivery date cannot be in the future");
      return;
    }

    if (documentLocation.length > MAX_DOCUMENT_LOCATION_LENGTH) {
      setDocumentLocationError(
        `Maximum ${MAX_DOCUMENT_LOCATION_LENGTH} characters allowed`
      );
      return;
    }

    setIsSaving(true);

    const updatedDataArray: EditFormData[] = formData.map((item) => {
      return {
        id: item.id,
        product: item.product,
        productId: item.productId,
        vintageId: SelectedVintage ?? item.vintageId,
        deliveredFlag: isDeliveredFlagDirty
          ? deliveredFlag
          : item.deliveredFlag,
        deliveryDateUtc: datePickerValue
          ? datePickerValue.format("YYYY-MM-DD")
          : item.deliveryDateUtc,
        vintageDate: vintageDate
          ? vintageDate.format("YYYY-MM-DD")
          : item.vintageDate,
        vintageDateEnd: vintageDateEnd
          ? vintageDateEnd.format("YYYY-MM-DD")
          : item.vintageDateEnd,
        documentLocation: documentLocation ?? item.documentLocation,
      };
    });

    try {
      const result = await productSelectionUpdate(updatedDataArray, id ?? "");
      // Set the updated data to trigger a refresh in the parent component
      setData(result.data);
      // Close the modal
      setOpen(false);
    } catch (err) {
      console.error("Error updating product selection:", err);
      // Even on error, close the modal to prevent it from staying open
      setOpen(false);
    } finally {
      setIsSaving(false);
    }
  };
  return (
    <>
      <DialogTitle
        className="border-0"
        sx={{ m: 0, p: 1 }}
        id="customized-dialog-title"
        style={{ backgroundColor: "#08394b", color: "#fff" }}
      >
        Edit Position
      </DialogTitle>
      <IconButton
        aria-label="close"
        onClick={handleClose}
        sx={(theme: Theme) => ({
          position: "absolute",
          right: 8,
          top: 8,
          color: theme.palette.grey[100],
        })}
      >
        <CloseIcon />
      </IconButton>
      <DialogContent>
        <Box>
          <Box sx={{ width: "100%" }}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                sx={{ width: "100%", mb: 2 }}
                label="Vintage Date"
                value={vintageDate}
                disabled={isSaving}
                onChange={(newValue) => {
                  if (newValue) {
                    setVintageDate(dayjs(newValue));
                  } else {
                    setVintageDate(null);
                  }
                }}
              />
              <DatePicker
                sx={{ width: "100%", mb: 2 }}
                label="Vintage Date End"
                value={vintageDateEnd}
                disabled={isSaving}
                onChange={(newValue) => {
                  if (newValue) {
                    setVintageDateEnd(dayjs(newValue));
                  } else {
                    setVintageDateEnd(null);
                  }
                }}
              />
            </LocalizationProvider>
          </Box>
          <Box sx={{ width: "100%", mb: 2 }}>
            <Autocomplete
              options={vintageOptions}
              value={
                SelectedVintage
                  ? vintageOptions.find(
                      (option) => option.value === SelectedVintage
                    )
                  : null
              }
              disabled={isSaving}
              renderInput={(params: AutocompleteRenderInputParams) => (
                <TextField
                  {...params}
                  label="Vintage"
                  variant="outlined"
                  sx={{
                    "& .MuiOutlinedInput-root": {
                      "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "primary.main",
                      },
                      "&:hover .MuiOutlinedInput-notchedOutline": {
                        borderColor: "primary.main",
                      },
                    },
                    "& .MuiInputLabel-root.Mui-focused": {
                      color: "primary.main",
                    },
                  }}
                />
              )}
              onChange={handleChange}
              sx={{
                "& .MuiAutocomplete-popupIndicator": {
                  color: "primary.main",
                },
                "& .MuiAutocomplete-clearIndicator": {
                  color: "primary.main",
                },
              }}
            />
          </Box>
          <Box sx={{ width: "100%", mb: 2 }}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                sx={{ width: "100%" }}
                label="Delivery Date"
                value={datePickerValue}
                maxDate={dayjs()}
                disabled={isSaving}
                onChange={(newValue) => {
                  if (newValue) {
                    const selectedDate = dayjs(newValue);
                    setDatePickerValue(selectedDate);
                    // Clear error when user selects a valid date
                    if (selectedDate.isAfter(dayjs(), "day")) {
                      setDeliveryDateError(
                        "Delivery date cannot be in the future"
                      );
                    } else {
                      setDeliveryDateError("");
                    }
                  } else {
                    setDatePickerValue(null);
                    setDeliveryDateError("");
                  }
                }}
                slotProps={{
                  textField: {
                    error: !!deliveryDateError,
                    helperText: deliveryDateError,
                  },
                }}
              />
            </LocalizationProvider>
          </Box>
          <Box sx={{ width: "100%", mb: 2 }}>
            <TextField
              fullWidth
              label="Document Location"
              value={documentLocation}
              disabled={isSaving}
              onChange={(e) => {
                const newValue = e.target.value;
                setDocumentLocation(newValue);

                // Validate length on change
                if (newValue.length > MAX_DOCUMENT_LOCATION_LENGTH) {
                  setDocumentLocationError(
                    `Maximum ${MAX_DOCUMENT_LOCATION_LENGTH} characters allowed (${newValue.length}/${MAX_DOCUMENT_LOCATION_LENGTH})`
                  );
                } else {
                  setDocumentLocationError("");
                }
              }}
              variant="outlined"
              error={!!documentLocationError}
              helperText={
                documentLocationError ||
                `${documentLocation.length}/${MAX_DOCUMENT_LOCATION_LENGTH} characters`
              }
              slotProps={{
                htmlInput: { maxLength: MAX_DOCUMENT_LOCATION_LENGTH },
              }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                    borderColor: "primary.main",
                  },
                  "&:hover .MuiOutlinedInput-notchedOutline": {
                    borderColor: "primary.main",
                  },
                },
                "& .MuiInputLabel-root.Mui-focused": {
                  color: "primary.main",
                },
              }}
            />
          </Box>
        </Box>
        <Box>
          <FormControlLabel
            control={
              <Checkbox
                checked={deliveredFlag}
                disabled={isSaving}
                onChange={(e) => {
                  setDeliveredFlag(e.target.checked);
                  setIsDeliveredFlagDirty(true);
                }}
              />
            }
            label="Delivered Flag"
          />
        </Box>
      </DialogContent>
      <DialogActions sx={{ mr: 2, mb: 1 }}>
        <Button
          variant="outlined"
          color="secondary"
          onClick={handleClose}
          disabled={isSaving}
        >
          Cancel
        </Button>
        <Tooltip
          title={
            deliveryDateError
              ? "Please fix validation errors before saving"
              : `Updating ${formData.length} Receipt Row${formData.length === 1 ? "" : "s"}`
          }
        >
          <Badge badgeContent={formData.length} color="info">
            <Button
              variant="contained"
              startIcon={<SaveIcon />}
              onClick={handleSubmit}
              disabled={
                !!deliveryDateError || !!documentLocationError || isSaving
              }
              loading={isSaving}
            >
              Save
            </Button>
          </Badge>
        </Tooltip>
      </DialogActions>
    </>
  );
};

export default EditPosition;
