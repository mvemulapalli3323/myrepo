import React, { useState, useEffect, useCallback } from "react";
import SelectVariants from "../SharedComponents/Selects/select";
import InputField from "../SharedComponents/Inputs/Input";
import {
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Theme,
  Button,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import SearchIcon from "@mui/icons-material/Search";
import {
  getCommodity,
  getPositionData,
  getTrackingSystemRegistrys,
} from "../../api/services/receipts-services/PositionService";
import { positionModelColDefs } from "../SharedComponents/Grids/GridColDefs";
import AutomatedReceiptsGrid from "../SharedComponents/Grids/AgGrid";
import { SelectionChangedEvent } from "ag-grid-enterprise";
import {
  CommodityOption,
  GetTrackingSystems,
  TrackingSystemRegistrys,
  DataTag,
  searchPositionsFormData,
  TrackingSystemInfo,
} from "../../api/services/receipts-services/ServicesInterfaces";
import { PositionModel } from "@/api/types/receipts-types";
import AddIcon from "@mui/icons-material/Add";

interface SearchPositionProps {
  selectedTrackingSystemInfo?: TrackingSystemInfo | null;
  onComplete: (data: PositionModel[]) => void;
  onClose: () => void;
  alreadySelectedPositions?: PositionModel[]; // Change from PositionRowData[] to PositionModel[]
}

const SearchPosition: React.FC<SearchPositionProps> = ({
  selectedTrackingSystemInfo,
  onComplete,
  onClose,
  alreadySelectedPositions = [], // Default to empty array
}) => {
  const [fliteredSearchPosition, setFilteredSearchPosition] = useState<
    PositionModel[]
  >([]);
  const [selectedRows, setSelectedRows] = useState<PositionModel[]>([]);
  const [show, setShow] = useState(false);
  const [error, setError] = useState(false);
  const [textError, settextError] = useState(false);
  const [commodityoptions, setcommodityoptions] = useState<CommodityOption[]>(
    []
  );
  const [trackingSystemOptions, settrackingSystemOptions] = useState<
    CommodityOption[]
  >([]);
  const [formData, setFormData] = useState<searchPositionsFormData>({
    deliveryWithinMonths: 2,
  } as searchPositionsFormData);

  // Get already selected position IDs for comparison
  const alreadySelectedPositionIds = alreadySelectedPositions
    .map((pos) => pos.positionId)
    .filter((id): id is number => id !== undefined);

  const handleChange = useCallback(
    async (
      name: string,
      value: string | number | null,
      dataTags?: DataTag[]
    ) => {
      setFormData((prev) => ({ ...prev, [name]: value }));
      if (name === "commodity") {
        try {
          const result = await getTrackingSystemRegistrys({
            commodityId: value === null ? undefined : value,
          });
          const trackingSystemData = result.data.map(
            (item: GetTrackingSystems) => ({
              value: item.trackingSystemId
                ? item.trackingSystemId
                : item.registryId,
              label: item.name,
              dataTags: [
                { key: "trackingsystemid", value: item.trackingSystemId },
                { key: "registryid", value: item.registryId },
              ],
            })
          );
          settrackingSystemOptions(trackingSystemData);
          setFormData((prev) => ({
            ...prev,
            trackingSystem: null,
            registry: null,
          }));
          setError(false);
        } catch (err) {
          console.error(err);
        }
      } else if (name === "deliveryWithinMonths") {
        settextError(false);
      } else if (name === "trackingSystem") {
        if (value === "ANY") {
          setFormData((prev) => ({
            ...prev,
            trackingSystem: -1,
            registry: -1,
          }));
          return;
        }

        const trackingSystemId = dataTags?.find(
          (item: DataTag) => item.key === "trackingsystemid"
        )?.value;
        const registryId = dataTags?.find(
          (item: DataTag) => item.key === "registryid"
        )?.value;

        setFormData((prev) => ({
          ...prev,
          trackingSystem: trackingSystemId || null,
          registry: registryId || null,
        }));
        return;
      }
    },
    []
  );

  const handleSubmit = async () => {
    let hasError = false;
    if (!formData.commodity) {
      setError(true);
      hasError = true;
    }
    if (
      formData.deliveryWithinMonths === undefined ||
      formData.deliveryWithinMonths === null
    ) {
      settextError(true);
      hasError = true;
    }
    if (hasError) return;
    const searchParams = {
      PositionSide: "Long",
      CommodityId: formData.commodity,
      DeliveryExpectationsMonth: formData.deliveryWithinMonths,
      CounterpartyName: formData.counterParty,
      AltRate: formData.rateAltrate ?? null,
      Rate: formData.rateAltrate ?? null,
      Quantity: formData.quantity ?? null,
      DeliveryTrackingSystemId:
        formData.trackingSystem === -1 ? null : formData.trackingSystem,
      DeliveryStatus: "NotDelivered",
      PageSize: 30,
      PageNumber: 0,
      PaginationType: "Paged",
    };
    try {
      const result = await getPositionData(searchParams);
      setFilteredSearchPosition(result.data ?? []);
      setShow(true);
    } catch (err) {
      console.error(err);
    }
  };
  const handleEdit = () => {
    setShow(false);
    setSelectedRows([]);
  };
  const handleNext = () => {
    onComplete(selectedRows);
  };
  // Enhanced row class rules to handle already selected positions
  // Disable multi-select for already selected positions
  const rowClassRules = {
    "already-selected-row": (params: any) => {
      return alreadySelectedPositionIds.includes(params.data.positionId);
    },
  };

  const isRowSelectable = () => {
    return true;
  };

  const onGridReady = useCallback(
    (event: any) => {
      // Initialize selections: only select disabled rows
      event.api.forEachNode((node: any) => {
        const isDisabled = alreadySelectedPositionIds.includes(
          node.data.positionId
        );
        node.setSelected(isDisabled, false, true);
      });
    },
    [alreadySelectedPositionIds]
  );

  const onSelectionChangedWrapped = useCallback(
    (event: SelectionChangedEvent) => {
      const allNodes: any[] = [];
      event.api.forEachNode((node: any) => allNodes.push(node));
      allNodes.forEach((node) => {
        const isDisabled = alreadySelectedPositionIds.includes(
          node.data.positionId
        );
        if (isDisabled) {
          // Keep disabled rows selected
          if (!node.isSelected()) {
            node.setSelected(true, false, true);
          }
        }
      });
      const selectedRows = allNodes
        .filter((node) => node.isSelected())
        .map((node) => node.data);
      setSelectedRows(selectedRows);
      event.api.refreshCells({ force: true });
    },
    [alreadySelectedPositionIds]
  );
  // Initialize form data when selectedTrackingSystemInfo is provided
  useEffect(() => {
    const initializeData = async () => {
      try {
        // If we have selectedTrackingSystemInfo, we can load both APIs in parallel
        if (selectedTrackingSystemInfo) {
          const [commodityResult, trackingSystemResult] = await Promise.all([
            getCommodity(),
            getTrackingSystemRegistrys({
              commodityId: selectedTrackingSystemInfo.commodityId,
            }),
          ]);

          // Set commodities
          const commodityData = commodityResult.data.map(
            (item: TrackingSystemRegistrys) => ({
              value: item.commodityId,
              label: item.commodityName,
            })
          );
          setcommodityoptions(commodityData);

          // Set tracking systems
          const trackingSystemData = trackingSystemResult.data.map(
            (item: GetTrackingSystems) => ({
              value: item.trackingSystemId
                ? item.trackingSystemId
                : item.registryId,
              label: item.name,
              dataTags: [
                { key: "trackingsystemid", value: item.trackingSystemId },
                { key: "registryid", value: item.registryId },
              ],
            })
          );
          settrackingSystemOptions(trackingSystemData);

          // Set form data with defaults in one operation
          setFormData((prev) => ({
            ...prev,
            commodity: String(selectedTrackingSystemInfo.commodityId),
            trackingSystem: selectedTrackingSystemInfo.trackingSystemId,
            registry: null,
          }));

          setError(false);
        } else {
          // Fallback: just load commodities if no selectedTrackingSystemInfo
          const result = await getCommodity();
          const commodityData = result.data.map(
            (item: TrackingSystemRegistrys) => ({
              value: item.commodityId,
              label: item.commodityName,
            })
          );
          setcommodityoptions(commodityData);
        }
      } catch (err) {
        console.error(err);
      }
    };

    initializeData();
  }, [selectedTrackingSystemInfo]);

  // Simplified: Only load tracking systems when commodity changes manually (not on initial load)
  useEffect(() => {
    const loadTrackingSystemOptions = async () => {
      if (formData.commodity && !selectedTrackingSystemInfo) {
        try {
          const result = await getTrackingSystemRegistrys({
            commodityId: formData.commodity,
          });
          const trackingSystemData = result.data.map(
            (item: GetTrackingSystems) => ({
              value: item.trackingSystemId
                ? item.trackingSystemId
                : item.registryId,
              label: item.name,
              dataTags: [
                { key: "trackingsystemid", value: item.trackingSystemId },
                { key: "registryid", value: item.registryId },
              ],
            })
          );
          settrackingSystemOptions(trackingSystemData);
          setError(false);
        } catch (err) {
          console.error(err);
        }
      }
    };

    loadTrackingSystemOptions();
  }, [formData.commodity, selectedTrackingSystemInfo]);

  return (
    <>
      <DialogTitle
        sx={{ m: 0, p: 2, backgroundColor: "primary.main", color: "white" }}
        id="draggable-dialog-title"
      >
        Search Positions
      </DialogTitle>
      <IconButton
        aria-label="close"
        onClick={onClose}
        sx={(theme: Theme) => ({
          position: "absolute",
          right: 8,
          top: 8,
          color: theme.palette.grey[100],
        })}
      >
        <CloseIcon />
      </IconButton>
      <DialogContent>
        {show === false ? (
          <>
            <div className="flex space-x-4">
              <div className="w-full mb-3">
                <SelectVariants
                  error={error}
                  errorText="Please Select Commodity"
                  options={commodityoptions}
                  label="Commodity *"
                  inputLabel="Commodity *"
                  value={formData.commodity}
                  disabled={false}
                  onChange={(event) =>
                    handleChange("commodity", event.target.value)
                  }
                />
              </div>
              <div className="w-full mb-3">
                <InputField
                  label="Quantity"
                  error={false}
                  errorText=""
                  value={formData.quantity ? String(formData.quantity) : ""}
                  onChange={(event) => {
                    const value = event.target.value;
                    const regex = /^\d*\.?\d{0,6}$/;
                    if (regex.test(value) || value === "") {
                      handleChange("quantity", value === "" ? null : value);
                    }
                  }}
                  placeholder="Enter quantity"
                />
              </div>
            </div>
            <div className="flex space-x-4">
              <div className="w-full mb-3">
                <SelectVariants
                  options={[
                    { label: "ANY", value: "ANY" },
                    ...trackingSystemOptions,
                  ]}
                  error={false}
                  errorText=""
                  inputLabel="Tracking System"
                  value={
                    formData.trackingSystem === -1
                      ? "ANY"
                      : formData.trackingSystem || formData.registry
                  }
                  disabled={trackingSystemOptions.length === 0}
                  label="Tracking System"
                  onChange={(event, dataTags) =>
                    handleChange("trackingSystem", event.target.value, dataTags)
                  }
                />
              </div>
              <div className="w-full mb-3">
                <InputField
                  label="Counterparty"
                  error={false}
                  errorText=""
                  value={formData.counterParty}
                  onChange={(event) =>
                    handleChange("counterParty", event.target.value)
                  }
                  placeholder="Type something..."
                />
              </div>
            </div>
            <div className="flex space-x-4">
              <div className="w-full mb-3">
                <InputField
                  label="Delivery Within +/- Months *"
                  error={textError}
                  errorText="This field is required"
                  value={
                    formData.deliveryWithinMonths
                      ? String(formData.deliveryWithinMonths)
                      : ""
                  }
                  onChange={(event) => {
                    const value = event.target.value;
                    const regex = /^\d*$/;
                    if (regex.test(value) || value === "") {
                      handleChange(
                        "deliveryWithinMonths",
                        value === "" ? null : Number(value)
                      );
                    }
                  }}
                  placeholder="Enter months"
                />
              </div>
              <div className="w-full mb-3">
                <InputField
                  label="Rate / Alt Rate"
                  value={
                    formData.rateAltrate ? String(formData.rateAltrate) : ""
                  }
                  onChange={(event) => {
                    const value = event.target.value;
                    const regex = /^\d*\.?\d{0,4}$/;
                    if (regex.test(value) || value === "") {
                      handleChange("rateAltrate", value === "" ? null : value);
                    }
                  }}
                  placeholder="Enter rateAltrate"
                  error={false}
                />
              </div>
            </div>
          </>
        ) : (
          <AutomatedReceiptsGrid
            data-testid="search-position-grid"
            onColumnMoved={() => {}}
            onGridReady={onGridReady}
            rowData={fliteredSearchPosition}
            colDefs={positionModelColDefs} // Use original column definitions
            onSelectionChanged={onSelectionChangedWrapped}
            detailCellRendererParams={undefined}
            rowClassRules={rowClassRules}
            gridId="search-positions-grid"
            isRowSelectable={isRowSelectable}
            disabledRowIds={alreadySelectedPositionIds}
          />
        )}
      </DialogContent>
      <DialogActions className="border-0">
        {show === false ? (
          <div
            className="text-end me-2"
            style={{ display: "flex", justifyContent: "flex-end", gap: "8px" }}
          >
            <Button variant="outlined" color="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button
              variant="contained"
              startIcon={<SearchIcon />}
              onClick={handleSubmit}
            >
              Search
            </Button>
          </div>
        ) : (
          <div className="text-end me-2">
            <Button
              variant="outlined"
              color="secondary"
              sx={{ mr: 1 }}
              onClick={handleEdit}
            >
              Edit Search
            </Button>
            <Button
              variant="contained"
              startIcon={<AddIcon fontSize="small" />}
              onClick={handleNext}
              disabled={!selectedRows || selectedRows.length === 0}
            >
              Add
            </Button>
          </div>
        )}
      </DialogActions>
    </>
  );
};

export default SearchPosition;
