import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import {
  AppBar,
  Box,
  Toolbar,
  IconButton,
  Typography,
  Menu,
  MenuItem,
  Link as MuiLink,
  useTheme,
  useMediaQuery,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import { useMsal } from "../hooks/useMsal";

export default function Navigation() {
  const { isAuthDataManager, isAuthMappingManager, isAuthProcessManager, isAuthReceiptsManager } = useMsal();
  const [anchorElNav, setAnchorElNav] = useState<null | HTMLElement>(null);

  const theme = useTheme();

  const callistoEnvironment = import.meta.env.VITE_CALLISTO_ENVIRONMENT;
  const callistoVersion = import.meta.env.VITE_CALLISTO_VERSION;

  const handleOpenNavMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const navItems = [
    ...(isAuthProcessManager
      ? [{ name: "Process Manager", path: "/tasks" }]
      : []),
    ...(isAuthMappingManager
      ? [{ name: "Mapping Manager", path: "/mapping" }]
      : []),
    ...(isAuthDataManager ? [{ name: "Data Manager", path: "/data" }] : []),
    ...(isAuthReceiptsManager
      ? [{ name: "Receipts Manager", path: "/receipts" }]
      : []),
  ];

  return (
    <AppBar position="static" color="primary" elevation={1} data-testid="navigation">
      <Toolbar sx={{ minHeight: { xs: 56, sm: 64 } }}>
        {/* Responsive Layout: Logo | Centered Env/Version | Hamburger Right (lg and below) */}
        {useMediaQuery(theme.breakpoints.down("lg")) ? (
          <Box sx={{ display: "flex", alignItems: "center", width: "100%" }}>
            {/* Logo left */}
            <Box
              sx={{
                flex: "0 0 auto",
                display: "flex",
                alignItems: "center",
                mt: 0.5,
              }}
            >
              <Link to="/" style={{ textDecoration: "none" }}>
                <img
                  src="/3DLogo.svg"
                  alt="3Degrees, Inc"
                  style={{ height: "40px", width: "auto" }}
                />
              </Link>
            </Box>
            {/* Env/Version center */}
            <Box
              sx={{
                flex: "1 1 auto",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              {callistoEnvironment !== "prod" && (
                <Typography variant="body2" color="white" sx={{ opacity: 0.8 }}>
                  {callistoEnvironment} - v{callistoVersion}
                </Typography>
              )}
            </Box>
            {/* Hamburger right */}
            <Box
              sx={{ flex: "0 0 auto", display: "flex", alignItems: "center" }}
            >
              <IconButton
                size="large"
                edge="end"
                color="inherit"
                aria-label="menu"
                onClick={handleOpenNavMenu}
              >
                <MenuIcon />
              </IconButton>
              <Menu
                anchorEl={anchorElNav}
                open={Boolean(anchorElNav)}
                onClose={handleCloseNavMenu}
                anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                transformOrigin={{ vertical: "top", horizontal: "right" }}
              >
                {navItems.map((item) => (
                  <MenuItem
                    key={item.name}
                    component={Link}
                    to={item.path}
                    onClick={handleCloseNavMenu}
                    selected={window.location.pathname === item.path}
                    sx={{
                      fontWeight:
                        window.location.pathname === item.path ? 700 : 600,
                      color:
                        window.location.pathname === item.path
                          ? theme.palette.action.active
                          : "inherit",
                      textTransform: "uppercase",
                    }}
                  >
                    <Typography variant="button" component="span">
                      {item.name}
                    </Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          </Box>
        ) : (
          <>
            {/* Desktop Layout: Logo | NavLinks | Env/Version */}
            <Box
              sx={{
                flexGrow: 0,
                display: "flex",
                alignItems: "center",
                mt: 0.5,
              }}
            >
              <Link to="/" style={{ textDecoration: "none" }}>
                <img
                  src="/3DLogo.svg"
                  alt="3Degrees, Inc"
                  style={{ height: "40px", width: "auto" }}
                />
              </Link>
            </Box>
            <Box
              sx={{
                flexGrow: 1,
                display: { xs: "none", lg: "flex" },
                justifyContent: "flex-start",
                ml: 4,
                whiteSpace: "nowrap",
              }}
            >
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  style={{ textDecoration: "none" }}
                >
                  {({ isActive }) => (
                    <MuiLink
                      component="span"
                      sx={{
                        my: 2,
                        mx: 1,
                        color: "white",
                        fontWeight: isActive ? 700 : 600,
                        textTransform: "none",
                        fontSize: "1rem",
                        textDecoration: "none",
                        borderBottom: isActive ? "2.5px solid" : "none",
                        borderColor: isActive
                          ? theme.palette.action.active
                          : "none",
                        padding: "8px 8px",
                        borderRadius: "4px",
                        transition: "all 0.2s ease-in-out",
                        "&:hover": {
                          backgroundColor: "rgba(255, 255, 255, 0.1)",
                          color: "white",
                          textDecoration: "none",
                        },
                      }}
                    >
                      <Typography
                        variant="button"
                        component="span"
                        sx={{
                          color: "white",
                          fontWeight: isActive ? 700 : 600,
                        }}
                      >
                        {item.name}
                      </Typography>
                    </MuiLink>
                  )}
                </NavLink>
              ))}
            </Box>
            <Box sx={{ flexGrow: 0, display: { xs: "none", sm: "block" } }}>
              {callistoEnvironment !== "prod" && (
                <Typography variant="body2" color="white" sx={{ opacity: 0.8 }}>
                  {callistoEnvironment} - v{callistoVersion}
                </Typography>
              )}
            </Box>
          </>
        )}
      </Toolbar>
    </AppBar>
  );
}
