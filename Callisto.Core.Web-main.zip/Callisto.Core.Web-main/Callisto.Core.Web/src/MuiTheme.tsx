import { createTheme } from "@mui/material/styles";

// Import theme augmentation for DatePicker components
import type {} from "@mui/x-date-pickers/themeAugmentation";

// TypeScript declarations for custom tertiary color
// HPD not sure if this is the direction we want to go: note that all MUI components using this color
// will require a "module augmentation" https://mui.com/material-ui/customization/palette/#typescript
declare module "@mui/material/styles" {
  interface Palette {
    tertiary: Palette["primary"];
  }

  interface PaletteOptions {
    tertiary?: PaletteOptions["primary"];
  }
}

declare module "@mui/material/Button" {
  interface ButtonPropsColorOverrides {
    tertiary: true;
  }
}

declare module "@mui/material/IconButton" {
  interface IconButtonPropsColorOverrides {
    tertiary: true;
  }
}

declare module "@mui/material/Badge" {
  interface BadgePropsColorOverrides {
    tertiary: true;
  }
}

declare module "@mui/material/Alert" {
  interface AlertPropsColorOverrides {
    primary: true;
    secondary: true;
    tertiary: true;
  }
}

const navyBlue = "#08394B";
const goldenRodYellow = "#FCB414";
const mediumOrange = "#FF9648";
//const lightGray = "#C7C6C2";
const darkGray = "#5C5C61";
const lightTeal = "#62BBBB";
const darkTeal = "#0D7A83";
// const sand = "#F5F4EC";
// const darkSand = "#EEEDE7";
const errorRed = "#E03C31";
const successLime = "#8dc569";
// const successForrest = "#3f784e";

export const threeDTheme = createTheme({
  typography: {
    // default to Montserrat
    fontFamily: '"Montserrat", sans-serif',
    fontWeightRegular: 600,
    allVariants: {
      color: navyBlue,
    },
    h2: {
      fontWeight: 400,
    },
    h3: {
      fontWeight: 400,
    },
    h4: {
      fontWeight: 500,
    },
    h5: {
      fontWeight: 500,
    },
    h6: {
      fontWeight: 500,
    },
  },
  palette: {
    mode: "light",
    primary: {
      main: navyBlue,
      contrastText: "#ffffff",
    },
    secondary: {
      main: darkTeal,
      contrastText: "#ffffff",
    },
    tertiary: {
      main: lightTeal,
      contrastText: "#ffffff",
    },
    info: {
      main: darkGray,
      contrastText: "#ffffff",
    },
    success: {
      main: successLime,
      contrastText: "#ffffff",
    },
    error: {
      main: errorRed,
    },
    warning: {
      main: mediumOrange,
    },
    action: {
      //default active: rgba(0, 0, 0, 0.54)
      active: goldenRodYellow,
      // hover is mostly noticeable in the select controls
      // default hover is just an alpha shift: rgba(0, 0, 0, 0.04)
      // attempting goldenrod yellow at 80% opacity
      hover: "#FCB414CC",
      //hover: darkTeal, //
      // increased from default of 0.04 to 0.06
      hoverOpacity: 0.06, // Hover opacity
    },
    background: {
      default: "#ffffff",
      paper: "#ffffff",
    },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 20,
        },
        outlined: {
          borderWidth: "2px",
          "&:hover": {
            borderWidth: "2px",
          },
          "&:focus": {
            borderWidth: "2px",
          },
        },
      },
    },
    MuiSwitch: {
      styleOverrides: {
        switchBase: {
          "&:hover:not(.Mui-checked)": {
            backgroundColor: `${navyBlue}20`, // necessary to override 'active' default color when switch is off (hides the goldenrod yellow)
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        icon: {
          color: navyBlue,
        },
      },
    },
    // DatePicker component customizations
    MuiDatePicker: {
      defaultProps: {
        slotProps: {
          // necessary to override 'active' default color when switch is off (hides the goldenrod yellow)
          openPickerButton: {
            sx: {
              color: navyBlue,
              "&:hover": {
                backgroundColor: `${navyBlue}20`, //
              },
            },
          },
        },
      },
    },
    // Customize DatePicker calendar header components
    MuiPickersCalendarHeader: {
      styleOverrides: {
        // necessary to override 'active' default color when switch is off (hides the goldenrod yellow)
        switchViewButton: {
          color: navyBlue,
          "&:hover": {
            backgroundColor: `${navyBlue}20`, // 20% opacity
          },
        },
      },
    },
    // Customize DatePicker arrow switcher components
    MuiPickersArrowSwitcher: {
      styleOverrides: {
        button: {
          color: navyBlue,
          "&:hover": {
            backgroundColor: `${navyBlue}20`, // 20% opacity
          },
        },
      },
    },
    // Customize Year Calendar component directly
    MuiYearCalendar: {
      styleOverrides: {
        button: {
          "&:hover": {
            backgroundColor: `${navyBlue}20`, // 20% opacity
          },
        },
      },
    },
  },
});
