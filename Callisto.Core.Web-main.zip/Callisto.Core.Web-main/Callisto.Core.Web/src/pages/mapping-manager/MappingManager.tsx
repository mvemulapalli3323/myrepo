import { useEffect, useRef, useState } from "react";
import { AgGridReact } from "ag-grid-react";

import api, { GenericMap } from "../../api";
import Spinner from "../../components/Spinner";
import MapTypeSelector from "./MapTypeSelector";
import GenericMapEditor from "./GenericMapEditor";
import GenericMapGrid from "./GenericMapGrid";

export default function MappingManager() {
  const grid = useRef<AgGridReact<GenericMap> | null>();
  const [isMapTypeSelectorOpen, setIsMapTypeSelectorOpen] = useState(false);
  const [isMapEditorOpen, setIsMapEditorOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const [maps, setMaps] = useState<GenericMap[]>([]);
  const [mapTypes, setMapTypes] = useState<string[]>([]);
  const [selectedMapType, setSelectedMapType] = useState<string>("");
  const [data, setData] = useState<GenericMap[]>([]);
  const [selectedRow, setSelectedRow] = useState<GenericMap>();

  const openMapTypeSelector = () => setIsMapTypeSelectorOpen(true);
  const closeMapTypeSelector = () => setIsMapTypeSelectorOpen(false);
  const closeMapEditor = () => setIsMapEditorOpen(false);
  const selectMapType = (type: string) => setSelectedMapType(type);
  const onAgGridReady = (g: AgGridReact<GenericMap> | null) =>
    (grid.current = g);

  const addNewRow = () => {
    const map = new GenericMap();
    map.typeCode = selectedMapType;
    setSelectedRow(map);
    setIsMapEditorOpen(true);
  };

  const editMap = (map: GenericMap) => {
    setSelectedRow(map);
    setIsMapEditorOpen(true);
  };

  const saveMap = (map: GenericMap) => {
    const saveAsync = async () => {
      if (loading) return;

      setLoading(true);

      const id = map.genericMapId;

      if (!id) {
        const r = await api.genericMap.create(map);

        grid.current!.api.applyTransaction({ add: [r] });

        maps.push(r);
      } else {
        const r = await api.genericMap.update(map);

        const node = grid.current!.api.getRowNode(`${id}`)!;
        node.updateData(r);

        const idx = maps.findIndex((d) => d.genericMapId === id);
        maps[idx] = r;
      }

      setMaps(maps);
      setLoading(false);
    };

    saveAsync();
  };

  const deleteMap = (map: GenericMap) => {
    const deleteAsync = async () => {
      if (loading) return;

      setLoading(true);

      await api.genericMap.delete(map);

      grid.current!.api.applyTransaction({ remove: [map] });

      const idx = maps.findIndex((d) => d.genericMapId === map.genericMapId);
      if (idx !== -1) maps.splice(idx, 1);

      setMaps(maps);

      setLoading(false);
    };

    deleteAsync();
  };

  useEffect(() => {
    if (!selectedMapType) return;

    const r = maps.filter((m) => m.typeCode == selectedMapType);
    setData(r);
  }, [selectedMapType]);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);

      const maps = (await api.genericMap.getAll()) || [];

      const types = Array.from(new Set(maps.map((data) => data.typeCode)));

      setMaps(maps);
      setMapTypes(types);
      setSelectedMapType(types[0]);
      setLoading(false);
    };

    loadData();
  }, []);

  return (
    <div className="page">
      <header className="page-header">
        <div className="min-w-0 flex flex-1 gap-x-2 items-center">
          <div>
            <h1>Mapping Manager</h1>
            <div className="flex items-center gap-x-2">
              <Spinner loading={loading} text="Loading ..." />
              {!loading && <p>{selectedMapType}</p>}
            </div>
          </div>
        </div>
        <div className="mt-4 flex md:ml-4 md:mt-0 gap-x-2">
          <button className="btn-primary-outline" onClick={openMapTypeSelector}>
            Select
          </button>
          <button className="btn-primary-outline" onClick={addNewRow}>
            Create
          </button>
        </div>
      </header>

      <main className="page-content">
        <GenericMapGrid
          data={data}
          onReady={onAgGridReady}
          onEdit={editMap}
          onDelete={deleteMap}
        />
      </main>

      <MapTypeSelector
        mapTypes={mapTypes}
        isOpen={isMapTypeSelectorOpen}
        onClose={closeMapTypeSelector}
        onChange={selectMapType}
      />

      <GenericMapEditor
        mapTypes={mapTypes}
        map={selectedRow}
        isOpen={isMapEditorOpen}
        onClose={closeMapEditor}
        onChange={saveMap}
      />
    </div>
  );
}
