import { useEffect, useRef, useState } from "react";
import { FieldValues, FormState } from "react-hook-form";
import Form, { FormConfiguration } from "../../forms/Form";
import Drawer, { DrawerProps } from "../../components/Drawer";
import { GenericMap } from "../../api";

interface GenericMapEditorProps extends DrawerProps {
  mapTypes: string[];
  map?: GenericMap;
  onChange: (row: GenericMap) => void;
}

export default function GenericMapEditor(props: GenericMapEditorProps) {
  const rowValues = useRef<FieldValues>();
  const [isValid, setIsValid] = useState<boolean>(false);
  const [genericMap, setGenericMap] = useState<GenericMap>(new GenericMap());
  const [formConfig, setFormConfig] = useState<FormConfiguration>();

  const onChange = (c: FieldValues) => (rowValues.current = c);
  const onStateChange = (s: FormState<FieldValues>) => setIsValid(s.isValid);

  const close = () => {
    props.onClose();
  };

  const save = () => {
    props.onChange(GenericMap.fromJS(rowValues.current));
    close();
  };

  useEffect(() => {
    const v = props.mapTypes || [];

    const formConfig: FormConfiguration = {
      fields: [
        {
          key: "typeCode",
          editor: "select",
          label: "Type",
          options: v.map((t) => ({ value: t, text: t })),
          required: true,
        },
        {
          key: "value1",
          editor: "text",
          label: "Key",
          required: true,
        },
        {
          key: "value2",
          editor: "text",
          label: "Value",
          required: true,
        },
      ],
    };

    setFormConfig(formConfig);
    setGenericMap(new GenericMap());
  }, [props.mapTypes]);

  useEffect(() => {
    setGenericMap(new GenericMap(props.map));
  }, [props.map]);

  return (
    <Drawer isOpen={props.isOpen} onClose={close}>
      <div className="panel-content">
        <div className="panel-body">
          <div className="mb-10">
            <h2>Row Editor</h2>
            <p>Complete the form below.</p>
          </div>
          <Form
            config={formConfig}
            item={genericMap}
            onChange={onChange}
            onStateChange={onStateChange}
          />
        </div>
        <div className="panel-footer">
          <button className="btn-primary-outline" onClick={close}>
            Cancel
          </button>
          <button className="btn-primary" disabled={!isValid} onClick={save}>
            Save
          </button>
        </div>
      </div>
    </Drawer>
  );
}
