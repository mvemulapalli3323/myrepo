import { useCallback, useEffect, useRef, useState } from "react";
import { AgGridReact } from "ag-grid-react";

import Spinner from "../../components/Spinner";
import api, { RunSearchCriteria, Task, TaskRun } from "../../api";
import TaskRunGrid from "./TaskRunGrid";
import ProcessRunFilter from "./ProcessRunFilter";
import ProcessLauncher from "./ProcessLauncher";
import TaskRunInfo from "./TaskRunInfo";

export default function ProcessManager() {
  const pollingIntervalInSeconds: number = 10;

  const grid = useRef<AgGridReact<TaskRun> | null>();
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isLauncherOpen, setIsLauncherOpen] = useState(false);
  const [isInfoOpen, setIsInfoOpen] = useState(false);

  const [loading, setLoading] = useState(false);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [taskRun, setTaskRun] = useState<TaskRun>();
  const [filterCriteria, setFilterCriteria] = useState<RunSearchCriteria>();
  const [data] = useState<TaskRun[]>([]);

  const onAgGridReady = (g: AgGridReact<TaskRun> | null) => (grid.current = g);

  const openFilter = () => setIsFilterOpen(true);

  const closeFilter = () => setIsFilterOpen(false);

  const changeFilterCriteria = (c: RunSearchCriteria) => setFilterCriteria(c);

  const openLauncher = () => setIsLauncherOpen(true);

  const closeLauncher = () => setIsLauncherOpen(false);

  const closeInfo = () => setIsInfoOpen(false);

  const launch = (taskRun: TaskRun) => {
    const launchAsync = async () => {
      if (loading) return;

      setLoading(true);

      await api.task.run(taskRun);

      setLoading(false);
      loadTaskRuns(true);
    };

    launchAsync();
  };

  const cancel = (taskRun?: TaskRun) => {
    const cancelAsync = async () => {
      if (!taskRun) return;

      setLoading(true);

      const r = await api.taskRun.cancel(taskRun.taskRunId);

      const node = grid.current!.api.getRowNode(`${taskRun.taskRunId}`)!;
      node?.updateData(r);

      setLoading(false);
    };

    cancelAsync();
  };

  const runAgain = (taskRun?: TaskRun) => {
    setTaskRun(taskRun);
    setIsLauncherOpen(true);
  };

  const viewMore = (taskRun?: TaskRun) => {
    setTaskRun(taskRun);
    setIsInfoOpen(true);
  };

  const loadTaskRuns = useCallback(
    async (showSpinner: boolean = false) => {
      if (!filterCriteria) return;

      setLoading(showSpinner);

      const runs = await api.taskRun.getBySearchCritera(filterCriteria);

      grid.current!.api.setGridOption("rowData", runs);

      setLoading(false);
    },
    [filterCriteria],
  );

  useEffect(() => {
    loadTaskRuns(true);
    const pollingInterval = setInterval(
      () => loadTaskRuns(),
      pollingIntervalInSeconds * 1000,
    );
    const processDurationInterval = setInterval(() => {
      const data = grid.current!.api.getGridOption("rowData") as TaskRun[];
      const rows = data
        ?.filter((r) => r.isRunning)
        .map((r) => {
          r.updateDuration();
          return r;
        });
      grid.current!.api.applyTransaction({ update: rows });
    }, 1000);
    return () => {
      clearInterval(pollingInterval);
      clearInterval(processDurationInterval);
    };
  }, [loadTaskRuns]);

  useEffect(() => {
    const loadTasks = async () => {
      setLoading(true);

      const tasks = await api.task.getAll();

      setTasks(tasks);

      setLoading(false);
    };

    loadTasks();
  }, []);

  return (
    <div className="page">
      <header className="page-header">
        <div className="min-w-0 flex flex-1 gap-x-2 items-center">
          <div>
            <h1>Process Manager</h1>
            <div className="flex items-center gap-x-2">
              <Spinner loading={loading} text="Loading ..." />
              <p>
                {filterCriteria && !loading && (
                  <span>
                    Showing{" "}
                    {filterCriteria.statusCode
                      ? filterCriteria.readableStatusCode
                      : ""}{" "}
                    {filterCriteria.code ? filterCriteria.code : "all"}{" "}
                    processes from{" "}
                    {filterCriteria.startDate?.toLocaleTimeString()} to{" "}
                    {filterCriteria.endDate?.toLocaleDateString()}.
                  </span>
                )}
              </p>
            </div>
          </div>
        </div>
        <div className="mt-4 flex md:ml-4 md:mt-0 gap-x-2">
          <button className="btn-primary-outline" onClick={openFilter}>
            Filter
          </button>
          <button className="btn-primary-outline" onClick={openLauncher}>
            Launch
          </button>
        </div>
      </header>

      <main className="page-content">
        <TaskRunGrid
          data={data}
          onReady={onAgGridReady}
          onCancel={cancel}
          onRunAgain={runAgain}
          onViewMore={viewMore}
        />
      </main>

      <ProcessRunFilter
        isOpen={isFilterOpen}
        onClose={closeFilter}
        tasks={tasks}
        onChange={changeFilterCriteria}
      />

      <ProcessLauncher
        taskRun={taskRun}
        isOpen={isLauncherOpen}
        onClose={closeLauncher}
        tasks={tasks}
        launch={launch}
      />

      <TaskRunInfo taskRun={taskRun} isOpen={isInfoOpen} onClose={closeInfo} />
    </div>
  );
}
