import { useEffect, useRef, useState } from "react";
import { FieldValues, FormState } from "react-hook-form";

import { IRunSearchCriteria, RunSearchCriteria, Task } from "../../api";
import Drawer, { DrawerProps } from "../../components/Drawer";
import Form, { FormConfiguration } from "../../forms/Form";

interface ProcessRunFilterProps extends DrawerProps {
  tasks: Task[];
  onChange: (c: RunSearchCriteria) => void;
}

export default function ProcessRunFilter(props: ProcessRunFilterProps) {
  const fieldValues = useRef<FieldValues>();

  const [isValid, setIsValid] = useState<boolean>(false);
  const [formConfig, setFormConfig] = useState<FormConfiguration>();
  const [criteria, setCriteria] = useState<RunSearchCriteria>();

  const apply = () =>
    setCriteria(
      new RunSearchCriteria(fieldValues.current as IRunSearchCriteria),
    );
  const onChange = (c: FieldValues) => (fieldValues.current = c);
  const onStateChange = (s: FormState<FieldValues>) => setIsValid(s.isValid);

  useEffect(() => {
    if (criteria) {
      props.onChange(criteria);
      props.onClose();
    }
  }, [criteria]);

  useEffect(() => {
    if (!props.tasks.length) return;

    const statuses = [
      {
        value: "",
        text: "All",
      },
      {
        value: "Succeeded",
        text: "Succeeded",
      },
      {
        value: "In Progress",
        text: "In Progress",
      },
      {
        value: "Cancelled",
        text: "Cancelled",
      },
      {
        value: "Failed",
        text: "Failed",
      },
    ];
    const processes = [{ value: "", text: "All" }].concat(
      props.tasks.map((t) => ({ text: t.taskName, value: t.taskCode })),
    );

    const config: FormConfiguration = {
      fields: [
        {
          key: "startDate",
          label: "Start Date",
          editor: "date",
          required: true,
        },
        {
          key: "endDate",
          label: "End Date",
          editor: "date",
          required: true,
        },
        {
          key: "code",
          label: "Process",
          editor: "select",
          options: processes,
        },
        {
          key: "statusCode",
          label: "Status",
          editor: "select",
          options: statuses,
        },
      ],
    };

    setFormConfig(config);
    setCriteria(new RunSearchCriteria());
  }, [props.tasks]);

  return (
    <Drawer isOpen={props.isOpen} onClose={props.onClose}>
      <div className="panel-content">
        <div className="panel-body">
          <div className="mb-10">
            <h2>Filter Processes</h2>
            <p>
              Select the desired values from the form below and filter down the
              list of processes.
            </p>
          </div>
          <Form
            config={formConfig}
            item={criteria}
            onChange={onChange}
            onStateChange={onStateChange}
          />
        </div>
        <div className="panel-footer">
          <button
            className="btn-primary-outline w-full"
            disabled={!isValid}
            onClick={apply}
          >
            Apply
          </button>
        </div>
      </div>
    </Drawer>
  );
}
