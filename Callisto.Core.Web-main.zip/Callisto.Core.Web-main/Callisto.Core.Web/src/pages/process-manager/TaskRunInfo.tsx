import { useEffect, useState } from "react";
import { TaskRun } from "../../api";
import Drawer, { DrawerProps } from "../../components/Drawer";

interface TaskRunInfoProps extends DrawerProps {
  taskRun?: TaskRun;
}

export default function TaskRunInfo(props: TaskRunInfoProps) {
  const [msg, setMsg] = useState<string>();

  useEffect(() => {
    setMsg(props.taskRun?.message);
  }, [props.taskRun]);

  return (
    <Drawer isOpen={props.isOpen} onClose={props.onClose}>
      <div className="panel-content">
        <div className="panel-body">
          <h2>Task Run Info</h2>
          <p>{msg}</p>
        </div>
        <div className="panel-footer">
          <button
            className="btn-primary-outline w-full"
            onClick={props.onClose}
          >
            Done
          </button>
        </div>
      </div>
    </Drawer>
  );
}
