import { useCallback, useEffect, useRef, useState } from "react";
import { AgGridReact, CustomCellRendererProps } from "ag-grid-react";
import { GetRowIdParams, IDetailCellRendererParams } from "ag-grid-enterprise";
import { ColDef } from "ag-grid-community";
import { threeDTheme } from "../../components/SharedComponents/Grids/threeDTheme";

import { StatusType, TaskRun } from "../../api";

interface TaskRunGridProps {
  data: TaskRun[];
  onReady?: (grid: AgGridReact<TaskRun> | null) => void;
  onCancel: (run?: TaskRun) => void;
  onViewMore: (run?: TaskRun) => void;
  onRunAgain: (run?: TaskRun) => void;
}

export default function TaskRunGrid(props: TaskRunGridProps) {
  const getRowId = (params: GetRowIdParams<TaskRun>) =>
    `${params.data.taskRunId}`;
  const ref = useRef<AgGridReact>(null);

  const [colDefs] = useState<ColDef[]>([
    {
      field: "statusId",
      headerName: "Process",
      cellRenderer: ProcessCellRenderer,
      flex: 1.5,
    },
    { field: "startTime", headerName: "Start Time", flex: 1 },
    { field: "endTime", headerName: "End Time", flex: 1 },
    {
      field: "duration",
      headerName: "Duration",
      flex: 1,
      valueFormatter: (p) => getDuration(Number(p.value) || 0),
    },
    { field: "createdBy", headerName: "Launched By", flex: 1 },
    {
      field: "actions",
      headerName: "Actions",
      flex: 0.5,
      cellRenderer: ActionsCell,
      cellRendererParams: {
        onCancel: (row?: TaskRun) => props.onCancel(row),
        onViewMore: (row?: TaskRun) => props.onViewMore(row),
        onRunAgain: (row?: TaskRun) => props.onRunAgain(row),
      },
    },
  ]);

  const [rowData, setRowData] = useState<TaskRun[]>([]);

  const getDuration = (value: number): string => {
    const hours = Math.floor(value / 3600);
    const minutes = Math.floor((value - hours * 3600) / 60);
    const seconds = value - hours * 3600 - minutes * 60;
    return hours > 24
      ? `+${Math.floor(hours / 24).toLocaleString()} days`
      : `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  };

  const detailCellRendererParams = {
    detailGridOptions: {
      pagination: false,
      columnDefs: [
        {
          field: "statusId",
          headerName: "Process",
          cellRenderer: ProcessCellRenderer,
          flex: 1.5,
        },
        { field: "currentStep", headerName: "Step", flex: 0.5 },
        { field: "startTime", headerName: "Start Time", flex: 1 },
        { field: "endTime", headerName: "End Time", flex: 1 },
        {
          field: "duration",
          headerName: "Duration",
          flex: 0.6,
          valueFormatter: (p) => getDuration(Number(p.value) || 0),
        },
        { field: "createdBy", headerName: "Launched By", flex: 0.6 },
        {
          field: "actions",
          headerName: "Actions",
          flex: 0.5,
          cellRenderer: ActionsCell,
          cellRendererParams: {
            onCancel: (row?: TaskRun) => props.onCancel(row),
            onViewMore: (row?: TaskRun) => props.onViewMore(row),
            onRunAgain: (row?: TaskRun) => props.onRunAgain(row),
          },
        },
      ],
    },
    getDetailRowData: (params) =>
      params.successCallback(params.data.subtaskRuns),
  } as IDetailCellRendererParams<TaskRun, TaskRun>;

  const isRowMaster = (taskRun: TaskRun) => taskRun.hasSubtasks;

  useEffect(() => {
    setRowData(props.data);
  }, [props.data]);

  useEffect(() => {
    if (props.onReady) props.onReady(ref.current);
  }, []);

  return (
    <div className="flex flex-col w-full h-full">
      <div className="ag-theme-quartz h-full">
        <AgGridReact
          ref={ref}
          masterDetail={true}
          detailRowAutoHeight={true}
          pagination={true}
          isRowMaster={isRowMaster}
          rowData={rowData}
          columnDefs={colDefs}
          detailCellRendererParams={detailCellRendererParams}
          getRowId={getRowId}
          theme={threeDTheme}
        />
      </div>
    </div>
  );
}

function ProcessCellRenderer(props: CustomCellRendererProps<TaskRun>) {
  const { node, data } = props;
  const [expanded, setExpanded] = useState(node.expanded);

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const expandListener = (event: any) => setExpanded(event.node.expanded); // Type is RowEvent but it was throwing errors when building for prod.
    node.addEventListener("expandedChanged", expandListener);
    return () => {
      node.removeEventListener("expandedChanged", expandListener);
    };
  }, []);

  const onClick = useCallback(() => {
    if (!node.master) return;
    node.setExpanded(!node.expanded);
  }, [node]);

  const renderStatus = useCallback(() => {
    let jsx = <></>;
    switch (data?.status?.statusCode) {
      case StatusType.NotStarted:
        jsx = (
          <div className="flex-none rounded-full bg-gray-400/10 p-1 text-gray-400">
            <div className="h-1.5 w-1.5 rounded-full bg-current"></div>
          </div>
        );
        break;
      case StatusType.InProgress:
        jsx = (
          <div className="flex-none rounded-full bg-yellow-400/10 p-1 text-yellow-400">
            <div className="h-1.5 w-1.5 rounded-full bg-current"></div>
          </div>
        );
        break;
      case StatusType.Succeeded:
        jsx = (
          <div className="flex-none rounded-full bg-green-400/10 p-1 text-lime-green">
            <div className="h-1.5 w-1.5 rounded-full bg-current"></div>
          </div>
        );
        break;
      case StatusType.Failed:
        jsx = (
          <div className="flex-none rounded-full bg-red-400/10 p-1 text-red-400">
            <div className="h-1.5 w-1.5 rounded-full bg-current"></div>
          </div>
        );
        break;
      case StatusType.Cancelled:
        jsx = (
          <div className="flex-none rounded-full bg-gray-400/50 p-1 text-dark-gray">
            <div className="h-1.5 w-1.5 rounded-full bg-current"></div>
          </div>
        );
        break;
    }
    return jsx;
  }, [data]);

  return (
    <div
      className="flex items-center gap-x-2"
      style={{ paddingLeft: `${node.level * 15}px` }}
    >
      <div
        style={{
          cursor: "pointer",
          transform: expanded ? "rotate(90deg)" : "rotate(0deg)",
          display: "inline-block",
        }}
        className={`${!node.master ? "opacity-0 pointer-events-none" : ""}`}
        onClick={onClick}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="size-5"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="m8.25 4.5 7.5 7.5-7.5 7.5"
          />
        </svg>
      </div>

      <div
        title={data?.getStatus}
        className="flex items-center justify-end gap-x-2 sm:justify-start hover:cursor-pointer"
      >
        {renderStatus()}
      </div>
      <span className="truncate">{data?.name}</span>
      {data?.hasSubtasks && (
        <span
          title={`Currently at step ${data?.currentStep}`}
          className="inline-flex items-center rounded-full bg-gray-50 px-2 py-1 text-xs font-medium text-gray-600 ring-1 ring-inset ring-gray-500/10"
        >
          {data?.currentStep}
        </span>
      )}
    </div>
  );
}

interface ActionsCellProps extends CustomCellRendererProps<TaskRun> {
  onCancel: (row?: TaskRun) => void;
  onRunAgain: (row?: TaskRun) => void;
  onViewMore: (row?: TaskRun) => void;
}

function ActionsCell(props: ActionsCellProps) {
  const { data } = props;

  const cancel = () => props.onCancel(data);
  const runAgain = () => props.onRunAgain(data);
  const viewMore = () => props.onViewMore(data);

  const render = useCallback(() => {
    let jsx = <></>;

    if (!data) return jsx;

    if (data.isCancellable) {
      jsx = (
        <button className="btn-icon" onClick={cancel} title="Cancel">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            className="size-4"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
            />
          </svg>
        </button>
      );
    } else if (data.isParentTaskRun) {
      jsx = (
        <button className="btn-icon" onClick={runAgain} title="Run Again">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="1.5"
            stroke="currentColor"
            className="size-4"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.347a1.125 1.125 0 0 1 0 1.972l-11.54 6.347a1.125 1.125 0 0 1-1.667-.986V5.653Z"
            />
          </svg>
        </button>
      );
    }
    return jsx;
  }, [data]);

  return (
    <div className="w-full h-full flex items-center justify-end gap-x-2">
      {render()}
      <button className="btn-icon" onClick={viewMore} title="View More">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="size-4"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z"
          />
        </svg>
      </button>
    </div>
  );
}
