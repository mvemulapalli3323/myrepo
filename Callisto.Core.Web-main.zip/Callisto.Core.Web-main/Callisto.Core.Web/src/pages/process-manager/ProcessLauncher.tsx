import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
} from "@mui/material";
import { useEffect, useRef, useState } from "react";
import { FieldValues, FormState } from "react-hook-form";

import api, {
  InputParameter,
  ParameterDataType,
  SelectOption,
  Task,
  TaskRun,
} from "../../api";
import Drawer, { DrawerProps } from "../../components/Drawer";
import Form, {
  FormConfiguration,
  FormFieldConfig,
  FormFieldOption,
} from "../../forms/Form";
import { useMsal } from "@azure/msal-react";
import { InteractionStatus } from "@azure/msal-browser";

interface ProcessLauncherProps extends DrawerProps {
  taskRun?: TaskRun;
  tasks: Task[];
  launch: (c: TaskRun) => void;
}

export default function ProcessLauncher(props: ProcessLauncherProps) {
  const parameterValues = useRef<FieldValues>();

  const [taskId, setTaskId] = useState(0);
  const [options, setOptions] = useState<SelectOption[]>([]);
  const [processes, setProcesses] = useState<FormFieldOption[]>([]);
  const [isValid, setIsValid] = useState<boolean>(false);
  const [formConfig, setFormConfig] = useState<FormConfiguration>();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [parameters, setParameters] = useState<any>();
  const { instance, inProgress } = useMsal();
  const activeAccount =
    inProgress === InteractionStatus.None ? instance.getActiveAccount() : null;

  const launch = () => {
    if (!taskId) return;

    const taskRun: TaskRun = new TaskRun();
    taskRun.taskId = taskId;
    taskRun.createdBy = activeAccount?.username ?? "Ops App User";
    taskRun.parameters = JSON.stringify(parameterValues.current);
    props.launch(taskRun);

    close();
  };

  const onProcessChange = (e: SelectChangeEvent<number>) =>
    setTaskId(e.target.value as number);
  const onParametersChange = (c: FieldValues) => (parameterValues.current = c);
  const onParametersFormStateChange = (s: FormState<FieldValues>) =>
    setIsValid(s.isValid);

  const close = () => {
    props.onClose();
    setParameters(undefined);
  };

  useEffect(() => {
    const getOptions = (p: InputParameter): FormFieldOption[] => {
      return options
        .filter((o) => o.selectOptionTypeCode === p.selectOptionType)
        .sort((a, b) =>
          a.selectOptionDescription > b.selectOptionDescription ? 1 : -1
        )
        .map((o) => {
          // TODO: Revisit these lines.
          if (!isNaN(parseInt(o.selectOptionValue))) {
            o.selectOptionValue = parseInt(o.selectOptionValue);
          }

          return {
            value: o.selectOptionValue,
            text: o.selectOptionDescription,
          };
        });
    };

    const task = props.tasks.find((t) => t.taskId === taskId);

    if (task && task.inputParameters) {
      const formConfig: FormConfiguration = { fields: [] };

      task.inputParameters.groups.forEach((g) => {
        g.parameters.forEach((p) => {
          const field: FormFieldConfig = {
            key: p.key,
            label: p.label,
            required: p.isRequired,
            error: p.isRequired
              ? "The value of this parameter is required."
              : "",
          };

          switch (p.dataType) {
            case ParameterDataType.Decimal:
              field.editor = "number";
              break;
            case ParameterDataType.Boolean:
              field.editor = "boolean";
              break;
            case ParameterDataType.DateTime:
              field.editor = "date";
              break;
            case ParameterDataType.Select:
              field.editor = "select";
              field.options = getOptions(p);
              break;
            case ParameterDataType.MultiSelect:
            case ParameterDataType.SelectDynamicOptions:
            case ParameterDataType.MultiSelectDynamicOptions:
              field.editor = "multi-select";
              field.options = getOptions(p);
              break;
            default:
              field.editor = "text";
              break;
          }

          formConfig.fields.push(field);
        });
      });

      setFormConfig(formConfig);
      if (props.taskRun) {
        setParameters(JSON.parse(props.taskRun?.parameters));
      } else {
        setParameters({});
      }
    }
  }, [taskId]);

  useEffect(() => {
    if (props.taskRun) setTaskId(props.taskRun.taskId);
  }, [props.taskRun]);

  useEffect(() => {
    const options: FormFieldOption[] = props.tasks.map((t) => ({
      text: t.taskName,
      value: t.taskId,
    }));
    options.sort((a, b) => a.text.localeCompare(b.text));
    if (options.length) setTaskId(props.tasks[0].taskId);
    setProcesses(options);
  }, [props.tasks]);

  useEffect(() => {
    const load = async () => {
      const opts = await api.selectOption.getAll();
      setOptions(opts);
    };
    load();
  }, []);

  return (
    <Drawer isOpen={props.isOpen} onClose={close}>
      <div className="panel-content">
        <div className="panel-body">
          <div className="mb-10">
            <h2>Launch Process</h2>
            <p>
              Select the desired process from the list below and its
              corresponding parameters.
            </p>
          </div>

          {processes.length && (
            <FormControl fullWidth>
              <InputLabel>Process</InputLabel>
              <Select<number>
                className="w-full"
                label="Process"
                value={taskId}
                onChange={onProcessChange}
              >
                {processes.map((o) => (
                  <MenuItem key={o.value} value={o.value}>
                    {o.text}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          )}
          <hr className="my-4 border-dark-gray" />
          <Form
            config={formConfig}
            item={parameters}
            onChange={onParametersChange}
            onStateChange={onParametersFormStateChange}
          />
        </div>
        <div className="panel-footer">
          <button
            className="btn-primary-outline w-full"
            disabled={!isValid}
            onClick={launch}
          >
            Launch
          </button>
        </div>
      </div>
    </Drawer>
  );
}
