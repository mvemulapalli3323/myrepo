import React, {
  useCallback,
  useContext,
  useEffect,
  useRef,
  useMemo,
  useState,
} from "react";
import {
  suggestPositions,
  assignPositions,
  positionsUndo,
  getAllocations,
  removeAllocations,
  autoAllocate,
  groupInboxTransactions,
  ungroupInboxTransactions,
  deAllocation,
} from "../../api/services/receipts-services/AllocationService";
import AutomatedReceiptsGrid from "../../components/SharedComponents/Grids/AgGrid";
import {
  positionAllocationModelColDef,
  subTrackingSystemColDefs,
  trackingSystemColDefs,
} from "../../components/SharedComponents/Grids/GridColDefs";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import UndoIcon from "@mui/icons-material/Undo";
import LinkOffIcon from "@mui/icons-material/LinkOff";
import AddLinkIcon from "@mui/icons-material/AddLink";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
// import AddIcon from "@mui/icons-material/Add";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import Switch from "@mui/material/Switch";
import FormControlLabel from "@mui/material/FormControlLabel";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { Alert, Box, Container } from "@mui/material";
import LinearProgress from "@mui/material/LinearProgress";
import { useNavigate, useParams } from "react-router-dom";
import { Context } from "../../Context/AppContext";
import GlobalModalComponent from "../../components/SharedComponents/Modals/globalModal";
import {
  PositionRowData,
  RowDataInterfaces,
} from "../../api/services/receipts-services/ServicesInterfaces";
import {
  GridApi,
  GridReadyEvent,
  RowDragEvent,
  GetContextMenuItemsParams,
  SelectionChangedEvent,
} from "ag-grid-community";
import { threeDTheme } from "../../components/SharedComponents/Grids/threeDTheme";
import { ModalData } from "../../components/SharedComponents/Grids/CommonUtils";
import { ModalMessageType } from "../../components/SharedComponents/Modals/ModalMessageType";
import {
  PositionAllocationModel,
  TrackingSystemAllocationModel,
} from "@/api/types/receipts-types";
import { TrackingSystemAllocationModelSubRow } from "@/api/types/receipts-types-extensions";
import { useErrorBoundary } from "react-error-boundary";
import Tooltip from "@mui/material/Tooltip";
import { useLoader } from "../../Context/LoaderContext";
import { AxiosError } from "axios";
import ErrorIcon from "@mui/icons-material/Error";
import { AddCircle, AutoAwesome, RemoveCircle } from "@mui/icons-material";

type Params = {
  id: string | undefined;
};
interface AllocationsProps {
  id: string;
}

const Allocations: React.FC<AllocationsProps> = ({ id: propId }) => {
  const { id: paramId } = useParams<Params>();
  const finalId = propId || paramId;
  const context = useContext(Context);
  if (!context) {
    throw new Error("Component must be used within an AppProvider");
  }
  const { open, setOpen } = context;
  const navigate = useNavigate();
  const { showBoundary } = useErrorBoundary();
  const { showLoader, hideLoader } = useLoader();
  const [inboxRows, setInboxRows] = useState<TrackingSystemAllocationModel[]>(
    []
  );
  const [positions, setPositions] = useState<PositionAllocationModel[]>([]);
  const [trackingSystem, setSystem] = useState<string>("");
  const [matchedPositions, setMatchedPositions] = useState<
    PositionAllocationModel[]
  >([]);
  const [selectedPositions, setelectedPositionRows] = useState<
    PositionRowData[]
  >([]);
  const [selectedReceipts, selectedReceiptsRows] = useState<
    RowDataInterfaces[]
  >([]);

  const [isEnabled, setIsEnabled] = useState(false);
  const [isenabledhiddenPositions, setEnabledhiddenPositions] = useState(false);
  const [enableNext, setenableNext] = useState(false);
  const [modalData, setModalData] = useState({});
  const [gridKey, setGridKey] = useState(0);

  const [showAutoAllocateModal, setShowAutoAllocateModal] = useState(false);
  const [autoAllocateMessage, setAutoAllocateMessage] = useState("");
  const [autoAllocateSeverity, setAutoAllocateSeverity] = useState<
    "success" | "warning" | "error"
  >("success");
  const [receiptId, setReceiptId] = useState<string | null>("");
  const [allocationRefresh, setAllocationRefresh] = React.useState(false);
  const [createTransactionError, setCreateTransactionError] = useState("");
  const [isGrouped, setIsGrouped] = useState(false);

  const filteredPositions = () => {
    return isenabledhiddenPositions
      ? positions.filter((row) => row.quantityAvailable !== 0)
      : positions;
  };

  const filteredInbox = () => {
    return inboxRows.filter((row) => (row.quantityAvailable ?? 0) > 0);
  };

  // Calculate allocation progress
  const allocationProgress = useMemo(() => {
    const totalSupply = inboxRows.reduce(
      (sum, row) => sum + (row.quantity ?? 0),
      0
    );
    const totalAllocated = positions.reduce((sum, position) => {
      const positionAllocated =
        position.allocations?.reduce(
          (allocSum, allocation) =>
            allocSum + (allocation.assignment?.quantity ?? 0),
          0
        ) ?? 0;
      return sum + positionAllocated;
    }, 0);

    const progressPercentage =
      totalSupply > 0 ? (totalAllocated / totalSupply) * 100 : 0;

    return {
      totalSupply,
      totalAllocated,
      progressPercentage: Math.min(progressPercentage, 100),
    };
  }, [inboxRows, positions]);

  useEffect(() => {
    getData();
  }, [finalId]);

  const disabled = useMemo(() => {
    return !!receiptId;
  }, [receiptId]);

  const getData = async () => {
    if (!finalId) return;
    showLoader();
    try {
      const result = await getAllocations({ allocationTransactionId: finalId });
      setReceiptId(result.receiptId ?? null);
      setSystem(result.trackingSystem ?? "");
      setInboxRows(result.inboxRows ?? []);
      setPositions(result.positions ?? []);
      const anyGroupName = Array.from(
        new Set(
          (result.inboxRows ?? [])
            .map((row: TrackingSystemAllocationModel) => row.groupName)
            .filter((name: string | null): name is string => !!name)
        )
      );

      setIsGrouped(anyGroupName.length > 0); // Reset grouping when loading new data
      hideLoader();
    } catch (err) {
      console.log(err);
      if (err instanceof AxiosError) {
        setCreateTransactionError(
          err.response?.data || err.message || "Unable to proceed"
        );
      } else {
        setCreateTransactionError("Unable to proceed");
      }
      hideLoader();
    }
  };
  const detailCellRendererParams = useCallback(
    (params: { data: PositionAllocationModel }) => {
      const hasGroupNames = params.data.allocations?.some(
        (allocation) => allocation.inboxRow?.groupName
      );

      const detailGridOptions: any = {
        columnDefs: subTrackingSystemColDefs,
      };

      if (hasGroupNames) {
        detailGridOptions.groupDisplayType = "groupRows";
        detailGridOptions.autoGroupColumnDef = {
          headerName: "Group",
          minWidth: 200,
          field: "ag-Grid-AutoColumn",
          cellRendererParams: {
            suppressCount: false,
          },
        };
        detailGridOptions.groupRowRendererParams = {
          innerRenderer: (params: { value: string }) => {
            return params.value ? params.value : "Ungrouped";
          },
        };
        detailGridOptions.initialState = {
          rowGroup: {
            groupColIds: ["groupName"],
          },
        };
        detailGridOptions.groupDefaultExpanded = 0;
      }

      return {
        detailGridOptions,
        getDetailRowData: (params: {
          successCallback: (
            rowData: TrackingSystemAllocationModelSubRow[]
          ) => void;
          data: PositionAllocationModel;
        }) => {
          const ret =
            params.data.allocations?.map((allocateData) => {
              const subRow =
                allocateData.inboxRow as TrackingSystemAllocationModelSubRow;
              subRow.quantityAllocated = allocateData.assignment?.quantity ?? 0;
              return subRow;
            }) ?? [];

          params.successCallback(ret);
        },
      };
    },
    []
  );

  const onSelectionPositions = useCallback((event: SelectionChangedEvent) => {
    clearHighlights();
    const selectedPositionsRowsData = event.api.getSelectedRows();
    setelectedPositionRows(selectedPositionsRowsData);
  }, []);
  function clearHighlights() {
    setMatchedPositions([]);
  }
  const onSelectionReceipts = useCallback(
    async (event: SelectionChangedEvent) => {
      const selectedNodes = event.api.getSelectedNodes();
      const selectedRowsData = selectedNodes
        .flatMap((node) => {
          if (node.allLeafChildren && node.allLeafChildren.length > 0) {
            return node.allLeafChildren
              .filter((child) => child.data !== undefined)
              .map((child) => child.data!);
          }
          return node.data ? [node.data] : [];
        })
        .filter((data): data is RowDataInterfaces => data !== undefined);

      selectedReceiptsRows(selectedRowsData);
      const inboxTransactionIds: string[] = [];
      selectedRowsData.forEach((row: RowDataInterfaces) => {
        if (row.transactionID) {
          inboxTransactionIds.push(row.transactionID);
        }
      });
      if (inboxTransactionIds.length === 0) {
        clearHighlights();
        return;
      }
      if (!finalId) return;
      const suggestParams = {
        allocationTransactionId: finalId,
        inboxTransactionIds,
      };
      try {
        if (inboxTransactionIds.length === 1) {
          const result = await suggestPositions(suggestParams);
          const matchedPositions = positions.filter((item) =>
            result.positionId?.includes(item.positionId ?? 0)
          );
          setMatchedPositions(matchedPositions);
        }
      } catch (err) {
        console.error(err);
        showBoundary(err);
      }
    },
    [finalId, positions]
  );
  const handleBack = () => {
    navigate(`/receipts/${finalId}`);
  };

  const handleUndo = async () => {
    if (!finalId) return;

    setCreateTransactionError("");

    try {
      const result = await positionsUndo({ allocationTransactionId: finalId });
      setGridKey((prev) => prev + 1);
      setInboxRows(result.data.inboxRows);
      setPositions(result.data.positions);
      setCreateTransactionError("");
    } catch (err) {
      console.error(err);
      showBoundary(err);
    }
  };
  const handleAllocate = async (
    allocatedValue: boolean,
    updatedQnt: number
  ) => {
    let positionId: number = 0;
    let assignmentData: {
      positionId: number;
      inboxTransactionid: string;
      quantity: number;
    }[] = [];

    setCreateTransactionError("");
    selectedPositions.forEach((row) => {
      if (row.positionId) {
        positionId = Number(row.positionId);
      }
    });

    selectedReceipts.forEach(
      (row: { transactionID: string; quantityAvailable: number }) => {
        if (row.transactionID) {
          assignmentData.push({
            positionId: positionId,
            inboxTransactionid: row.transactionID,
            quantity: row.quantityAvailable,
          });
        }
      }
    );

    if (
      isEnabled === true &&
      allocatedValue === true &&
      selectedReceipts.length === 1
    ) {
      // Use the selected receipt's available quantity as modal default
      handleQuantity(
        (selectedReceipts[0] as any)?.quantityAvailable ??
          assignmentData[0]?.quantity ??
          0
      );
      return;
    }

    // Set loading state only when we're actually going to make the API call
    setIsApiCallInProgress(true);
    setCurrentOperation("allocate");
    setAllocationRefresh(true);

    if (updatedQnt !== 0) {
      assignmentData = assignmentData.map((item) => ({
        ...item,
        quantity: updatedQnt,
      }));
    }

    const assignParams = {
      allocationTransactionId: finalId,
      assignedData: assignmentData,
    };
    try {
      const result = await assignPositions(assignParams);

      setInboxRows(result.data.inboxRows);
      setPositions(result.data.positions);
      setAllocationRefresh(false);
      setIsApiCallInProgress(false);
      setCurrentOperation(null);
      setCreateTransactionError("");
    } catch (err) {
      console.error(err);
      showBoundary(err);
      setIsApiCallInProgress(false);
      setCurrentOperation(null);
    }
  };
  const rowClassRules = {
    "highlight-row": (params: {
      data: PositionAllocationModel | undefined;
    }) => {
      if (!params.data) return false;
      const positionData = params.data as PositionRowData;
      if (!positionData.positionId) return false;

      const isMatched = matchedPositions.some((item) => {
        return item.positionId && item.positionId === positionData.positionId;
      });
      return isMatched;
    },
  };
  const enable = (event: React.SyntheticEvent, checked: boolean) => {
    event.stopPropagation();
    setIsEnabled(checked);
  };

  const handleRejectAlertClose = (
    data?: "close" | "cancel" | "confirm" | { quantity: number }
  ) => {
    setOpen(false);
    if (data && typeof data === "object" && "quantity" in data) {
      // Set loading state when the modal is confirmed
      setIsApiCallInProgress(true);
      setCurrentOperation("allocate");
      setAllocationRefresh(true);
      handleAllocate(false, Number(data.quantity));
    }
  };
  const handleRemove = async (type: "inbox" | "position") => {
    const inboxTransactionIds: string[] = [];
    const positionIds: number[] = [];

    setCreateTransactionError("");

    if (type === "inbox") {
      selectedReceipts.forEach((row: { transactionID: string }) => {
        if (row.transactionID) {
          inboxTransactionIds.push(row.transactionID);
        }
      });
    } else {
      selectedPositions.forEach((row: PositionRowData) => {
        if (row.positionId) {
          positionIds.push(Number(row.positionId));
        }
      });
    }

    try {
      const result = await removeAllocations({
        allocationTransactionId: finalId,
        trackingSystem: trackingSystem,
        inboxTransactionIds,
        positionIds,
      });

      setInboxRows(result.data.inboxRows);
      setPositions(result.data.positions);
      setGridKey((prev) => prev + 1);

      // Clear the appropriate selection state based on type
      if (type === "inbox") {
        selectedReceiptsRows([]);
      } else {
        setelectedPositionRows([]);
      }
      setCreateTransactionError("");
    } catch (err) {
      console.error(err);
      showBoundary(err);
    }
  };
  const draggedRowData = useRef<RowDataInterfaces[] | null>(null);

  const rowDraggedRef = useRef(false);
  const sourceGridApi = useRef<GridApi | null>(null);
  const targetGridApi = useRef<GridApi | null>(null);

  const onRowDragEnter = useCallback((event: RowDragEvent) => {
    const targetRowNodes = event.nodes;
    if (targetRowNodes && targetRowNodes.length > 0) {
      draggedRowData.current = targetRowNodes
        .map((node) =>
          node.group
            ? node.allLeafChildren?.map((child) => child.data)
            : node.data
        )
        .flat() as RowDataInterfaces[];
      rowDraggedRef.current = true;
    }
  }, []);
  const onRowDragEnd = () => {
    draggedRowData.current = [];
    rowDraggedRef.current = false;
  };

  const [isApiCallInProgress, setIsApiCallInProgress] = useState(false);
  const [currentOperation, setCurrentOperation] = useState<
    "auto-allocate" | "allocate" | null
  >(null);

  const registerDropZone = useCallback(() => {
    if (sourceGridApi.current && targetGridApi.current) {
      const dropZoneParams = targetGridApi.current.getRowDropZoneParams({
        onDragStop: async (params) => {
          // Logic for when rows are dropped on the target grid
          if (isApiCallInProgress) {
            return;
          }

          if (rowDraggedRef.current && draggedRowData.current) {
            const hoveredRowData = params.overNode?.data;

            const dataArray = [hoveredRowData];

            setCreateTransactionError("");

            setIsApiCallInProgress(true);
            setCurrentOperation("allocate");
            setAllocationRefresh(true);
            let positionId: number = 0;
            const assignmentData: {
              positionId: number;
              inboxTransactionid: string;
              quantity: number;
            }[] = [];

            dataArray.forEach((row: { positionId: number }) => {
              if (row.positionId) {
                positionId = row.positionId;
              }
            });

            draggedRowData.current.forEach(
              (row: { transactionID: string; quantityAvailable: number }) => {
                if (row.transactionID) {
                  assignmentData.push({
                    positionId,
                    inboxTransactionid: row.transactionID,
                    quantity: row.quantityAvailable,
                  });
                }
              }
            );
            const assignParams = {
              allocationTransactionId: finalId,
              assignedData: assignmentData,
            };
            try {
              const result = await assignPositions(assignParams);

              setInboxRows(result.data.inboxRows);
              setPositions(result.data.positions);
              setelectedPositionRows([]);
              selectedReceiptsRows([]);
              setCreateTransactionError("");
              return;
            } catch (err) {
              console.error(err);
              return;
            } finally {
              rowDraggedRef.current = false;
              setIsApiCallInProgress(false);
              setCurrentOperation(null);
              setAllocationRefresh(false);
            }
          }
        },
      });

      if (dropZoneParams) {
        sourceGridApi.current.addRowDropZone(dropZoneParams);
      }
    }
  }, [finalId]);

  const onSourceGridReady = useCallback(
    (params: GridReadyEvent) => {
      sourceGridApi.current = params.api;
      if (targetGridApi.current) {
        registerDropZone();
      }
    },
    [registerDropZone]
  );

  const onTargetGridReady = useCallback(
    (params: GridReadyEvent) => {
      targetGridApi.current = params.api;
      if (sourceGridApi.current) {
        registerDropZone();
      }
    },
    [registerDropZone]
  );

  const getContextMenuItems = (params: GetContextMenuItemsParams) => {
    if (!params.node) return [];
    return [
      {
        name: "Remove Position",
        action: async () => {
          setCreateTransactionError("");

          try {
            const result = await removeAllocations({
              allocationTransactionId: finalId,
              trackingSystem: trackingSystem,
              inboxTransactionIds: [],
              positionIds: params.node?.data?.positionId
                ? [params.node.data.positionId]
                : [],
            });
            setInboxRows(result.data.inboxRows);
            setPositions(result.data.positions);
            setCreateTransactionError("");
          } catch (err) {
            console.error(err);
            showBoundary(err);
          }
        },
      },
    ];
  };
  const handleNext = () => {
    navigate(`/products/${finalId}`);
  };

  const handleAutoAllocate = async () => {
    if (!finalId || isApiCallInProgress) return;
    setCreateTransactionError("");
    setIsApiCallInProgress(true);
    setCurrentOperation("auto-allocate");
    try {
      const result = await autoAllocate({ allocationTransactionId: finalId });
      console.log(result);

      // Add null checks for the API response
      const allocationTransactionModel =
        result.data?.allocationTransactionModel;
      setSystem(allocationTransactionModel?.trackingSystem ?? "");

      // Update inboxRows and positions from the allocation transaction model
      if (allocationTransactionModel) {
        setInboxRows(allocationTransactionModel.inboxRows ?? []);
        setPositions(allocationTransactionModel.positions ?? []);
      }

      setIsApiCallInProgress(false);
      setCurrentOperation(null);
      setCreateTransactionError("");
      if (result.data?.affectedRows === 0) {
        setAutoAllocateMessage("No rows were auto-allocated");
        setAutoAllocateSeverity("warning");
        setShowAutoAllocateModal(true);
      } else {
        setAutoAllocateMessage(
          `${result.data?.affectedRows ?? 0} rows auto-allocated`
        );
        setAutoAllocateSeverity("success");
        setShowAutoAllocateModal(true);
      }
    } catch (error) {
      console.error(error);
      showBoundary(error);
      setIsApiCallInProgress(false);
      setCurrentOperation(null);
      setAutoAllocateMessage("Auto allocation failed");
      setAutoAllocateSeverity("error");
      setShowAutoAllocateModal(true);
    }
  };
  const handleAutoAllocateModalClose = () => {
    setShowAutoAllocateModal(false);
  };
  const handleQuantity = async (quantity: number) => {
    const modalMessage = await ModalData(
      ModalMessageType.ALLOCATE_QUANTITY,
      quantity
    );
    setModalData(modalMessage);
    setOpen(true);
  };
  const handleGrouping = async () => {
    const inboxTransactionIds: string[] = [];
    let selectedGroupNames: string[] = [];
    let selectedGroupName: string = "";

    setCreateTransactionError("");

    selectedReceipts.forEach((row: RowDataInterfaces) => {
      if (row.transactionID) {
        inboxTransactionIds.push(row.transactionID);
      }
    });
    selectedGroupNames = Array.from(
      new Set(
        selectedReceipts
          .map((row: RowDataInterfaces) => row.groupName)
          .filter((name): name is string => !!name)
      )
    );
    if (selectedGroupNames.length >= 2) {
      setCreateTransactionError(
        "Please select only one group to add ungrouped tracking system rows."
      );
      return;
    } else if (selectedGroupNames.length === 1) {
      selectedGroupName = selectedGroupNames[0];
    }
    try {
      const result = await groupInboxTransactions({
        allocationTransactionId: finalId,
        selectedGroup: selectedGroupName,
        inboxTransactionIds,
      });
      console.log(result);

      setInboxRows(result.data.inboxRows);
      setPositions(result.data.positions);
      setIsGrouped(true);
      setGridKey((prev) => prev + 1);
      selectedReceiptsRows([]);
      setCreateTransactionError("");
    } catch (err) {
      console.error(err);
      showBoundary(err);
    }
  };
  const handleUnGrouping = async () => {
    setCreateTransactionError("");
    const groupNames = Array.from(
      new Set(
        selectedReceipts
          .map((row: RowDataInterfaces) => row.groupName)
          .filter((name): name is string => !!name)
      )
    );

    try {
      const result = await ungroupInboxTransactions({
        allocationTransactionId: finalId,
        groupNames: groupNames,
      });
      console.log(result);

      setInboxRows(result.data.inboxRows);
      setPositions(result.data.positions);
      const anyGroupNames = Array.from(
        new Set(
          result.data.inboxRows
            .map(
              (row: RowDataInterfaces) =>
                row.groupName && (row.quantityAvailable ?? 0) > 0
            )
            .filter((name: string | null | undefined): name is string => !!name)
        )
      );

      setIsGrouped(anyGroupNames.length > 0);
      setGridKey((prev) => prev + 1);
      // Clear selection so Group & UnGroup buttons become disabled when no rows are selected
      selectedReceiptsRows([]);
      setCreateTransactionError("");
    } catch (err) {
      console.error(err);
      showBoundary(err);
    }
  };
  useEffect(() => {
    // Enable Next button when there are no more inbox rows with available quantity
    const hasAvailableInboxRows = filteredInbox().length > 0;
    setenableNext(!hasAvailableInboxRows && !isApiCallInProgress);
  }, [inboxRows, isApiCallInProgress]);
  const handleDeallocate = async () => {
    let positionId: number[] = [];
    selectedPositions.forEach((row) => {
      if (row.positionId) {
        positionId.push(Number(row.positionId));
      }
    });
    try {
      const result = await deAllocation({
        allocationTransactionId: finalId,
        positionIds: positionId,
      });
      console.log(result);

      setInboxRows(result.inboxRows);
      setPositions(result.positions);
    } catch (err) {
      console.error(err);
      showBoundary(err);
    }
  };

  return (
    <Container maxWidth={false} sx={{ py: 2 }} data-testid="allocations-page">
      <GlobalModalComponent
        open={open}
        handleClose={handleRejectAlertClose}
        modelData={modalData}
      />

      {/* Auto Allocate Result Modal */}
      <GlobalModalComponent
        open={showAutoAllocateModal}
        handleClose={handleAutoAllocateModalClose}
        modelData={{
          title:
            autoAllocateSeverity === "success"
              ? "Auto Allocation Successful"
              : autoAllocateSeverity === "warning"
                ? "Auto Allocation Warning"
                : "Auto Allocation Error",
          confirmBtn: "OK",
        }}
        contentComponent={
          <Box sx={{ py: 1 }}>
            <Typography
              variant="body1"
              sx={{
                mb: 2,
                color: "primary",
              }}
            >
              {autoAllocateMessage}
            </Typography>
            {autoAllocateSeverity === "success" && (
              <Typography variant="body2" color="text.secondary">
                The auto-allocation process has completed successfully.
              </Typography>
            )}
            {autoAllocateSeverity === "warning" && (
              <Typography variant="body2" color="text.secondary">
                No positions were available for auto-allocation. Please check
                your data and try again.
              </Typography>
            )}
            {autoAllocateSeverity === "error" && (
              <Typography variant="body2" color="text.secondary">
                An error occurred during the auto-allocation process. Please try
                again or contact support.
              </Typography>
            )}
          </Box>
        }
      />
      {/* Tracking System Supply Section */}
      <Box sx={{ mb: 3 }}>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            mb: 2,
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Typography variant="h6">Allocate Supply</Typography>
            <Button
              variant="contained"
              color="primary"
              onClick={handleAutoAllocate}
              disabled={filteredInbox().length === 0 || isApiCallInProgress}
              startIcon={<AutoAwesome />}
            >
              Auto Allocate
            </Button>
            <Button
              variant="contained"
              color="secondary"
              onClick={handleGrouping}
              startIcon={<AddCircle />}
              disabled={
                selectedReceipts.length === 0 ||
                selectedReceipts.length < 2 ||
                filteredInbox().length === 0 ||
                selectedReceipts.every((row) => row.groupName) ||
                isApiCallInProgress
              }
            >
              Group
            </Button>
            <Button
              variant="outlined"
              color="secondary"
              onClick={handleUnGrouping}
              disabled={
                selectedReceipts.length === 0 ||
                selectedReceipts.every((row) => !row.groupName) ||
                isApiCallInProgress
              }
              startIcon={<RemoveCircle />}
            >
              UnGroup
            </Button>
          </Box>
          <Box
            sx={{
              flexGrow: 1,
              display: "flex",
              justifyContent: "center",
              minWidth: 0,
            }}
          >
            {createTransactionError && (
              <Alert
                severity="error"
                icon={<ErrorIcon color="error" fontSize="small" />}
                onClose={() => {
                  setCreateTransactionError("");
                }}
                sx={{
                  borderRadius: 2,
                }}
              >
                <Typography variant="body2">
                  {createTransactionError}
                </Typography>
              </Alert>
            )}
          </Box>

          {/* Allocation Progress Indicator */}
          <Box
            sx={{
              backgroundColor: "background.paper",
              borderRadius: 1,
              px: 2,
              py: 1,
              boxShadow: 1,
              border: 1,
              borderColor: "divider",
              display: "flex",
              alignItems: "center",
              gap: 2,
            }}
          >
            <Typography
              variant="body2"
              sx={{ fontWeight: "medium", whiteSpace: "nowrap" }}
            >
              {allocationProgress.totalAllocated.toLocaleString()} {" of "}
              {allocationProgress.totalSupply.toLocaleString()} allocated
            </Typography>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
                minWidth: 120,
              }}
            >
              <LinearProgress
                variant="determinate"
                value={allocationProgress.progressPercentage}
                color={
                  allocationProgress.progressPercentage >= 100
                    ? "success"
                    : "primary"
                }
                sx={{
                  height: 6,
                  borderRadius: 3,
                  backgroundColor: "grey.200",
                  flexGrow: 1,
                  "& .MuiLinearProgress-bar": {
                    borderRadius: 3,
                  },
                }}
              />
              <Typography
                variant="caption"
                color="text.secondary"
                sx={{ whiteSpace: "nowrap" }}
              >
                {Math.round(allocationProgress.progressPercentage)}%
              </Typography>
            </Box>
          </Box>
        </Box>
        <Box sx={{ position: "relative", minHeight: 300 }}>
          {!trackingSystem ? (
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: 300,
              }}
            >
              <Typography variant="body1" color="text.secondary">
                Loading tracking system...
              </Typography>
            </Box>
          ) : (
            <AutomatedReceiptsGrid
              key={gridKey}
              theme={threeDTheme}
              rowData={filteredInbox()}
              colDefs={
                isGrouped
                  ? trackingSystemColDefs.map((col) =>
                      col.field === "tsActions"
                        ? {
                            ...col,
                            rowDrag: (params: any) => {
                              if (params.node.group === true) {
                                const groupKey = params.node.key;
                                if (
                                  !groupKey ||
                                  groupKey === "Ungrouped" ||
                                  groupKey === null
                                ) {
                                  return false;
                                }
                                return true;
                              }
                              return !params.data?.groupName;
                            },
                          }
                        : col
                    )
                  : trackingSystemColDefs
              }
              onRowDragEnd={onRowDragEnd}
              onSelectionChanged={onSelectionReceipts}
              onRowDragEnter={onRowDragEnter}
              onGridReady={onSourceGridReady}
              loading={isApiCallInProgress}
              loadingMessage={
                currentOperation === "auto-allocate"
                  ? "Auto Allocating ..."
                  : "Allocating Supply ..."
              }
              noRowsMessage="No Supply To Allocate"
              detailCellRendererParams={undefined}
              rowClassRules={{}}
              gridId={`inbox-${trackingSystem.toLowerCase()}-grid`}
              groupDisplayType={isGrouped ? "multipleColumns" : undefined}
              autoGroupColumnDef={
                isGrouped
                  ? {
                      headerName: "Group",
                      minWidth: 250,
                      field: "ag-Grid-AutoColumn",
                      cellRendererParams: {
                        suppressCount: false,
                        innerRenderer: (params: {
                          data: TrackingSystemAllocationModel;
                          value: string;
                        }) => {
                          return params.value
                            ? params.value
                            : params?.data?.groupName
                              ? params?.data?.groupName
                              : "Ungrouped";
                        },
                      },
                    }
                  : undefined
              }
              groupByFields={isGrouped ? ["groupName"] : ["Ungrouped"]}
              groupDefaultExpanded={0}
              isRowSelectable={
                isGrouped
                  ? (node) => {
                      if (node.group === true) {
                        const groupKey = node.key;
                        if (
                          !groupKey ||
                          groupKey === "Ungrouped" ||
                          groupKey === null
                        ) {
                          return false;
                        }
                        return true;
                      }
                      const rowData =
                        node.data as TrackingSystemAllocationModel;
                      return !rowData?.groupName;
                    }
                  : undefined
              }
            />
          )}
        </Box>
        <Box sx={{ display: "flex", gap: 1, mt: 2 }}>
          <Button
            variant="contained"
            color="error"
            onClick={() => handleRemove("inbox")}
            disabled={
              selectedReceipts.length === 0 || disabled || isApiCallInProgress
            }
            startIcon={<DeleteOutlineOutlinedIcon />}
          >
            Remove
          </Button>
          <FormControlLabel
            control={
              <Switch
                size="medium"
                disabled={selectedReceipts.length > 1 || isApiCallInProgress}
                checked={isEnabled}
                onChange={enable}
              />
            }
            label="Assign to Multiple Positions"
            labelPlacement="start"
            sx={{ ml: "auto" }}
          />
        </Box>
      </Box>

      {/* Artemis Positions Section */}
      <Box sx={{ mb: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2 }}>
          <Typography variant="h6">Allocate Positions</Typography>
          <Box sx={{ display: "flex", gap: 1 }}>
            <Tooltip
              title={
                selectedReceipts.length === 0 || selectedPositions.length === 0
                  ? "Select at least one supply and one position to enable this button"
                  : ""
              }
              disableHoverListener={
                selectedReceipts.length !== 0 && selectedPositions.length !== 0
              }
            >
              <Box sx={{ display: "flex", gap: 1 }}>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleAllocate(true, 0)}
                  data-testid="allocate-button"
                  startIcon={<AddLinkIcon />}
                  disabled={
                    selectedReceipts.length === 0 ||
                    selectedPositions.length === 0 ||
                    isApiCallInProgress
                  }
                  aria-label={
                    selectedReceipts.length === 0 ||
                    selectedPositions.length === 0
                      ? "Allocate button is disabled until at least one supply and one position are selected"
                      : "Allocate selected supply to selected position"
                  }
                >
                  Allocate
                </Button>
                <Button
                  variant="contained"
                  color="secondary"
                  onClick={handleDeallocate}
                  startIcon={<LinkOffIcon />}
                  disabled={
                    selectedPositions.every(
                      (pos) => !pos.allocations || pos.allocations.length === 0
                    ) || isApiCallInProgress
                  }
                >
                  Deallocate
                </Button>
              </Box>
            </Tooltip>
          </Box>
        </Box>
        <Box sx={{ position: "relative", minHeight: 300 }}>
          <AutomatedReceiptsGrid
            key={gridKey}
            rowData={filteredPositions()}
            colDefs={positionAllocationModelColDef}
            onSelectionChanged={onSelectionPositions}
            customContextMenuItems={getContextMenuItems}
            onGridReady={onTargetGridReady}
            detailCellRendererParams={detailCellRendererParams as any}
            rowClassRules={rowClassRules}
            theme={threeDTheme}
            noRowsMessage="No Positions To Allocate"
            rowSelection={{
              mode: "singleRow",
              headerCheckbox: false,
              checkboxes: true,
            }}
            gridId="allocations-positions-grid"
            loadingMessage="Allocations Loading ..."
            loading={allocationRefresh}
          />
        </Box>
        <Box
          sx={{
            mt: 2,
            position: "relative",
            display: "flex",
            alignItems: "center",
          }}
        >
          <Box sx={{ display: "flex", gap: 1 }}>
            <Button
              variant="contained"
              color="error"
              onClick={() => handleRemove("position")}
              disabled={
                selectedPositions.length === 0 ||
                disabled ||
                isApiCallInProgress
              }
              startIcon={<DeleteOutlineOutlinedIcon />}
            >
              Remove
            </Button>
            <Button
              variant="contained"
              color="secondary"
              onClick={handleUndo}
              startIcon={<UndoIcon />}
              disabled={disabled}
            >
              Undo All
            </Button>
          </Box>

          <Box
            sx={{
              position: "absolute",
              left: "50%",
              transform: "translateX(-50%)",
              display: "flex",
              justifyContent: "center",
              gap: 2,
            }}
          >
            <Button
              variant="outlined"
              color="secondary"
              onClick={handleBack}
              startIcon={<ArrowBackIosIcon />}
              disabled={isApiCallInProgress}
            >
              Back
            </Button>
            <Button
              variant="contained"
              color="primary"
              onClick={handleNext}
              disabled={!enableNext || isApiCallInProgress}
              data-testid="next-button"
              endIcon={<ArrowForwardIosIcon sx={{ fontSize: "16px" }} />}
            >
              Next
            </Button>
          </Box>

          <FormControlLabel
            control={
              <Switch
                size="medium"
                checked={isenabledhiddenPositions}
                onChange={(event) =>
                  setEnabledhiddenPositions(event.target.checked)
                }
                disabled={isApiCallInProgress}
              />
            }
            label="Hide Delivered Positions"
            labelPlacement="start"
            sx={{ ml: "auto" }}
          />
        </Box>
      </Box>
    </Container>
  );
};

export default Allocations;
