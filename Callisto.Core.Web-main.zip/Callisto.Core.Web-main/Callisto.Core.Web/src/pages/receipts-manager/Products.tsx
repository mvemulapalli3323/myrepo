import React, {
  useState,
  useEffect,
  useContext,
  useCallback,
  useMemo,
  useRef,
} from "react";
import {
  FormControlLabel,
  Switch,
  Button,
  Typography,
  Box,
  Container,
  Alert,
} from "@mui/material";
import AutomatedReceiptsGrid from "../../components/SharedComponents/Grids/AgGrid";
import {
  productColDefs,
  productSubTrackingSystemColDefs,
} from "../../components/SharedComponents/Grids/GridColDefs";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import GlobalModalComponent from "../../components/SharedComponents/Modals/globalModal";
import {
  ModalDataType,
  ProductRowData,
  RowDataInterfaces,
} from "../../api/services/receipts-services/ServicesInterfaces";
import { ModalMessageType } from "../../components/SharedComponents/Modals/ModalMessageType";
import { useNavigate, useParams } from "react-router-dom";
import {
  createReceipt,
  getProducts,
} from "../../api/services/receipts-services/ProductService";
import { Context } from "../../Context/AppContext";
import { SelectionChangedEvent } from "ag-grid-enterprise";
import { AxiosError } from "axios";
import { threeDTheme } from "../../components/SharedComponents/Grids/threeDTheme";
import { useErrorBoundary } from "react-error-boundary";
import { getAllocationMini } from "@/api/services/receipts-services/AllocationService";
import SplitButton from "../../components/SharedComponents/Buttons/SplitButton";

import EditSquareIcon from "@mui/icons-material/EditSquare";
import CancelIcon from "@mui/icons-material/Cancel";
import ReceiptIcon from "@mui/icons-material/Receipt";
import AssignmentAddIcon from "@mui/icons-material/AssignmentAdd";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import ErrorIcon from "@mui/icons-material/Error";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import AnimationPopover from "../../components/animations/AnimationPopover";

type Params = {
  id: string;
};

const defaultModalData: ModalDataType = {
  title: "",
  content1: "",
  cancelBtn: "CANCEL",
  confirmBtn: "OK",
  type: "",
  btn: "",
  form: {},
};
const Products: React.FC = () => {
  const { id } = useParams<Params>();
  const context = useContext(Context);
  if (!context) {
    throw new Error("Component must be used within an AppProvider");
  }

  const navigate = useNavigate();
  const { open, setOpen, setData, data: contextData } = context;
  const { showBoundary } = useErrorBoundary();
  const [products, setProducts] = useState<RowDataInterfaces[]>([]);
  const [selectedProducts, selectedProductRows] = useState<RowDataInterfaces[]>(
    []
  );
  const [modalData, setModalData] =
    React.useState<ModalDataType>(defaultModalData);
  const [loading, setLoading] = useState(false);
  const [
    isHidingRowsWithSuggestedOrSelectedProducts,
    setIsHidingRowsWithSuggestedOrSelectedProducts,
  ] = useState(false);

  const [receiptId, setReceiptId] = useState<string>("");
  const [createReceiptError, setCreateReceiptError] = useState("");
  const [loadingMessage, setLoadingMessage] = useState<string>(
    "Loading Allocations ..."
  );
  const [isPartialReceipt, setIsPartialReceipt] = useState<boolean>(false);
  const [isSuccessPaneVisible, setIsSuccessPaneVisible] = useState(false);
  const alertContainerRef = useRef<HTMLDivElement>(null);

  // Refresh products when context data changes (indicating a successful product assignment or edit)
  useEffect(() => {
    const getData = async () => {
      if (!id) return;
      setLoading(true);

      try {
        const transaction = await getAllocationMini(id);

        if (transaction.receiptId) {
          setReceiptId(transaction.receiptId);
        }

        const result = await getProducts({ allocationTransactionId: id });
        const newData = result.data;
        // Apply the current filter state to the new data
        if (isHidingRowsWithSuggestedOrSelectedProducts) {
          const filteredProducts = newData.filter(
            (product: ProductRowData) =>
              !(
                Array.isArray(product.suggestedProducts) &&
                product.suggestedProducts.length > 0
              ) && !product.isManuallySelected
          );
          setProducts(filteredProducts);
        } else {
          setProducts(newData);
        }
        setLoading(false);
      } catch (err) {
        console.error(err);
        showBoundary(err);
        setProducts([]);
        setLoading(false);
      }
    };
    getData();
  }, [contextData, id, isHidingRowsWithSuggestedOrSelectedProducts]);

  // Handle ESC key press to hide success pane
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && isSuccessPaneVisible) {
        setIsSuccessPaneVisible(false);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [isSuccessPaneVisible]);

  const handleClose = async (
    data?: "close" | "cancel" | "confirm" | { quantity: number }
  ) => {
    if (data === "confirm" && modalData.title === "Go Back?") {
      setOpen(false);
      navigate(`/allocations/${id}`);
    } else if (data === "confirm" && modalData.title === "Cancel Receipt?") {
      setOpen(false);
      navigate(`/receipts`);
    } else if (data === "confirm" && modalData.title === "Create Receipt?") {
      setOpen(false);
      handleCreateReceiptConfirmed();
    } else {
      // Handle close/cancel for other modals
      setOpen(false);
    }
  };

  const onSelectionProducts = useCallback((event: SelectionChangedEvent) => {
    const selectedNodes = event.api.getSelectedNodes();
    const selectedPositionsRowsData = selectedNodes
      .flatMap((node) => {
        if (node.allLeafChildren && node.allLeafChildren.length > 0) {
          return node.allLeafChildren
            .filter((child) => child.data !== undefined)
            .map((child) => child.data!);
        }
        return node.data ? [node.data] : [];
      })
      .filter((data): data is RowDataInterfaces => data !== undefined);

    selectedProductRows(selectedPositionsRowsData);
  }, []);

  const handleBack = async () => {
    const modalMessage = await ModalData(ModalMessageType.PRODUCT_BACK);
    setModalData(modalMessage);
    setOpen(true);
  };
  const handleCancel = async () => {
    const modalMessage = await ModalData(ModalMessageType.PRODUCT_CANCEL);
    setModalData(modalMessage);
    setOpen(true);
  };
  const handleProducts = async (row: ProductRowData, type: string) => {
    setData([row]);
    const modalMessage = await ModalData(ModalMessageType.PRODUCT_CHOOSEBUTTON);
    modalMessage.btn = type == "formEdit" ? "editproduct" : "chooseproduct";
    setModalData(modalMessage);
    setOpen(true);
  };
  const handleFindProducts = async () => {
    setData(selectedProducts);
    const modalMessage = await ModalData(ModalMessageType.PRODUCT_CHOOSEBUTTON);
    setModalData(modalMessage);
    setOpen(true);
  };
  const handleEditProducts = async (type: string) => {
    setData(selectedProducts);
    const modalMessage = await ModalData(ModalMessageType.PRODUCT_CHOOSEBUTTON);
    modalMessage.btn = type == "formEdit" ? "editproduct" : "chooseproduct";
    setModalData(modalMessage);
    setOpen(true);
  };
  const handleCreateReceipt = async (partialReceipt: boolean) => {
    setCreateReceiptError("");
    setData(selectedProducts);
    setIsPartialReceipt(partialReceipt);
    const modalMessage = await ModalData(ModalMessageType.CREATE_RECEIPT);
    products.forEach((product) => {
      if (product.isConfirmationRequired) {
        modalMessage.checkbox = true;
      }
    });
    setModalData(modalMessage);
    setOpen(true);
  };

  const handleCreateReceiptConfirmed = async () => {
    setLoading(true);
    setLoadingMessage("Creating Receipt ...");
    if (!id) {
      setLoading(false);
      setLoadingMessage("Loading Allocations ...");
      return;
    }
    try {
      // Add 3 second delay for debugging purposes
      //await new Promise((resolve) => setTimeout(resolve, 3000));

      const result = await createReceipt({
        allocationTransactionId: id,
        partial: isPartialReceipt,
      });

      setReceiptId(result.data);
      setIsSuccessPaneVisible(true);
    } catch (err) {
      console.error(err);
      if (err instanceof AxiosError) {
        // Handle Axios error
        setCreateReceiptError(err.response?.data || "Failed to create receipt");
      } else {
        // Handle other types of errors
        setCreateReceiptError("An error occurred while creating receipt");
      }
    } finally {
      setLoading(false);
      //reset the loading message (might have been 'Creating Receipt ...')
      setLoadingMessage("Loading Allocations ...");
    }
  };
  const colDefs = useMemo(
    () => productColDefs(handleProducts, receiptId),
    [receiptId]
  );

  const ModalData = (message: ModalMessageType): ModalDataType => {
    if (message === ModalMessageType.PRODUCT_BACK) {
      return {
        title: "Go Back?",
        content1: "Are you sure you want to leave this screen?",
        content2:
          "You`ll lose any work that you`ve done here and be returned to the previous step in the Receipt process.",
        cancelBtn: "NO, KEEP WORKING",
        confirmBtn: "YES, GO BACK",
      };
    } else if (message === ModalMessageType.PRODUCT_CANCEL) {
      return {
        title: "Cancel Receipt?",
        content2:
          "This will take you back to the Receipt home page. No changes made to Artemis or the Tracking System.",
        content1: "Are you sure you want to cancel entire Receipt?",
        cancelBtn: "NO, KEEP WORKING",
        confirmBtn: "YES, CANCEL RECEIPT",
      };
    } else if (message === ModalMessageType.CREATE_RECEIPT) {
      return {
        title: "Create Receipt?",
        content1: "Are you sure you want to create a new Receipt?",
        checkbox: false,
        cancelBtn: "NO, KEEP WORKING",
        confirmBtn: "YES, CREATE RECEIPT",
      };
    } else if (message === ModalMessageType.PRODUCT_CHOOSEBUTTON) {
      return {
        type: "form",
        btn: "chooseproduct",
      };
    }
    return {};
  };

  const handleCreatePartialReceipt = () => {
    handleCreateReceipt(true);
  };

  const handleCreateFullReceipt = () => {
    handleCreateReceipt(false);
  };

  const hideRowsWithSuggestedOrSelectedProducts = (
    _event: React.SyntheticEvent,
    checked: boolean
  ) => {
    setIsHidingRowsWithSuggestedOrSelectedProducts(checked);
  };
  const detailGridOptions = {
    columnDefs: productSubTrackingSystemColDefs,
  };

  const detailCellRendererParams = {
    detailGridOptions,
    getDetailRowData: (params: any) => {
      params.successCallback(params.data.inboxItems || []);
    },
  };
  return (
    <Container
      maxWidth={false}
      sx={{ py: 2, height: "100vh", display: "flex", flexDirection: "column" }}
      data-testid="products-page"
    >
      <GlobalModalComponent
        open={open}
        handleClose={handleClose}
        modelData={modalData}
      />
      {/* Product Assignment Section */}
      <Box sx={{ mb: 2, flexShrink: 0 }}>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 2,
            flexWrap: "nowrap",
          }}
        >
          <Typography variant="h6" sx={{ flexShrink: 0 }}>
            Assign Products
          </Typography>
          <Button
            variant="contained"
            onClick={handleFindProducts}
            disabled={selectedProducts.length === 0 || !!receiptId || loading}
            startIcon={<AssignmentAddIcon />}
            sx={{ flexShrink: 0, minWidth: "fit-content" }}
          >
            Assign Product
          </Button>
          <Button
            variant="contained"
            onClick={() => handleEditProducts("formEdit")}
            disabled={selectedProducts.length === 0 || !!receiptId || loading}
            startIcon={<EditSquareIcon />}
            sx={{ flexShrink: 0, minWidth: "fit-content" }}
          >
            Edit Positions
          </Button>
          <AnimationPopover
            open={isSuccessPaneVisible}
            anchorEl={alertContainerRef.current}
            onClose={() => setIsSuccessPaneVisible(false)}
          />
          <Box
            ref={alertContainerRef}
            sx={{
              flexGrow: 1,
              display: "flex",
              justifyContent: "flex-end",
              minWidth: 0,
            }}
          >
            {receiptId && (
              <Box>
                <Alert
                  severity="success"
                  icon={<CheckCircleIcon color="success" fontSize="small" />}
                  action={
                    <Button
                      variant="contained"
                      sx={{
                        backgroundColor: "success.main",
                        "&:hover": {
                          backgroundColor: "success.main",
                          filter: "brightness(0.9)",
                        },
                        mt: -0.25,
                      }}
                      size="small"
                      href={`${import.meta.env.VITE_ARTEMIS_HOST || "http://artemis"}/Receipts`}
                      target="_blank"
                      rel="noopener noreferrer"
                      startIcon={<OpenInNewIcon />}
                    >
                      Artemis Receipts
                    </Button>
                  }
                  sx={{
                    borderRadius: 2,
                  }}
                >
                  <Typography variant="body2">
                    Artemis Receipt '{receiptId}' created!
                  </Typography>
                </Alert>
              </Box>
            )}
            {createReceiptError && (
              <Alert
                severity="error"
                icon={<ErrorIcon color="error" fontSize="small" />}
                onClose={() => {
                  setCreateReceiptError("");
                }}
                sx={{
                  borderRadius: 2,
                }}
              >
                <Typography variant="body2">{createReceiptError}</Typography>
              </Alert>
            )}
          </Box>
          {/* Success Popover with Animation */}
        </Box>
      </Box>

      {/* Products Grid - Now uses flex to fill available space */}
      <Box sx={{ flex: 1, minHeight: 0, mb: 2, position: "relative" }}>
        <AutomatedReceiptsGrid
          rowData={products}
          colDefs={colDefs}
          rowClassRules={{}}
          onSelectionChanged={onSelectionProducts}
          theme={threeDTheme}
          loading={loading}
          loadingMessage={loadingMessage}
          noRowsMessage="No Allocations Available"
          height="100%"
          paginationPageSize={100}
          detailCellRendererParams={detailCellRendererParams}
        />
      </Box>

      {/* Footer Section - Fixed height */}
      <Box sx={{ flexShrink: 0 }}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <FormControlLabel
              control={
                <Switch
                  size="medium"
                  checked={isHidingRowsWithSuggestedOrSelectedProducts}
                  onChange={hideRowsWithSuggestedOrSelectedProducts}
                  disabled={!!receiptId || loading}
                />
              }
              label={
                <Typography variant="body1">Hide Rows with Products</Typography>
              }
              labelPlacement="end"
            />
          </Box>
          <Box
            sx={{
              position: "absolute",
              left: "50%",
              transform: "translateX(-50%)",
              display: "flex",
              justifyContent: "center",
              gap: 2,
            }}
          >
            <Button
              variant="outlined"
              color="secondary"
              onClick={handleBack}
              disabled={!!receiptId || loading}
              startIcon={<ArrowBackIosIcon sx={{ fontSize: "16px" }} />}
            >
              Back
            </Button>
          </Box>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "flex-end",
            }}
          >
            <Button
              variant="contained"
              color="error"
              onClick={handleCancel}
              disabled={!!receiptId || loading}
              sx={{ mr: 2 }}
              startIcon={<CancelIcon />}
            >
              Cancel
            </Button>
            <SplitButton
              mainButtonIcon={<ReceiptIcon />}
              menuItems={[
                {
                  text: "Create Full Receipt",
                  onClick: handleCreateFullReceipt,
                },
                {
                  text: "Create Partial Receipt",
                  onClick: handleCreatePartialReceipt,
                },
              ]}
              disabled={!!receiptId || loading}
            />
          </Box>
        </Box>
      </Box>
    </Container>
  );
};

export default Products;
