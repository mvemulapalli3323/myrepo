"use client";

import React, {
  useState,
  useEffect,
  useContext,
  useCallback,
  useRef,
} from "react";

import AutomatedReceiptsGrid from "../../components/SharedComponents/Grids/AgGrid";
import AddIcon from "@mui/icons-material/Add";
import { Context } from "../../Context/AppContext";
import UploadIcon from "@mui/icons-material/Upload";
import DownloadIcon from "@mui/icons-material/Download";
import LightbulbIcon from "@mui/icons-material/Lightbulb";
import ApiIcon from "@mui/icons-material/Api";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import {
  getAvailableTrackingSystems,
  getTrackingSystemDataFromUploadedFile,
} from "../../api/services/receipts-services/TrackingsystemService";
import {
  positionModelColDefs,
  inboxTrackingSystemColDef,
} from "../../components/SharedComponents/Grids/GridColDefs";
import { useNavigate, useParams } from "react-router-dom";
import {
  getAllocations,
  getTransactions,
  updateTransactions,
} from "../../api/services/receipts-services/AllocationService";
import GlobalModalComponent from "../../components/SharedComponents/Modals/globalModal";
import {
  AutoSearchParams,
  ModalDataType,
  TrackingSystemInfo,
} from "../../api/services/receipts-services/ServicesInterfaces";
import { ModalMessageType } from "../../components/SharedComponents/Modals/ModalMessageType";
import {
  Button,
  SelectChangeEvent,
  Typography,
  Box,
  Container,
  Alert,
} from "@mui/material";
import SelectWithLoadingIndicator from "../../components/SharedComponents/Selects/SelectWithLoadingIndicator";
import { SelectionChangedEvent } from "ag-grid-enterprise";
import FileUploadDialog from "../../components/SharedComponents/Dialogs/FileUploadDialog";
import { useErrorBoundary } from "react-error-boundary";
import { autoSearchPositionData } from "../../api/services/receipts-services/PositionService";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import { threeDTheme } from "../../components/SharedComponents/Grids/threeDTheme";
import { ModalData } from "@/components/SharedComponents/Grids/CommonUtils";
import type { GridApi } from "ag-grid-community";
import {
  PositionModel,
  TrackingSystemInboxItem,
} from "@/api/types/receipts-types";
import ModalComponent from "@/components/SharedComponents/Modals/ModalComponent";
import SearchPosition from "@/components/SearchPosition";
import { useLoader } from "../../Context/LoaderContext";
import { useGridStateManager } from "@/utils/gridStateManager";
import { AxiosError } from "axios";
import { appInsights, SeverityLevel } from "@/hooks/appinsights";
import ErrorIcon from "@mui/icons-material/Error";
import { TransactionModal } from "@/components/SharedComponents/Modals/TransactionModal";
import { getInboxForTransactionNumber } from "@/api/services/receipts-services/TransactionService";
type Params = {
  id: string;
};

interface ContextDataItem {
  type: string;
  data: PositionModel[] | TrackingSystemInboxItem[];
}

const defaultModalData: ModalDataType = {
  title: "",
  content1: "",
  cancelBtn: "CANCEL",
  confirmBtn: "OK",
  type: "",
  form: {},
};

const addTrackingSystemWarnings = (
  positionData: PositionModel[],
  selectedTrackingSystemInfo: TrackingSystemInfo | null,
  availableTrackingSystems: TrackingSystemInfo[]
): PositionModel[] => {
  return positionData.map((position) => {
    const positionWithTracking = position as any;
    let existingWarnings: string[] = [];
    if (Array.isArray(positionWithTracking.warnings)) {
      existingWarnings = positionWithTracking.warnings.map((w: any) =>
        typeof w === "string" ? w : w.message
      );
    } else if (typeof positionWithTracking.warnings === "string") {
      existingWarnings = [positionWithTracking.warnings];
    }
    if (
      positionWithTracking.eC_TrackingSystemId &&
      selectedTrackingSystemInfo &&
      positionWithTracking.eC_TrackingSystemId !==
        selectedTrackingSystemInfo.trackingSystemId
    ) {
      // Find the friendly name for the position's tracking system
      const positionTrackingSystemInfo = availableTrackingSystems.find(
        (ts) => ts.trackingSystemId === positionWithTracking.eC_TrackingSystemId
      );
      const positionFriendlyName =
        positionTrackingSystemInfo?.friendlyName ||
        positionWithTracking.trackingSystemName;

      // Only add the warning if it doesn't already exist
      const warningMsg = `Position tracking system (${positionFriendlyName}) does not match selected tracking system (${selectedTrackingSystemInfo.friendlyName})`;
      if (!existingWarnings.includes(warningMsg)) {
        existingWarnings.push(warningMsg);
      }
      return {
        ...position,
        warnings: existingWarnings,
      } as PositionModel;
    }
    return position;
  });
};

export default function ReceiptsManager() {
  const { id } = useParams<Params>();
  const context = useContext(Context);
  const navigate = useNavigate();
  const [modalOpen, setModalOpen] = useState(false);
  const [transactionModalOpen, setTransactionModalOpen] = useState(false);

  const gridStateManager = useGridStateManager();
  if (!context) {
    throw new Error("Component must be used within an AppProvider");
  }

  const { data, open, setOpen, setData } = context;
  const [searchPositionData, setSearchPositionData] = useState<PositionModel[]>(
    []
  );
  const [inboxData, setInboxData] = useState<TrackingSystemInboxItem[]>([]);
  const [searchReceiptsRows, setSelectedSearchReceiptsRows] = useState<
    TrackingSystemInboxItem[]
  >([]);
  const [availableTrackingSystems, setAvailableTrackingSystems] = useState<
    { value: string; label: string }[]
  >([]);
  const [availableTrackingSystemInfos, setAvailableTrackingSystemInfos] =
    useState<TrackingSystemInfo[]>([]);
  const [selectedTrackingSystemInfo, setSelectedTrackingSystemInfo] =
    useState<TrackingSystemInfo | null>(null);

  const [selectedSearchPositionRows, setSelectedSearchPositionRows] = useState<
    PositionModel[]
  >([]);
  const [transactionid, setTransactionid] = useState<string>(id || "");
  const [createTransactionError, setCreateTransactionError] = useState("");
  const [trackingSystemGridId, setTrackingSystemGridId] = useState<string>(
    "inbox-inboxItem-grid"
  );
  const [modalData, setModalData] =
    React.useState<ModalDataType>(defaultModalData);
  const [isFileUploadDialogOpen, setFileUploadDialogOpen] =
    React.useState(false);
  const [showNoSuggestionsModal, setShowNoSuggestionsModal] =
    React.useState(false);
  const [
    isTrackingSystemSupplyGridLoading,
    setIsTrackingSystemSupplyGridLoading,
  ] = React.useState(false);
  const [isTrackingSystemLoading, setIsTrackingSystemLoading] =
    React.useState(false);
  const [positionRefresh, setPositionRefresh] = React.useState(false);
  const { showBoundary } = useErrorBoundary();
  const { showLoader, hideLoader } = useLoader();

  // Refs for grid APIs to restore selections
  const receiptsGridRef = useRef<GridApi | null>(null);
  const positionsGridRef = useRef<GridApi | null>(null);
  const trackingSystemGridRef = useRef<GridApi | null>(null);
  // Ref to track previous selections to prevent infinite loops
  const previousSelectedPositionsRef = useRef<PositionModel[]>([]);

  const saveCurrentGridState = () => {
    if (
      trackingSystemGridRef.current &&
      trackingSystemGridId &&
      trackingSystemGridId !== "inbox-inboxItem-grid"
    ) {
      try {
        const currentState = trackingSystemGridRef.current.getState();
        gridStateManager.saveState(trackingSystemGridId, currentState);
      } catch (error) {
        console.error("Failed to save grid state:", error);
      }
    }
  };

  const handleChange = async (event: SelectChangeEvent<string | number>) => {
    saveCurrentGridState();

    const value = event.target.value;
    const selectedTS = String(value);
    const newGridId = setTrackingSystemGridIdBySelection(selectedTS);
    setTrackingSystemGridId(newGridId);

    // Find and store the selected TrackingSystemInfo object from existing state
    const selectedInfo = availableTrackingSystemInfos.find(
      (item) => item.serviceName === selectedTS
    );
    setSelectedTrackingSystemInfo(selectedInfo || null);

    setInboxData([]);
    setSearchPositionData([]);
    setIsTrackingSystemSupplyGridLoading(false);
  };
  const setTrackingSystemGridIdBySelection = useCallback(
    (selectedTS: string): string => {
      if (selectedTS && selectedTS !== "") {
        return `inbox-${selectedTS.toLowerCase()}-grid`;
      }
      return "inbox-inboxItem-grid";
    },
    []
  );

  useEffect(() => {
    // Effect runs when trackingSystemGridId changes
    // Grid will automatically re-render due to key prop
  }, [trackingSystemGridId]);
  const handleOpen = () => setOpen(true);
  const onSelectionChanged = useCallback((event: SelectionChangedEvent) => {
    const selectedPositionsRowsData = event.api.getSelectedRows();

    // Only update state if selections have actually changed
    // Introduced via DT-2963 and greatly increases the complexity of the useEffect/state management
    // this breaks the infinite loop of grid selection but retains the desired functionality
    const previousSelections = previousSelectedPositionsRef.current;
    const currentSelectionIds = selectedPositionsRowsData
      .map((row) => row.positionId)
      .sort();
    const previousSelectionIds = previousSelections
      .map((row) => row.positionId)
      .sort();

    if (
      JSON.stringify(currentSelectionIds) !==
      JSON.stringify(previousSelectionIds)
    ) {
      previousSelectedPositionsRef.current = selectedPositionsRowsData;
      setSelectedSearchPositionRows(selectedPositionsRowsData);
    }
  }, []);
  const onSelectionInboxRows = useCallback(
    (event: SelectionChangedEvent<TrackingSystemInboxItem>) => {
      const selectedRowsData = event.api.getSelectedRows();
      setSelectedSearchReceiptsRows(selectedRowsData);
    },
    []
  );

  const handleRemove = () => {
    setSearchPositionData((prevData) =>
      prevData.filter((row) => {
        if (row.positionId == null) return true;

        return !selectedSearchPositionRows.some((selectedRow) => {
          if (selectedRow.positionId == null) return false;
          return selectedRow.positionId === row.positionId;
        });
      })
    );
  };

  const showFileUploadDialog = useCallback(() => {
    setInboxData([]);
    setFileUploadDialogOpen(true);
  }, []);
  const handleFileUploadDialogClose = useCallback(
    async (uploadId: string) => {
      setFileUploadDialogOpen(false);

      if (uploadId.trim().length != 0) {
        setIsTrackingSystemSupplyGridLoading(true);
        try {
          console.log(`fileUploadDialog uploadId: `, uploadId);
          const trackingSystemFileUploadData =
            await getTrackingSystemDataFromUploadedFile({
              trackingSystem: selectedTrackingSystemInfo?.serviceName || "",
              uploadId: uploadId,
            });
          setInboxData(trackingSystemFileUploadData.data);
          setIsTrackingSystemSupplyGridLoading(false);
        } catch (err) {
          const errorObj = err as any;
          // Log error so tests (and devs) can verify graceful handling
          console.error(
            "Failed to load uploaded tracking system data:",
            errorObj
          );
          if (appInsights) {
            try {
              appInsights.trackException({
                exception:
                  errorObj instanceof Error
                    ? errorObj
                    : new Error("File upload processing failed"),
                severityLevel: SeverityLevel.Error,
                properties: {
                  component: "ReceiptsManager",
                  action: "getTrackingSystemDataFromUploadedFile",
                  trackingSystem: selectedTrackingSystemInfo?.serviceName || "",
                  uploadId,
                  //HPD rework this as time permits: not finding the axios error particularly helpful in the azure portal
                  //but for now, we can drill into 'details' column to see the full .net exception/call stack
                  isAxiosError: String(errorObj instanceof AxiosError),
                  message: (errorObj as AxiosError)?.message,
                },
              });
            } catch (_) {
              console.error("unexpected telemetry error!");
            }
          }

          if (errorObj instanceof AxiosError) {
            setCreateTransactionError(
              errorObj.response?.data?.message ||
                errorObj.message ||
                "Failed to load uploaded tracking system data."
            );
          } else {
            setCreateTransactionError(
              "Failed to load uploaded tracking system data."
            );
          }
        } finally {
          setIsTrackingSystemSupplyGridLoading(false);
        }
      }
    },
    [selectedTrackingSystemInfo]
  );

  const handleDownloadTemplate = useCallback(() => {
    const templateUrl = "/templates/TrackingSystemInboxItemTemplate.xlsx";
    const link = document.createElement("a");
    link.href = templateUrl;
    link.download = "TrackingSystemInboxItemTemplate.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, []);

  useEffect(() => {
    const fetchAvailableTrackingSystems = async () => {
      setIsTrackingSystemLoading(true);
      showLoader();
      try {
        const result = await getAvailableTrackingSystems();
        const modifiedData = result.data.map((item: TrackingSystemInfo) => ({
          value: item.serviceName,
          label: item.friendlyName,
        }));
        setAvailableTrackingSystems(modifiedData);
        setAvailableTrackingSystemInfos(result.data);
        getAllocationData();
      } catch (err) {
        console.error(err);
        showBoundary(err);
      } finally {
        setIsTrackingSystemLoading(false);
      }
    };
    fetchAvailableTrackingSystems();
    if (id) {
      setTransactionid(id);
    }

    // Clean up expired grid states on component mount
    gridStateManager.clearExpiredStates();
  }, [id, gridStateManager]);

  // Clear positions grid when navigating to receipts without an ID
  useEffect(() => {
    if (!id) {
      // Clear positions data when navigating to /receipts (without ID)
      setSearchPositionData([]);
      setSelectedSearchPositionRows([]);
      setInboxData([]);
      setSelectedSearchReceiptsRows([]);
      setSelectedTrackingSystemInfo(null);
      setTransactionid("");
      setTrackingSystemGridId("inbox-inboxItem-grid");
      // Clear context data as well
      setData([]);
      // Clear all position-related grid states for new receipts
      gridStateManager.clearStatesForContext("search-positions-grid");
      // Reset the ref to track selections
      previousSelectedPositionsRef.current = [];
    }
  }, [id]);

  // Helper function to select grid rows by IDs
  const selectGridRowsByIds = useCallback(
    (gridRef: any, ids: (string | number | null | undefined)[]) => {
      if (gridRef?.current) {
        gridRef.current.deselectAll();
        gridRef.current.forEachNode((node: any) => {
          const nodeId = node.data.positionId || node.data.transactionID;
          if (nodeId && ids.includes(nodeId)) {
            node.setSelected(true);
          }
        });
      }
    },
    []
  );

  // Handle visual selection in grid when selectedSearchPositionRows changes
  useEffect(() => {
    if (positionsGridRef.current && selectedSearchPositionRows.length > 0) {
      const selectedPositionIds = selectedSearchPositionRows
        .map((row) => row.positionId)
        .filter((id): id is number => id !== undefined);
      selectGridRowsByIds(positionsGridRef, selectedPositionIds);
      // Update the ref with current selections
      previousSelectedPositionsRef.current = selectedSearchPositionRows;
    }
  }, [selectedSearchPositionRows, selectGridRowsByIds]);

  const getAllocationData = async () => {
    try {
      if (!id) return;
      const result = await getAllocations({ allocationTransactionId: id });

      // Find and store the selected TrackingSystemInfo object
      const trackingSystemsResult = await getAvailableTrackingSystems();
      const selectedInfo = trackingSystemsResult.data.find(
        (item) => item.serviceName === result.trackingSystem
      );
      setSelectedTrackingSystemInfo(selectedInfo || null);
      setTrackingSystemGridId(
        selectedInfo?.serviceName
          ? `inbox-${selectedInfo.serviceName.toLowerCase()}-grid`
          : "inbox-inboxItem-grid"
      );
      const contextTrackingSystemData = (data as ContextDataItem[])?.find(
        (item) => item.type === "allTrackingSystem"
      )?.data;
      setInboxData(contextTrackingSystemData || (result.inboxRows ?? []));

      if (result.inboxRows && receiptsGridRef.current) {
        const receiptIds = result.inboxRows
          .map((row: TrackingSystemInboxItem) => row.transactionID)
          .filter((id): id is string => id !== null && id !== undefined);

        // Ensure grid selections happen after grid is ready
        // TODO: try using AG Grid 'onFirstDataRendered' event instead of setTimeout
        setTimeout(() => {
          selectGridRowsByIds(receiptsGridRef, receiptIds);
        }, 100);
      }
      const positionsWithWarnings = addTrackingSystemWarnings(
        result.positions as PositionModel[],
        selectedInfo || null,
        trackingSystemsResult.data
      );
      setSearchPositionData(positionsWithWarnings);
      setSelectedSearchPositionRows(positionsWithWarnings);
      // Update the ref to track the initial selections
      previousSelectedPositionsRef.current = positionsWithWarnings;

      // Ensure grid selections happen after grid is ready
      // TODO: try using AG Grid 'onFirstDataRendered' event instead of setTimeout
      setTimeout(() => {
        if (positionsWithWarnings.length > 0) {
          const positionIds = positionsWithWarnings
            .map((item) => item.positionId)
            .filter((id): id is number => id !== undefined);
          selectGridRowsByIds(positionsGridRef, positionIds);
        }
      }, 100);
    } catch (err) {
      console.error(err);
    } finally {
      hideLoader();
    }
  };

  const handleClose = (
    data?: "close" | "cancel" | "confirm" | { quantity: number }
  ) => {
    setOpen(false);
    if (data === "confirm") {
      handleNext("confirm");
    }
  };
  const handleNext = async (confirmType: string = "") => {
    const inboxTransactionIds: string[] = [];
    const positionIds: number[] = [];
    showLoader();
    searchReceiptsRows.forEach((row) => {
      if (row.transactionID) {
        inboxTransactionIds.push(row.transactionID);
      }
    });
    let hasWarnings = false;

    selectedSearchPositionRows.forEach((row) => {
      if (
        confirmType === "" &&
        ((row.warnings?.length ?? 0) > 0 || (row.errors?.length ?? 0) > 0)
      ) {
        hasWarnings = true;
        handlePositionsErrors();
        return;
      }

      if (row.positionId) {
        positionIds.push(Number(row.positionId));
      }
    });

    if (hasWarnings && confirmType === "") return;

    // Set tracking systems and positions data into context with specific names
    setData([
      {
        type: "allPositions",
        data: searchPositionData,
      },
      {
        type: "allTrackingSystem",
        data: inboxData,
      },
    ]);

    try {
      let result;
      if (id === undefined) {
        result = await getTransactions({
          trackingSystem: selectedTrackingSystemInfo?.serviceName || "",
          inboxTransactionIds,
          positionIds,
        });
      } else {
        result = await updateTransactions({
          trackingSystem: selectedTrackingSystemInfo?.serviceName || "",
          inboxTransactionIds,
          positionIds,
          transactionid,
        });
      }
      const allocationId = result.data.allocationTransactionId;
      navigate(`/allocations/${allocationId}`);
    } catch (err) {
      console.error(err);
      console.log(err);
      if (err instanceof AxiosError) {
        setCreateTransactionError(
          err.message || err.response?.data || "Unable to proceed"
        );
        window.scrollTo({
          top: 0,
          behavior: "smooth",
        });
      } else {
        setCreateTransactionError("Unable to proceed");
      }
      hideLoader();
      // showBoundary(err);
    }
  };

  const handlePositionsErrors = async () => {
    const modalMessage = await ModalData(ModalMessageType.POSITION_ERROR_ALERT);
    setModalData(modalMessage);
    hideLoader();
    handleOpen();
  };
  const handleAddPositions = async () => {
    console.log("Current selected positions:", selectedSearchPositionRows); // Debug log
    setModalOpen(true);
  };
  const handleSuggestedPositions = async () => {
    console.log(
      `Suggested positions for receipts: `,
      selectedTrackingSystemInfo?.serviceName
    );
    setPositionRefresh(true);
    const paginationOptions = {
      pageSize: 50,
      pageNumber: 0,
      paginationType: "Paged",
    };
    const autoSearchParams: AutoSearchParams = {
      trackingSystem: selectedTrackingSystemInfo?.serviceName || "",
      inboxTransactionIds: searchReceiptsRows
        .filter((id) => id !== undefined)
        .map((row) => row.transactionID!),
      paginationOptions,
    };
    try {
      const result = await autoSearchPositionData(autoSearchParams);
      setData(result.data ?? []);
      setPositionRefresh(false);
      const suggestedData = result.data;

      // Check if there are no results
      if (!suggestedData || suggestedData.length === 0) {
        setShowNoSuggestionsModal(true);
      } else {
        setData(suggestedData);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setPositionRefresh(false);
    }
  };

  const handlePositionsGridReady = useCallback((event: { api: GridApi }) => {
    positionsGridRef.current = event.api;
  }, []);
  const handleTrackingSystemGridReady = useCallback(
    (event: { api: GridApi }) => {
      trackingSystemGridRef.current = event.api;
    },
    []
  );
  const handleNoSuggestionsModalClose = () => {
    setShowNoSuggestionsModal(false);
  };

  // Ensure selectedSearchPositionRows is properly maintained
  useEffect(() => {
    console.log("Selected positions updated:", selectedSearchPositionRows); // Debug log
  }, [selectedSearchPositionRows]);

  const handleTransactionModalSubmit = async (selectedRow: any) => {
    const transactionNumber: string[] = [];
    const trackingSystem = selectedTrackingSystemInfo?.serviceName;
    selectedRow.forEach((row: { transactionNumber?: string }) => {
      if (row.transactionNumber) {
        transactionNumber.push(row.transactionNumber);
      }
    });
    try {
      const response = await getInboxForTransactionNumber(
        trackingSystem,
        transactionNumber
      );
      setInboxData(response);
      hideLoader();
    } catch (err) {
      throw err;
    }
  };

  return (
    <Container maxWidth={false} sx={{ py: 2 }} data-testid="inbox-page">
      <ModalComponent
        onClose={() => setModalOpen(false)}
        open={modalOpen}
        draggable={true}
      >
        <SearchPosition
          onComplete={(data) => {
            setSearchPositionData((prevProp: PositionModel[]) => {
              const existingIds = new Set(
                prevProp.map((item) => item.positionId)
              );
              const newItems = (data || []).filter(
                (item) => !existingIds.has(item.positionId)
              );

              // Add warnings for tracking system mismatches
              const newItemsWithWarnings = addTrackingSystemWarnings(
                newItems,
                selectedTrackingSystemInfo,
                availableTrackingSystemInfos
              );

              // Auto-select newly added positions
              if (newItemsWithWarnings.length > 0) {
                setSelectedSearchPositionRows((prevSelected) => {
                  const newSelections = [
                    ...prevSelected,
                    ...newItemsWithWarnings,
                  ];
                  // Update the ref to track the new selections
                  previousSelectedPositionsRef.current = newSelections;
                  return newSelections;
                });

                // Use setTimeout to ensure grid has rendered the new rows before selecting
                setTimeout(() => {
                  if (positionsGridRef.current) {
                    const newPositionIds = newItemsWithWarnings.map(
                      (item) => item.positionId
                    );
                    positionsGridRef.current.forEachNode((node) => {
                      if (newPositionIds.includes(node.data.positionId)) {
                        node.setSelected(true);
                      }
                    });
                  }
                }, 100);
              }

              return [...prevProp, ...newItemsWithWarnings];
            });
            setModalOpen(false);
          }}
          onClose={() => setModalOpen(false)}
          selectedTrackingSystemInfo={selectedTrackingSystemInfo}
          alreadySelectedPositions={searchPositionData}
        />
      </ModalComponent>
      <GlobalModalComponent
        open={open}
        handleClose={handleClose}
        modelData={modalData}
      />

      {/* No Suggestions Warning Modal */}
      <GlobalModalComponent
        open={showNoSuggestionsModal}
        handleClose={handleNoSuggestionsModalClose}
        modelData={{
          title: "No Suggestions Available",
          confirmBtn: "OK",
        }}
        contentComponent={
          <Box sx={{ py: 1 }}>
            <Typography variant="subtitle1" sx={{ mb: 2 }}>
              Unable to suggest positions for the selected tracking system
              items.
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Please try selecting different items or add positions manually.
            </Typography>
          </Box>
        }
      />

      <Box sx={{ mb: 2 }}>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            mb: 2,
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <Typography variant="h5">Select Supply</Typography>
            <Box sx={{ width: "200px", ml: 2 }}>
              <SelectWithLoadingIndicator
                labelId="tracking-system-label"
                id="tracking-system-select"
                value={selectedTrackingSystemInfo?.serviceName || ""}
                label="Tracking System"
                onChange={handleChange}
                disabled={false}
                loading={isTrackingSystemLoading}
                options={availableTrackingSystems}
                fullWidth={true}
                size="small"
              />
            </Box>
            <Button
              variant="contained"
              disabled={!selectedTrackingSystemInfo}
              onClick={showFileUploadDialog}
              startIcon={<UploadIcon />}
            >
              Upload
            </Button>
            <Button
              variant="contained"
              color="primary"
              disabled={!selectedTrackingSystemInfo?.supportsApi}
              onClick={() => setTransactionModalOpen(true)}
              startIcon={<ApiIcon />}
            >
              Fetch from API
            </Button>
            <TransactionModal
              isOpen={transactionModalOpen}
              onClose={() => setTransactionModalOpen(false)}
              onSubmit={handleTransactionModalSubmit}
              selectedTrackingSystemInfo={selectedTrackingSystemInfo}
            />
            <FileUploadDialog
              isFileUploadDialogOpen={isFileUploadDialogOpen}
              onClose={handleFileUploadDialogClose}
              uploadUrl={
                import.meta.env.VITE_RECEIPTS_API_BASE_URL +
                "/trackingsystems/upload"
              }
              trackingSystemInfo={selectedTrackingSystemInfo}
            />
          </Box>
          <Box
            sx={{
              flexGrow: 1,
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "center",
              minWidth: 0,
              gap: 2,
            }}
          >
            {createTransactionError && (
              <Alert
                severity="error"
                icon={<ErrorIcon color="error" fontSize="small" />}
                onClose={() => {
                  setCreateTransactionError("");
                }}
                sx={{
                  borderRadius: 2,
                }}
              >
                <Typography variant="body2">
                  {createTransactionError}
                </Typography>
              </Alert>
            )}
            <Button
              variant="outlined"
              color="secondary"
              disabled={!selectedTrackingSystemInfo}
              onClick={handleDownloadTemplate}
              startIcon={<DownloadIcon />}
              sx={{ whiteSpace: "nowrap" }}
            >
              Template
            </Button>
          </Box>
        </Box>
      </Box>

      {/* Tracking System Grid */}
      <Box sx={{ mb: 3 }}>
        <Box sx={{ position: "relative", minHeight: 300 }}>
          <AutomatedReceiptsGrid
            onGridReady={handleTrackingSystemGridReady}
            rowData={inboxData}
            colDefs={inboxTrackingSystemColDef}
            onSelectionChanged={onSelectionInboxRows}
            theme={threeDTheme}
            detailCellRendererParams={undefined}
            rowClassRules={{}}
            loading={isTrackingSystemSupplyGridLoading}
            loadingMessage="Loading tracking system supply..."
            noRowsMessage="No Tracking System Supply"
            gridId={trackingSystemGridId}
            key={trackingSystemGridId}
          />
        </Box>
      </Box>

      {/* Positions Section */}
      <Box sx={{ mb: 2 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 2 }}>
          <Typography variant="h5">Select Positions</Typography>
          <Button
            variant="contained"
            onClick={handleAddPositions}
            startIcon={<AddIcon fontSize="small" />}
            disabled={!selectedTrackingSystemInfo}
            sx={{ ml: 2 }}
          >
            Add
          </Button>
          <Button
            variant="contained"
            color="secondary"
            onClick={handleSuggestedPositions}
            disabled={searchReceiptsRows.length === 0}
            startIcon={<LightbulbIcon />}
          >
            Suggest
          </Button>
        </Box>
      </Box>

      {/* Positions Grid */}
      <Box sx={{ mb: 3 }}>
        <Box sx={{ position: "relative", minHeight: 300 }}>
          <AutomatedReceiptsGrid
            onGridReady={handlePositionsGridReady}
            rowData={searchPositionData}
            colDefs={positionModelColDefs}
            onSelectionChanged={onSelectionChanged}
            detailCellRendererParams={undefined}
            rowClassRules={{}}
            theme={threeDTheme}
            loadingMessage="Suggesting Positions..."
            loading={positionRefresh}
            noRowsMessage="No Positions Selected"
            gridId="inbox-positions-grid"
          />
        </Box>
      </Box>

      {/* Action Buttons */}
      <Box
        sx={{
          mb: 3,
          position: "relative",
          display: "flex",
          alignItems: "center",
        }}
      >
        <Button
          variant="contained"
          color="error"
          disabled={selectedSearchPositionRows.length === 0}
          onClick={handleRemove}
          startIcon={<DeleteOutlineOutlinedIcon />}
        >
          Remove Position
        </Button>

        <Box
          sx={{
            position: "absolute",
            left: "50%",
            transform: "translateX(-50%)",
            display: "flex",
            justifyContent: "center",
          }}
        >
          <Button
            variant="contained"
            color="primary"
            onClick={() => handleNext()}
            disabled={
              searchReceiptsRows.length === 0 ||
              selectedSearchPositionRows.length === 0
            }
            data-testid="next-button"
            endIcon={<ArrowForwardIosIcon />}
          >
            Next
          </Button>
        </Box>
      </Box>
    </Container>
  );
}
