/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useRef, useState } from "react";
import { AgGridReact } from "ag-grid-react";

import api, { DataTable, DataType } from "../../api";
import Spinner from "../../components/Spinner";
import DataGrid from "./DataGrid";
import TableSelector from "./TableSelector";
import RowEditor from "./RowEditor";
import { useMsal } from "@azure/msal-react";
import { InteractionStatus } from "@azure/msal-browser";

export default function DataManager() {
  const grid = useRef<AgGridReact<any> | null>();
  const [isTableSelectorOpen, setIsTableSelectorOpen] = useState(false);
  const [isRowEditorOpen, setIsRowEditorOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [tableDef, setTableDef] = useState<DataTable>();
  const [row, setRow] = useState<any>();
  const [data, setData] = useState<any[]>([]);

  const openTableSelector = () => setIsTableSelectorOpen(true);
  const closeTableSelector = () => setIsTableSelectorOpen(false);
  const selectTableDef = (def: DataTable) => setTableDef(def);
  const { instance, inProgress } = useMsal();
  const activeAccount =
    inProgress === InteractionStatus.None ? instance.getActiveAccount() : null;

  const addNewRow = () => {
    if (!tableDef) return;

    const newRow: any = {};
    tableDef.fields.forEach((f) => {
      switch (f.dataType) {
        case DataType.Boolean:
          newRow[f.key] = false;
          break;
        case DataType.DateTime:
          newRow[f.key] = new Date();
          break;
        default:
          newRow[f.key] = "";
          break;
      }
      if (f.primaryKey) newRow[f.key] = 0;
    });

    newRow["createdBy"] = activeAccount?.username;
    newRow["createdOn"] = new Date();
    newRow["lastModifiedBy"] = activeAccount?.username;
    newRow["lastModifiedOn"] = new Date();

    setRow(newRow);
    setIsRowEditorOpen(true);
  };

  const editRow = (row: any) => {
    setRow(row);
    setIsRowEditorOpen(true);
  };

  const closeRowEditor = () => setIsRowEditorOpen(false);

  const saveRow = (editedRow: any) => {
    const save = async () => {
      if (!tableDef || loading) return;

      setLoading(true);
      setError("");

      const id = row[tableDef.primaryKey];
      editedRow["lastModifiedBy"] = activeAccount?.username;
      editedRow["lastModifiedOn"] = new Date();
      editedRow["createdOn"] = row["createdOn"];
      editedRow["createdBy"] = row["createdBy"];
      delete editedRow.history;

      if (!id) {
        try {
          const r = await api.table.addRow(tableDef.code, editedRow);
          grid.current!.api.applyTransaction({ add: [r] });
        } catch (e: any) {
          setError(e.response.data.details);
        }
      } else {
        editedRow[tableDef.primaryKey] = id;

        try {
          const r = await api.table.updateRow(tableDef.code, editedRow);

          const idx = data.findIndex((r0) => r0[tableDef.primaryKey] === id);
          data[idx] = r;
          grid.current!.api.setGridOption("rowData", data);
        } catch (e: any) {
          setError(e.response.data.details);
        }
      }

      setLoading(false);
    };

    save();
  };

  const deleteRow = (row: any) => {
    const del = async () => {
      if (!tableDef) return;

      delete row.history;

      setLoading(true);
      setError("");
      try {
        await api.table.deleteRow(tableDef.code, row);

        grid.current!.api.applyTransaction({ remove: [row] });
      } catch (e: any) {
        setError(e.response.data.details);
      }

      setLoading(false);
    };

    del();
  };

  const onAgGridReady = (g: AgGridReact<any> | null) => (grid.current = g);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      setError("");
      const tableCode = `${tableDef?.code}`;
      const key = api.table.getKey(tableCode);

      let rows = [];

      try {
        rows = await api.table.getRows(tableCode);
        //loads history and groups rows, not efficient for large tables.
        const history = (await api.table.getHistory(tableCode)) || [];

        rows.forEach(
          (r) => (r.history = history.filter((h) => h[key] === r[key])),
        );
      } catch (e: any) {
        setError(e);
      }

      setData(rows);
      setLoading(false);
      grid.current!.api.setGridOption("rowData", rows);
    };

    if (tableDef) loadData();
  }, [tableDef]);

  return (
    <div className="page">
      <header className="page-header">
        <div className="min-w-0 flex flex-1 gap-x-2 items-center">
          <div>
            <h1>Data Manager</h1>
            <div className="flex items-center gap-x-2">
              <Spinner loading={loading} text="Loading ..." />
              {!loading && <p>{tableDef?.code}</p>}
            </div>
            {error && (
              <span className="text-sm text-red-800 font-bold">{error}</span>
            )}
          </div>
        </div>
        <div className="mt-4 flex md:ml-4 md:mt-0 gap-x-2">
          <button className="btn-primary-outline" onClick={openTableSelector}>
            Select
          </button>
          <button className="btn-primary-outline" onClick={addNewRow}>
            Add Row
          </button>
        </div>
      </header>

      <main className="page-content">
        <DataGrid
          tableDef={tableDef}
          onReady={onAgGridReady}
          onEdit={editRow}
          onDelete={deleteRow}
        />
      </main>

      <TableSelector
        isOpen={isTableSelectorOpen}
        onClose={closeTableSelector}
        onChange={selectTableDef}
      />

      <RowEditor
        tableDef={tableDef}
        row={row}
        isOpen={isRowEditorOpen}
        onClose={closeRowEditor}
        onChange={saveRow}
      />
    </div>
  );
}
