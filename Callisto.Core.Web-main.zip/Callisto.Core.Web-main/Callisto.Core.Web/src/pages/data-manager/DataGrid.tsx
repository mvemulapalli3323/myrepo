import { AgGridReact, CustomCellRendererProps } from "ag-grid-react";
import { ColDef, IDetailCellRendererParams } from "ag-grid-community";
import { useCallback, useEffect, useRef, useState } from "react";
import { DataTable, DataType } from "../../api";
import { threeDTheme } from "../../components/SharedComponents/Grids/threeDTheme";

interface DataGridProps<T> {
  tableDef?: DataTable;
  onReady?: (grid: AgGridReact<T> | null) => void;
  onEdit?: (row: T) => void;
  onDelete?: (row: T) => void;
}

export default function DataGrid<T>(props: DataGridProps<T>) {
  const ref = useRef<AgGridReact>(null);
  const [colDefs, setColDefs] = useState<ColDef[]>([]);
  const [detailCellRendererParams, setDetailCellRendererParams] =
    useState<IDetailCellRendererParams>();

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const isRowMaster = (row: any) => !!row.history;

  useEffect(() => {
    if (!props.tableDef) return;

    const columns =
      props.tableDef.fields
        .filter(
          (f) =>
            f.key !== "createdOn" &&
            f.key !== "createdBy" &&
            f.key !== "lastModifiedOn" &&
            f.key !== "lastModifiedBy",
        )
        .map((f) => {
          const col: ColDef = {
            field: f.key,
            headerName: f.label,
            filter: true,
            flex: 1,
            editable: !f.primaryKey,
            cellRenderer: f.primaryKey ? PrimaryKeyCellRenderer : null,
            valueFormatter: (p) => {
              let formattedValue = p.value;

              switch (f.dataType) {
                case DataType.DateTime:
                  formattedValue = p.value?.toLocaleString();
                  break;
              }
              return formattedValue;
            },
          };

          return col;
        }) || [];

    const dcRendererParams = {
      detailGridOptions: {
        pagination: false,
        columnDefs: columns.concat([
          {
            field: "validFrom",
            headerName: "Valid From",
            flex: 1,
            valueFormatter: (p) => p.value.toLocaleString(),
          },
          {
            field: "validTo",
            headerName: "Valid To",
            flex: 1,
            valueFormatter: (p) => p.value.toLocaleString(),
          },
        ]),
      },
      getDetailRowData: (params) => params.successCallback(params.data.history),
    } as IDetailCellRendererParams;

    columns.push({
      field: "actions",
      headerName: "Actions",
      flex: 0.5,
      cellRenderer: ActionsCell,
      cellRendererParams: {
        onEdit: (row: T) => {
          if (props.onEdit) props.onEdit(row);
        },
        onDelete: (row: T) => {
          if (props.onDelete) props.onDelete(row);
        },
      },
    });

    ref.current?.api.setGridOption("rowData", []);
    setColDefs(columns);
    setDetailCellRendererParams(dcRendererParams);
  }, [props.tableDef]);

  useEffect(() => {
    if (props.onReady) props.onReady(ref.current);
  }, []);

  return (
    <div className="flex flex-col w-full h-full">
      <div className="ag-theme-quartz h-full">
        <AgGridReact
          ref={ref}
          pagination={true}
          masterDetail={true}
          detailRowAutoHeight={true}
          isRowMaster={isRowMaster}
          columnDefs={colDefs}
          detailCellRendererParams={detailCellRendererParams}
          theme={threeDTheme}
        />
      </div>
    </div>
  );
}

function PrimaryKeyCellRenderer(props: CustomCellRendererProps) {
  const { node, value } = props;
  const [expanded, setExpanded] = useState(node.expanded);

  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const expandListener = (event: any) => setExpanded(event.node.expanded); // Type is RowEvent but it was throwing errors when building for prod.
    node.addEventListener("expandedChanged", expandListener);
    return () => {
      node.removeEventListener("expandedChanged", expandListener);
    };
  }, []);

  const onClick = useCallback(() => {
    if (!node.master) return;
    node.setExpanded(!node.expanded);
  }, [node]);

  return (
    <div
      className="flex items-center gap-x-2"
      style={{ paddingLeft: `${node.level * 15}px` }}
    >
      <div
        style={{
          cursor: "pointer",
          transform: expanded ? "rotate(90deg)" : "rotate(0deg)",
          display: "inline-block",
        }}
        className={`${!node.master ? "opacity-0 pointer-events-none" : ""}`}
        onClick={onClick}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="size-5"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="m8.25 4.5 7.5 7.5-7.5 7.5"
          />
        </svg>
      </div>
      <span className="truncate">{value}</span>
    </div>
  );
}

interface ActionsCellProps<T> extends CustomCellRendererProps {
  onEdit: (row: T) => void;
  onDelete: (row: T) => void;
}

function ActionsCell<T>(props: ActionsCellProps<T>) {
  const onEdit = () => {
    const row = props.data;
    props.onEdit(row);
  };

  const onDelete = () => {
    const row = props.data;
    props.onDelete(row);
  };

  return (
    <div className="w-full h-full flex items-center justify-center gap-x-2">
      <button className="btn-icon" onClick={onEdit}>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="size-4"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L6.832 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125"
          />
        </svg>
      </button>
      <button className="btn-icon" onClick={onDelete}>
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="size-4"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
          />
        </svg>
      </button>
    </div>
  );
}
