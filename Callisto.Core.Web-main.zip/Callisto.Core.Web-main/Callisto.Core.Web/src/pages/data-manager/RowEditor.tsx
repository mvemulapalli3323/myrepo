/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useRef, useState } from "react";
import { FieldValues, FormState } from "react-hook-form";
import Form, { FormConfiguration, FormFieldConfig } from "../../forms/Form";
import Drawer, { DrawerProps } from "../../components/Drawer";
import api, { DataTable, DataType } from "../../api";

interface RowEditorProps extends DrawerProps {
  tableDef?: DataTable;
  row?: any;
  onChange: (row: any) => void;
}

export default function RowEditor(props: RowEditorProps) {
  const rowValues = useRef<FieldValues>();

  const [isValid, setIsValid] = useState<boolean>(false);
  const [row, setRow] = useState<any>();
  const [formConfig, setFormConfig] = useState<FormConfiguration>();

  const onChange = (c: FieldValues) => {
    rowValues.current = c;
  };
  const onStateChange = (s: FormState<FieldValues>) => setIsValid(s.isValid);

  const close = () => {
    props.onClose();
  };

  const save = () => {
    props.onChange(rowValues.current as any);
    close();
  };

  useEffect(() => {
    if (!props.tableDef) return;
    const d = props.tableDef;
    const fields = d?.fields || [];
    const formConfig: FormConfiguration = {
      fields: fields.map((f) => {
        const formField: FormFieldConfig = {
          key: f.key,
          label: f.label,
          required: f.required,
          disabled: f.primaryKey || f.disabled,
        };

        if (f.dataSourceId) {
          formField.editor = "select";
          formField.optionProvider = async () => {
            const code = f.dataSourceId || "";
            const rows = (await api.table.getRows(code)) || [];

            return rows.map((r) => ({
              text: r[f.dataSourceDisplayColumn!],
              value: r[f.dataSourceValueColumn!],
            }));
          };
        } else {
          switch (f.dataType) {
            case DataType.Boolean:
              formField.editor = "boolean";
              break;
            case DataType.DateTime:
              formField.editor = "date";
              break;
            case DataType.Decimal:
              formField.editor = "number";
              break;
            case DataType.Integer:
              formField.editor = "integer";
              formField.min = f.min;
              formField.max = f.max;
              break;
            case DataType.String:
            default:
              formField.editor = "text";
              formField.minLength = f.minLength;
              formField.maxLength = f.maxLength;
              break;
          }
        }

        return formField;
      }),
    };

    setFormConfig(formConfig);
  }, [props.tableDef]);

  useEffect(() => {
    if (!props.row) return;
    setRow({ ...props.row });
  }, [props.row]);

  return (
    <Drawer isOpen={props.isOpen} onClose={close}>
      <div className="panel-content">
        <div className="panel-body">
          <div className="mb-10">
            <h2>Row Editor</h2>
            <p>Complete the form below.</p>
          </div>
          <Form
            config={formConfig}
            item={row}
            onChange={onChange}
            onStateChange={onStateChange}
          />
        </div>
        <div className="panel-footer">
          <button className="btn-primary-outline" onClick={close}>
            Cancel
          </button>
          <button className="btn-primary" disabled={!isValid} onClick={save}>
            Save
          </button>
        </div>
      </div>
    </Drawer>
  );
}
