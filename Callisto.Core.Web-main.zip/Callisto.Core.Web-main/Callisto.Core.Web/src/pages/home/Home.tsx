import { Link } from "react-router-dom";
import { useMsal } from "../../hooks/useMsal";
import { DotLottieReact } from "@lottiefiles/dotlottie-react";
import { Box, Grid, Typography, Container } from "@mui/material";
import { useRef, useEffect, useState } from "react";

export default function Home() {
  const {
    isAuthReceiptsManager,
    isAuthDataManager,
    isAuthMappingManager,
    isAuthProcessManager,
    username,
  } = useMsal();

  const lottieRef = useRef<any>(null);
  const [isAnimationComplete, setIsAnimationComplete] = useState(false);

  // Handle animation completion and restart after 10 seconds
  useEffect(() => {
    if (isAnimationComplete) {
      const timer = setTimeout(() => {
        if (lottieRef.current) {
          lottieRef.current.play();
          setIsAnimationComplete(false);
        }
      }, 10000); // 10 seconds

      return () => clearTimeout(timer);
    }
  }, [isAnimationComplete]);

  const dotLottieRefCallback = (dotLottie: any) => {
    lottieRef.current = dotLottie;
    if (dotLottie) {
      const handleComplete = () => {
        setIsAnimationComplete(true);
      };
      dotLottie.addEventListener("complete", handleComplete);
    }
  };

  const modules: IApplicationModule[] = [];

  if (isAuthProcessManager) {
    modules.push({
      id: 0,
      background: "bg-teal-blue",
      url: "/tasks",
      title: "Process Manager",
      description: "View and manage system processes",
    });
  }

  if (isAuthMappingManager) {
    modules.push({
      id: 1,
      background: "bg-lime-green",
      url: "/mapping",
      title: "Mapping Manager",
      description: "View and edit data mappings",
    });
  }

  if (isAuthDataManager) {
    modules.push({
      id: 2,
      background: "bg-taupe-gold",
      url: "/data",
      title: "Data Manager",
      description: "View and edit table data",
    });
  }

  if (isAuthReceiptsManager) {
    modules.push({
      id: 3,
      background: "bg-navy-blue",
      url: "/receipts",
      title: "Receipts Manager",
      description: "View and manage receipts",
    });
  }

  return (
    <Box
      data-testid="home-page"
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        height: "100%",
        alignItems: "center",
        pt: 4, // Reduced top padding to move content closer to top
      }}
    >
      <Container maxWidth="md">
        <Grid container direction="column">
          {/* 3D Logo Animation */}
          <Grid>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                mb: 10,
                mt: 2, // Reduced top margin
              }}
            >
              <Box
                sx={{
                  backgroundColor: "#08394B",
                  borderRadius: "12px",
                  width: "400px",
                  height: "150px",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <DotLottieReact
                  src="/animations/3DLogo_transparent.lottie"
                  autoplay
                  loop={false}
                  style={{
                    width: "200px",
                    height: "200px",
                  }}
                  dotLottieRefCallback={dotLottieRefCallback}
                />
              </Box>
            </Box>
          </Grid>

          <Grid>
            <Typography variant="h6" component="h1" sx={{ textAlign: "left" }}>
              {username
                ? `Welcome to Callisto, ${username}`
                : `Getting your info.`}
            </Typography>
          </Grid>

          <Grid>
            <Typography variant="body2" sx={{ mt: 1, textAlign: "left" }}>
              Let's get to work! Here are the modules available to you:
            </Typography>
          </Grid>

          <Grid sx={{ width: "100%" }}>
            <ul
              role="list"
              className="mt-6 grid grid-cols-1 gap-6 border-b border-t border-gray-200 py-6 sm:grid-cols-2"
              data-testid="home-grid"
            >
              {modules.map((m) => (
                <li key={m.id} className="flow-root">
                  <div className="relative -m-2 flex items-center space-x-4 rounded-xl p-2 focus-within:ring-2 focus-within:ring-indigo-500 hover:bg-gray-50">
                    <div
                      className={`flex h-16 w-16 flex-shrink-0 items-center justify-center rounded-lg ${m.background}`}
                    >
                      <svg
                        className="h-6 w-6 text-white"
                        fill="none"
                        viewBox="0 0 24 24"
                        strokeWidth="1.5"
                        stroke="currentColor"
                        aria-hidden="true"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M3.75 5.25h16.5m-16.5 4.5h16.5m-16.5 4.5h16.5m-16.5 4.5h16.5"
                        />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">
                        <Link to={m.url} className="focus:outline-none">
                          <span
                            className="absolute inset-0"
                            aria-hidden="true"
                          ></span>
                          <span>{m.title}</span>
                          <span aria-hidden="true"> &rarr;</span>
                        </Link>
                      </h3>
                      <p className="mt-1 text-sm">{m.description}</p>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </Grid>

          <Grid>
            <Box sx={{ mt: 4, display: "flex" }}>
              <a
                href="https://3degreesinc.com"
                target="_blank"
                className="text-sm font-medium text-goldenrod"
              >
                3Degrees, Inc
                <span aria-hidden="true"> &rarr;</span>
              </a>
            </Box>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
}

interface IApplicationModule {
  id: number;
  background:
    | "bg-taupe-gold"
    | "bg-navy-blue"
    | "bg-teal-blue"
    | "bg-lime-green"
    | "bg-gray-500";
  url: string;
  title: string;
  description: string;
}
