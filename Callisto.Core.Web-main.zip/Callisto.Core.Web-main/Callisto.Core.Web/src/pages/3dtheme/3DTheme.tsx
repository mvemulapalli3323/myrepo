import {
  Box,
  Typography,
  Paper,
  Stack,
  Button,
  TextField,
  Switch,
  FormControlLabel,
  Slider,
  Alert,
  Divider,
  Card,
  CardContent,
  CardActions,
  IconButton,
  Badge,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Autocomplete,
  CircularProgress,
  LinearProgress,
  Checkbox,
  Snackbar,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  AppBar,
  Toolbar,
  Link,
} from "@mui/material";

import Grid from "@mui/material/Grid";

import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import {
  Favorite,
  Notifications,
  Close,
  Lock,
  LockOpen,
} from "@mui/icons-material";
import { useState, useEffect } from "react";
import dayjs from "dayjs";

export default function ThreeDTheme() {
  const [value, setValue] = useState<number>(0);
  const [selectedDate, setSelectedDate] = useState<dayjs.Dayjs | null>(dayjs());
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<string>("");
  const [activeAlerts, setActiveAlerts] = useState<
    Array<{
      id: number;
      type:
        | "success"
        | "info"
        | "warning"
        | "error"
        | "primary"
        | "secondary"
        | "tertiary";
    }>
  >([]);
  const [alertCounter, setAlertCounter] = useState(0);
  const [progress, setProgress] = useState(0);
  const [openChipDialog, setOpenChipDialog] = useState(false);
  const [openPrimaryDialog, setOpenPrimaryDialog] = useState<{
    open: boolean;
    variant: string;
  }>({ open: false, variant: "" });
  const [openSecondaryDialog, setOpenSecondaryDialog] = useState<{
    open: boolean;
    variant: string;
  }>({ open: false, variant: "" });
  const [openInfoDialog, setOpenInfoDialog] = useState<{
    open: boolean;
    variant: string;
  }>({ open: false, variant: "" });
  const [openTertiaryDialog, setOpenTertiaryDialog] = useState<{
    open: boolean;
    variant: string;
  }>({ open: false, variant: "" });
  const [openSuccessDialog, setOpenSuccessDialog] = useState<{
    open: boolean;
    variant: string;
  }>({ open: false, variant: "" });
  const [allDisabled, setAllDisabled] = useState(false);
  const [inputsDisabled, setInputsDisabled] = useState(false);
  const [snackbar, setSnackbar] = useState<{
    open: boolean;
    message: string;
    severity: "success" | "info" | "warning" | "error";
  }>({
    open: false,
    message: "",
    severity: "info",
  });

  const callistoVersion = import.meta.env.VITE_CALLISTO_VERSION;

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prevProgress) =>
        prevProgress >= 100 ? 0 : prevProgress + 1
      );
    }, 50);

    return () => {
      clearInterval(timer);
    };
  }, []);

  const countries = [
    "United States",
    "United Kingdom",
    "Canada",
    "Australia",
    "Germany",
    "France",
    "Japan",
    "China",
    "India",
    "Brazil",
    "Mexico",
    "South Africa",
    "Italy",
    "Spain",
    "Netherlands",
  ];

  const colors = ["Red", "Blue", "Green", "Yellow", "Purple"];

  const addAlert = (
    type:
      | "success"
      | "info"
      | "warning"
      | "error"
      | "primary"
      | "secondary"
      | "tertiary"
  ) => {
    setActiveAlerts((prev) => [...prev, { id: alertCounter, type }]);
    setAlertCounter((prev) => prev + 1);

    // Show snackbar with corresponding severity
    const messages = {
      success: "Success alert added!",
      info: "Info alert added!",
      warning: "Warning alert added!",
      error: "Error alert added!",
      primary: "Primary alert added!",
      secondary: "Secondary alert added!",
      tertiary: "Tertiary alert added!",
    };

    setSnackbar({
      open: true,
      message: messages[type],
      severity:
        type === "primary" || type === "secondary" || type === "tertiary"
          ? "info"
          : type,
    });
  };

  const removeAlert = (id: number) => {
    setActiveAlerts((prev) => prev.filter((alert) => alert.id !== id));
  };

  const clearAlerts = () => {
    setActiveAlerts([]);
  };

  const handleSnackbarClose = () => {
    setSnackbar((prev) => ({ ...prev, open: false }));
  };

  return (
    <Box sx={{ p: 3 }} data-testid="3d-theme-page">
      <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
        <Stack spacing={2}>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              flexWrap: "wrap",
              gap: 2,
            }}
          >
            <Typography variant="h4">MUI 3D Theme Showcase</Typography>
            <Typography
              variant="body2"
              sx={{
                color: "text.secondary",
                backgroundColor: "grey.100",
                padding: "4px 12px",
                borderRadius: 1,
                fontWeight: "medium",
                boxShadow: 1,
                border: `1px solid`,
                borderColor: "grey.300",
              }}
            >
              Callisto Version {callistoVersion}
            </Typography>
          </Box>
          <Typography variant="body1">
            This page demonstrates various MUI components with 3D styles
          </Typography>
          <Typography variant="body2">
            Here is a link to the MUI theme documentation:
            <Link
              variant="subtitle1"
              href="https://mui.com/material-ui/customization/theming/"
              sx={{ color: "secondary.main", ml: 1 }}
            >
              Customizing MUI Components
            </Link>
          </Typography>
        </Stack>
      </Paper>

      <Grid container spacing={3}>
        {/* Inputs Section */}
        <Grid>
          <Paper elevation={3} sx={{ p: 3, width: "100%" }}>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                mb: 2,
              }}
            >
              <Typography variant="h5" gutterBottom sx={{ mb: 0 }}>
                Inputs
              </Typography>
              <Button
                variant="contained"
                onClick={() => setInputsDisabled((prev) => !prev)}
                startIcon={inputsDisabled ? <LockOpen /> : <Lock />}
                sx={{ minWidth: 120 }}
              >
                {inputsDisabled ? "Enable" : "Disable"}
              </Button>
            </Box>
            <Stack spacing={3}>
              <TextField
                label="Text Field"
                variant="outlined"
                fullWidth
                disabled={inputsDisabled}
                color="primary"
              />
              <Autocomplete
                value={selectedCountry}
                onChange={(_, newValue) => {
                  setSelectedCountry(newValue);
                }}
                options={countries}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Select Country"
                    variant="outlined"
                    disabled={inputsDisabled}
                    color="primary"
                  />
                )}
                fullWidth
                disabled={inputsDisabled}
                color="primary"
                sx={{
                  "& .MuiAutocomplete-popupIndicator": {
                    color: "primary.main",
                  },
                  "& .MuiSvgIcon-root": {
                    color: "primary.main",
                  },
                }}
              />
              <FormControl fullWidth disabled={inputsDisabled}>
                <InputLabel id="color-select-label">Select Color</InputLabel>
                <Select
                  labelId="color-select-label"
                  id="color-select"
                  value={selectedColor}
                  label="Select Color"
                  onChange={(e) => setSelectedColor(e.target.value)}
                  color="primary"
                >
                  {colors.map((color) => (
                    <MenuItem key={color} value={color}>
                      {color}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              <LocalizationProvider dateAdapter={AdapterDayjs}>
                <DatePicker
                  label="Date"
                  value={selectedDate}
                  onChange={(newValue) => setSelectedDate(newValue)}
                  disabled={inputsDisabled}
                />
              </LocalizationProvider>
              <FormControlLabel
                control={<Switch defaultChecked disabled={inputsDisabled} />}
                label="Switch"
              />
              <Slider
                defaultValue={30}
                aria-label="Default"
                valueLabelDisplay="auto"
                disabled={inputsDisabled}
              />
              <FormControlLabel
                control={<Checkbox defaultChecked disabled={inputsDisabled} />}
                label="Accept terms and conditions"
              />
            </Stack>
          </Paper>
        </Grid>

        {/* Buttons & Actions Section */}
        <Grid>
          <Paper elevation={3} sx={{ p: 3, width: "100%" }}>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                mb: 2,
              }}
            >
              <Typography variant="h5" gutterBottom sx={{ mb: 0 }}>
                Buttons & Actions
              </Typography>
              <Button
                variant="contained"
                onClick={() => setAllDisabled((prev) => !prev)}
                startIcon={allDisabled ? <LockOpen /> : <Lock />}
                sx={{ minWidth: 120 }}
              >
                {allDisabled ? "Enable" : "Disable"}
              </Button>
            </Box>
            <Stack spacing={2}>
              <Typography variant="subtitle2" color="text.secondary">
                Primary
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                <Button
                  variant="contained"
                  onClick={() =>
                    setOpenPrimaryDialog({ open: true, variant: "Contained" })
                  }
                  disabled={allDisabled}
                >
                  Contained
                </Button>
                <Button
                  variant="outlined"
                  onClick={() =>
                    setOpenPrimaryDialog({ open: true, variant: "Outlined" })
                  }
                  disabled={allDisabled}
                >
                  Outlined
                </Button>
                <Button
                  variant="text"
                  onClick={() =>
                    setOpenPrimaryDialog({ open: true, variant: "Text" })
                  }
                  disabled={allDisabled}
                >
                  Text
                </Button>
                <IconButton color="primary" disabled={allDisabled}>
                  <Badge badgeContent={4} color="error">
                    <Notifications />
                  </Badge>
                </IconButton>
              </Stack>
              <Divider />
              <Typography variant="subtitle2" color="text.secondary">
                Secondary
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                <Button
                  variant="contained"
                  color="secondary"
                  onClick={() =>
                    setOpenSecondaryDialog({ open: true, variant: "Contained" })
                  }
                  disabled={allDisabled}
                >
                  Contained
                </Button>
                <Button
                  variant="outlined"
                  color="secondary"
                  onClick={() =>
                    setOpenSecondaryDialog({ open: true, variant: "Outlined" })
                  }
                  disabled={allDisabled}
                >
                  Outlined
                </Button>
                <Button
                  variant="text"
                  color="secondary"
                  onClick={() =>
                    setOpenSecondaryDialog({ open: true, variant: "Text" })
                  }
                  disabled={allDisabled}
                >
                  Text
                </Button>
                <IconButton color="secondary" disabled={allDisabled}>
                  <Badge badgeContent={4} color="error">
                    <Notifications />
                  </Badge>
                </IconButton>
              </Stack>
              <Divider />
              <Typography variant="subtitle2" color="text.secondary">
                Tertiary
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                <Button
                  variant="contained"
                  color="tertiary"
                  onClick={() =>
                    setOpenTertiaryDialog({ open: true, variant: "Contained" })
                  }
                  disabled={allDisabled}
                >
                  Contained
                </Button>
                <Button
                  variant="outlined"
                  color="tertiary"
                  onClick={() =>
                    setOpenTertiaryDialog({ open: true, variant: "Outlined" })
                  }
                  disabled={allDisabled}
                >
                  Outlined
                </Button>
                <Button
                  variant="text"
                  color="tertiary"
                  onClick={() =>
                    setOpenTertiaryDialog({ open: true, variant: "Text" })
                  }
                  disabled={allDisabled}
                >
                  Text
                </Button>
                <IconButton color="tertiary" disabled={allDisabled}>
                  <Badge badgeContent={4} color="error">
                    <Notifications />
                  </Badge>
                </IconButton>
              </Stack>
              <Divider />
              <Typography variant="subtitle2" color="text.secondary">
                Info
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                <Button
                  variant="contained"
                  color="info"
                  onClick={() =>
                    setOpenInfoDialog({ open: true, variant: "Contained" })
                  }
                  disabled={allDisabled}
                >
                  Contained
                </Button>
                <Button
                  variant="outlined"
                  color="info"
                  onClick={() =>
                    setOpenInfoDialog({ open: true, variant: "Outlined" })
                  }
                  disabled={allDisabled}
                >
                  Outlined
                </Button>
                <Button
                  variant="text"
                  color="info"
                  onClick={() =>
                    setOpenInfoDialog({ open: true, variant: "Text" })
                  }
                  disabled={allDisabled}
                >
                  Text
                </Button>
                <IconButton color="info" disabled={allDisabled}>
                  <Badge badgeContent={4} color="error">
                    <Notifications />
                  </Badge>
                </IconButton>
              </Stack>
              <Divider />
              <Typography variant="subtitle2" color="text.secondary">
                Success
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                <Button
                  variant="contained"
                  color="success"
                  onClick={() =>
                    setOpenSuccessDialog({ open: true, variant: "Contained" })
                  }
                  disabled={allDisabled}
                >
                  Contained
                </Button>
                <Button
                  variant="outlined"
                  color="success"
                  onClick={() =>
                    setOpenSuccessDialog({ open: true, variant: "Outlined" })
                  }
                  disabled={allDisabled}
                >
                  Outlined
                </Button>
                <Button
                  variant="text"
                  color="success"
                  onClick={() =>
                    setOpenSuccessDialog({ open: true, variant: "Text" })
                  }
                  disabled={allDisabled}
                >
                  Text
                </Button>
                <IconButton color="success" disabled={allDisabled}>
                  <Badge badgeContent={4} color="error">
                    <Notifications />
                  </Badge>
                </IconButton>
              </Stack>
            </Stack>
          </Paper>
        </Grid>

        {/* Navigation Section */}
        <Grid>
          <Paper elevation={3} sx={{ p: 0, width: "100%", overflow: "hidden" }}>
            <Typography variant="h5" sx={{ p: 3, pb: 1 }}>
              App Bar Example
            </Typography>
            <AppBar position="static" color="primary" elevation={1}>
              <Toolbar sx={{ minHeight: { xs: 56, sm: 64 } }}>
                <Box
                  sx={{
                    flexGrow: 1,
                    display: "flex",
                    justifyContent: "flex-start",
                    whiteSpace: "nowrap",
                  }}
                >
                  {["Item One", "Item Two", "Item Three"].map((item, index) => (
                    <Button
                      key={item}
                      onClick={() => setValue(index)}
                      sx={{
                        my: 2,
                        mx: 1,
                        color: "white",
                        fontWeight: value === index ? 700 : 600,
                        textTransform: "none",
                        fontSize: "1rem",
                        textDecoration: "none",
                        borderBottom: value === index ? "2.5px solid" : "none",
                        borderColor: value === index ? "action.active" : "none",
                        padding: "8px 8px",
                        borderRadius: "4px",
                        transition: "all 0.2s ease-in-out",
                        "&:hover": {
                          backgroundColor: "rgba(255, 255, 255, 0.1)",
                          color: "white",
                          textDecoration: "none",
                        },
                      }}
                    >
                      <Typography
                        variant="button"
                        component="span"
                        sx={{
                          color: "white",
                          fontWeight: value === index ? 700 : 600,
                        }}
                      >
                        {item}
                      </Typography>
                    </Button>
                  ))}
                </Box>
              </Toolbar>
            </AppBar>
          </Paper>
        </Grid>

        {/* Feedback Section */}
        <Grid>
          <Paper elevation={3} sx={{ p: 3, width: "100%" }}>
            <Typography variant="h5" gutterBottom>
              Feedback
            </Typography>
            <Stack spacing={2}>
              <Stack spacing={2}>
                <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => addAlert("primary")}
                  >
                    Primary Alert
                  </Button>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={() => addAlert("secondary")}
                  >
                    Secondary Alert
                  </Button>
                  <Button
                    variant="contained"
                    color="tertiary"
                    onClick={() => addAlert("tertiary")}
                  >
                    Tertiary Alert
                  </Button>
                  <Button
                    variant="contained"
                    color="success"
                    onClick={() => addAlert("success")}
                  >
                    Success Alert
                  </Button>
                </Stack>
                <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
                  <Button
                    variant="contained"
                    color="info"
                    onClick={() => addAlert("info")}
                  >
                    Info Alert
                  </Button>
                  <Button
                    variant="contained"
                    color="warning"
                    onClick={() => addAlert("warning")}
                  >
                    Warning Alert
                  </Button>
                  <Button
                    variant="contained"
                    color="error"
                    onClick={() => addAlert("error")}
                  >
                    Error Alert
                  </Button>
                  <Button
                    variant="outlined"
                    onClick={clearAlerts}
                    disabled={activeAlerts.length === 0}
                  >
                    Clear All Alerts
                  </Button>
                </Stack>
              </Stack>
              <Stack spacing={1}>
                {activeAlerts.map((alert) => (
                  <Alert
                    key={alert.id}
                    severity={alert.type}
                    variant={
                      alert.type === "primary" ||
                      alert.type === "secondary" ||
                      alert.type === "tertiary"
                        ? "filled"
                        : "standard"
                    }
                    sx={
                      alert.type === "primary"
                        ? {
                            backgroundColor: "primary.light",
                            color: "primary.contrastText",
                          }
                        : alert.type === "secondary"
                          ? {
                              backgroundColor: "secondary.light",
                              color: "secondary.contrastText",
                            }
                          : alert.type === "tertiary"
                            ? {
                                backgroundColor: "tertiary.light",
                                color: "tertiary.contrastText",
                              }
                            : {}
                    }
                    action={
                      <IconButton
                        aria-label="close"
                        color="inherit"
                        size="small"
                        onClick={() => removeAlert(alert.id)}
                      >
                        <Close fontSize="inherit" />
                      </IconButton>
                    }
                  >
                    This is a {alert.type} alert!
                  </Alert>
                ))}
              </Stack>
            </Stack>
          </Paper>
        </Grid>

        {/* Progress Indicators Section */}
        <Grid>
          <Paper elevation={3} sx={{ p: 3, width: "100%" }}>
            <Typography variant="h5" gutterBottom>
              Progress Indicators
            </Typography>
            <Stack spacing={3}>
              <Box
                sx={{
                  position: "relative",
                  display: "inline-flex",
                  justifyContent: "center",
                  width: "100%",
                }}
              >
                <CircularProgress
                  variant="determinate"
                  color="secondary"
                  value={progress}
                  size={100}
                  thickness={4}
                />
                <Box
                  sx={{
                    top: 0,
                    left: 0,
                    bottom: 0,
                    right: 0,
                    position: "absolute",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Typography
                    variant="h5"
                    component="div"
                    color="text.secondary"
                  >
                    {`${Math.round(progress)}%`}
                  </Typography>
                </Box>
              </Box>
              <Box sx={{ width: "100%" }}>
                <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Progress
                    </Typography>
                  </Box>
                  <Box sx={{ minWidth: 35 }}>
                    <Typography variant="body2" color="text.secondary">
                      {`${Math.round(progress)}%`}
                    </Typography>
                  </Box>
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={progress}
                  color="secondary"
                  sx={{ height: 8, borderRadius: 4 }}
                />
              </Box>
            </Stack>
          </Paper>
        </Grid>

        {/* Card Example */}
        <Grid>
          <Paper elevation={3} sx={{ p: 3, width: "100%" }}>
            <Typography variant="h5" gutterBottom>
              Card Example
            </Typography>
            <Card sx={{ maxWidth: 345 }}>
              <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                  Example Card
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  This is an example of a MUI card component with various
                  features.
                </Typography>
              </CardContent>
              <CardActions>
                <Button size="small">Learn More</Button>
                <IconButton size="small" color="primary">
                  <Favorite />
                </IconButton>
              </CardActions>
            </Card>
          </Paper>
        </Grid>

        {/* Typography Section */}
        <Grid>
          <Paper elevation={3} sx={{ p: 3, width: "100%" }}>
            <Typography variant="h5" gutterBottom>
              Typography
            </Typography>
            <Stack spacing={2}>
              <Typography variant="h1">h1. Heading</Typography>
              <Typography variant="h2">h2. Heading</Typography>
              <Typography variant="h3">h3. Heading</Typography>
              <Typography variant="h4">h4. Heading</Typography>
              <Typography variant="h5">h5. Heading</Typography>
              <Typography variant="h6">h6. Heading</Typography>
              <Divider />
              <Typography variant="subtitle1">
                subtitle1. Lorem ipsum dolor sit amet
              </Typography>
              <Typography variant="subtitle2">
                subtitle2. Lorem ipsum dolor sit amet
              </Typography>
              <Divider />
              <Typography variant="body1">
                body1. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Quos blanditiis tenetur unde suscipit, quam beatae rerum
                inventore consectetur, neque doloribus, cupiditate numquam
                dignissimos laborum fugiat deleniti? Eum quasi quidem quibusdam.
              </Typography>
              <Typography variant="body2">
                body2. Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Quos blanditiis tenetur unde suscipit, quam beatae rerum
                inventore consectetur, neque doloribus, cupiditate numquam
                dignissimos laborum fugiat deleniti? Eum quasi quidem quibusdam.
              </Typography>
              <Divider />
              <Typography variant="button" display="block">
                button text
              </Typography>
              <Typography variant="caption" display="block">
                caption text
              </Typography>
              <Typography variant="overline" display="block">
                overline text
              </Typography>
            </Stack>
          </Paper>
        </Grid>
      </Grid>

      <Dialog
        open={openChipDialog}
        onClose={() => setOpenChipDialog(false)}
        aria-labelledby="chip-dialog-title"
        aria-describedby="chip-dialog-description"
      >
        <DialogTitle id="chip-dialog-title">Clickable Chip Dialog</DialogTitle>
        <DialogContent>
          <DialogContentText id="chip-dialog-description">
            This dialog was opened by clicking the "Clickable" chip.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenChipDialog(false)}>Cancel</Button>
          <Button
            onClick={() => setOpenChipDialog(false)}
            variant="contained"
            autoFocus
          >
            Primary
          </Button>
        </DialogActions>
      </Dialog>

      {/* Primary Dialog */}
      <Dialog
        open={openPrimaryDialog.open}
        onClose={() => setOpenPrimaryDialog({ open: false, variant: "" })}
        aria-labelledby="primary-dialog-title"
        aria-describedby="primary-dialog-description"
      >
        <DialogTitle id="primary-dialog-title">
          Primary {openPrimaryDialog.variant} Button
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="primary-dialog-description">
            This dialog was opened by clicking the Primary{" "}
            {openPrimaryDialog.variant} button.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenPrimaryDialog({ open: false, variant: "" })}
          >
            Cancel
          </Button>
          <Button
            onClick={() => setOpenPrimaryDialog({ open: false, variant: "" })}
            variant="contained"
            color="primary"
            autoFocus
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Secondary Dialog */}
      <Dialog
        open={openSecondaryDialog.open}
        onClose={() => setOpenSecondaryDialog({ open: false, variant: "" })}
        aria-labelledby="secondary-dialog-title"
        aria-describedby="secondary-dialog-description"
      >
        <DialogTitle id="secondary-dialog-title">
          Secondary {openSecondaryDialog.variant} Button
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="secondary-dialog-description">
            This dialog was opened by clicking the Secondary{" "}
            {openSecondaryDialog.variant} button.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenSecondaryDialog({ open: false, variant: "" })}
          >
            Cancel
          </Button>
          <Button
            onClick={() => setOpenSecondaryDialog({ open: false, variant: "" })}
            variant="contained"
            color="secondary"
            autoFocus
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Success Dialog */}
      <Dialog
        open={openSuccessDialog.open}
        onClose={() => setOpenSuccessDialog({ open: false, variant: "" })}
        aria-labelledby="success-dialog-title"
        aria-describedby="success-dialog-description"
      >
        <DialogTitle id="success-dialog-title">
          Success {openSuccessDialog.variant} Button
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="success-dialog-description">
            This dialog was opened by clicking the Success{" "}
            {openSuccessDialog.variant} button.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenSuccessDialog({ open: false, variant: "" })}
          >
            Cancel
          </Button>
          <Button
            onClick={() => setOpenSuccessDialog({ open: false, variant: "" })}
            variant="contained"
            color="success"
            autoFocus
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Info Dialog */}
      <Dialog
        open={openInfoDialog.open}
        onClose={() => setOpenInfoDialog({ open: false, variant: "" })}
        aria-labelledby="info-dialog-title"
        aria-describedby="info-dialog-description"
      >
        <DialogTitle id="info-dialog-title">
          Info {openInfoDialog.variant} Button
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="info-dialog-description">
            This dialog was opened by clicking the Info {openInfoDialog.variant}{" "}
            button.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenInfoDialog({ open: false, variant: "" })}
          >
            Cancel
          </Button>
          <Button
            onClick={() => setOpenInfoDialog({ open: false, variant: "" })}
            variant="contained"
            color="info"
            autoFocus
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Tertiary Dialog */}
      <Dialog
        open={openTertiaryDialog.open}
        onClose={() => setOpenTertiaryDialog({ open: false, variant: "" })}
        aria-labelledby="tertiary-dialog-title"
        aria-describedby="tertiary-dialog-description"
      >
        <DialogTitle id="tertiary-dialog-title">
          Tertiary {openTertiaryDialog.variant} Button
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="tertiary-dialog-description">
            This dialog was opened by clicking the Tertiary{" "}
            {openTertiaryDialog.variant} button.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => setOpenTertiaryDialog({ open: false, variant: "" })}
          >
            Cancel
          </Button>
          <Button
            onClick={() => setOpenTertiaryDialog({ open: false, variant: "" })}
            variant="contained"
            color="tertiary"
            autoFocus
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar for Alert Notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={handleSnackbarClose}
          severity={snackbar.severity}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
