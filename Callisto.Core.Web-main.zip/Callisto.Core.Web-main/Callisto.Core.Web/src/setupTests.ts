import "@testing-library/jest-dom";
import { vi } from "vitest";
import React from "react";

const localStorageMock = (() => {
  let store: { [key: string]: string } = {};

  return {
    getItem(key: string) {
      return store[key] || null;
    },
    setItem(key: string, value: string) {
      store[key] = value;
    },
    removeItem(key: string) {
      delete store[key];
    },
    clear() {
      store = {};
    },
  };
})();

Object.defineProperty(window, "localStorage", {
  value: localStorageMock,
});

// Mock IntersectionObserver
Object.defineProperty(window, "IntersectionObserver", {
  writable: true,
  configurable: true,
  value: class IntersectionObserver {
    constructor() {}
    observe() {
      return null;
    }
    unobserve() {
      return null;
    }
    disconnect() {
      return null;
    }
  },
});

// Mock DotLottieReact component
vi.mock("@lottiefiles/dotlottie-react", () => ({
  DotLottieReact: ({
    dotLottieRefCallback,
  }: {
    dotLottieRefCallback: (ref: any) => void;
  }) => {
    // Call the callback with a mock ref
    React.useEffect(() => {
      dotLottieRefCallback({
        addEventListener: vi.fn(),
        play: vi.fn(),
        current: null,
      });
    }, []);

    return React.createElement(
      "div",
      { "data-testid": "lottie-animation" },
      "Mock Lottie Animation"
    );
  },
}));
