import { Routes, Route } from "react-router-dom";
import { MsalProvider } from "@azure/msal-react";
import { IPublicClientApplication } from "@azure/msal-browser";
import { Button, Card, Stack, Typography, Box } from "@mui/material";
import WarningAmberOutlined from "@mui/icons-material/WarningAmberOutlined";
import { ErrorBoundary } from "react-error-boundary";
import Layout from "./Layout";
import NotFound from "./components/NotFound";
import RequireAuth from "./components/RequireAuth";
import Home from "./pages/home/Home";
import ProcessManager from "./pages/process-manager/ProcessManager";
import DataManager from "./pages/data-manager/DataManager";
import MappingManager from "./pages/mapping-manager/MappingManager";
import ReceiptsManager from "./pages/receipts-manager/Inbox";
import Allocations from "./pages/receipts-manager/Allocations";
import Products from "./pages/receipts-manager/Products";
import AuthenticationError from "./components/AuthenticationError";
import NotAuthorized from "./components/NotAuthorized";
import ThreeDTheme from "./pages/3dtheme/3DTheme";
import { useLoader } from "@/Context/LoaderContext";
import { useEffect } from "react";

export default function App({ pca }: { pca: IPublicClientApplication }) {
  // despite following the example https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/samples/msal-react-samples/react-router-sample/src/utils/NavigationClient.js,
  // can't get import to work: revisit this later
  // const navigate = useNavigate();
  // const navigationClient = new MsalNavigationClient(navigate);
  // pca.setNavigationClient(navigationClient);

  const { hideLoader } = useLoader();

  useEffect(() => {
    hideLoader();
  }, []);

  function ApplicationError({ error }: { error: Error }) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", my: 6 }}>
        <Card
          elevation={3}
          sx={{
            padding: 4,
            width: "600px",
            borderRadius: 2,
            bgcolor: "primary.main",
          }}
        >
          <Stack spacing={2} sx={{ alignItems: "center" }}>
            <img
              src="/3DLogo.svg"
              alt="3D Logo"
              style={{ width: "300px", height: "auto" }}
            />
            <Stack direction={"row"} spacing={2} sx={{ alignItems: "center" }}>
              <WarningAmberOutlined
                sx={{
                  fontSize: 50,
                  color: (theme) => theme.palette.error.main,
                }}
              />
              <Typography variant="h6" sx={{ mb: 2, color: "white" }}>
                Unexpected Error!
              </Typography>
            </Stack>
            <Typography variant="body2" sx={{ mb: 2, color: "white" }}>
              {error.message}
            </Typography>
            <Typography variant="body1" sx={{ color: "white" }}>
              Please contact the 3D help desk!
            </Typography>
          </Stack>
        </Card>
      </Box>
    );
  }

  function ReceiptManagerError({ error }: { error: Error }) {
    const { hideLoader } = useLoader();

    useEffect(() => {
      hideLoader();
    }, []);

    return (
      <Box sx={{ display: "flex", justifyContent: "center", my: 6 }}>
        <Card
          elevation={3}
          sx={{
            padding: 4,
            width: "600px",
            borderRadius: 2,
            bgcolor: "primary.main",
          }}
        >
          <Stack spacing={2} sx={{ alignItems: "center" }}>
            <Stack direction={"row"} spacing={3} sx={{ alignItems: "center" }}>
              <WarningAmberOutlined
                sx={{
                  fontSize: 50,
                  color: (theme) => theme.palette.error.main,
                }}
              />
              <Typography variant="h6" sx={{ mb: 2, color: "white" }}>
                Receipts Manager Error!
              </Typography>
            </Stack>
            <Typography variant="body1" sx={{ color: "white" }}>
              {error.message}
            </Typography>
            <Button
              variant="contained"
              color="info"
              onClick={() => window.location.reload()}
            >
              Retry
            </Button>
          </Stack>
        </Card>
      </Box>
    );
  }

  return (
    <MsalProvider instance={pca}>
      <ErrorBoundary FallbackComponent={ApplicationError}>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route
              path="tasks"
              element={
                <RequireAuth authorizedRoles={{ isAuthProcessManager: true }}>
                  <ProcessManager />
                </RequireAuth>
              }
            />
            <Route
              path="mapping"
              element={
                <RequireAuth authorizedRoles={{ isAuthMappingManager: true }}>
                  <MappingManager />
                </RequireAuth>
              }
            />
            <Route
              path="data"
              element={
                <RequireAuth authorizedRoles={{ isAuthDataManager: true }}>
                  <DataManager />
                </RequireAuth>
              }
            />
            <Route path="3dtheme" element={<ThreeDTheme />} />
            <Route
              path="receipts/:id?"
              element={
                <RequireAuth authorizedRoles={{ isAuthReceiptsManager: true }}>
                  <ErrorBoundary FallbackComponent={ReceiptManagerError}>
                    <ReceiptsManager />
                  </ErrorBoundary>
                </RequireAuth>
              }
            />
            <Route
              path="allocations/:id"
              element={
                <RequireAuth authorizedRoles={{ isAuthReceiptsManager: true }}>
                  <ErrorBoundary FallbackComponent={ReceiptManagerError}>
                    <Allocations id={""} />
                  </ErrorBoundary>
                </RequireAuth>
              }
            />
            <Route
              path="products/:id"
              element={
                <RequireAuth authorizedRoles={{ isAuthReceiptsManager: true }}>
                  <ErrorBoundary FallbackComponent={ReceiptManagerError}>
                    <Products />
                  </ErrorBoundary>
                </RequireAuth>
              }
            />
            <Route path="notauthorized" element={<NotAuthorized />} />
            <Route path="*" element={<NotFound />} />
          </Route>
          {/* this route was intended for use when acquireTokenSilent throws an error and we need a page that doesn't implement MSAL*/}
          {/* test/revisit this by changing the VITE_CLIENT_ID to use ar-wc-data-system-dev*/}
          <Route path="authenticationerror" element={<AuthenticationError />} />
        </Routes>
      </ErrorBoundary>
    </MsalProvider>
  );
}
