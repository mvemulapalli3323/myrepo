/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */

export interface IReferenceDataEntity {
  referenceDataEntityId: number;
  referenceDataEntityCode: string;
  referenceDataEntityDescription: string;
  isActive: boolean;
  referenceDataFields: ReferenceDataField[];
}

export enum ReferenceDataFieldDataType {
  Boolean = "BOOLEAN",
  Date = "DATETIME",
  Decimal = "DECIMAL",
  String = "STRING",
}

export interface IReferenceDataField {
  referenceDataFieldId: number;
  referenceDataFieldCode: string;
  referenceDataEntityId: number;
  dataType: ReferenceDataFieldDataType;
  sortOrder: number;
  isRequired: boolean;
  isTimeSeries: boolean;
  isActive: boolean;
  referenceDataFieldValues: ReferenceDataFieldValue[];
}

export interface IReferenceDataFieldValue {
  referenceDataFieldValueId?: number;
  referenceDataFieldId: number;
  referenceDataField?: IReferenceDataField;
  stringValue?: string;
  dateTimeValue?: Date;
  integerValue?: number;
  booleanValue?: boolean;
  decimalValue?: number;
  startDate?: Date;
  endDate?: Date;
  isActive?: boolean;
}

export class ReferenceDataEntity implements IReferenceDataEntity {
  referenceDataEntityId: number = 0;
  referenceDataEntityCode: string = "";
  referenceDataEntityDescription: string = "";
  isActive: boolean = false;
  referenceDataFields: ReferenceDataField[] = [];

  visibleColumns: string[] = [];
  rows: any[] = [];

  constructor(data?: IReferenceDataEntity) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        switch (property) {
          case "referenceDataFields":
            this.referenceDataFields = ReferenceDataField.fromJSCollection(
              data[property],
            );
            this.init();
            break;
          default:
            (<any>this)[property] = (<any>data)[property];
            break;
        }
      }
    }
  }

  addRow(row: any): void {
    // this.referenceDataFields.forEach((f, i) => {
    //     f.referenceDataFieldValues.push(v[i]);
    // });
    this.rows.push(row);
  }

  updateRow(index: number, row: any): void {
    this.rows[index] = row;
  }

  deleteRow(index: number): void {
    this.rows.splice(index, 1);
  }

  private init(): void {
    const rows: any[] = [];
    this.visibleColumns = this.referenceDataFields.map(
      (f) => f.referenceDataFieldCode,
    );
    this.referenceDataFields.forEach((field) => {
      field.referenceDataFieldValues.forEach((v, i) => {
        const existingRow = !!rows[i];
        const row = existingRow ? rows[i] : {};
        let value = null;
        switch (field.dataType) {
          case ReferenceDataFieldDataType.Boolean:
            value = v.booleanValue;
            break;
          case ReferenceDataFieldDataType.Date:
            value = v.dateTimeValue;
            break;
          case ReferenceDataFieldDataType.Decimal:
            value = v.decimalValue;
            break;
          default:
            value = v.stringValue;
            break;
        }
        row[field.referenceDataFieldCode] = value;
        if (!existingRow) rows.push(row);
      });
    });

    this.rows = rows;
  }

  static fromJS(data: any): ReferenceDataEntity {
    data = typeof data === "object" ? data : {};
    return new ReferenceDataEntity(data);
  }

  static fromJSCollection(data: any[]): ReferenceDataEntity[] {
    if (!data) return [];
    return data.map((d) => ReferenceDataEntity.fromJS(d));
  }
}

export class ReferenceDataField implements IReferenceDataField {
  referenceDataFieldId: number = 0;
  referenceDataFieldCode: string = "";
  referenceDataEntityId: number = 0;
  dataType: ReferenceDataFieldDataType = ReferenceDataFieldDataType.Boolean;
  sortOrder: number = 0;
  isRequired: boolean = false;
  isTimeSeries: boolean = false;
  isActive: boolean = false;
  referenceDataFieldValues: ReferenceDataFieldValue[] = [];

  constructor(data?: IReferenceDataField) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        switch (property) {
          case "referenceDataFieldValues":
            this.referenceDataFieldValues =
              ReferenceDataFieldValue.fromJSCollection(data[property]);
            break;
          default:
            (<any>this)[property] = (<any>data)[property];
            break;
        }
      }
    }
  }

  has(index: number): boolean {
    if (index === null) return false;
    const v = this.referenceDataFieldValues[index];
    return !!v;
  }

  static fromJS(data: any): ReferenceDataField {
    data = typeof data === "object" ? data : {};
    return new ReferenceDataField(data);
  }

  static fromJSCollection(data: any[]): ReferenceDataField[] {
    if (!data) return [];
    return data.map((d) => ReferenceDataField.fromJS(d));
  }
}

export class ReferenceDataFieldValue implements IReferenceDataFieldValue {
  referenceDataFieldValueId?: number;
  referenceDataFieldId: number = 0;
  referenceDataField?: ReferenceDataField; //TODO: Discuss with Cody, this should not be here.
  stringValue?: string;
  dateTimeValue?: Date;
  integerValue?: number;
  booleanValue?: boolean;
  decimalValue?: number;
  startDate?: Date;
  endDate?: Date;
  isActive?: boolean;

  constructor(data?: IReferenceDataFieldValue) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        switch (property) {
          case "dateTimeValue":
          case "startDate":
          case "endDate":
            (<any>this)[property] = new Date((<any>data)[property]);
            break;
          default:
            (<any>this)[property] = (<any>data)[property];
            break;
        }
      }
      this.referenceDataField = new ReferenceDataField();
    }
  }

  static fromJS(data: any): ReferenceDataFieldValue {
    data = typeof data === "object" ? data : {};
    return new ReferenceDataFieldValue(data);
  }

  static fromJSCollection(data: any[]): ReferenceDataFieldValue[] {
    if (!data) return [];
    return data.map((d) => ReferenceDataFieldValue.fromJS(d));
  }
}
