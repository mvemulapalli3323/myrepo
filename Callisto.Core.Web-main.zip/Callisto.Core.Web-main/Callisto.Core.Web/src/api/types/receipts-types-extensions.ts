import { TrackingSystemAllocationModel } from "./receipts-types";

export interface TrackingSystemAllocationModelSubRow
  extends TrackingSystemAllocationModel {
  quantityAllocated?: number;
}
