/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */

export interface ISelectOption {
  selectOptionId: number;
  selectOptionValue: any;
  selectOptionDescription: string;
  selectOptionTypeCode: string;
  isActive: boolean;
}

export class SelectOption implements ISelectOption {
  selectOptionId: number = 0;
  selectOptionValue: any;
  selectOptionDescription: string = "";
  selectOptionTypeCode: string = "";
  isActive: boolean = false;

  constructor(data?: ISelectOption) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        (<any>this)[property] = (<any>data)[property];
      }
    }
  }

  static fromJS(data: any): SelectOption {
    data = typeof data === "object" ? data : {};
    return new SelectOption(data);
  }

  static fromJSCollection(data: any[]): SelectOption[] {
    if (!data) return [];
    return data.map((d) => SelectOption.fromJS(d));
  }
}
