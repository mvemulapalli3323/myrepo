/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */

export interface IDataTable {
  id?: number;
  code: string;
  description?: string;
  fields: IDataTableField[];
}

export interface IDataTableField {
  label?: string;
  primaryKey?: boolean;
  key: string;
  required?: boolean;
  disabled?: boolean;
  dataType: DataType;
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  dataSourceId?: string;
  dataSourceValueColumn?: string;
  dataSourceDisplayColumn?: string;
}

export class DataTable implements IDataTable {
  id?: number;
  code: string = "";
  description?: string;
  fields: IDataTableField[] = [];

  get primaryKey(): string {
    if (!this._primaryKey) this._primaryKey = this.camelCase(`${this.code}Id`);

    return this._primaryKey;
  }
  private _primaryKey?: string;

  constructor(data?: IDataTable) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        (<any>this)[property] = (<any>data)[property];
      }
    }
  }

  static fromJS(data: IDataTable): DataTable {
    return new DataTable(data);
  }

  static fromJSCollection(data: IDataTable[]): DataTable[] {
    if (!data) return [];
    return data.map((d) => DataTable.fromJS(d));
  }

  private camelCase(str: string): string {
    return str
      .replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => {
        return index == 0 ? word.toLowerCase() : word.toUpperCase();
      })
      .replace(/\s+/g, "");
  }
}

export class DataTableField implements IDataTableField {
  dataType: DataType = DataType.String;
  primaryKey?: boolean = false;
  key: string = "";
  required?: boolean;
  label?: string;
  readOnly?: boolean = false;

  dataSourceId?: string;
  dataSourceValueColumn?: string;
  dataSourceDisplayColumn?: string;

  min?: number;
  max?: number;

  minLength?: number;
  maxLength?: number;

  constructor(data?: IDataTableField) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        (<any>this)[property] = (<any>data)[property];
      }
    }
  }

  static fromJS(data: IDataTableField): DataTableField {
    return new DataTableField(data);
  }

  static fromJSCollection(data: IDataTableField[]): DataTableField[] {
    if (!data) return [];
    return data.map((d) => DataTableField.fromJS(d));
  }
}

export enum DataType {
  String,
  Decimal,
  Boolean,
  DateTime,
  Integer,
  // ... more types
}
