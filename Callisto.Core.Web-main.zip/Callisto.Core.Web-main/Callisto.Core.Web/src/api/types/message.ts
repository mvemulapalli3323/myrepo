export interface IMessage {
  messageType: MessageType;
  message: string;
  url?: string;
}

export class Message implements IMessage {
  messageType: MessageType = MessageType.Basic;
  message: string = "";
  url?: string;
}

export enum MessageType {
  Basic = "basic",
  FileLinks = "fileLinks",
}
