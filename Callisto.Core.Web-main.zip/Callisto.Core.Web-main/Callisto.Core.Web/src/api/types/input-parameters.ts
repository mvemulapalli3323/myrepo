/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */

export interface IInputParameters {
  groups: IInputParameterGroup[];
}

export interface IInputParameterGroup {
  title?: string;
  parameters: IInputParameter[];
}

export interface IComboOption {
  value: any;
  description: string;
}

export interface IInputParameter {
  key: string;
  label: string;
  dataType: ParameterDataType;
  columns: number;
  options: IComboOption[];
  selectOptionType: string;
  isRequired: boolean;
}

export enum ParameterDataType {
  Boolean,
  DateTime,
  Decimal,
  String,
  Select,
  MultiSelect,
  SelectDynamicOptions,
  MultiSelectDynamicOptions,
  File,
}

export class InputParameters implements IInputParameters {
  groups: InputParameterGroup[];

  constructor(data?: IInputParameters) {
    this.groups = data
      ? data.groups.map((g) => new InputParameterGroup(g))
      : [];
  }
}

export class InputParameterGroup {
  title?: string;
  parameters: InputParameter[] = [];

  constructor(data?: IInputParameterGroup) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        switch (property) {
          case "parameters":
            this.parameters = data.parameters.map((p) => new InputParameter(p));
            break;
          default:
            (<any>this)[property] = (<any>data)[property];
            break;
        }
      }
    }
  }
}

export class ComboOption implements IComboOption {
  value: any;
  description: string;

  constructor(val: any, desc: string) {
    this.value = val;
    this.description = desc;
  }
  //constructor(data?: IComboOption) {
  //  if (data) {
  //    for (var property in data) {
  //      if (!data.hasOwnProperty(property)) continue;
  //      (<any>this)[property] = (<any>data)[property];
  //    }
  //  }
  //}
}

export class InputParameter implements IInputParameter {
  key: string = "";
  label: string = "";
  dataType: ParameterDataType = ParameterDataType.String;
  columns: number = 12;
  options: IComboOption[] = [];
  selectOptionType: string = "";
  isRequired: boolean = true;

  get bootstrapColumnClass(): string {
    return `col-${this.columns}`;
  }

  constructor(data?: IInputParameter) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        (<any>this)[property] = (<any>data)[property];
      }
    }
  }
}
