/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */

export interface IRunSearchCriteria {
  code: string;
  statusCode: string;
  startDate?: Date;
  endDate?: Date;
}

export class RunSearchCriteria implements IRunSearchCriteria {
  code: string = "";
  statusCode: string = "";
  startDate?: Date;
  endDate?: Date;

  get readableStatusCode(): string {
    let result = "";
    switch (this.statusCode) {
      case "Succeeded":
        result = "successful";
        break;
      case "In Progress":
        result = "running";
        break;
      default:
        result = this.statusCode.toLocaleLowerCase();
        break;
    }

    return result;
  }

  constructor(data?: IRunSearchCriteria) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        (<any>this)[property] = (<any>data)[property];
      }
    } else {
      this.setDateRange(5);
    }
  }

  setDateRange(days: number): void {
    this.endDate = new Date();
    this.startDate = new Date();
    this.startDate.setDate(this.endDate.getDate() - days);
    this.startDate.setHours(0, 0, 0, 0);
    this.endDate.setHours(23, 59, 59, 59);
  }
}
