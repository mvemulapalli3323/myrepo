/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */

export interface IGenericMap {
  genericMapId: number;
  value1: string;
  value2: string;
  typeCode: string;
}

export class GenericMap implements IGenericMap {
  genericMapId: number = 0;
  value1: string = "";
  value2: string = "";
  typeCode: string = "";

  constructor(data?: IGenericMap) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        (<any>this)[property] = (<any>data)[property];
      }
    }
  }

  static fromJS(data: any): GenericMap {
    data = typeof data === "object" ? data : {};
    return new GenericMap(data);
  }

  static fromJSCollection(data: any[]): GenericMap[] {
    if (!data) return [];
    return data.map((d) => GenericMap.fromJS(d));
  }
}
