/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */

export interface IStatus {
  statusId: number;
  statusCode: string;
  statusDescription: string;
  isActive: boolean;
}

export class Status implements IStatus {
  statusId: number = 0;
  statusCode: string = "";
  statusDescription: string = "";
  isActive: boolean = false;

  constructor(data?: IStatus) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        (<any>this)[property] = (<any>data)[property];
      }
    }
  }

  static fromJS(data: any): Status {
    data = typeof data === "object" ? data : {};
    return new Status(data);
  }

  static fromJSCollection(data: any[]): Status[] {
    if (!data) return [];
    return data.map((d) => Status.fromJS(d));
  }
}

export enum StatusType {
  NotStarted = "Not Started",
  Succeeded = "Succeeded",
  InProgress = "In Progress",
  Cancelled = "Cancelled",
  Failed = "Failed",
}
