/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */
import { InputParameters } from "./input-parameters";

export interface ITask {
  taskId: number;
  taskCode: string;
  taskDescription: string;
  taskName: string;
  isActive: boolean;
  allowMultiple: boolean;

  parameters: string;
  inputParameters?: InputParameters;
}

export class Task implements ITask {
  taskId: number = 0;
  taskCode: string = "";
  taskDescription: string = "";
  taskName: string = "";
  taskMethod: string = "";
  isActive: boolean = false;
  allowMultiple: boolean = false;

  parameters: string = "";
  inputParameters?: InputParameters;

  constructor(data?: ITask) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        switch (property) {
          case "parameters":
            this.parameters = data.parameters;
            this.inputParameters = new InputParameters(
              JSON.parse(data.parameters),
            );
            break;
          default:
            (<any>this)[property] = (<any>data)[property];
            break;
        }
      }
    }
  }

  static fromJS(data: any): Task {
    data = typeof data === "object" ? data : {};
    return new Task(data);
  }

  static fromJSCollection(data: any[]): Task[] {
    if (!data) return [];
    return data.map((d) => Task.fromJS(d));
  }
}
