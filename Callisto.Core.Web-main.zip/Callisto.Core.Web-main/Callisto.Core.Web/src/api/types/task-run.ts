/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-prototype-builtins */

import { Task } from "./task";
import { Status, StatusType } from "./status";

export interface ITaskRun {
  taskRunId: number;
  createdBy: string;
  createdOn: Date;
  currentStep: number;
  lastModifiedBy: string;
  lastModifiedOn: Date;
  message: string;
  parameters: string;
  parentStep: number;
  parentTaskRunId: number;
  startedOn: Date;
  statusId: number;
  taskId: number;

  parentTaskRun?: ITaskRun;
  status?: Status;
  subtaskRuns?: ITaskRun[];
  task?: Task;
}

export class TaskRun implements ITaskRun {
  taskRunId: number = 0;
  createdBy: string = "";
  createdOn: Date = new Date();
  currentStep: number = 0;
  lastModifiedBy: string = "";
  lastModifiedOn: Date = new Date();
  message: string = "";
  parameters: string = "";
  parentStep: number = 0;
  parentTaskRunId: number = 0;
  startedOn: Date = new Date();
  statusId: number = 0;
  taskId: number = 0;

  parentTaskRun?: TaskRun;
  status?: Status;
  subtaskRuns: TaskRun[] = [];
  task?: Task;

  duration: number = 0;
  isExpanded: boolean = false;

  get name(): string {
    return this.task ? this.task.taskName : "-";
  }

  get getStatus(): string {
    return this.status ? this.status.statusCode : "";
  }

  get notStarted(): boolean {
    return this.status
      ? this.status.statusCode === StatusType.NotStarted
      : false;
  }

  get isRunning(): boolean {
    return this.status
      ? this.status.statusCode === StatusType.InProgress
      : false;
  }

  get hasSubtasks(): boolean {
    return !(!this.subtaskRuns || !this.subtaskRuns.length);
  }

  get isParentTaskRun(): boolean {
    return this.parentTaskRunId == null;
  }

  get getId(): number {
    return this.taskRunId;
  }

  get isCancellable(): boolean {
    return this.getStatus == StatusType.InProgress;
  }

  get hasSucceeded(): boolean {
    return this.getStatus == StatusType.Succeeded;
  }

  get inProgress(): boolean {
    return this.getStatus == StatusType.InProgress;
  }

  get hasFailed(): boolean {
    return this.getStatus == StatusType.Failed;
  }

  get isCancelled(): boolean {
    return this.getStatus == StatusType.Cancelled;
  }

  get startTime(): string {
    return this.getStatus == StatusType.NotStarted
      ? ""
      : this.startedOn?.toLocaleString();
  }

  get endTime(): string {
    let v: string = "";
    switch (this.getStatus) {
      case StatusType.NotStarted:
      case StatusType.InProgress:
        break;
      default:
        v = this.lastModifiedOn?.toLocaleString();
        break;
    }
    return v;
  }

  hasJsonStructure(str: string) {
    try {
      const result = JSON.parse(str);
      const type = Object.prototype.toString.call(result);
      return type === "[object Object]" || type === "[object Array]";
    } catch (err) {
      return false;
    }
  }

  constructor(data?: ITaskRun) {
    if (data) {
      for (const property in data) {
        if (!data.hasOwnProperty(property)) continue;
        switch (property) {
          case "task":
            this.task = Task.fromJS(data[property]);
            break;
          case "status":
            this.status = Status.fromJS(data[property]);
            break;
          case "createdOn":
            this.createdOn = new Date(data[property]);
            break;
          case "startedOn":
            this.startedOn = new Date(data[property]);
            break;
          case "lastModifiedOn":
            this.lastModifiedOn = new Date(data[property]);
            break;
          case "subtaskRuns":
            if (data[property]) {
              this.subtaskRuns = data[property]?.map((o) => TaskRun.fromJS(o));
            }
            break;
          default:
            (<any>this)[property] = (<any>data)[property];
            break;
        }
      }
      if (this.isRunning) this.updateDuration();
      else this.computeDuration();
    }
  }

  private computeDuration(): void {
    let d = 0;
    if (!this.notStarted) {
      if (this.startedOn && this.lastModifiedOn) {
        d = this.lastModifiedOn.getTime() - this.startedOn.getTime();
        d /= 1000;
      }
      d = Math.round(d);
    }
    this.duration = d;
  }

  updateDuration(): void {
    if (!this.isRunning) return;
    let d = 0;
    const now = new Date();
    if (this.startedOn) {
      d = now.getTime() - this.startedOn.getTime();
      d /= 1000;
    }
    d = Math.round(d);
    this.duration = d;
    this.subtaskRuns = this.subtaskRuns.map((r) => {
      r.updateDuration();
      return r;
    });
  }

  static fromJS(data: any): TaskRun {
    data = typeof data === "object" ? data : {};
    return new TaskRun(data);
  }

  static fromJSCollection(data: any[]): TaskRun[] {
    if (!data) return [];
    return data.map((d) => TaskRun.fromJS(d));
  }
}
