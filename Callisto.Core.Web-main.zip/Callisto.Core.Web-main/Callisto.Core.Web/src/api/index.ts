import ApiService from "./api.service";

export * from "./types";
const api = new ApiService();
export default api;
