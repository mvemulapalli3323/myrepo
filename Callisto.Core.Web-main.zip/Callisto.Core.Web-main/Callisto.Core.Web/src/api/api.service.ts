import {
  AzureDataFactoryService,
  AzureService,
  GenericListService,
  GenericMapService,
  ReferenceDataService,
  SelectOptionService,
  TableService,
  TaskRunService,
  TaskService,
} from "./services";

class ApiService {
  readonly azure: AzureService;
  readonly azureDataFactory: AzureDataFactoryService;
  readonly genericList: GenericListService;
  readonly genericMap: GenericMapService;
  readonly referenceData: ReferenceDataService;
  readonly selectOption: SelectOptionService;
  readonly table: TableService;
  readonly task: TaskService;
  readonly taskRun: TaskRunService;
  readonly backendUrl: string = import.meta.env
    .VITE_DATAMANAGEMENT_API_BASE_URL;

  constructor() {
    const baseUrl = `${this.backendUrl}/api`;
    this.azure = new AzureService(baseUrl);
    this.azureDataFactory = new AzureDataFactoryService(baseUrl);
    this.genericList = new GenericListService(baseUrl);
    this.genericMap = new GenericMapService(baseUrl);
    this.referenceData = new ReferenceDataService(baseUrl);
    this.selectOption = new SelectOptionService(baseUrl);
    this.table = new TableService(baseUrl);
    this.task = new TaskService(baseUrl);
    this.taskRun = new TaskRunService(baseUrl);
  }
}

export default ApiService;
