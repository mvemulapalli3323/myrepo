import axios from "axios";

import { BaseService } from "./base.service";

export class AzureService extends BaseService {
  constructor(baseUrl: string) {
    super(baseUrl, "/Azure");
  }

  create(containerName: string, blobPrefix?: string): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      let url = `${this.apiUrl}/blobs/${containerName}`;
      if (blobPrefix) url += `?blobPrefix=${blobPrefix}`;
      axios
        .post<string>(url, {})
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  get(containerName: string): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const url = `${this.apiUrl}/blobs/${containerName}`;
      axios
        .get(url)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }
}
