/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from "axios";

export class TableDataService<T> {
  constructor(private readonly endpointUrl: string) {}

  create(tableCode: string, row: T): Promise<T> {
    const url = `${this.endpointUrl}/${tableCode}`;
    return new Promise<T>((resolve, reject) => {
      axios
        .post<T>(url, row)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  read(tableCode: string): Promise<T> {
    const url = `${this.endpointUrl}/${tableCode}`;
    return new Promise<T>((resolve, reject) => {
      axios
        .get<T>(url)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  update(tableCode: string, row: T) {
    const key: string = this.getKey(tableCode);
    const id: any = (<any>row)[key];
    const url = `${this.endpointUrl}/${tableCode}/${id}`;
    return new Promise<T>((resolve, reject) => {
      axios
        .put<T>(url, row)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  delete(tableCode: string, row: T) {
    const key: string = this.getKey(tableCode);
    const id: any = (<any>row)[key];
    const url = `${this.endpointUrl}/${tableCode}/${id}`;
    return new Promise<boolean>((resolve, reject) => {
      axios
        .delete<boolean>(url)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  history(tableCode: string): Promise<Array<T>> {
    const url = `${this.endpointUrl}/${tableCode}/history`;
    return new Promise<Array<T>>((resolve, reject) => {
      axios
        .get<Array<any>>(url)
        .then((r) =>
          resolve(
            r.data.map((d) => ({
              ...d,
              validFrom: new Date(d.validFrom),
              validTo: new Date(d.validTo),
            })),
          ),
        )
        .catch((e) => reject(e));
    });
  }

  getKey(tableCode: string): string {
    return this.camelCase(`${tableCode}Id`);
  }

  private camelCase(str: string): string {
    return str
      .replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => {
        return index == 0 ? word.toLowerCase() : word.toUpperCase();
      })
      .replace(/\s+/g, "");
  }
}
