import { apiClient } from "./BaseService";
import { TrackingSystemInboxItem } from "@/api/types/receipts-types";
import { TransactionRowData } from "./ServicesInterfaces";

export const getInboxForTransactionNumber = async (
  trackingSystem: string | undefined,
  transactionNumber: string[]
): Promise<TrackingSystemInboxItem[]> => {
  try {
    const response = await apiClient.post(
      "/TrackingSystems/InboxByTransactionNumber",
      transactionNumber,
      {
        params: {
          trackingSystem: trackingSystem,
        },
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};

export const getTransactionsForTrackingSystem = async (
  trackingSystem: string | undefined
): Promise<TransactionRowData[]> => {
  try {
    const response = await apiClient.get("/TrackingSystems/InboxTransactions", {
      params: {
        trackingSystem: trackingSystem,
      },
    });
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
