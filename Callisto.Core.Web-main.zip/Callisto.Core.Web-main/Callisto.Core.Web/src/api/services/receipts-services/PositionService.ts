import { PositionModelPaginatedResult } from "@/api/types/receipts-types";
import { apiClient } from "./BaseService";
import {
  PositionData,
  TrackingSystemRegistrys,
  AutoSearchParams,
} from "./ServicesInterfaces";
export const getCommodity = async () => {
  try {
    const response = await apiClient.get("/References/Commodities", {});
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const getTrackingSystemRegistrys = async (
  params: TrackingSystemRegistrys
) => {
  try {
    const response = await apiClient.get(
      "/References/TrackingSystemRegistries",
      { params }
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const getPositionData = async (
  params: PositionData
): Promise<PositionModelPaginatedResult> => {
  try {
    const response = await apiClient.get<PositionModelPaginatedResult>(
      "/Positions/Search",
      { params }
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const autoSearchPositionData = async (
  params: AutoSearchParams
): Promise<PositionModelPaginatedResult> => {
  try {
    const response = await apiClient.post<PositionModelPaginatedResult>(
      "/Positions/AutoSearch",
      params
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
