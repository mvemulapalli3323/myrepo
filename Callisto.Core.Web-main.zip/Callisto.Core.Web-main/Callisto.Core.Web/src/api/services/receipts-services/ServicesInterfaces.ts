export interface TrackingSystemInfo {
  serviceName: string;
  friendlyName: string;
  trackingSystemId: number;
  supportsApi: boolean;
  commodityId: number;
}

export interface TrackingSystemData {
  trackingSystem?: string;
  uploadId?: string;
}
export interface GetTrackingSystems {
  trackingSystemId?: number;
  registryId?: number;
  name?: string;
}
export interface TrackingSystemRegistrys {
  commodityId?: string | number;
  commodityName?: string;
}
export interface CommodityOption {
  value: string;
  label: string;
}
export interface PositionData {
  PositionSide: string;
  CommodityId: string;
  DeliveryExpectationsMonth: number;
  DeliveryTrackingSystemId?: number | null;
  DeliveryStatus: string;
  PageSize: number;
  PageNumber: number;
  PaginationType: string;
}
export interface SuggestPositions {
  allocationTransactionId: string;
  inboxTransactionIds: string[];
}
export interface UpdateTransactions {
  transactionid?: string;
  positionIds: number[];
  inboxTransactionIds: string[];
  trackingSystem: string;
}
export interface AllocationPositions {
  allocationTransactionId?: string;
  assignedData: {
    positionId: number;
    inboxTransactionid: string;
    quantity: number;
  }[];
}
export interface Allocations {
  allocationTransactionId?: string;
}
export interface GroupInboxTransactions {
  allocationTransactionId?: string;
  selectedGroup: string;
  inboxTransactionIds: string[];
}
export interface UngroupInboxTransactions {
  allocationTransactionId?: string;
  groupNames: string[];
}
export interface CreateReceiptParams {
  allocationTransactionId: string;
  partial: boolean;
}
export interface CreateandRemoveItems {
  allocationTransactionId?: string;
  positionIds: number[];
  inboxTransactionIds: string[];
  trackingSystem: string;
}
export interface RowDataInterfaces {
  facilityID: string;
  facilityName: string;
  fuelType: string;
  eligibility: string;
  vintageDate: string;
  quantity: number;
  quantityAvailable: number;
  transferDate: string;
  from: string;
  to: string;
  transactionID: string;
  [key: string]: string | number | boolean | Date;
}
export interface ColDefsInterfaces {
  field: Extract<keyof RowDataInterfaces, string>;
  filter?: boolean;
  enableRowGroup?: boolean;
  headerName: string;
}
export interface RowInterafaceforValidations {
  errors?: { message: string }[];
  warnings?: { message: string }[];
  allocations?: [];
  positionId?: string;
  facilityID?: string;
}
export interface GridParamsTypes {
  value: number | string | null;
  data: {
    quantity?: number;
    positionId?: string;
    contractProductDescription?: string;
    isGreenE?: boolean;
    contractProduct?: string;
    product?: string;
  };
}
export interface PositionRowData {
  quantity?: number;
  allocations?: AllocationData[];
  positionId?: number;
  contractProductDescription?: string;
  confirmName?: string;
  quantityAvailable?: number;
  rate?: number;
  currencyShortName?: string;
  generationPeriodName?: string;
  startDate?: string;
  endDate?: string;
  trackingSystemName?: string;
  earliestDeliveryDate?: string;
  deliveryDeadline?: string;
  warnings?: string[];
  errors?: string[];
}
/**
 * @deprecated Use ModalComponent with custom content instead.
 * @see {@link ModalComponent}
 *
 * ModalDataType is a legacy interface used with GlobalModalComponent.
 * For new modals, use ModalComponent and pass your content as children. *
 * This interface got very complex and results in a lot of if/else branch statements in globalModal.tsx
 */
export interface ModalDataType {
  type?: "form" | string;
  title?: string;
  content1?: string;
  content2?: string;
  cancelBtn?: string;
  confirmBtn?: string;
  btn?: string;
  checkbox?: boolean;
  form?: {
    type?: "number";
    label?: string;
    number?: number;
    data?: {
      number?: number;
      quantity?: number;
    };
  };
}
export interface ModalFormData {
  type?: string;
  label?: string;
  data?: {
    number?: number;
    quantity?: number;
  };
}
export interface GetDetailRowDataParams {
  data: PositionRowData;
  successCallback: (data: RowDataInterfaces[]) => void;
}
export interface AllocationData {
  assignment: {
    positionId: string | number;
    quantity: number;
  };
  inboxRow: RowDataInterfaces;
}
export interface ProductRowData {
  quantity: number;
  facilityName: string;
  vintage: string;
  generationPeriodStart?: string;
  generationPeriodEnd?: string;
  eligibility: string;
  rate: number;
  currencyShortName: string;
  ucType: string;
  contractProduct: string;
  product?: string;
  productId?: number;
  id?: string;
  isManuallySelected?: boolean;
  suggestedProducts?: [SearchRowData] | SearchRowData[];
}
export interface SearchRowData {
  productId: number;
  productDescription: string;
}
export interface ProductSearchSelectionParams {
  allocationTransactionId: string;
  positionId: string;
  inboxTransactionId: string;
  quantity: number;
  errors: string[];
  warnings: string[];
  id: number;
  vintageId: number;
  productId: number;
  product: string;
  deliveredFlag: boolean;
  deliveryDateUtc: string;
  vintageDate?: string;
  vintageDateEnd?: string;
}
export interface productsearchParams {
  SearchTerm: string;
  PageSize: number;
  PageNumber: number;
  PaginationType: string;
}
export interface bulkParams {
  allocationIds: string[];
  allocationTransactionId: string;
  productId: number;
  product: string;
}
export interface Params {
  id: string;
}
export interface VintageOption {
  generationPeriodId: number;
  generationPeriodName: string;
  vintageId: number;
  vintage: string;
}
export interface VintageOptionData {
  vintageId: number;
  vintage: string;
}
export interface EditFormData {
  vintage?: string;
  vintageId?: number;
  product?: string;
  productId?: number;
  id?: string;
  deliveredFlag?: boolean;
  deliveryDateUtc?: string;
  vintageDate?: string;
  vintageDateEnd?: string;
  documentLocation?: string;
}
export interface EditAppContextType {
  data: {
    vintage: string | number;
    vintageId: number;
    deliveredFlag: boolean;
    deliveryDateUtc?: string | number | null;
  }[];
  setData: (
    data: {
      vintage: string | number;
      vintageId: number;
      deliveredFlag: boolean;
      deliveryDateUtc?: string | number | null;
    }[]
  ) => void;
  setOpen: (open: boolean) => void;
}

export interface DataTag {
  key: string;
  value: number;
}
export interface searchPositionsFormData {
  commodity: string;
  trackingSystem: number | null;
  quantity: number | null;
  deliveryWithinMonths: number;
  rateAltrate: number | null;
  counterParty: string;
  registry: number | null;
}
export interface AutoSearchParams {
  trackingSystem: string;
  inboxTransactionIds: string[];
  paginationOptions: {
    pageSize: number;
    pageNumber: number;
    paginationType: string;
  };
}
export interface TransactionRowData {
  transactionNumber: string;
  transactionStatus: string;
  completionDate: string;
  transactionVolume: number;
  fromAccountNumber: string;
  fromAccountName: string;
  transactionType: string;
  toAccountNumber: string;
  toAccountName: string;
  description: string;
}
