import { apiClient } from "./BaseService";
import {
  Allocations,
  bulkParams,
  productsearchParams,
  ProductSearchSelectionParams,
} from "./ServicesInterfaces";
import { EditFormData, CreateReceiptParams } from "./ServicesInterfaces";
export const getProducts = async (params: Allocations) => {
  try {
    const response = await apiClient.get(
      "Allocations/" + params.allocationTransactionId + "/productSelection",
      {}
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const getSearchProducts = async (params: productsearchParams) => {
  try {
    const response = await apiClient.get("/Products", { params });
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};

export const productSearchSelection = async (
  params: ProductSearchSelectionParams
) => {
  try {
    const reqObj = {
      positionId: params.positionId,
      inboxTransactionId: params.inboxTransactionId,
      quantity: params.quantity,
      errors: params.errors,
      warnings: params.warnings,
      id: params.id,
      vintageId: params.vintageId,
      productId: params.productId,
      product: params.product,
      deliveredFlag: params.deliveredFlag,
      deliveryDateUtc: params.deliveryDateUtc,
      vintageDate: params.vintageDate,
      vintageDateEnd: params.vintageDateEnd,
    };
    const response = await apiClient.post(
      "Allocations/" +
        params.allocationTransactionId +
        "/productSearchSelection",
      reqObj
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const productSearchSelectionBulk = async (params: bulkParams) => {
  try {
    const reqObj = {
      productSelectionModelIds: params.allocationIds,
      productId: params.productId,
      product: params.product,
    };
    const response = await apiClient.patch(
      "Allocations/" + params.allocationTransactionId + "/bulk",
      reqObj
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const getVintages = async () => {
  try {
    const response = await apiClient.get("/References/vintages", {});
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const productSelectionUpdate = async (
  params: EditFormData[],
  allocationId: string
) => {
  try {
    const response = await apiClient.put(
      "Allocations/" + allocationId + "/productSelectionsUpdate",
      params
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const createReceipt = async (params: CreateReceiptParams) => {
  try {
    const response = await apiClient.post(
      "/Allocations/" + params.allocationTransactionId + "/Receipt",
      {},
      { params: { partial: params.partial } }
    );
    return response;
  } catch (error) {
    console.error("Error while creating receipt:", error);
    throw error;
  }
};
