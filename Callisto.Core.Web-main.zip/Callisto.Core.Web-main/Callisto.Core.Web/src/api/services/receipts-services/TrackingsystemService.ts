import { apiClient } from "./BaseService";
import { TrackingSystemData, TrackingSystemInfo } from "./ServicesInterfaces";

export const getAvailableTrackingSystems = async (): Promise<{ data: TrackingSystemInfo[] }> => {
  try {
    const response = await apiClient.get("/TrackingSystems", {});
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const getTrackingSystemData = async (params: TrackingSystemData) => {
  try {
    const response = await apiClient.get("/TrackingSystems/Inbox", { params });
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const getTrackingSystemDataFromUploadedFile = async (
  params: TrackingSystemData,
) => {
  try {
    const response = await apiClient.get("/TrackingSystems/InboxFromUpload", {
      params,
    });
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
