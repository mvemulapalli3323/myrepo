import {
  AllocationSuggestResponse,
  AllocationTransaction,
  AllocationTransactionModel,
  DeAllocation,
} from "@/api/types/receipts-types";
import { apiClient } from "./BaseService";
import {
  AllocationPositions,
  Allocations,
  CreateandRemoveItems,
  GroupInboxTransactions,
  SuggestPositions,
  UngroupInboxTransactions,
  UpdateTransactions,
} from "./ServicesInterfaces";

export const getTransactions = async (params: CreateandRemoveItems) => {
  try {
    const response = await apiClient.post("/Allocations/Create", params);
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const suggestPositions = async (params: SuggestPositions) => {
  try {
    const response = await apiClient.get<AllocationSuggestResponse>(
      "Allocations/" + params.allocationTransactionId + "/suggest",
      { params: { inboxTransactionIds: params.inboxTransactionIds.join(",") } }
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const updateTransactions = async (params: UpdateTransactions) => {
  try {
    const reqObj = {
      positionIds: params.positionIds,
      inboxTransactionIds: params.inboxTransactionIds,
      trackingSystem: params.trackingSystem,
    };
    const response = await apiClient.put(
      "Allocations/" + params.transactionid,
      reqObj
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const assignPositions = async (params: AllocationPositions) => {
  try {
    const response = await apiClient.put(
      "Allocations/" + params.allocationTransactionId + "/assign",
      params.assignedData,
      { params: { test: true } }
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const positionsUndo = async (params: Allocations) => {
  try {
    const response = await apiClient.put(
      "Allocations/" + params.allocationTransactionId + "/reset",
      {}
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const getAllocations = async (
  params: Allocations
): Promise<AllocationTransactionModel> => {
  try {
    const response = await apiClient.get<AllocationTransactionModel>(
      "Allocations/" + params.allocationTransactionId,
      {}
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const removeAllocations = async (params: CreateandRemoveItems) => {
  try {
    const reqObj = {
      positionIds: params.positionIds,
      inboxTransactionIds: params.inboxTransactionIds,
      trackingSystem: params.trackingSystem,
    };
    const response = await apiClient.put(
      "Allocations/" + params.allocationTransactionId + "/RemoveItems",
      reqObj
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const autoAllocate = async (params: Allocations) => {
  try {
    const response = await apiClient.post(
      "Allocations/" + params.allocationTransactionId + "/AutoAllocate",
      {}
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const getAllocationMini = async (
  allocationTransactionId: string
): Promise<AllocationTransaction> => {
  try {
    const response = await apiClient.get<AllocationTransaction>(
      "Allocations/" + allocationTransactionId + "/transaction",
      {}
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const groupInboxTransactions = async (
  params: GroupInboxTransactions
) => {
  const reqObj = {
    inboxTransactionIds: params.inboxTransactionIds,
    selectedGroup: params.selectedGroup,
  };
  try {
    const response = await apiClient.post(
      "Allocations/" + params.allocationTransactionId + "/Group",
      reqObj
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const ungroupInboxTransactions = async (
  params: UngroupInboxTransactions
) => {
  try {
    const response = await apiClient.post(
      "Allocations/" + params.allocationTransactionId + "/UnGroup",
      { groupNames: params.groupNames }
    );
    return response;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
export const deAllocation = async (params: DeAllocation) => {
  try {
    const response = await apiClient.put(
      "Allocations/" + params.allocationTransactionId + "/unassign",
      params.positionIds,
      { params: { test: false } }
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
};
