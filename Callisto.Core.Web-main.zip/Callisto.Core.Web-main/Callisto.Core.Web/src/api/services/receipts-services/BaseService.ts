import axios from "axios";
import { msalInstance } from "../../../hooks/useMsal";
import { InteractionRequiredAuthError } from "@azure/msal-browser";

// import { useNavigate } from 'react-router-dom';

const BASE_URL = import.meta.env.VITE_RECEIPTS_API_BASE_URL;
const RECEIPTS_API_CLIENT_ID = import.meta.env.VITE_RECEIPTS_API_CLIENT_ID;

export const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

apiClient.interceptors.request.use(async (config) => {
  const account = msalInstance.getActiveAccount();
  if (!account) {
    throw Error(
      "No active account! Verify a user has been signed in and setActiveAccount has been called."
    );
  }

  const accessTokenRequest = {
    // this will cause an ugly error where the url in the window changes to #error=invalid_client&error_description=AADSTS650053%3a+The+application+%27ar-callisto-web%27+asked+for+scope+%27Employees.Read.All%27+that+doesn%27t+exist+on+the+resource+%2700000003-0000-0000-c000-000000000000%27.+Contact+the+app+vendor.+Trace+ID%3a+eb8ab862-6dfe-421f-89e8-b965c2e50e00+Correlation+ID%3a+0196b1db-e0ed-7d15-8daa-6323d97a6c70+Timestamp%3a+2025-05-08+21%3a45%3a01Z&state=eyJpZCI6IjAxOTZiMWRiLWUwZWUtNzc4MC1hNTM1LWQ5ZmNkOWZmNjEwZiIsIm1ldGEiOnsiaW50ZXJhY3Rpb25UeXBlIjoicmVkaXJlY3QifX0%3d
    // this is left here for testing the error handling in the interceptor
    //scopes: ["Employees.Read.All"],
    scopes: [`api://${RECEIPTS_API_CLIENT_ID}/Employees.Read.All`],
    account: account,
  };

  // link to error handling: https://learn.microsoft.com/en-us/entra/identity-platform/msal-error-handling-js
  await msalInstance
    .acquireTokenSilent(accessTokenRequest)
    .then((response) => {
      if (!response.accessToken) {
        throw new Error("No access token found in response!");
      }

      config.headers.Authorization = `Bearer ${response.accessToken}`;
    })
    .catch(async (e) => {
      if (e instanceof InteractionRequiredAuthError) {
        msalInstance.acquireTokenRedirect(accessTokenRequest).catch((e) => {
          console.error("Error acquiring token via redirect", e);
          throw e;
        });
      }

      console.log(e);

      //this won't work: we're in a hook
      //const navigate = useNavigate();
      //navigate("/authenticationerror", { replace: true });

      // none of these options plays well with the ErrorBoundaries (for either app or receipts manager levels)
      //return Promise.reject(e); // Reject the promise to propagate the error
      //window.location.href = "/authenticationerror";
      //throw e;
    });

  return config;
});

// possible approach to handle errors globally
// today's focus is on getting ErrorBoundary functional

// apiClient.interceptors.response.use(
//   (response) => response, // Pass through successful responses
//   (error) => {
//     // Handle errors globally
//     if (error.response) {
//       // Server responded with a status other than 2xx
//       console.error("Error Response:", error.response.data);
//     } else if (error.request) {
//       // No response received from server
//       console.error("No Response:", error.request);
//     } else {
//       // Something else caused the error
//       console.error("Error Message:", error.message);
//     }
//     return Promise.reject(error); // Reject the promise to propagate the error
//   }
// );
