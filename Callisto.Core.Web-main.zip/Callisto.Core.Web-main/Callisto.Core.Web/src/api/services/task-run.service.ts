import axios from "axios";

import { RunSearchCriteria } from "../types/run-search-criteria";
import { ITaskRun, TaskRun } from "../types/task-run";
import { BaseService } from "./base.service";

export class TaskRunService extends BaseService {
  constructor(baseUrl: string) {
    super(baseUrl, "/TaskRun");
  }

  getAll(
    taskCode: string = "",
    topOnly: boolean = true,
    inclusive: boolean = true,
  ): Promise<TaskRun[]> {
    const url = this.apiUrl;

    return new Promise<TaskRun[]>((resolve, reject) => {
      axios
        .get<ITaskRun[]>(url, {
          params: {
            taskCode: taskCode,
            topOnly: topOnly,
            inclusive: inclusive,
          },
        })
        .then((r) => resolve(TaskRun.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  get(taskRunId: number, inclusive: boolean = true): Promise<TaskRun> {
    const url = `${this.apiUrl}/${taskRunId}`;
    return new Promise<TaskRun>((resolve, reject) => {
      axios
        .get<ITaskRun>(url, { params: { inclusive: inclusive } })
        .then((r) => resolve(TaskRun.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  delete(taskRunId: number): Promise<boolean> {
    const url = `${this.apiUrl}/${taskRunId}`;
    return new Promise<boolean>((resolve, reject) => {
      axios
        .delete<boolean>(url)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  cancel(taskRunId: number): Promise<TaskRun> {
    const url = `${this.apiUrl}/${taskRunId}/cancel`;
    return new Promise<TaskRun>((resolve, reject) => {
      axios
        .post<ITaskRun>(url, {})
        .then((r) => resolve(TaskRun.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  getChildrenByTaskCode(
    taskRunId: number,
    taskCode: string,
  ): Promise<TaskRun[]> {
    const url = `${this.apiUrl}/${taskRunId}/${taskCode}`;
    return new Promise<TaskRun[]>((resolve, reject) => {
      axios
        .get<ITaskRun[]>(url)
        .then((r) => resolve(TaskRun.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  getFiles(taskRunId: number): Promise<string[]> {
    const url = `${this.apiUrl}/${taskRunId}/files`;
    return new Promise<string[]>((resolve, reject) => {
      axios
        .get(url)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  getFile(taskRunId: number, fileName: string): Promise<Blob> {
    const url = `${this.apiUrl}/${taskRunId}/files/${fileName}`;
    return new Promise<Blob>((resolve, reject) => {
      axios
        .get(url, { responseType: "blob" })
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  rerun(taskRunId: number, async: boolean = true): Promise<TaskRun> {
    let url = `${this.apiUrl}/${taskRunId}/rerun`;
    if (async) url += "/async";
    return new Promise<TaskRun>((resolve, reject) => {
      axios
        .post<ITaskRun>(url, {})
        .then((r) => resolve(TaskRun.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  getByTaskCode(taskCode: string): Promise<TaskRun[]> {
    const url = `${this.apiUrl}/${taskCode}`;
    return new Promise<TaskRun[]>((resolve, reject) => {
      axios
        .get<ITaskRun[]>(url)
        .then((r) => resolve(TaskRun.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  completeByTaskCode(taskCode: string): Promise<TaskRun> {
    const url = `${this.apiUrl}/${taskCode}/complete`;
    return new Promise<TaskRun>((resolve, reject) => {
      axios
        .get<ITaskRun>(url)
        .then((r) => resolve(TaskRun.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  failByTaskCode(taskCode: string, message: string): Promise<TaskRun> {
    const url = `${this.apiUrl}/${taskCode}/fail`;
    return new Promise<TaskRun>((resolve, reject) => {
      axios
        .get<ITaskRun>(url, { params: { message } })
        .then((r) => resolve(TaskRun.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  validate(): Promise<boolean> {
    const url = `${this.apiUrl}/validate`;
    return new Promise<boolean>((resolve, reject) => {
      axios
        .post<boolean>(url, {})
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  getBySearchCritera(criteria: RunSearchCriteria): Promise<TaskRun[]> {
    const url = `${this.apiUrl}/by-criteria`;
    return new Promise<TaskRun[]>((resolve, reject) => {
      axios
        .get<ITaskRun[]>(url, {
          params: {
            taskCode: criteria.code,
            statusCode: criteria.statusCode,
            startDate: criteria.startDate?.toISOString() || "",
            endDate: criteria.endDate?.toISOString() || "",
          },
        })
        .then((r) => resolve(TaskRun.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }
}
