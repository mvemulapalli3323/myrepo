import axios from "axios";

import { BaseService } from "./base.service";
import { ISelectOption, SelectOption } from "../types";

export class SelectOptionService extends BaseService {
  constructor(baseUrl: string) {
    super(baseUrl, "/SelectOption");
  }

  getAll(): Promise<SelectOption[]> {
    const url = `${this.apiUrl}/get-select-options`;
    return new Promise<SelectOption[]>((resolve, reject) => {
      axios
        .get<ISelectOption[]>(url)
        .then((r) => resolve(SelectOption.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  getAllByTypeCode(typeCode: string): Promise<SelectOption[]> {
    const url = `${this.apiUrl}/get-select-options-by-type-code/${typeCode}`;
    return new Promise<SelectOption[]>((resolve, reject) => {
      axios
        .get<ISelectOption[]>(url)
        .then((r) => resolve(SelectOption.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }
}
