export class BaseService {
  protected get apiUrl(): string {
    return `${this.baseUrl}${this.serviceUrl}`;
  }

  constructor(
    private readonly baseUrl: string,
    private readonly serviceUrl: string,
  ) {}
}
