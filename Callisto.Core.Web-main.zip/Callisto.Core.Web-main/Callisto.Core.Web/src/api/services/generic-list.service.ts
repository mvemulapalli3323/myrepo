import axios from "axios";

import { BaseService } from "./base.service";

export class GenericListService extends BaseService {
  constructor(baseUrl: string) {
    super(baseUrl, "/GenericList");
  }

  getLists(): Promise<string[]> {
    const url = `${this.apiUrl}/lists`;
    return new Promise<string[]>((resolve, reject) => {
      axios
        .get<string[]>(url)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  getList(listTypeCode: string): Promise<string[]> {
    const url = `${this.apiUrl}/lists/${listTypeCode}`;
    return new Promise<string[]>((resolve, reject) => {
      axios
        .get<string[]>(url)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }
}
