import axios from "axios";

import { ITask, Task } from "../types/task";
import { ITaskRun, TaskRun } from "../types/task-run";
import { BaseService } from "./base.service";

export class TaskService extends BaseService {
  constructor(baseUrl: string) {
    super(baseUrl, "/Task");
  }

  getAll(uiOnly: boolean = true, topOnly: boolean = false): Promise<Task[]> {
    const url = this.apiUrl;
    return new Promise<Task[]>((resolve, reject) => {
      axios
        .get<ITask[]>(url, { params: { uiOnly: uiOnly, topOnly: topOnly } })
        .then((r) => resolve(Task.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  run(taskRun: TaskRun): Promise<TaskRun> {
    const url = `${this.apiUrl}/${taskRun.taskId}/async`;
    return new Promise<TaskRun>((resolve, reject) => {
      axios
        .post<ITaskRun>(url, taskRun)
        .then((r) => resolve(TaskRun.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  runByCodeAsync(taskCode: string): Promise<TaskRun> {
    const url = `${this.apiUrl}/${taskCode}/async`;
    return new Promise<TaskRun>((resolve, reject) => {
      axios
        .post<ITaskRun>(url, {})
        .then((r) => resolve(TaskRun.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  isRunning(taskCode: string): Promise<boolean> {
    const url = `${this.apiUrl}/${taskCode}/isRunning`;
    return new Promise<boolean>((resolve, reject) => {
      axios
        .post<boolean>(url, {})
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }
}
