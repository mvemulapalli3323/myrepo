import axios from "axios";

import { BaseService } from "./base.service";
import { ITaskRun, TaskRun } from "../types";

export class AzureDataFactoryService extends BaseService {
  constructor(baseUrl: string) {
    super(baseUrl, "/AzureDataFactory");
  }

  get(): Promise<TaskRun> {
    const url = `${this.apiUrl}/test-adf`;
    return new Promise<TaskRun>((reject, resolve) => {
      axios
        .get<ITaskRun>(url)
        .then((r) => resolve(TaskRun.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }
}
