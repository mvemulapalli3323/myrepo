import axios from "axios";

import { BaseService } from "./base.service";
import { GenericMap, IGenericMap } from "../types";

export class GenericMapService extends BaseService {
  constructor(baseUrl: string) {
    super(baseUrl, "/GenericMap");
  }

  getAll(): Promise<GenericMap[]> {
    const url = `${this.apiUrl}/get-generic-maps`;
    return new Promise<GenericMap[]>((resolve, reject) => {
      axios
        .get<IGenericMap[]>(url)
        .then((r) => resolve(GenericMap.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  getAllByTypeCode(typeCode: string): Promise<GenericMap[]> {
    const url = `${this.apiUrl}/get-generic-maps-by-type-code/${typeCode}`;
    return new Promise<GenericMap[]>((resolve, reject) => {
      axios
        .get<IGenericMap[]>(url)
        .then((r) => resolve(GenericMap.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  create(map: GenericMap): Promise<GenericMap> {
    const url = this.apiUrl;
    return new Promise<GenericMap>((resolve, reject) => {
      axios
        .post<IGenericMap>(url, map)
        .then((r) => resolve(GenericMap.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  update(map: GenericMap): Promise<GenericMap> {
    const url = `${this.apiUrl}/${map.genericMapId}`;
    return new Promise<GenericMap>((resolve, reject) => {
      axios
        .put<IGenericMap>(url, map)
        .then((r) => resolve(GenericMap.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  delete(map: GenericMap): Promise<boolean> {
    const url = `${this.apiUrl}/${map.genericMapId}`;
    return new Promise<boolean>((resolve, reject) => {
      axios
        .delete<boolean>(url)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }
}
