export class FileService {
  constructor() {}

  download(fileName: string, data: Blob) {
    fileName = fileName.split("/")[fileName.split("/").length - 1];
    const a = document.createElement("a");
    const objectUrl = URL.createObjectURL(data);
    a.href = objectUrl;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(objectUrl);
  }
}
