import axios from "axios";

import {
  IReferenceDataEntity,
  IReferenceDataFieldValue,
  ReferenceDataEntity,
  ReferenceDataFieldValue,
} from "../types/reference-data-entity";
import { BaseService } from "./base.service";

export class ReferenceDataService extends BaseService {
  constructor(baseUrl: string) {
    super(baseUrl, "/ReferenceData");
  }

  getAll(): Promise<ReferenceDataEntity[]> {
    const url = `${this.apiUrl}/get-reference-data-entities`;
    return new Promise<ReferenceDataEntity[]>((resolve, reject) => {
      axios
        .get<IReferenceDataEntity[]>(url)
        .then((r) => resolve(ReferenceDataEntity.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  addValue(value: ReferenceDataFieldValue): Promise<ReferenceDataFieldValue> {
    const url = `${this.apiUrl}/values`;
    return new Promise<ReferenceDataFieldValue>((resolve, reject) => {
      axios
        .post<IReferenceDataFieldValue>(url, value)
        .then((r) => resolve(ReferenceDataFieldValue.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  updateValue(
    value: ReferenceDataFieldValue,
  ): Promise<ReferenceDataFieldValue> {
    const url = `${this.apiUrl}/values`;
    return new Promise<ReferenceDataFieldValue>((resolve, reject) => {
      axios
        .put<IReferenceDataFieldValue>(url, value)
        .then((r) => resolve(ReferenceDataFieldValue.fromJS(r.data)))
        .catch((e) => reject(e));
    });
  }

  delete(ids: number[]): Promise<boolean> {
    const url = `${this.apiUrl}/delete-values`;
    return new Promise<boolean>((resolve, reject) => {
      axios
        .post<boolean>(url, ids)
        .then((r) => resolve(r.data))
        .catch((e) => reject(e));
    });
  }

  addRow(
    values: ReferenceDataFieldValue[],
  ): Promise<ReferenceDataFieldValue[]> {
    const url = `${this.apiUrl}/rows`;
    return new Promise<ReferenceDataFieldValue[]>((resolve, reject) => {
      axios
        .post<IReferenceDataFieldValue[]>(url, values)
        .then((r) => resolve(ReferenceDataFieldValue.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }

  updateRow(
    values: ReferenceDataFieldValue[],
  ): Promise<ReferenceDataFieldValue[]> {
    const url = `${this.apiUrl}/rows`;
    return new Promise<ReferenceDataFieldValue[]>((resolve, reject) => {
      axios
        .put<IReferenceDataFieldValue[]>(url, values)
        .then((r) => resolve(ReferenceDataFieldValue.fromJSCollection(r.data)))
        .catch((e) => reject(e));
    });
  }
}
