/* eslint-disable @typescript-eslint/no-explicit-any */
import { BaseService } from "./base.service";
import { TableDataService } from "./table-data.service";

export class TableService extends BaseService {
  private readonly _data: TableDataService<any>;

  constructor(baseUrl: string) {
    super(baseUrl, "/Table");
    this._data = new TableDataService<any>(baseUrl);
  }

  getKey(tableCode: string): string {
    return this._data.getKey(tableCode);
  }

  getRows(tableCode: string): Promise<any[]> {
    return this._data.read(tableCode);
  }

  getHistory(tableCode: string): Promise<any[]> {
    return this._data.history(tableCode);
  }

  addRow(tableCode: string, row: any): Promise<any> {
    return this._data.create(tableCode, row);
  }

  updateRow(tableCode: string, row: any): Promise<any> {
    return this._data.update(tableCode, row);
  }

  deleteRow(tableCode: string, row: any): Promise<any> {
    return this._data.delete(tableCode, row);
  }
}
