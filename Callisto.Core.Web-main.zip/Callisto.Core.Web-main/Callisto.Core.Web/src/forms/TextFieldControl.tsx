import { TextField } from "@mui/material";
import { useController } from "react-hook-form";
import { FormControlProps } from "./Form";

export default function TextFieldControl<T>(props: FormControlProps<T>) {
  const { config, control } = props;
  const { field, fieldState } = useController({
    control: control,
    name: config.key,
    disabled: config.disabled,

    rules: {
      required: config.required,
      minLength: config.minLength || 0,
      maxLength: config.maxLength,
    },
  });

  const renderError = () => {
    let jsx = <></>;
    const err = fieldState.error;

    if (!err) return jsx;

    switch (err.type) {
      case "required":
        jsx = <p>{config.error || "This field is required."}</p>;
        break;
      case "maxLength":
        jsx = <p>Max length is {config.maxLength}</p>;
        break;
    }

    return jsx;
  };

  return (
    <>
      <TextField className="w-full" {...field} label={config.label} />
      {renderError()}
    </>
  );
}
