import { FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import { useEffect, useState } from "react";
import { useController } from "react-hook-form";

import { FormControlProps, FormFieldOption } from "./Form";

export default function SelectControl<T>(props: FormControlProps<T>) {
  const { config, control } = props;
  const { field, fieldState } = useController({
    control: control,
    name: config.key,
    disabled: config.disabled,
    rules: { required: config.required },
  });
  const [options, setOptions] = useState<FormFieldOption[]>([]);

  useEffect(() => {
    const loadOptionsAsync = async () => {
      const fn = config.optionProvider;
      if (fn) {
        const opts = await fn();
        setOptions(opts);
      }
    };

    if (config.options) setOptions(config.options);
    else loadOptionsAsync();
  }, [config]);

  return (
    <>
      <FormControl fullWidth>
        <InputLabel>{config.label}</InputLabel>
        <Select className="w-full" {...field} label={config.label}>
          {options.map((o) => (
            <MenuItem key={o.value} value={o.value}>
              {o.text}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      {fieldState.invalid && <p>{config.error || "This field is required."}</p>}
    </>
  );
}
