import { Checkbox, FormControlLabel, FormGroup } from "@mui/material";
import { useController } from "react-hook-form";
import { FormControlProps } from "./Form";

export default function CheckboxControl<T>(props: FormControlProps<T>) {
  const { config, control } = props;
  const { field, fieldState } = useController({
    control: control,
    name: config.key,
    disabled: config.disabled,
    rules: { required: config.required },
  });

  return (
    <>
      <FormGroup>
        <FormControlLabel
          control={<Checkbox {...field} />}
          label={config.label}
        />
      </FormGroup>
      {fieldState.invalid && <p>{config.error || "This field is required."}</p>}
    </>
  );
}
