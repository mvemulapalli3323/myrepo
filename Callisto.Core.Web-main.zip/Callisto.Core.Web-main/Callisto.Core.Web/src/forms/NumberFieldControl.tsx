import { TextField } from "@mui/material";
import { useController } from "react-hook-form";
import { FormControlProps } from "./Form";

export default function NumberFieldControl<T>(props: FormControlProps<T>) {
  const { config, control } = props;
  const { field, fieldState } = useController({
    control: control,
    name: config.key,
    disabled: config.disabled,
    rules: {
      required: config.required,
      pattern: config.editor === "integer" ? new RegExp("d*") : undefined,
      min: config.min,
      max: config.max,
    },
  });

  const renderError = () => {
    let jsx = <></>;
    const err = fieldState.error;

    if (!err) return jsx;

    switch (err.type) {
      case "required":
        jsx = <p>{config.error || "This field is required."}</p>;
        break;
      case "pattern":
        jsx = <p>Only integer values are allowed.</p>;
        break;
      case "min":
        jsx = <p>Minimum allowed value is {config.min}</p>;
        break;
      case "max":
        jsx = <p>Maximum allowed value is {config.max}</p>;
        break;
    }

    return jsx;
  };

  return (
    <>
      <TextField
        className="w-full"
        type="number"
        {...field}
        label={config.label}
        InputProps={{ readOnly: true }}
      />
      {renderError()}
    </>
  );
}
