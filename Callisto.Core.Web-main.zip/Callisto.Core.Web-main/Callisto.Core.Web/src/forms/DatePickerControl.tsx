import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs, { Dayjs } from "dayjs";
import { useController } from "react-hook-form";

import { FormControlProps } from "./Form";

export default function DatePickerControl(props: FormControlProps<Date>) {
  const { config, control } = props;
  const { field, fieldState } = useController({
    control: control,
    name: config.key,
    rules: { required: config.required },
  });

  const dateValue = field.value ? dayjs(field.value) : null;

  const handleChange = (newValue: Dayjs | null) => {
    if (newValue) field.onChange(newValue.toDate());
  };

  return (
    <>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
          {...field}
          className="w-full"
          label={config.label}
          value={dateValue}
          onChange={handleChange}
          readOnly={config.disabled}
        />
      </LocalizationProvider>
      {fieldState.invalid && <p>{config.error || "This field is required."}</p>}
    </>
  );
}
