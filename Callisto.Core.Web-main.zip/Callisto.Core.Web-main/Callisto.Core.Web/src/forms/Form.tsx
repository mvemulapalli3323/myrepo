import { useCallback, useEffect, useState } from "react";
import { Control, FieldValues, FormState, useForm } from "react-hook-form";

import TextFieldControl from "./TextFieldControl";
import SelectControl from "./SelectControl";
import DatePickerControl from "./DatePickerControl";
import CheckboxControl from "./CheckboxControl";
import NumberFieldControl from "./NumberFieldControl";

export interface FormConfiguration {
  fields: Array<FormFieldConfig>;
}

export interface FormFieldOption {
  value: string | number;
  text: string;
}

export interface FormFieldConfig {
  key: string;
  cols?: number;
  label?: string;
  editor?:
    | "text"
    | "number"
    | "integer"
    | "date"
    | "boolean"
    | "select"
    | "multi-select";
  className?: string;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  error?: string;
  options?: Array<FormFieldOption>;
  optionProvider?: () =>
    | Array<FormFieldOption>
    | Promise<Array<FormFieldOption>>;
}

export interface FormControlProps<T> {
  control: Control<FieldValues, T>;
  config: FormFieldConfig;
}

interface FormProps<T> {
  config?: FormConfiguration;
  item?: T;
  onChange: (i: FieldValues) => void;
  onStateChange?: (i: FormState<FieldValues>) => void;
}

export default function Form<T extends FieldValues>(props: FormProps<T>) {
  const { control, reset, watch, formState } = useForm({
    mode: "onChange",
  });
  const [fields, setFields] = useState<FormFieldConfig[]>([]);

  const renderFieldControl = (config: FormFieldConfig) => {
    let jsx = <></>;
    switch (config.editor) {
      case "text":
      default:
        jsx = <TextFieldControl config={config} control={control} />;
        break;
      case "number":
      case "integer":
        jsx = <NumberFieldControl config={config} control={control} />;
        break;
      case "select":
        jsx = <SelectControl config={config} control={control} />;
        break;
      case "date":
        jsx = <DatePickerControl config={config} control={control} />;
        break;
      case "boolean":
        jsx = <CheckboxControl config={config} control={control} />;
        break;
    }
    return jsx;
  };

  const getClassNameForField = useCallback((config: FormFieldConfig) => {
    let cssClass = "";
    switch (config.cols) {
      case 1:
        cssClass = "col-span-1";
        break;
      case 2:
        cssClass = "col-span-2";
        break;
      case 3:
        cssClass = "col-span-3";
        break;
      case 4:
        cssClass = "col-span-4";
        break;
      case 5:
        cssClass = "col-span-5";
        break;
      default:
        cssClass = "col-span-6";
        break;
    }
    return cssClass;
  }, []);

  const onChange = (value: FieldValues) => props.onChange(value);

  useEffect(() => {
    if (!props.config || !props.item) return;
    setFields(props.config.fields);
    reset(props.item);
  }, [props.item, reset]);

  useEffect(() => {
    const { unsubscribe } = watch((value: FieldValues) => onChange(value));
    return () => unsubscribe();
  }, [watch]);

  useEffect(() => {
    const fn = props.onStateChange;
    if (fn) fn(formState);
  }, [formState]);

  return (
    <form className="grid grid-cols-6 gap-4">
      {fields.map((f) => (
        <div key={f.key} className={getClassNameForField(f)}>
          {renderFieldControl(f)}
        </div>
      ))}
    </form>
  );
}
