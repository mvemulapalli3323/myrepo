import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { ModuleRegistry } from "ag-grid-enterprise";
import {
  ClientSideRowModelModule,
  MenuModule,
  ColumnsToolPanelModule,
  FiltersToolPanelModule,
  SetFilterModule,
  ExcelExportModule,
  RowGroupingModule,
  MasterDetailModule,
  ValidationModule,
  RowSelectionModule,
  PaginationModule,
  RowStyleModule,
  CellStyleModule,
  RowApiModule,
  RowDragModule,
  ClipboardModule,
  GridStateModule,
  TooltipModule,
  StatusBarModule,
  CellSelectionModule,
  ColumnAutoSizeModule,
} from "ag-grid-enterprise";

import App from "./App";

import "ag-grid-enterprise/styles/ag-theme-quartz.css";
import "./index.css";

import { LicenseManager } from "ag-grid-enterprise";
import { Provider } from "./Context/AppContext";
LicenseManager.setLicenseKey(import.meta.env.VITE_AG_LICENSE_KEY);

import { ThemeProvider } from "@mui/material/styles";
import { threeDTheme } from "./MuiTheme";

import { AppInsightsContext } from "@microsoft/applicationinsights-react-js";
import { reactPlugin } from "./hooks/appinsights";

// Import MSAL instance from hook
import { msalInstance } from "./hooks/useMsal";
import { LoaderProvider } from "./Context/LoaderContext";

ModuleRegistry.registerModules([
  ClientSideRowModelModule,
  MenuModule,
  ColumnsToolPanelModule,
  FiltersToolPanelModule,
  SetFilterModule,
  ExcelExportModule,
  RowGroupingModule,
  MasterDetailModule,
  ValidationModule,
  RowSelectionModule,
  PaginationModule,
  RowStyleModule,
  CellStyleModule,
  RowApiModule,
  RowDragModule,
  ClipboardModule,
  GridStateModule,
  TooltipModule,
  StatusBarModule,
  CellSelectionModule,
  ColumnAutoSizeModule,
]);

// Function to render the app
function renderApp() {
  const container = document.getElementById("root");
  if (!container) {
    throw new Error("Root element not found");
  }

  const root = createRoot(container);
  root.render(
    <StrictMode>
      <BrowserRouter>
        <Provider>
          <LoaderProvider>
            <ThemeProvider theme={threeDTheme} data-testid="mui-theme">
              <AppInsightsContext.Provider value={reactPlugin}>
                <App pca={msalInstance} />
              </AppInsightsContext.Provider>
            </ThemeProvider>
          </LoaderProvider>
        </Provider>
      </BrowserRouter>
    </StrictMode>
  );

  return root;
}

// Render the app - MSAL React will handle initialization
const root = renderApp();

// Handle hot module replacement
if (import.meta.hot) {
  import.meta.hot.accept("./App", () => {
    // Re-render with the updated App component
    root.render(
      <StrictMode>
        <BrowserRouter>
          <Provider>
            <ThemeProvider theme={threeDTheme} data-testid="mui-theme">
              <AppInsightsContext.Provider value={reactPlugin}>
                <App pca={msalInstance} />
              </AppInsightsContext.Provider>
            </ThemeProvider>
          </Provider>
        </BrowserRouter>
      </StrictMode>
    );
  });
}
