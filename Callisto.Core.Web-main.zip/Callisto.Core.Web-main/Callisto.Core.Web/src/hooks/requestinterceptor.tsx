import React from "react";
import { useMsal, useAccount } from "@azure/msal-react";
import axios from "axios";

interface RequestInterceptorProps {
  children: JSX.Element;
}

const RequestInterceptor: React.FC<RequestInterceptorProps> = ({
  children,
}: RequestInterceptorProps) => {
  const { instance, accounts } = useMsal();
  const account = useAccount(accounts[0]);

  const loginRequest = {
    scopes: ["User.Read"],
  };

  axios.interceptors.request.use(async (config) => {
    // this doesn't appear to fire: why?
    console.log("Request interceptor triggered!");

    if (!account) {
      throw Error("No active account! Verify a user has been signed in.");
    }

    const response = await instance.acquireTokenSilent({
      ...loginRequest,
      account,
    });

    const bearer = `Bearer ${response.accessToken}`;
    config.headers.Authorization = bearer;

    return config;
  });
  return <>{children}</>;
};

export default RequestInterceptor;
