import { useEffect, useState } from "react";
import { useMsal as useMsalReact } from "@azure/msal-react";
import {
  InteractionStatus,
  IPublicClientApplication,
} from "@azure/msal-browser";
import {
  BrowserCacheLocation,
  PublicClientApplication,
  LogLevel,
} from "@azure/msal-browser";

// Create MSAL instance
const ua = window.navigator.userAgent;
const msedge = ua.indexOf("Edge/");
const firefox = ua.indexOf("Firefox");
const isEdge = msedge > 0;
const isFirefox = firefox > 0;

export const msalInstance = new PublicClientApplication({
  auth: {
    clientId: import.meta.env.VITE_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${import.meta.env.VITE_TENANT_ID}/`,
    redirectUri: import.meta.env.VITE_REDIRECT_URI,
  },
  cache: {
    cacheLocation: BrowserCacheLocation.LocalStorage,
    storeAuthStateInCookie: isEdge || isFirefox,
  },
  system: {
    loggerOptions: {
      logLevel: LogLevel.Warning,
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
          default:
            return;
        }
      },
    },
  },
});

// Initialize MSAL - handle redirect promise and set active account
msalInstance
  .initialize()
  .then(() => {
    // Handle redirect promise to process any redirect response
    msalInstance
      .handleRedirectPromise()
      .then((response) => {
        if (response) {
          // Set the active account after successful redirect
          msalInstance.setActiveAccount(response.account);
        } else {
          // Check if there are any accounts in the cache
          const accounts = msalInstance.getAllAccounts();
          if (accounts.length > 0) {
            // Set the first account as active
            msalInstance.setActiveAccount(accounts[0]);
          }
        }
      })
      .catch((error) => {
        console.error("Error handling redirect promise:", error);
      });
  })
  .catch((error) => {
    console.error("Error initializing MSAL:", error);
  });

export interface AuthRoles {
  isAuthReceiptsManager: boolean;
  isAuthDataManager: boolean;
  isAuthMappingManager: boolean;
  isAuthProcessManager: boolean;
  isDev: boolean;
  isAdmin: boolean;
  username: string | null;
}

export interface MsalHookReturn extends AuthRoles {
  instance: IPublicClientApplication;
  inProgress: InteractionStatus;
}

export function useMsal(): MsalHookReturn {
  const { instance, inProgress } = useMsalReact();
  const [username, setUserName] = useState<string | null>(null);
  const [isAuthReceiptsManager, setIsAuthReceiptsManager] = useState(false);
  const [isAuthDataManager, setIsAuthDataManager] = useState(false);
  const [isAuthMappingManager, setIsAuthMappingManager] = useState(false);
  const [isAuthProcessManager, setIsAuthProcessManager] = useState(false);
  const [isDev, setIsDev] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const activeAccount =
    inProgress === InteractionStatus.None ? instance.getActiveAccount() : null;

  useEffect(() => {
    // Handle account processing when interaction is complete
    if (inProgress === InteractionStatus.None) {
      // Process active account if available
      if (activeAccount) {
        const firstName = (activeAccount.name ?? "").split(" ")[0];
        setUserName(firstName);

        if (activeAccount.idTokenClaims && activeAccount.idTokenClaims.roles) {
          const roles = activeAccount.idTokenClaims.roles as string[];

          setIsAuthReceiptsManager(
            roles.includes("callisto.dev") ||
              roles.includes("callisto.tradeops") ||
              roles.includes("callisto.admin")
          );

          setIsAuthDataManager(
            roles.includes("callisto.dev") ||
              roles.includes("callisto.datamanagers") ||
              roles.includes("callisto.admin")
          );

          setIsAuthMappingManager(
            roles.includes("callisto.dev") ||
              roles.includes("callisto.mappingmanagers") ||
              roles.includes("callisto.admin")
          );

          setIsAuthProcessManager(
            roles.includes("callisto.dev") ||
              roles.includes("callisto.processmanagers") ||
              roles.includes("callisto.admin")
          );

          setIsDev(roles.includes("callisto.dev"));
          setIsAdmin(roles.includes("callisto.admin"));
        }
      } else {
        // Clear state when no active account
        setUserName(null);
        setIsAuthReceiptsManager(false);
        setIsAuthDataManager(false);
        setIsAuthMappingManager(false);
        setIsAuthProcessManager(false);
        setIsDev(false);
        setIsAdmin(false);
      }
    }
  }, [activeAccount, instance, inProgress]);

  return {
    instance,
    inProgress,
    isAuthReceiptsManager,
    isAuthDataManager,
    isAuthMappingManager,
    isAuthProcessManager,
    isDev,
    isAdmin,
    username,
  };
}
