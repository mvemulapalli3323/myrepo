import {
  ApplicationInsights,
  ITelemetryItem,
  SeverityLevel,
} from "@microsoft/applicationinsights-web";
import { ReactPlugin } from "@microsoft/applicationinsights-react-js";

const reactPlugin = new ReactPlugin();
const appInsights = new ApplicationInsights({
  config: {
    connectionString: import.meta.env.VITE_APPINSIGHTS_CONNECTION_STRING,
    extensions: [reactPlugin],
    enableAutoRouteTracking: true,
    disableAjaxTracking: false,
    autoTrackPageVisitTime: true,
    enableCorsCorrelation: true,
    enableRequestHeaderTracking: true,
    enableResponseHeaderTracking: true,
  },
});

// breadcrumb: this environment variable is set via .bicep scripts
if (import.meta.env.VITE_APPINSIGHTS_CONNECTION_STRING) {
  appInsights.addTelemetryInitializer((env: ITelemetryItem) => {
    env.tags = env.tags || {};
    env.tags["ai.cloud.role"] =
      `frontend-callisto-${import.meta.env.VITE_CALLISTO_ENVIRONMENT}`;
    //custom props
    env.data = env.data || {};
    env.data["ms-appName"] = "Callisto";
    // env.data["ms-user"] = "<frontend-auth-user>";
    // env.data["ms-userid"] = "<frontend-auth-userid>";
  });

  appInsights.loadAppInsights();
}

export { reactPlugin, appInsights, SeverityLevel };
