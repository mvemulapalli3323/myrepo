/// <reference types="vitest" />
import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

// https://vitest.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, "./src/environments", "");
  const includeTestData = env.VITE_INCLUDE_TEST_DATA === "true";

  return {
    plugins: [react()],
    envDir: "./src/environments",
    resolve: {
      alias: {
        "@": "/src",
        ...(includeTestData && {
          "@testdata": "/TestData",
        }),
      },
    },
    build: {
      chunkSizeWarningLimit: 2000,
      sourcemap: false,
    },
    test: {
      globals: true,
      environment: "jsdom",
      setupFiles: "./src/setupTests.ts",
      coverage: {
        provider: "v8",
        reporter: ["text", "json", "html", "lcov", "json-summary", "cobertura"],
        exclude: [
          "node_modules/",
          "src/setupTests.ts",
          "src/vite-env.d.ts",
          "**/*.d.ts",
          "**/*.config.*",
          "**/coverage/**",
          "**/dist/**",
          "**/.{idea,git,cache,output,temp}/**",
          "**/{karma,rollup,webpack,vite,vitest,jest,ava,babel,nyc,cypress,tsup,build}.config.*",
          "**/*.test.{js,ts,jsx,tsx}",
          "**/*.spec.{js,ts,jsx,tsx}",
        ],
      },
    },
    define: {
      __INCLUDE_TEST_DATA__: includeTestData,
    },
  };
});
