import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (process.env.VITE_INCLUDE_TEST_DATA === 'true') {
  const srcDir = path.join(__dirname, '../TestData/TrackingSystemUploads');
  const destDir = path.join(__dirname, '../public/TestData/TrackingSystemUploads');
  
  // Create destination directory if it doesn't exist
  fs.mkdirSync(destDir, { recursive: true });
  
  // Read all files from source directory
  const files = fs.readdirSync(srcDir);
  
  // Copy each file
  files.forEach(file => {
    const srcFile = path.join(srcDir, file);
    const destFile = path.join(destDir, file);
    
    // Check if it's a file (not a directory)
    if (fs.statSync(srcFile).isFile()) {
      fs.copyFileSync(srcFile, destFile);
      console.log(`Copied: ${file}`);
    }
  });
  
  console.log(`Test data copied to public directory. Total files: ${files.length}`);
} else {
  console.log("VITE_INCLUDE_TEST_DATA is not true; test data not copied.");
}
