# Callisto.Core.Web

UI Components for Project Callisto

### Environments

#### Development

Before running the application, you need to create an environment configuration file. Follow these steps:

1. Navigate to the `src/environments/` directory
2. Create a new file named `env.dev.local`
3. Copy and paste the following content into the file:

```env
VITE_CALLISTO_ENVIRONMENT='development'
VITE_REDIRECT_URI=http://localhost:5173/
VITE_RECEIPTS_API_BASE_URL = https://localhost:7123
VITE_DATAMANAGEMENT_API_BASE_URL = https://localhost:7002
VITE_INCLUDE_TEST_DATA=true
```
#### Dev

- Resource Group: `rg-callisto-dev`
- Key Vault: `keyvault-callisto-dev`
- Url: [https://webapp-callisto-core-dev.azurewebsites.net/](https://webapp-callisto-core-dev.azurewebsites.net/)

#### Test

- Resource Group: `rg-callisto-test`
- Key Vault: `keyvault-callisto-test`
- Url: [https://webapp-callisto-core-test.azurewebsites.net/](https://webapp-callisto-core-test.azurewebsites.net/)

#### Prod

- Resource Group: `rg-callisto-prod`
- Key Vault: `keyvault-callisto-prod`
- Url: [https://webapp-callisto-core-prod.azurewebsites.net/](https://webapp-callisto-core-prod.azurewebsites.net/)

