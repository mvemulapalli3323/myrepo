﻿using Microsoft.Identity.Client;
using System.Diagnostics;
using System.Dynamic;
using System.Net.Http.Headers;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using ThreeDegreesDataSystem.Common.ConnectionParameters;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Connectors.Interface;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Connectors.Azure
{
    public class AzureDataFactoryConnector : IAzureDataFactoryConnector
    {
        private AzureDataFactoryConnectionParameters ConnectionParameters { get; set; }

        public AzureDataFactoryConnector()
        {
            ConnectionParameters = EnvironmentHelper.GetAzureDataFactoryConnectionParameters();
        }
        private async Task<string> GetAccessToken()
        {
            try
            {
                var clientId = ConnectionParameters.ClientId;
                var tenantId = ConnectionParameters.TenantId;
                var clientSecret = ConnectionParameters.ClientSecret;
                var authority = $"https://login.microsoftonline.com/{tenantId}";

                var app = ConfidentialClientApplicationBuilder.Create(clientId)
                    .WithClientSecret(clientSecret)
                    .WithAuthority(new Uri(authority))
                    .Build();

                var result = await app.AcquireTokenForClient(new[] { "https://management.azure.com/.default" }).ExecuteAsync();
                return result.AccessToken;
            }
            catch(Exception ex)
            {
                throw new Exception("Error acquiring token: " + ex.Message);
            }

        }

        public async Task<string> TriggerPipeline(TaskRun taskRun)
        {
            var subscriptionId = ConnectionParameters.SubscriptionId;
            var resourceGroupName = ConnectionParameters.ResourceGroup;
            var factoryName = ConnectionParameters.DataFactoryName;

            var client = new HttpClient();
            var token = await GetAccessToken();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var createUrl = $"https://management.azure.com/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.DataFactory/factories/{factoryName}/pipelines/{taskRun.Task.TaskCode}/createRun?api-version=2018-06-01";

            var inputJsonObj = GenerateParams(taskRun.Parameters, taskRun.TaskRunId);

            if (inputJsonObj != null)
            {
                taskRun.AppendToMessage($"Pipeline parameters:");
                foreach (KeyValuePair<string,dynamic> param in inputJsonObj)
                {
                    taskRun.AppendToMessage($"{param.Key.ToString()} {param.Value.ToString()}");

                }
            }
                
            var jsonParameters = new
            {
                InputJson = JsonSerializer.Serialize(inputJsonObj)
            };

            string jsonContent = System.Text.Json.JsonSerializer.Serialize(jsonParameters);
            var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            var response = await client.PostAsync(createUrl, httpContent);
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();

            return responseBody;
        }

        public async Task<PipelineStatus> GetPipelineStatus(string runId)
        {
            var subscriptionId = ConnectionParameters.SubscriptionId;
            var resourceGroupName = ConnectionParameters.ResourceGroup;
            var factoryName = ConnectionParameters.DataFactoryName;

            var client = new HttpClient();
            var token = await GetAccessToken();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var statusUrl = $"https://management.azure.com/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.DataFactory/factories/{factoryName}/pipelineruns/{runId}?api-version=2018-06-01";

            var response = await client.GetAsync(statusUrl);
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();
            try
            {
                var runInfo = JsonSerializer.Deserialize<PipelineRun>(responseBody);

                return new PipelineStatus(runInfo.Status,runInfo.Message);
            }
            catch (Exception ex)
            {
                return new PipelineStatus(AzureDataFactoryStatus.Failed,"Could not retrieve pipeline status");
            }
            

        }

        private static dynamic GenerateParams(string jsonInput, int taskRunId)
        {
            var expando = new ExpandoObject() as IDictionary<string, object>;

            // Add taskRunId manually
            expando["taskRunId"] = taskRunId;

            // Parse the rest of the JSON
            using var doc = JsonDocument.Parse(jsonInput);
            foreach (var prop in doc.RootElement.EnumerateObject())
            {
                if (prop.NameEquals("taskRunId")) continue; // already added

                expando[prop.Name] = prop.Value.ValueKind switch
                {
                    JsonValueKind.String => prop.Value.GetString(),
                    JsonValueKind.Number => prop.Value.TryGetInt64(out long lVal) ? lVal : prop.Value.GetDouble(),
                    JsonValueKind.True => true,
                    JsonValueKind.False => false,
                    _ => prop.Value.ToString() // fallback for other types
                };
            }

            return (ExpandoObject)expando;
        }
    }
}
