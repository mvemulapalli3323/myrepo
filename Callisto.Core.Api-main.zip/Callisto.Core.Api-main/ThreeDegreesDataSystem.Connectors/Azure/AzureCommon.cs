﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Connectors.Azure
{
    //public enum AzureDownloadTypes
    //{
        
    //}


    public static class AzureDataFactoryStatus
    {
        public const string InProgress = "InProgress";
        public const string Queued = "Queued";
        public const string Succeeded = "Succeeded";
        public const string Failed = "Failed";
        public const string Cancelled = "Cancelled";
        public const string Canceling = "Canceling";
    }
    
    //public static class AzureDataMap
    //{
    //    private static readonly Dictionary<string, AzureDownloadTypes> TaskCodeDownloadTypeMap = new()
    //    {
            
    //    };

    //    public static AzureDownloadTypes GetDownloadType(string taskCode)
    //    {
    //        if (TaskCodeDownloadTypeMap.ContainsKey(taskCode))
    //        {
    //            return TaskCodeDownloadTypeMap[taskCode];
    //        }
    //        throw new Exception($"Task code '{taskCode}' is not mapped to a download type.");
    //    }

    //    private static readonly Dictionary<AzureDownloadTypes, string> DownloadTypeBlobNameMap = new()
    //    {
            
    //    };

    //    public static string GetBlobName(AzureDownloadTypes downloadType)
    //    {
    //        if (DownloadTypeBlobNameMap.ContainsKey(downloadType))
    //        {
    //            return DownloadTypeBlobNameMap[downloadType];
    //        }
    //        throw new Exception($"Download type '{downloadType}' is not mapped to any blob name.");
    //    }

    //    private static readonly Dictionary<AzureDownloadTypes, string> DownloadTypeContainerNameMap = new()
    //    {
            
            
    //    };

    //    public static string GetContainerName(AzureDownloadTypes downloadType)
    //    {
    //        if (DownloadTypeContainerNameMap.ContainsKey(downloadType))
    //        {
    //            return DownloadTypeContainerNameMap[downloadType];
    //        }
    //        throw new Exception($"Download type '{downloadType}' is not mapped to any container name.");
    //    }
    //}
}
