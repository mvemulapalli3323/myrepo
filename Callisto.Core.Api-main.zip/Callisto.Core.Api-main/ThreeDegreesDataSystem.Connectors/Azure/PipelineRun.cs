﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Connectors.Azure
{
    public class PipelineRun
    {
        [JsonPropertyName("durationInMs")]
        public int? DurationInMs { get; set; }
        [JsonPropertyName("invokedBy")] 
        public object? InvokedBy { get; set; }
        [JsonPropertyName("isLatest")]
        public bool IsLatest { get; set; }
        [JsonPropertyName("lastUpdated")]
        public DateTime? LastUpdated { get; set; }
        [JsonPropertyName("message")]
        public string Message { get; set; }
        [JsonPropertyName("parameters")]
        public object? Parameters { get; set; }
        [JsonPropertyName("pipelineName")]
        public string PipelineName { get; set; }
        [JsonPropertyName("runDimensions")]
        public object? RunDimensions { get; set; }
        [JsonPropertyName("runEnd")]
        public DateTime? RunEnd { get; set; }
        [JsonPropertyName("runGroupId")]
        public string RunGroupId { get; set; }
        [JsonPropertyName("runId")]
        public string RunId { get; set; }
        [JsonPropertyName("runStart")]
        public DateTime? RunStart { get; set; }
        [JsonPropertyName("status")]
        public string Status { get; set; }

    }
}
