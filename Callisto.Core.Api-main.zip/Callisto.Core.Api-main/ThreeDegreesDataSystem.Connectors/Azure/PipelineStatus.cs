﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Connectors.Azure
{
    public class PipelineStatus
    {
        public PipelineStatus() { }
        public PipelineStatus(string status, string message) 
        {
            Status = status;
            Message = message;
        }

        public string Status { get; set; }
        public string Message { get; set; }
    }
}
