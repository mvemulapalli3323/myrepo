﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using ThreeDegreesDataSystem.Common.Helper;
using System.Text.Json;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Connectors.Azure
{
    public static class AzureConnector
    {
        public static async Task<BlobItem[]> ListBlobs(string containerName, string blobPrefix="")
        {
            string connectionString = EnvironmentHelper.GetBlobStorageConnectionString();
            BlobServiceClient serviceClient = new(connectionString);
            BlobContainerClient containerClient = serviceClient.GetBlobContainerClient(containerName);
            AsyncPageable<BlobItem> blobItems = containerClient.GetBlobsAsync(prefix:blobPrefix);
            List<BlobItem> blobItemsList = new();
            await foreach (BlobItem blobItem in blobItems)
            {
                blobItemsList.Add(blobItem);
            }
            return blobItemsList.ToArray();
        }

        public static void UploadBlob(Stream blobData, string containerName, string blobName)
        {
            string connectionString = EnvironmentHelper.GetBlobStorageConnectionString();
            BlobServiceClient serviceClient = new (connectionString);
            BlobContainerClient containerClient = serviceClient.GetBlobContainerClient(containerName);
            BlobClient blobClient = containerClient.GetBlobClient(blobName);

            blobData.Seek(0, SeekOrigin.Begin);
            blobClient.Upload(blobData, overwrite: true);
        }

        public static void UploadBlob(Stream blobData, string containerName, string blobPrefix, string blobName)
        {
            UploadBlob(blobData, containerName, $"{blobPrefix}{blobName}");
        }

        public static async Task<string> DownloadBlob(string containerName, string blobName)
        {
            var connectionString = EnvironmentHelper.GetBlobStorageConnectionString();
            var downloadFilePath = $"./Files/{blobName}";

            await DownloadBlob(connectionString, containerName, blobName, downloadFilePath);

            return downloadFilePath;
        }

        public static async Task<string> DownloadBlob(string containerName, string blobPrefix, string fileName)
        {
            string connectionString = EnvironmentHelper.GetBlobStorageConnectionString();
            string downloadDirectoryPath = $"./Files/{blobPrefix}";
            string blobName = $"{blobPrefix}{fileName}";
            string downloadFilePath = $"{downloadDirectoryPath}{fileName}";

            await DownloadBlob(connectionString, containerName, blobName, downloadFilePath);

            return downloadFilePath;
        }

        private static async Task DownloadBlob(string blobStorageConnectionString, string containerName, string blobName, string downloadFilePath)
        {
            var serviceClient = new BlobServiceClient(blobStorageConnectionString);
            var containerClient = serviceClient.GetBlobContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(blobName);
            
            string downloadDirectoryPath = Path.GetDirectoryName(downloadFilePath);
            Directory.CreateDirectory(downloadDirectoryPath);

            await blobClient.DownloadToAsync(downloadFilePath);
        }

        private static async Task<string[]> DownloadBlobs(string blobStorageConnectionString, string containerName, string blobNamePrefix)
        {
            BlobServiceClient serviceClient = new(blobStorageConnectionString);
            BlobContainerClient containerClient = serviceClient.GetBlobContainerClient(containerName);
            Pageable<BlobItem> blobItems = containerClient.GetBlobs(prefix:blobNamePrefix);
            List<string> localFilePaths = new();
            foreach (BlobItem blobItem in blobItems)
            {
                //blobItem.Properties.LastModified
                BlobClient blobClient = containerClient.GetBlobClient(blobItem.Name);
                string localFilePath = $"./Files/{blobItem.Name}";
                await blobClient.DownloadToAsync(localFilePath);
                localFilePaths.Add(localFilePath);
            }
            return localFilePaths.ToArray();
        }

    }
}
