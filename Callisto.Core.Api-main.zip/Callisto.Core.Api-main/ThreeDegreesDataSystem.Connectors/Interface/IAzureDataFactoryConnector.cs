﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Connectors.Interface
{
    public interface IAzureDataFactoryConnector
    {
        Task<string> TriggerPipeline(TaskRun taskRun);
        Task<PipelineStatus> GetPipelineStatus(string runId);
    }
}
