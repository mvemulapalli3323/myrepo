﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Connectors.Interface
{
    public interface INetSuiteConnector
    {
        

        
    }
}
