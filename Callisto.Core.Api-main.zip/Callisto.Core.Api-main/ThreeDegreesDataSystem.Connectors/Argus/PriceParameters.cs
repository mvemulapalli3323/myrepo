﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Connectors.Argus
{
    public class PriceParameters
    {
        public PriceParameters(DateTime startDate, DateTime endDate, int taskRunId)
        {
            StartDate = startDate;
            EndDate = endDate;
            TaskRunId = taskRunId;
        }

        public PriceParameters()
        {
        }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int TaskRunId { get; set; }
    }
}
