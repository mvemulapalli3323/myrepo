﻿using Argus;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.ConnectionParameters;
using ThreeDegreesDataSystem.Common.Converters;
using ThreeDegreesDataSystem.Common.Extensions;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Connectors.Interface;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Connectors.Argus
{
    public class ArgusConnector : IArgusConnector
    {
        private ArgusConnectionParameters ConnectionParameters { get; set; }
        
        public ArgusConnector()
        {
            ConnectionParameters = EnvironmentHelper.GetArgusConnectionParameters();
        }

        public async Task<List<ArgusPriceUpdate>> GetArgusPrices(DateTime startDate, DateTime endDate)
        {
            var client = new ArgusWSSoapClient(ConnectionParameters.Binding, new EndpointAddress(ConnectionParameters.Uri));
            var token = await GetAuthToken(client);

            var priceXml = await client.GetUpdatedPricesInDateTimeRangeAsync(token, startDate.Date,
                        endDate.Date, 0);

            if (priceXml == null)
            {
                return new List<ArgusPriceUpdate>();
            }
            else
            {
                var pricesDataSet = ToDataSet(priceXml, "Prices");
                return GetArgusPriceUpdates(pricesDataSet);
            }
        }

        public async Task<List<ArgusCode>> GetArgusCodes()
        {
            var client = new ArgusWSSoapClient(ConnectionParameters.Binding, new EndpointAddress(ConnectionParameters.Uri));
            var token = await GetAuthToken(client);

            var codeXml = await client.GetTablesAsync(token, new[] { "V_CODE" });
            
            var codesDataSet = ToDataSet(codeXml, "Codes");
            
            return GetArgusCodes(codesDataSet);
        }

        private async Task<string> GetAuthToken(ArgusWSSoapClient client)
        {
           var result = await client.AuthenticateAsync(ConnectionParameters.Id, ConnectionParameters.Password);

           return result.AuthToken;

        }
        
        private List<ArgusPriceUpdate> GetArgusPriceUpdates(DataSet dataSet)
        {
            var prices = new List<ArgusPriceUpdate>();

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                var price = new ArgusPriceUpdate();

                price.RepositoryId = decimal.ToInt32((decimal)row["REPOSITORY_ID"]);
                price.CorrectionId = decimal.ToInt32((decimal)row["CORRECTION_ID"]);
                price.QuoteId = decimal.ToInt32((decimal)row["QUOTE_ID"]);
                price.CodeId = decimal.ToInt32((decimal)row["CODE_ID"]);
                price.TimestampId = decimal.ToInt32((decimal)row["TIMESTAMP_ID"]);
                price.ContinuousForward = decimal.ToInt32((decimal)row["CONTINUOUS_FORWARD"]);
                price.PublicationDate = (DateTime)row["PUBLICATION_DATE"];
                price.Value = Convert.ToDecimal((double)row["VALUE"]);
                price.ForwardPeriod = decimal.ToInt32((decimal)row["FORWARD_PERIOD"]);
                price.ForwardYear = decimal.ToInt32((decimal)row["FORWARD_YEAR"]);
                price.DiffBaseRoll = decimal.ToInt32((decimal)row["DIFFBASEROLL"]);
                price.PriceTypeId = decimal.ToInt32((decimal)row["PRICETYPE_ID"]);
                price.PriceReportItemId = (int)row["PRICEREPORTITEMID"];
                price.ErrorId = row["ERROR_ID"] == DBNull.Value ? null : (int)row["ERROR_ID"];
                price.UnitId1 = decimal.ToInt32((decimal)row["UNIT_ID1"]);
                price.UnitId2 = decimal.ToInt32((decimal)row["UNIT_ID2"]);
                price.DecimalPlaces = (int)row["DECIMALPLACES"];
                price.DiffBaseValue = (string)row["DIFF_BASE_VALUE"];
                price.DiffBaseTimingId = decimal.ToInt32((decimal)row["DIFF_BASE_TIMING_ID"]);
                price.Correction = row["CORRECTION"] == DBNull.Value ? String.Empty : (string)row["CORRECTION"];
                price.DateModified = (DateTime)row["DATE_MODIFIED"];
                
                prices.Add(price);
            }

            return prices;
        }

        private List<ArgusCode> GetArgusCodes(DataSet dataSet)
        {
            var codes = new List<ArgusCode>();

            foreach (DataRow row in dataSet.Tables[0].Rows)
            {
                var code = new ArgusCode();

                code.CodeId = decimal.ToInt32((decimal)row["CODE_ID"]);
                code.Description = (string)row["DESCRIPTION"];
                code.UnitId1 = decimal.ToInt32((decimal)row["UNIT_ID1"]);
                code.UnitId2 = row["UNIT_ID2"] == DBNull.Value ? null : decimal.ToInt32((decimal)row["UNIT_ID2"]);
                code.DelModeId = decimal.ToInt32((decimal)row["DEL_MODE_ID"]);
                code.ActiveYn = (string)row["ACTIVE_YN"];
                code.WefDate = (DateTime)row["WEFDATE"];
                code.EndDate = row["ENDDATE"] == DBNull.Value ? null : (DateTime)row["ENDDATE"];
                code.WeekendIsHolidayYn = (string)row["WEEKENDISHOLIDAY_YN"];
                code.UploadFreqId = decimal.ToInt32((decimal)row["UPLOAD_FREQ_ID"]);
                code.RepTimestamp = (DateTime)row["REP_TIMESTAMP"];
                code.Specification = row["SPECIFICATION"] == DBNull.Value ? String.Empty : (string)row["SPECIFICATION"];
                //code.TaskRunId = decimal.ToInt32((decimal)row["TASK_RUN_ID"]);

                codes.Add(code);
            }

            return codes;
        }

        private static DataSet ToDataSet(ArrayOfXElement arrayOfXElement, string dataSetName)
        {
            var strSchema = arrayOfXElement.Nodes[0].ToString();
            var strData = arrayOfXElement.Nodes[1].ToString();
            var strXml = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n\t<DataSet>";
            strXml += strSchema + strData;
            strXml += "</DataSet>";

            DataSet ds = new DataSet(dataSetName);
            ds.ReadXml(new MemoryStream(Encoding.UTF8.GetBytes(strXml)));

            return ds;
        }
    }
}
