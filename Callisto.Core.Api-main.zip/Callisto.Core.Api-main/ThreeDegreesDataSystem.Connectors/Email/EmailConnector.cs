﻿using Argus;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.ConnectionParameters;
using ThreeDegreesDataSystem.Common.Converters;
using ThreeDegreesDataSystem.Common.Extensions;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Connectors.Interface;
using ThreeDegreesDataSystem.Models.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Connectors.Email
{
    public class EmailConnector : IEmailConnector
    {
        private EmailConnectionParameters ConnectionParameters { get; set; }
        protected readonly CentralOpsDbContext CentralOpsDbContext;
        private readonly ILogger<EmailConnector> _logger;

        public EmailConnector(CentralOpsDbContext centralOpsDbContext, ILogger<EmailConnector> logger)
        {
            CentralOpsDbContext = centralOpsDbContext;
            ConnectionParameters = EnvironmentHelper.GetEmailConnectionParameters();
            _logger = logger;
        }

        public async Task<bool> SendEmailAlert(string message, string subject, string taskCode)
        {
            try
            {
                if (string.IsNullOrEmpty(ConnectionParameters.EnvironmentName)
                    || string.IsNullOrEmpty(ConnectionParameters.AlertEmail)
                    || string.IsNullOrEmpty(ConnectionParameters.AlertEmailPassword))
                {
                    throw new ConfigurationErrorsException("Alert email configuration is invalid");
                }

                var environment = ConnectionParameters.EnvironmentName;
                var toRecipients = await GetEmailRecipients(taskCode, environment);
                var fromAddress = ConnectionParameters.AlertEmail!;
                var emailPassword = ConnectionParameters.AlertEmailPassword!;

                using var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential(fromAddress, emailPassword),
                    EnableSsl = true,
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(fromAddress),
                    Subject = $"{environment.ToUpper()} ENV - {subject}",
                    Body = message,
                };

                var separators = new[] { ';', ',' };
                foreach (var addr in toRecipients
                                     .Split(separators, StringSplitOptions.RemoveEmptyEntries)
                                     .Select(a => a.Trim()))
                {
                    mailMessage.To.Add(new MailAddress(addr));
                }

                smtpClient.Send(mailMessage);
                return true;
            }
            catch (Exception)
            {
                _logger.LogError($"Error sending email alert: {message}");
                throw;
            }
        }

        public async Task<string> GetEmailRecipients(string taskCode, string environment)
        {
            var taskMap = await CentralOpsDbContext.GenericMaps
                .AsNoTracking()
                .Where(m => m.TypeCode == "EmailNotification" && m.Value1 == taskCode)
                .FirstOrDefaultAsync();

            var environmentMap = await CentralOpsDbContext.GenericMaps
                .AsNoTracking()
                .Where(m => m.TypeCode == "EmailNotification" && m.Value1 == $"{environment}Environment")
                .FirstOrDefaultAsync();

            if (taskMap != null) return taskMap.Value2!;
            if (environmentMap != null) return environmentMap.Value2!;

            throw new Exception(
              $"No email recipient found for task code '{taskCode}' or environment '{environment}'");
        }
    }
}
