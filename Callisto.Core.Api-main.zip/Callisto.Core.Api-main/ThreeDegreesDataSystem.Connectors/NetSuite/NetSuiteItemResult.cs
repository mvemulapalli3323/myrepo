﻿using NetSuiteService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Connectors.NetSuite
{
    public class NetSuiteItemResult
    {
        public NetSuiteItemResult()
        {
            Items = new List<InventoryItem>();
        }

        public string Message { get; set; }
        public List<InventoryItem> Items { get; set; }
    }
}
