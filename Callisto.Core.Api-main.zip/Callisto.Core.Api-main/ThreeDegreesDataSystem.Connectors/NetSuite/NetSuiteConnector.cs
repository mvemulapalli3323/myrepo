﻿using Argus;
using NetSuiteService;
using Newtonsoft.Json.Linq;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.ConnectionParameters;
using ThreeDegreesDataSystem.Common.Converters;
using ThreeDegreesDataSystem.Common.Extensions;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Connectors.Interface;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Connectors.NetSuite
{
    public class NetSuiteConnector : INetSuiteConnector
    {
        private NetSuiteConnectionParameters ConnectionParameters { get; set; }
        private NetSuitePortTypeClient Service { get; set; }
        private TokenPassport Passport { get; set; }
        private Dictionary<string, string> RecordIdMap { get; set; }

        //private readonly IGenericMapService GenericMapRepository;

        public NetSuiteConnector()
        {
            ConnectionParameters = EnvironmentHelper.GetNetSuiteConnectionParameters();
            Service = CreateClient();
            //RecordIdMap = _gene
        }

        public async Task<string> TestNetSuiteConnection()
        {
            try
            {
                Passport = CreateTokenPassport();
                // Call getServerTimeAsync to verify connection
                getServerTimeResponse response = await Service.getServerTimeAsync(Passport, null, null);

                return $"NetSuite Server Time: {response.getServerTimeResult.serverTime}";
                
            }
            catch (Exception ex)
            {
               return $"Error connecting to NetSuite:{ ex.Message}";
            }
        }

        public async Task<NetSuiteItemResult> AddOrUpdateItem(MdmProduct product)
        {
            //first check if the productcode exists in NetSuite
            NetSuiteItemResult matchByProductCode = await GetItems(product.MdmProductCode);
            NetSuiteItemResult matchByNetSuiteId = new NetSuiteItemResult();
            //if multiple items are found, return error
            if (matchByProductCode.Items.Count > 1)
            {
                return new NetSuiteItemResult { Message = $"Error adding or updating InventoryItem. Multiple items found for {product.MdmProductCode}" };
            }
            // check for null
            if (product.NetSuiteId != null)
            {
                matchByNetSuiteId = await GetItem(int.Parse(product.NetSuiteId));
            }
            
            //if match by netsuite id is found and mdm product code is not, update the item
            if (matchByNetSuiteId.Items.Count == 1 && matchByProductCode.Items.Count == 0)
            {
                return await UpdateItem(product.NetSuiteId, product.MdmProductName, product.MdmProductCode, product.ProductStatus);
            }

            //if match by netsuite id is found and mdm product code is also, update the item
            if (matchByNetSuiteId.Items.Count == 1 && matchByProductCode.Items.Count == 1)
            {
                return await UpdateItem(product.NetSuiteId, product.MdmProductName, product.MdmProductCode, product.ProductStatus);
            }

            //if match by netsuite id is not found and mdm product code is ,update the mdm record to have the correct netsuite id
            if (matchByNetSuiteId.Items.Count == 0 && matchByProductCode.Items.Count == 1)
            {
                var result = new NetSuiteItemResult();
                var foundItem = matchByProductCode.Items.FirstOrDefault();
                //if display name or isinactive is different, update the display name / inactive status
                if (foundItem.displayName != product.MdmProductName || foundItem.isInactive != CheckForInactive(product.ProductStatus))
                {
                    result = await UpdateItem(matchByProductCode.Items.FirstOrDefault().internalId, product.MdmProductName, product.MdmProductCode, product.ProductStatus);
                    string updatedFields = string.Empty;
                    //set message based on what was updated
                    if (foundItem.displayName != product.MdmProductName && foundItem.isInactive != CheckForInactive(product.ProductStatus))
                    {
                        updatedFields = "display name, inactive status";
                    }
                    else if (foundItem.displayName != product.MdmProductName)
                    {
                        updatedFields = "display name";
                    }
                    else
                    {
                        updatedFields = "inactive status";
                    }

                    result.Message = $"Item found with different Id and {updatedFields}, but same mdm product code. Updating {updatedFields} in NetSuite and Id in MDM DB for {product.MdmProductName}";
                }
                else
                {
                    result.Items.Add(new InventoryItem { internalId = matchByProductCode.Items.FirstOrDefault().internalId, externalId = product.MdmProductCode, displayName = product.MdmProductName });
                    result.Message = $"Item found with different Id, but same mdm info. Updating Id in MDM DB for {product.MdmProductName}";
                }
                return result;
            }

            //item does not exist in NetSuite, add it
            if (matchByProductCode.Items.Count == 0 && matchByNetSuiteId.Items.Count == 0)
            {
                return await CreateItem(product);
            }

            //item already exists in NetSuite fail
            return new NetSuiteItemResult { Message = $"Error adding or updating InventoryItem. Item already exists in NetSuite" };
        }

        private bool CheckForInactive(string status)
        {
            return status == "InActive" ? true : false;
        }

        public async Task<NetSuiteItemResult> UpdateItem(string internalId, string displayName, string productCode, string status)
        {
            Passport = CreateTokenPassport();
            var result = new NetSuiteItemResult();
            try
            {
                
                InventoryItem updatedItem = new InventoryItem
                {
                    internalId = internalId,
                    itemId = productCode,
                    displayName = displayName,
                    salesDescription = displayName,
                    externalId = productCode,
                    isInactive = CheckForInactive(status),
                    isInactiveSpecified = true
                };

                // add item
                var updateResponse = await Service.updateAsync(Passport, null, null, null, updatedItem);

                if (updateResponse.writeResponse != null && updateResponse.writeResponse.status.isSuccess && updateResponse.writeResponse.baseRef != null)
                {
                    result.Items.Add(updatedItem);
                    result.Message = $"Successfully updated InventoryItem";
                }
                else
                {
                    result.Message = $"Error updating InventoryItem";
                }
                
            }
            catch (Exception ex)
            {
                result.Message = $"Error adding InventoryItem. Message:{ex.StackTrace}";
            }

            return result;
        }

        public async Task<NetSuiteItemResult> CreateItem(MdmProduct product)
        {
            //get updated token for each request
            Passport = CreateTokenPassport();
            var result = new NetSuiteItemResult();
            try
            {
                //Create new item
                InventoryItem newItem = new InventoryItem
                {
                    itemId = product.MdmProductCode,
                    displayName = product.MdmProductName,
                    salesDescription = product.MdmProductName,
                    externalId = product.MdmProductCode,
                    lastModifiedDate = DateTime.Now,
                    isInactive = product.ProductStatus == "InActive" ? true : false,
                    isInactiveSpecified = true,

                    taxSchedule = new RecordRef
                    {
                        internalId = "1"
                    },

                    assetAccount = new RecordRef
                    {
                        internalId = "437"
                    },

                    cogsAccount = new RecordRef
                    {
                        internalId = "141"
                    }
                };
                    
                // add item
                var addResponse = await Service.addAsync(Passport,null,null,null,newItem);

                if (addResponse.writeResponse != null && addResponse.writeResponse.status.isSuccess && addResponse.writeResponse.baseRef != null)
                {
                    var record = addResponse.writeResponse.baseRef as RecordRef;
                    newItem.internalId = record.internalId;
                    result.Items.Add(newItem);
                    result.Message = $"Successfully added InventoryItem";
                }
                else
                {
                    result.Message = $"Error adding InventoryItem";
                }
                
            }
            catch (Exception ex)
            {
                result.Message = $"Error adding InventoryItem. Message:{ex.StackTrace}";
            }

            return result;
        }
        public async Task<NetSuiteItemResult> BulkCreateItems(IEnumerable<MdmProduct> products)
        {
            var items = BuildBulkProductList(products).ToArray();
            //get updated token for each request
            Passport = CreateTokenPassport();
            var result = new NetSuiteItemResult();
            try
            {
                // add item
                var addResponse = await Service.addListAsync(Passport, null, null, null, items);

                if (addResponse.writeResponseList != null && addResponse.writeResponseList.status.isSuccess)
                {
                    
                    result.Message = $"Successfully added InventoryItems";
                }
                else
                {
                    result.Message = $"Error adding InventoryItem";
                }

            }
            catch (Exception ex)
            {
                result.Message = $"Error adding InventoryItem. Message:{ex.StackTrace}";
            }

            return result;
        }

        private List<InventoryItem> BuildBulkProductList(IEnumerable<MdmProduct> products)
        {
            var items = new List<InventoryItem>();
            foreach (var product in products)
            {
                InventoryItem newItem = new InventoryItem
                {
                    itemId = product.MdmProductCode,
                    displayName = product.MdmProductName,
                    salesDescription = product.MdmProductName,
                    externalId = product.MdmProductCode,
                    lastModifiedDate = DateTime.Now,
                    isInactive = product.ProductStatus == "InActive" ? true : false,
                    isInactiveSpecified = true,

                    taxSchedule = new RecordRef
                    {
                        internalId = "1"
                    },

                    assetAccount = new RecordRef
                    {
                        internalId = "437"
                    },

                    cogsAccount = new RecordRef
                    {
                        internalId = "141"
                    }
                };

                items.Add(newItem);
            }
            
            return items;
        }

        //Get Item by InternalId
        public async Task<NetSuiteItemResult> GetItem(int id)
        {
            //get updated token for each request
            Passport = CreateTokenPassport();
            var result = new NetSuiteItemResult();
            try
            {
                ItemSearchBasic itemSearchBasic = new ItemSearchBasic
                {
                    internalIdNumber = new SearchLongField
                    {
                        operatorSpecified = true,
                        @operator = SearchLongFieldOperator.equalTo,
                        searchValue = id,
                        searchValueSpecified = true
                    }
                };

                ItemSearch itemSearch = new ItemSearch { basic = itemSearchBasic };

                searchResponse searchResponse = await Service.searchAsync(Passport, null, null, null, itemSearch);

                if (searchResponse.searchResult != null && searchResponse.searchResult.status.isSuccess && searchResponse.searchResult.recordList != null && searchResponse.searchResult.recordList.Length > 0)
                {
                    result.Items.Add((InventoryItem)searchResponse.searchResult.recordList[0]);
                    result.Message = $"Successfully found item id:{id}";
                }
                else
                {
                    result.Message = $"No items found for {id}";
                }
            }
            catch (Exception ex)
            {
                result.Message = $"Error searching for item id:{id} Message:{ex.StackTrace}";
            }

            return result;
        }
        //Get Item by MdmProductCode
        public async Task<NetSuiteItemResult> GetItems(string mdmProductCode)
        {
            //get updated token for each request
            Passport = CreateTokenPassport();
            var result = new NetSuiteItemResult();
            try
            {
                ItemSearchBasic itemSearchBasic = new ItemSearchBasic
                {
                    externalIdString = new SearchStringField
                    {
                        operatorSpecified = true,
                        @operator = SearchStringFieldOperator.@is, // Search for items containing the name
                        searchValue = mdmProductCode
                    }
                };

                ItemSearch itemSearch = new ItemSearch { basic = itemSearchBasic };

                SearchPreferences searchPreferences = new SearchPreferences
                {
                    pageSize = 10, // Max 1000 per request
                    bodyFieldsOnly = false, // Retrieve all fields
                    pageSizeSpecified = true
                };

                var searchResponse = await Service.searchAsync(Passport,null,null,searchPreferences, itemSearch);

                if (searchResponse.searchResult != null && searchResponse.searchResult.status.isSuccess && searchResponse.searchResult.recordList != null && searchResponse.searchResult.recordList.Length > 0)
                {
                    result.Items.AddRange(searchResponse.searchResult.recordList.Select(r => (InventoryItem)r));
                    result.Message = $"Successfully found {result.Items.Count} item";
                }
                else
                {
                    result.Message = $"No items found for {mdmProductCode}";
                }              
            }
            catch (Exception ex)
            {
                result.Message = $"Error searching for items. Message:{ex.StackTrace}";
            }

            return result;
        }
        private NetSuitePortTypeClient CreateClient() 
        {
            // Create NetSuite Service Client
            BasicHttpsBinding binding = new BasicHttpsBinding
            {
                MaxBufferSize = int.MaxValue,
                MaxReceivedMessageSize = int.MaxValue,
                Security = new BasicHttpsSecurity
                {
                    Mode = BasicHttpsSecurityMode.Transport
                }
            };
            // Create Client
            EndpointAddress endpoint = new EndpointAddress(ConnectionParameters.Uri);

            return  new NetSuitePortTypeClient(binding, endpoint);
        }
        private TokenPassport CreateTokenPassport()
        {
            string account = ConnectionParameters.AccountId;
            string consumerKey = ConnectionParameters.ConsumerKey;
            string consumerSecret = ConnectionParameters.ConsumerSecret;
            string tokenId = ConnectionParameters.TokenId;
            string tokenSecret = ConnectionParameters.TokenSecret;

            string nonce = GenerateNonce();
            long timestamp = GetUnixTimestamp();
            var signature = GenerateSignature(account, consumerKey, tokenId, nonce, timestamp, consumerSecret, tokenSecret);

            TokenPassport tokenPassport = new TokenPassport();
            tokenPassport.account = account;
            tokenPassport.consumerKey = consumerKey;
            tokenPassport.token = tokenId;
            tokenPassport.nonce = nonce;
            tokenPassport.timestamp = timestamp;
            tokenPassport.signature = signature;

            return tokenPassport;
        }

        private static string GenerateNonce()
        {
            return Guid.NewGuid().ToString("N");
        }

        //Get Current Unix Timestamp
        private static long GetUnixTimestamp()
        {
            return DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        }

        // Generate HMAC-SHA256 Signature
        private TokenPassportSignature GenerateSignature(string account, string consumerKey, string token, string nonce, long timestamp, string consumerSecret, string tokenSecret)
        {
            string baseString = $"{account}&{consumerKey}&{token}&{nonce}&{timestamp}";
            string key = $"{consumerSecret}&{tokenSecret}";

            using (var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(key)))
            {
                byte[] hashBytes = hmac.ComputeHash(Encoding.UTF8.GetBytes(baseString));
                var signature = Convert.ToBase64String(hashBytes);

                var sign = new TokenPassportSignature();
                sign.algorithm = "HMAC-SHA256";
                sign.Value = signature;
                return sign;
            }
        }
    }
}
