﻿using EFCore.BulkExtensions;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Base;
using ThreeDegreesDataSystem.Models.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service
{
    public class DataLoader
    {

        public async Task<WriterResult> BulkInsertData(IList<dynamic> data)
        {
            var result = new WriterResult();

            try
            {
                using (var dbContext = new CentralOpsDbContext())
                {
                    await dbContext.BulkInsertAsync(data);
                    result.Status = StringConstants.Succeeded;
                    return result;
                }
            }
            catch (Exception ex)
            {
                result.Status = StringConstants.Failed;
                result.Message = $"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}";
                throw;
            }
        }

        public dynamic Add(dynamic data)
        {
            var result = new WriterResult();

            try
            {
                using (var dbContext = new CentralOpsDbContext())
                {
                    
                    result.Data = dbContext.Add(data);
                    dbContext.SaveChanges();
                    
                    result.Status = StringConstants.Succeeded;
                }
            }
            catch (Exception ex)
            {
                result.Status = StringConstants.Failed;
                result.Message = $"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}";
            }

            return result;

        }

        public dynamic Update(dynamic data)
        {
            var result = new WriterResult();

            try
            {
                using (var dbContext = new CentralOpsDbContext())
                {

                    result.Data = dbContext.Entry(data);
                    dbContext.SaveChanges();

                    result.Status = StringConstants.Succeeded;
                }
            }
            catch (Exception ex)
            {
                result.Status = StringConstants.Failed;
                result.Message = $"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}";
            }

            return result;

        }

        public WriterResult AddMultiple(IList<dynamic> data)
        {
            var result = new WriterResult();

            try
            {
                using (var dbContext = new CentralOpsDbContext())
                {
                    foreach(var item in data)
                    {
                        dbContext.Add(item);
                        dbContext.SaveChanges();
                    }
                    
                    result.Status = StringConstants.Succeeded;
                }
            }
            catch (Exception ex)
            {
                result.Status = StringConstants.Failed;
                result.Message = $"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}";
            }

            return result;

        }

        public WriterResult UpdateMultiple(IList<dynamic> data)
        {
            var result = new WriterResult();

            try
            {
                using (var dbContext = new CentralOpsDbContext())
                {
                    foreach (var item in data)
                    {
                        dbContext.Entry(item);
                        dbContext.SaveChanges();
                    }

                    result.Status = StringConstants.Succeeded;
                }
            }
            catch (Exception ex)
            {
                result.Status = StringConstants.Failed;
                result.Message = $"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}";
            }

            return result;

        }

        public DataTable DataTable(DbContext context, string sqlQuery, params DbParameter[] parameters)
        {
            DataTable dataTable = new DataTable();
            DbConnection connection = context.Database.GetDbConnection();
            DbProviderFactory dbFactory = DbProviderFactories.GetFactory(connection);
            using (var cmd = dbFactory.CreateCommand())
            {
                cmd.Connection = connection;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sqlQuery;
                if (parameters != null)
                {
                    foreach (var item in parameters)
                    {
                        cmd.Parameters.Add(item);
                    }
                }
                using (DbDataAdapter adapter = dbFactory.CreateDataAdapter())
                {
                    adapter.SelectCommand = cmd;
                    adapter.Fill(dataTable);
                }
            }
            return dataTable;
        }

    }
}
