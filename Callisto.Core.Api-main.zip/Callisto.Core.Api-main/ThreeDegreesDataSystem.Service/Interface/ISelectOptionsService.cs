﻿using ThreeDegreesDataSystem.Models.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface ISelectOptionsService : IService
    {
        public Task<List<SelectOption>> GetSelectOptions();
        public Task<List<SelectOption>> GetSelectOptionsByTypeCode(string typeCode);
        
    }
}
