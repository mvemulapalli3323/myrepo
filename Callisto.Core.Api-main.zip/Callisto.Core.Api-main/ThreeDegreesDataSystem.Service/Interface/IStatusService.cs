﻿using ThreeDegreesDataSystem.Models.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IStatusService : IService
    {
        public Task<Dictionary<int, string>> GetStatusIdCodeMap();
    }
}
