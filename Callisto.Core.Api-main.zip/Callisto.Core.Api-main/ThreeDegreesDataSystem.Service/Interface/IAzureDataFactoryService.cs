﻿using ThreeDegreesDataSystem.Models.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IAzureDataFactoryService : IService
    {
    }

}
