﻿namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IDateDimService
    {
        public Task<bool> IsUsBusinessDate(DateTime date);
        
    }
}
