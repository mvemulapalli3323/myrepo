﻿using Azure.Storage.Blobs.Models;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IAzureService
    {
        public Task<string> DownloadBlob(TaskRun taskRun, string fileName, string containerName);
        //Task<BlobItem[]> GetBlobs(TaskRun taskRun);
    }
}
