﻿using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IGenericTimeoutService : IService
    {
        public int GetTimeout(int taskId);
        public int GetTimeout(string typeCode);
    }
}
