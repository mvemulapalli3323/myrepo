﻿using ThreeDegreesDataSystem.Models.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IGenericMapService : IService
    {
        public Task<List<GenericMap>> GetGenericMaps();
        public Task<List<GenericMap>> GetGenericMapsByTypeCode(string typeCode);
        public Task<bool> DeleteAsync(int id);
        public string[] GetLists();
        public string[] GetList(string listTypeCode);

    }
}
