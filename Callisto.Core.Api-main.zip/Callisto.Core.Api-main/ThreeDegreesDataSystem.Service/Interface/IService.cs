﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IService
    {
        IQueryable<TEntity> GetCentralOpsEntities<TEntity>() where TEntity : class, ICentralOpsEntity;
        Task<IEnumerable<TEntity>> GetCentralOpsEntitiesAsync<TEntity>() where TEntity : class, ICentralOpsEntity;
        Task<TEntity> AddCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity;
        Task<TEntity> UpdateCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity;
        Task<TEntity> UpdateOrAddCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity;
        Task<bool> DeleteCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity;
        Task<bool> DeleteCentralOpsEntityAsync<TEntity>(int id) where TEntity : class, ICentralOpsEntity;
        Task<TEntity> ReloadCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity;
        Task<int> BulkCreateCentralOpsEntities(IEnumerable<dynamic> entities);
        Task<int> BulkDeleteCentralOpsEntities(IEnumerable<dynamic> entities);
        Task<int> BulkUpdateCentralOpsEntities(IEnumerable<dynamic> entities);
        Task<int> BulkCreateDwEntities(IEnumerable<dynamic> entities);
        Task<int> BulkDeleteDwEntities(IEnumerable<dynamic> entities);
        Task<int> BulkUpdateDwEntities(IEnumerable<dynamic> entities);
    }
}
