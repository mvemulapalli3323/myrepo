﻿using ThreeDegreesDataSystem.Models.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface ITaskService : IService
    {
        public Task<Dictionary<int, string>> GetTaskIdCodeMap();
        public Task<Models.Models.Task[]> GetTasks(bool topOnly=false, bool uiOnly=false);
        public Task<Models.Models.Task> GetTask(int taskId);
        public Task<Models.Models.Task> GetTask(string taskCode);
        public int GetTaskId(string taskCode);
        public Task<Models.Models.Task> GetTaskInclusive(int taskId);
        /// <summary>
        /// Get TaskSubtasks ordered by step.
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public Task<TaskSubtask[]> GetTaskSubtasks(int taskId);
        public bool IsRunning(int taskId);
    }
}
