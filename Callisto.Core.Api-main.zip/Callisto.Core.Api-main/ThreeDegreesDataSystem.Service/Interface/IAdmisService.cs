﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Connectors.Argus;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IAdmisService
    {
        public Task<IEnumerable<AdmisMappingHistory>> GetAdmisMappingHistory();
        public Task<string> UpdateAdmisProductDimensions(int taskunId);
        public Task<string> CreateAdmisDailyFacts(int taskRunId, int admisDbLoadTaskRunId, DateOnly businessDate);


    }
}
