﻿using ThreeDegreesDataSystem.Models.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Connectors.Argus;


namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IMdmProductService
    {
        public Task<IEnumerable<MdmProduct>> SyncMdmProductsToDb(IEnumerable<SalesforceMdmProductInfo> products);

        public Task<string> SyncMdmProductsToNetSuite(IEnumerable<MdmProduct> products);

        public Task<string> NotifyLogicWebhook(string callback, string status);
    }
}
