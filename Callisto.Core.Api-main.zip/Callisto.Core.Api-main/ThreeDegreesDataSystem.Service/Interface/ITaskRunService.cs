﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface ITaskRunService : IService
    {
        public Task<TaskRun> CancelTaskRun(int taskRunId);
        public Task<TaskRun> CompleteTaskRun(TaskRun taskRun);
        public Task<TaskRun> CompleteTaskRun(string taskCode);
        public Task<TaskRun> CreateTaskRun(int taskId, TaskRun taskRunIn, int? parentTaskRunId=null, int? parentStep=null);
        public System.Threading.Tasks.Task DeleteTaskRun(int taskRunId);
        public System.Threading.Tasks.Task DeleteTaskRun(TaskRun taskRun);
        public Task<TaskRun> FailTaskRun(TaskRun taskRun);
        public Task<TaskRun> FailTaskRun(TaskRun taskRun, string message);
        public Task<TaskRun> FailTaskRun(string taskCode, string message);
        public TaskRun GetLastSuccessfulTaskRun(TaskRun topTaskRun, string taskCode);
        public TaskRun GetLastSuccessfulTaskRun(string taskCode);
        public TaskRun GetLastTaskRunByParameterEndDate(string taskCode, DateTime endDate);
        public TaskRun GetLastValidTaskRun(string taskCode);
        public TaskRun GetTopTaskRun(TaskRun taskRun);
        public Task<TaskRun> GetTopTaskRunAsync(TaskRun taskRun);
        public IQueryable<TaskRun> GetTaskRuns(bool topOnly = false, string taskCode = default, bool tracking = false, bool inclusive = false);
        public Task<IEnumerable<TaskRun>> GetTaskRuns(string taskCode);
        public IEnumerable<TaskRun> GetTaskRuns(int topTaskRunId, string taskCode);
        public IQueryable<TaskRun> GetTaskRunsByCriteria(TaskRunCriteria criteria);
        public Task<TaskRun> GetTaskRun(int taskRunId, bool tracking=false, bool inclusive=false);
        public Task<bool> IsCanceled(int taskRunId);
        public Task<TaskRun> RestartTaskRun(TaskRun taskRun);
        public Task<TaskRun> SetStep(TaskRun taskRun, int step);
        public Task<TaskRun> SkipTaskRun(TaskRun taskRun);
        public Task<TaskRun> StartTaskRun(TaskRun taskRun);
        public System.Threading.Tasks.Task ValidateAllTaskRuns();
        public Task<TaskRun> ValidateTaskRun(TaskRun taskRun);
        public TaskRun[] GetTaskRunsByCriteria(string startDate, string endDate, string taskCode, string statusCode);
    }
}
