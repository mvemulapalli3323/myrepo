﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IDataCleansingService
    {
        public Task<string> CleanCsvFile(CsvReaderParameters csvReaderParams);
    }
}
