﻿using ThreeDegreesDataSystem.Models.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface IReferenceDataService : IService
    {
        public Task<List<ReferenceDataEntity>> GetReferenceDataEntities();
        Task<ReferenceDataFieldValue> AddValueAsync(ReferenceDataFieldValue value);
        Task<ReferenceDataFieldValue> UpdateValueAsync(ReferenceDataFieldValue value);
        Task<List<ReferenceDataFieldValue>> AddRowAsync(List<ReferenceDataFieldValue> values);
        Task<List<ReferenceDataFieldValue>> UpdateRowAsync(List<ReferenceDataFieldValue> values);
        Task<bool> DeleteValuesAsync(IEnumerable<int> referenceDataFieldValueIds);
    }
}
