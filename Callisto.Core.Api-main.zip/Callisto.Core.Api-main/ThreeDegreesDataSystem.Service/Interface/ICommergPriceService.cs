﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Connectors.Argus;

namespace ThreeDegreesDataSystem.Service.Interface
{
    public interface ICommergPriceService
    {
        public Task<string> LoadCommergPricesToDb(BlobFileReaderParameters blobFileReaderParameters);
    }
}
