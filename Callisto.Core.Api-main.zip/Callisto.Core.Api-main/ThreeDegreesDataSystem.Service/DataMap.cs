﻿using ThreeDegreesDataSystem.Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service
{
    public class DataMap
    {
        private static Dictionary<int, string> StatusIdCodeMap = new();
        private static Dictionary<int, string> TaskIdCodeMap = new();

        public static async Task Init(
            IStatusService statusService,
            ITaskService taskService)
        {
            StatusIdCodeMap = await statusService.GetStatusIdCodeMap();
            TaskIdCodeMap = await taskService.GetTaskIdCodeMap();
        }

        private static int GetIdFromMap(string code, Dictionary<int, string> map, string mapType)
        {
            var id = map.FirstOrDefault(x => x.Value.ToLower() == code.ToLower()).Key;
            if (id == 0)
            {
                throw new Exception($"{mapType}: Code '{code}' is not mapped to an ID");
            }
            return id;
        }

        private static string GetCodeFromMap(int id, Dictionary<int, string> map, string mapType)
        {
            if (map.ContainsKey(id))
            {
                return map[id];
            }
            throw new Exception($"{mapType}: ID '{id}' is not mapped to a code");
        }
        
        public static int GetStatusId(string statusCode)
        {
            return GetIdFromMap(statusCode, StatusIdCodeMap, "status");
        }

        public static string GetStatusCode(int statusId)
        {
            return GetCodeFromMap(statusId, StatusIdCodeMap, "status");
        }

        public static int GetTaskId(string taskCode)
        {
            return GetIdFromMap(taskCode, TaskIdCodeMap, "task");
        }

        public static string GetTaskCode(int taskId)
        {
            return GetCodeFromMap(taskId, TaskIdCodeMap, "task");
        }

        public static string GetTaskMethod(int taskId)
        {
            return GetCodeFromMap(taskId, TaskIdCodeMap, "task");
        }
    }
}
