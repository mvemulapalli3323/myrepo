﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Connectors.Argus;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Readers;
using NPOI.HSSF.Record;
using CsvHelper;
using System.Text;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Connectors.Interface;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class ArgusPriceService : Service, IArgusPriceService
    {
        private readonly IArgusConnector _argusConnector;

        public ArgusPriceService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, IArgusConnector argusConnector, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
            _argusConnector = argusConnector;
        }

        public async Task<string> LoadArgusPricesToDb(PriceParameters argusParameters)
        {
            var prices = await _argusConnector.GetArgusPrices(argusParameters.StartDate,argusParameters.EndDate);
            var codes = await _argusConnector.GetArgusCodes();
            
            //set taskrunid for each price and code
            prices.ForEach(price => price.TaskRunId = argusParameters.TaskRunId);
            codes.ForEach(codes => codes.TaskRunId = argusParameters.TaskRunId);
            
            var pricesLoaded = await BulkCreateCentralOpsEntities(prices);
            var codesLoaded = await BulkCreateCentralOpsEntities(codes);

            return $"Succefully loaded {pricesLoaded} and {codesLoaded} codes.";
        }
    }
}
