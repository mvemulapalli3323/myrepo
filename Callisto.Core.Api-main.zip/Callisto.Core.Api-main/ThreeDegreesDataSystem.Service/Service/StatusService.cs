﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class StatusService : Service, IStatusService
    {
        public StatusService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {

        }

        public async Task<Dictionary<int, string>> GetStatusIdCodeMap()
        {
            Dictionary<int, string> map = new Dictionary<int, string>();
            var statuses = await GetCentralOpsEntities<Status>().AsNoTracking().ToListAsync();
            foreach(var s in statuses)
            {
                System.Diagnostics.Debug.WriteLine($"Adding new kv pair to map {s.StatusId}:{s.StatusCode}");
                map.Add(s.StatusId, s.StatusCode);
            }
            return map;
        }
    }
}
