﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Exceptions;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Models.DwModels;
using System.Text;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class TaskRunCriteria
    {
        public bool IsTopOnly { get; set; }
        public bool IsValid { get; set; }
        public DateTime LastModifiedOnLessThan { get; set; }
        public DateTime ParameterEndDate { get; set; }
        public DateTime ParameterEndDateGreaterThan { get; set; }
        public DateTime ParameterEndDateGreaterThanEqualTo { get; set; }
        public int[] StatusIds { get; set; }
        public string TaskCode { get; set; }
    }

    public class TaskRunService : Service, ITaskRunService
    {
        private readonly ILogger<TaskRunService> _taskRunLogger;

        public TaskRunService(CentralOpsDbContext centralOpsDbContext,DwDbContext dwDbContext, ILogger<Service> baseLogger, ILogger<TaskRunService> taskRunLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
            _taskRunLogger = taskRunLogger;
        }

        public async Task<TaskRun> CancelTaskRun(int taskRunId)
        {
            TaskRun taskRun = await GetTaskRun(taskRunId, tracking: true, inclusive: true);
            // Set current task run to cancelled
            if (taskRun.Status.StatusCode == StringConstants.InProgress) await SetStatus(taskRun, StringConstants.Cancelled);
            // Propogate parent
            await CancelTaskRunParent(taskRun.ParentTaskRunId);
            // Propogate children
            foreach (TaskRun subtaskRun in taskRun.SubtaskRuns)
            {
                await CancelTaskRunChild(subtaskRun.TaskRunId);
            }
            await ReloadCentralOpsEntityAsync(taskRun);
            _taskRunLogger.LogInformation("TaskRun cancelled {{\"TaskRunId\":{taskRunId},\"TaskId\":{taskId},\"TaskCode\":{taskCode}}}",
                taskRun.TaskRunId, taskRun.Task.TaskId, taskRun.Task.TaskCode);
            return taskRun;
        }

        private async System.Threading.Tasks.Task CancelTaskRunParent(int? taskRunId)
        {
            if (taskRunId == null) return;

            TaskRun taskRun = await GetTaskRun(taskRunId.Value, tracking: true, inclusive: true);
            if (taskRun.Status.StatusCode == StringConstants.InProgress) await SetStatus(taskRun, StringConstants.Cancelled);
            // Propogate parent
            await CancelTaskRunParent(taskRun.ParentTaskRunId);
        }

        private async System.Threading.Tasks.Task CancelTaskRunChild(int taskRunId)
        {
            TaskRun taskRun = await GetTaskRun(taskRunId, tracking: true, inclusive: true);
            // Set current task run to cancelled
            if (taskRun.Status.StatusCode == StringConstants.InProgress) await SetStatus(taskRun, StringConstants.Cancelled);
            // Propogate children
            foreach (TaskRun subtaskRun in taskRun.SubtaskRuns)
            {
                await CancelTaskRunChild(subtaskRun.TaskRunId);
            }
        }

        public async Task<TaskRun> CompleteTaskRun(TaskRun taskRun)
        {
            //taskRun.Message = GetAllSubTaskRunMessages(taskRun);
            await SetStatus(taskRun, StringConstants.Succeeded);
            _taskRunLogger.LogDebug("TaskRun completed {{\"TaskRunId\":{taskRunId}}}", taskRun.TaskRunId);
            return taskRun;
        }

        public async Task<TaskRun> CompleteTaskRun(string taskCode)
        {
            TaskRun taskRun = CentralOpsDbContext.TaskRuns
                .Include(tr => tr.Status)
                .Include(tr => tr.Task)
                .Where(tr => tr.Task.TaskCode == taskCode && tr.Status.StatusCode == StringConstants.InProgress)
                .OrderByDescending(tr => tr.TaskRunId)
                .FirstOrDefault();

            if (taskRun != default)
            {
                await SetStatus(taskRun, StringConstants.Succeeded);
                _taskRunLogger.LogDebug("TaskRun completed {{\"TaskRunId\":{taskRunId}}}", taskRun.TaskRunId);
            }
            else
            {
                _taskRunLogger.LogWarning("Cannot complete task. No tasks running for task code '{taskCode}'.", taskCode);
            }

            return taskRun;
        }

        public async Task<TaskRun> CreateTaskRun(int taskId, TaskRun taskRunIn, int? parentTaskRunId = null, int? parentStep = null)
        {
            TaskRun taskRun = new();
            taskRun.CreatedBy = String.IsNullOrEmpty(taskRunIn.CreatedBy) ? "Data Warehouse" : taskRunIn.CreatedBy;
            taskRun.CreatedOn = DateTime.Now.ToUniversalTime();
            taskRun.CurrentStep = 1;
            taskRun.LastModifiedBy = String.IsNullOrEmpty(taskRunIn.CreatedBy) ? "Data Warehouse" : taskRunIn.CreatedBy;
            taskRun.LastModifiedOn = DateTime.Now.ToUniversalTime();
            taskRun.Parameters = taskRunIn.Parameters;
            taskRun.ParentStep = parentStep;
            taskRun.ParentTaskRunId = parentTaskRunId;
            taskRun.StatusId = (taskRunIn.StatusId == default) ? DataMap.GetStatusId(StringConstants.NotStarted) : taskRunIn.StatusId;
            taskRun.TaskId = taskId;

            return await AddCentralOpsEntityAsync(taskRun);
        }

        public async System.Threading.Tasks.Task DeleteTaskRun(int taskRunId)
        {
            TaskRun taskRun = await GetTaskRun(taskRunId, inclusive: true);
            foreach (TaskRun subTaskRun in taskRun.SubtaskRuns)
            {
                await DeleteTaskRun(subTaskRun.TaskRunId);
            }
            taskRun.SubtaskRuns = null; // Removed deleted sub TaskRuns
            CentralOpsDbContext.Entry(taskRun).State = EntityState.Deleted;

            await CentralOpsDbContext.SaveChangesAsync();
            _taskRunLogger.LogInformation("TaskRun deleted {{\"TaskRunId\":{taskRunId},\"TaskId\":{taskId},\"TaskCode\":{taskCode}}}",
                taskRun.TaskRunId, taskRun.Task.TaskId, taskRun.Task.TaskCode);
        }

        public async System.Threading.Tasks.Task DeleteTaskRun(TaskRun taskRun)
        {
            await DeleteTaskRun(taskRun.TaskRunId);
        }

        public async Task<TaskRun> FailTaskRun(TaskRun taskRun)
        {
            await SetStatus(taskRun, StringConstants.Failed);
            _logger.LogInformation("TaskRun failed {{\"TaskRunId\":{taskRunId},\"Message\":{message}}}",
                taskRun.TaskRunId, taskRun.Message);
            return taskRun;
        }

        public async Task<TaskRun> FailTaskRun(TaskRun taskRun, string message)
        {
            taskRun.Message = message;
            await SetStatus(taskRun, StringConstants.Failed);
            await SetTopTaskRunMessage(taskRun);

            _taskRunLogger.LogInformation("TaskRun failed {{\"TaskRunId\":{taskRunId},\"Message\":{message}}}",
                taskRun.TaskRunId, taskRun.Message);
            return taskRun;
        }

        public async Task<TaskRun> FailTaskRun(string taskCode, string message)
        {
            TaskRun taskRun = CentralOpsDbContext.TaskRuns
                .Include(tr => tr.Status)
                .Include(tr => tr.Task)
                .Where(tr => tr.Task.TaskCode == taskCode && tr.Status.StatusCode == StringConstants.InProgress)
                .OrderByDescending(tr => tr.TaskRunId)
                .First();

            taskRun.Message = message;
            await SetStatus(taskRun, StringConstants.Failed);
            _taskRunLogger.LogDebug("TaskRun failed {{\"TaskRunId\":{taskRunId}}}", taskRun.TaskRunId);
            return taskRun;
        }

        public TaskRun GetLastSuccessfulTaskRun(TaskRun topTaskRun, string taskCode)
        {
            IQueryable<TaskRun> successfulTaskRuns = GetCentralOpsEntities<TaskRun>()
                .AsNoTracking()
                .Where(t => t.TaskId == DataMap.GetTaskId(taskCode) && t.StatusId == DataMap.GetStatusId(StringConstants.Succeeded));

            TaskRun lastSuccessfulTaskRun = successfulTaskRuns
                .AsEnumerable()
                .Where(t => GetTopTaskRun(t) == topTaskRun)
                .OrderByDescending(t => t.TaskRunId)
                .FirstOrDefault();

            return lastSuccessfulTaskRun;
        }

        public TaskRun GetLastSuccessfulTaskRun(string taskCode)
        {
            IQueryable<TaskRun> successfulTaskRuns = GetCentralOpsEntities<TaskRun>()
                .AsNoTracking()
                .Where(t => t.TaskId == DataMap.GetTaskId(taskCode) && t.StatusId == DataMap.GetStatusId(StringConstants.Succeeded))
                .OrderByDescending(t => t.TaskRunId);

            return successfulTaskRuns.First();
        }

        public TaskRun GetLastTaskRunByParameterEndDate(string taskCode, DateTime endDate)
        {
            IQueryable<TaskRun> taskRuns = CentralOpsDbContext.TaskRuns
                .AsNoTracking()
                .Where(tr => tr.TaskId == DataMap.GetTaskId(taskCode))
                .OrderByDescending(tr => tr.TaskRunId);
            foreach(TaskRun taskRun in taskRuns)
            {
                DateTime taskRunEndDate;
                try
                {
                    taskRunEndDate = ParameterHelper.GetEndDate(taskRun.Parameters);
                }
                catch (ParameterNotFoundException)
                {
                    taskRunEndDate = taskRun.CreatedOn;
                }
                if (taskRunEndDate.Date == endDate.Date)
                {
                    return taskRun;
                }
            }
            return null;
        }

        public TaskRun GetLastValidTaskRun(string taskCode)
        {
            IQueryable<TaskRun> taskRuns = CentralOpsDbContext.TaskRuns
                .AsNoTracking()
                .Where(tr => tr.TaskId == DataMap.GetTaskId(taskCode) && tr.IsValid == true)
                .OrderByDescending(tr => tr.TaskRunId);

            return taskRuns.First();
        }

        public TaskRun GetTopTaskRun(TaskRun taskRun)
        {
            using CentralOpsDbContext dbContext = new();
            if (taskRun.ParentTaskRunId == null) return taskRun;
            TaskRun parentTaskRun = dbContext.TaskRuns.AsNoTracking()
                .Where(t => t.TaskRunId == taskRun.ParentTaskRunId).FirstOrDefault();

            return GetTopTaskRun(parentTaskRun);
        }

        public async Task<TaskRun> GetTopTaskRunAsync(TaskRun taskRun)
        {
            if (taskRun.ParentTaskRunId == null) return taskRun;
            TaskRun parentTaskRun = await GetCentralOpsEntities<TaskRun>().AsNoTracking()
                .Where(t => t.TaskRunId == taskRun.ParentTaskRunId).FirstOrDefaultAsync();

            return await GetTopTaskRunAsync(parentTaskRun);
        }

        public IQueryable<TaskRun> GetTaskRuns(bool topOnly = false, string taskCode = default, bool tracking = false, bool inclusive = false)
        {
            IQueryable<TaskRun> taskRuns = CentralOpsDbContext.TaskRuns;

            taskRuns = topOnly
                ? taskRuns.Where(tr => tr.ParentTaskRunId == null)
                : taskRuns;

            taskRuns = taskCode != default
                ? taskRuns.Where(tr => tr.TaskId == DataMap.GetTaskId(taskCode))
                : taskRuns;

            taskRuns = inclusive
                ? taskRuns
                    .Include(t => t.Status)
                    .Include(t => t.Task)
                    .Include(t => t.SubtaskRuns).ThenInclude(s => s.Status)
                    .Include(t => t.SubtaskRuns).ThenInclude(s => s.Task)
                    .Include(t => t.SubtaskRuns).ThenInclude(s => s.SubtaskRuns)
                    .Include(t => t.SubtaskRuns).ThenInclude(s => s.SubtaskRuns).ThenInclude(s2 => s2.Status)
                    .Include(t => t.SubtaskRuns).ThenInclude(s => s.SubtaskRuns).ThenInclude(s2 => s2.Task)
                : taskRuns.AsNoTracking();

            taskRuns = tracking
                ? taskRuns
                : taskRuns.AsNoTracking();

            return taskRuns;
        }

        public async Task<IEnumerable<TaskRun>> GetTaskRuns(string taskCode)
        {
            return await GetCentralOpsEntities<TaskRun>().AsNoTracking()
                .Include(t => t.Status)
                .Include(t => t.Task)
                .Where(t => t.Task.TaskCode == taskCode)
                .ToListAsync();
        }

        public IEnumerable<TaskRun> GetTaskRuns(int topTaskRunId, string taskCode)
        {
            return GetCentralOpsEntities<TaskRun>().AsNoTracking()
                .Include(t => t.Status)
                .Include(t => t.Task)
                .AsEnumerable()
                .Where(t => GetTopTaskRun(t).TaskRunId == topTaskRunId && t.Task.TaskCode == taskCode)
                .ToList();
        }

        public async Task<TaskRun> GetTaskRun(int taskRunId, bool tracking=false, bool inclusive=false)
        {
            IQueryable<TaskRun> taskRuns = GetCentralOpsEntities<TaskRun>();

            taskRuns = inclusive
                ? taskRuns
                    .Include(t => t.ParentTaskRun)
                    .Include(t => t.Status)
                    .Include(t => t.SubtaskRuns.OrderBy(sr => sr.ParentStep))
                    .Include(t => t.Task)
                : taskRuns;

            taskRuns = tracking
                ? taskRuns
                : taskRuns.AsNoTracking();

            return await taskRuns
                .FirstOrDefaultAsync(t => t.TaskRunId == taskRunId);
        }

        public TaskRun[] GetTaskRunsByCriteria(string startDate, string endDate, string taskCode, string statusCode)
        {
            var start = DateTime.Parse(startDate);
            var end = DateTime.Parse(endDate);


            var taskRuns = GetTaskRuns(topOnly: true, taskCode: default, inclusive: true)
                .Where(t => t.CreatedOn.Date >= start.Date && t.CreatedOn.Date <= end.Date);

            if (!string.IsNullOrEmpty(taskCode))
            {
                var taskId = DataMap.GetTaskId(taskCode);
                taskRuns = taskRuns.Where(t => t.TaskId == taskId);
            }

            if (!string.IsNullOrEmpty(statusCode))
            {
                var statusId = DataMap.GetStatusId(statusCode);
                taskRuns = taskRuns.Where(t => t.StatusId == statusId);
            }

            return taskRuns.OrderByDescending(t => t.TaskRunId).ToArray();
        }

        public IQueryable<TaskRun> GetTaskRunsByCriteria(TaskRunCriteria criteria)
        {
            IQueryable<TaskRun> taskRuns = CentralOpsDbContext.TaskRuns.AsNoTracking();

            if (criteria.IsValid == true)
            {
                taskRuns = taskRuns.Where(tr => tr.IsValid == true);
            }

            if (criteria.IsTopOnly == true)
            {
                taskRuns = taskRuns.Where(tr => tr.ParentTaskRunId == null);
            }

            if (criteria.TaskCode != default)
            {
                taskRuns = taskRuns.Where(tr => tr.TaskId == DataMap.GetTaskId(criteria.TaskCode));
            }

            if (criteria.LastModifiedOnLessThan != default)
            {
                taskRuns = taskRuns.Where(tr => tr.LastModifiedOn < criteria.LastModifiedOnLessThan);
            }

            if (criteria.StatusIds != default)
            {
                taskRuns = taskRuns.Where(tr => criteria.StatusIds.Contains(tr.StatusId));
            }

            DateTime[] parameterDateCriteria = new DateTime[] {
                criteria.ParameterEndDate,
                criteria.ParameterEndDateGreaterThan,
                criteria.ParameterEndDateGreaterThanEqualTo
            };
            if (parameterDateCriteria.Any(c => c != default)) {

                List<TaskRun> taskRunsOut = new();
                foreach(TaskRun taskRun in taskRuns)
                {
                    DateTime? endDate = ParameterHelper.GetNullableEndDate(taskRun.Parameters);
                    if (endDate != null)
                    {
                        if (criteria.ParameterEndDate != default && endDate?.Date == criteria.ParameterEndDate.Date)
                        {
                            taskRunsOut.Add(taskRun);
                        }
                        else if (criteria.ParameterEndDateGreaterThan!= default && endDate?.Date > criteria.ParameterEndDateGreaterThan.Date)
                        {
                            taskRunsOut.Add(taskRun);
                        }
                        else if (criteria.ParameterEndDateGreaterThanEqualTo != default && endDate?.Date >= criteria.ParameterEndDateGreaterThanEqualTo.Date)
                        {
                            taskRunsOut.Add(taskRun);
                        }
                    }
                }

                return taskRunsOut.AsQueryable();
            }

            return taskRuns;
        }

        public async Task<bool> IsCanceled(int taskRunId)
        {
            TaskRun taskRun = await GetCentralOpsEntities<TaskRun>().AsNoTracking().Where(t => t.TaskRunId == taskRunId).FirstOrDefaultAsync();
            return taskRun.StatusId == DataMap.GetStatusId(StringConstants.Cancelled);
        }

        public async Task<TaskRun> RestartTaskRun(TaskRun taskRun)
        {
            await SetStatus(taskRun, StringConstants.InProgress);
            return taskRun;
        }

        private async Task<TaskRun> SetStatus(TaskRun taskRun, string statusCode)
        {
            taskRun.StatusId = DataMap.GetStatusId(statusCode);
            taskRun.LastModifiedOn = DateTime.Now.ToUniversalTime();
            await UpdateCentralOpsEntityAsync(taskRun);
            return taskRun;
        }

        public async Task<TaskRun> SetStep(TaskRun taskRun, int step)
        {
            taskRun.CurrentStep = step;
            taskRun.LastModifiedOn = DateTime.Now.ToUniversalTime();
            await UpdateCentralOpsEntityAsync(taskRun);
            return taskRun;
        }

        public async System.Threading.Tasks.Task SetTopTaskRunMessage(TaskRun taskRun)
        {
            TaskRun topTaskRun = await GetTopTaskRunAsync(taskRun);
            topTaskRun.LastModifiedOn = DateTime.Now.ToUniversalTime();
            topTaskRun.Message = taskRun.Message;
            //try {
            //    await UpdateCentralOpsEntityAsync(topTaskRun);
            //}
            //catch (Exception ex)
            //{
               
            //    throw new Exception($"Failed to update TaskRun message: {ex.Message}");
            //}

        }

        public string GetAllSubTaskRunMessages(TaskRun taskRun)
        {
            if (taskRun.SubtaskRuns == null || taskRun.SubtaskRuns.Count == 0)
            {
                return taskRun.Message ?? string.Empty;
            }
            else
            {
                StringBuilder message = new StringBuilder();
                
                foreach (TaskRun subtaskRun in taskRun.SubtaskRuns)
                {
                    message.AppendLine(subtaskRun.Task.TaskCode);
                    message.AppendLine(GetAllSubTaskRunMessages(subtaskRun));
                }
                return message.ToString();
            }
        }

        public async Task<TaskRun> SkipTaskRun(TaskRun taskRun)
        {
            await SetStatus(taskRun, StringConstants.Skipped);
            _taskRunLogger.LogInformation("TaskRun skipped {{\"TaskRunId\":{taskRunId}}}",
                taskRun.TaskRunId);
            return taskRun;
        }

        public async Task<TaskRun> StartTaskRun(TaskRun taskRun)
        {
            taskRun.StartedOn = DateTime.Now.ToUniversalTime();
            await SetStatus(taskRun, StringConstants.InProgress);
            return taskRun;
        }

        public async System.Threading.Tasks.Task ValidateAllTaskRuns()
        {
            IEnumerable<TaskRun> taskRuns = GetTaskRuns(topOnly:true)
                .Where(tr => tr.StatusId == DataMap.GetStatusId(StringConstants.Succeeded))
                .AsEnumerable();

            foreach (TaskRun taskRun in taskRuns)
            {
                ValidateTaskRun(taskRun, CentralOpsDbContext);
            }
            await CentralOpsDbContext.SaveChangesAsync();
        }

        public async Task<TaskRun> ValidateTaskRun(TaskRun taskRun)
        {
            ValidateTaskRun(taskRun, CentralOpsDbContext);
            await CentralOpsDbContext.SaveChangesAsync();
            return taskRun;
        }

        private void ValidateTaskRun(TaskRun taskRun, CentralOpsDbContext context)
        {
            taskRun = context.TaskRuns
                .Include(tr => tr.SubtaskRuns)
                .Where(tr => tr.TaskRunId == taskRun.TaskRunId)
                .Single();
            taskRun.IsValid = true;
            context.Update(taskRun);
            foreach (TaskRun subtaskRun in taskRun.SubtaskRuns)
            {
                ValidateTaskRun(subtaskRun, context);
            }
        }
    }
}
