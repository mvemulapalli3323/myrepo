﻿using ThreeDegreesDataSystem.Models.Models;
using Microsoft.EntityFrameworkCore;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;


namespace ThreeDegreesDataSystem.Service.Service
{
    public class GenericMapService : Service, IGenericMapService
    {
        public GenericMapService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {

        }

        public async Task<List<GenericMap>> GetGenericMaps()
        {
            return await GetCentralOpsEntities<GenericMap>().AsNoTracking().ToListAsync();
        }

        public async Task<List<GenericMap>> GetGenericMapsByTypeCode(string typeCode)
        {
            return await GetCentralOpsEntities<GenericMap>().Where(m => m.TypeCode == typeCode).AsNoTracking().ToListAsync();
        }

        public async Task<bool> DeleteAsync(int id)
        {
            bool result = false;
            GenericMap map = await CentralOpsDbContext.GenericMaps
                .Where(m => m.GenericMapId.Equals(id))
                .FirstOrDefaultAsync();
            if (map != null)
            {
                CentralOpsDbContext.GenericMaps.Remove(map);
                await CentralOpsDbContext.SaveChangesAsync();
                result = true;
            }
            return result;
        }

        public string[] GetLists()
        {
            return CentralOpsDbContext.GenericListItems
                .GroupBy(li => li.TypeCode)
                .Select(g => g.Key)
                .ToArray();
        }

        public string[] GetList(string listTypeCode)
        {
            return CentralOpsDbContext.GenericListItems
                .Where(li => listTypeCode.Equals(li.TypeCode))
                .Select(li => li.Value)
                .ToArray();
        }
    }
}
