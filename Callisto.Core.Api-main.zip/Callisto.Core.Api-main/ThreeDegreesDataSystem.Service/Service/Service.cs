﻿using EFCore.BulkExtensions;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MathNet.Numerics.Statistics.Mcmc;
using ThreeDegreesDataSystem.Models.DwModels;
using ThreeDegreesDataSystem.Models.Interface;
using NPOI.SS.Formula.Functions;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class Service : IService
    {
        protected readonly CentralOpsDbContext CentralOpsDbContext;
        protected readonly DwDbContext DwDbContext;
        protected readonly ILogger<Service> _logger;

        public Service(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> logger)
        {
            CentralOpsDbContext = centralOpsDbContext;
            DwDbContext = dwDbContext;
            _logger = logger;
        }

        public virtual IQueryable<TEntity> GetCentralOpsEntities<TEntity>() where TEntity : class, ICentralOpsEntity
        {
            try
            {
                return CentralOpsDbContext.Set<TEntity>();
            }
            catch (Exception ex)
            {
                throw new Exception($"Couldn't retrieve entities: {ex.Message}");
            }
        }

        public async virtual Task<IEnumerable<TEntity>> GetCentralOpsEntitiesAsync<TEntity>() where TEntity : class, ICentralOpsEntity
        {
            try
            {
                return await CentralOpsDbContext.Set<TEntity>().ToListAsync();
            }
            catch (Exception ex)
            {
                throw new Exception($"Couldn't retrieve entities: {ex.Message}");
            }
        }
    

        public async virtual Task<TEntity> AddCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(AddCentralOpsEntityAsync)} entity must not be null");
            }

            try
            {
                await CentralOpsDbContext.AddAsync(entity);
                await CentralOpsDbContext.SaveChangesAsync();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception($"{nameof(entity)} could not be saved: {ex.Message}");
            }
        }

        public async virtual Task<TEntity> UpdateCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(UpdateCentralOpsEntityAsync)} entity must not be null");
            }

            try
            {
                CentralOpsDbContext.Update(entity);
                await CentralOpsDbContext.SaveChangesAsync();

                return entity;
            }
            //catch (DbUpdateException ex)
            //{
            //    if (ex.InnerException?.Message.Contains("UNIQUE constraint failed") == true || ex.InnerException?.Message.Contains("duplicate key value violates unique constraint") == true)
            //    {
            //        throw new Exception($"Unique constraint violation:  already exists.");

            //    }
            //}
            catch (Exception ex)
            {
                throw new Exception($"{nameof(entity)} could not be updated: {ex.Message}");
            }
        }

        public async virtual Task<TEntity> UpdateOrAddCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(UpdateOrAddCentralOpsEntityAsync)} entity must not be null");
            }

            try
            {
                var keyName = CentralOpsDbContext.Model.FindEntityType(typeof(TEntity)).FindPrimaryKey().Properties
                    .Select(x => x.Name).Single();
                var key = (int)entity.GetType().GetProperty(keyName).GetValue(entity, null);
                if (key == 0)
                {
                    await CentralOpsDbContext.AddAsync(entity);
                }
                else
                {
                    CentralOpsDbContext.Update(entity);
                }

                await CentralOpsDbContext.SaveChangesAsync();

                return entity;
            }
            catch (Exception ex)
            {
                throw new Exception($"{nameof(entity)} could not be updated or added: {ex.Message}");
            }
        }

        public async virtual Task<bool> DeleteCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(DeleteCentralOpsEntityAsync)} entity must not be null");
            }

            try
            {
                if (CentralOpsDbContext.Entry(entity).State == EntityState.Detached)
                {
                    CentralOpsDbContext.Attach(entity);
                }
                CentralOpsDbContext.Remove(entity);
                await CentralOpsDbContext.SaveChangesAsync();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception($"{nameof(entity)} could not be deleted: {ex.Message}");
            }
        }

        public async virtual Task<bool> DeleteCentralOpsEntityAsync<TEntity>(int id) where TEntity : class, ICentralOpsEntity
        {
            var entity = await CentralOpsDbContext.Set<TEntity>().FindAsync(id);
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(DeleteCentralOpsEntityAsync)} entity must not be null");
            }
            return await DeleteCentralOpsEntityAsync(entity); 
        }

        public async virtual Task<TEntity> ReloadCentralOpsEntityAsync<TEntity>(TEntity entity) where TEntity : class, ICentralOpsEntity
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity), $"{nameof(entity)} entity must not be null");
            }

            await CentralOpsDbContext.Entry(entity).ReloadAsync();

            return entity;
        }

        public static Dictionary<string, object> DeserializeParams(JArray json)
        {
            var queryParams = new Dictionary<string, object>();

            foreach (JObject obj in json.Children<JObject>())
            {
                foreach (JProperty singleProp in obj.Properties())
                {
                    string name = singleProp.Name;
                    string value = singleProp.Value.ToString();
                    queryParams.Add(name, value);

                }
            }

            return queryParams;
        }

        public async Task<int> BulkCreateDwEntities(IEnumerable<dynamic> entitiesToCreate)
        {
            if (!entitiesToCreate.Any()) return 0;
            
            DwDbContext.ChangeTracker.AutoDetectChangesEnabled = false;
            await DwDbContext.BulkInsertAsync(entitiesToCreate.ToList());
            return entitiesToCreate.Count();
        }

        public async Task<int> BulkDeleteDwEntities(IEnumerable<dynamic> entitiesToDelete)
        {
            if (!entitiesToDelete.Any()) return 0;
            int numDeleted = entitiesToDelete.Count();
            DwDbContext.ChangeTracker.AutoDetectChangesEnabled = false;
            await DwDbContext.BulkDeleteAsync(entitiesToDelete.ToList());
            return numDeleted;
        }

        public async Task<int> BulkUpdateDwEntities(IEnumerable<dynamic> entitiesToUpdate)
        {
            if (!entitiesToUpdate.Any()) return 0;
            
            DwDbContext.ChangeTracker.AutoDetectChangesEnabled = false;
            await DwDbContext.BulkUpdateAsync(entitiesToUpdate.ToList());
            return entitiesToUpdate.Count();
        }

        public async Task<int> BulkCreateCentralOpsEntities(IEnumerable<dynamic> entitiesToCreate)
        {
            if (!entitiesToCreate.Any()) return 0;
            
            CentralOpsDbContext.ChangeTracker.AutoDetectChangesEnabled = false;
            await CentralOpsDbContext.BulkInsertAsync(entitiesToCreate.ToList());
            return entitiesToCreate.Count();
        }

        public async Task<int> BulkDeleteCentralOpsEntities(IEnumerable<dynamic> entitiesToDelete)
        {
            if (!entitiesToDelete.Any()) return 0;
            CentralOpsDbContext.ChangeTracker.AutoDetectChangesEnabled = false;
            await CentralOpsDbContext.BulkDeleteAsync(entitiesToDelete.ToList());
            int numDeleted = entitiesToDelete.Count();
            
            return numDeleted;
        }

        public async Task<int> BulkUpdateCentralOpsEntities(IEnumerable<dynamic> entitiesToUpdate)
        {
            if (!entitiesToUpdate.Any()) return 0;
            CentralOpsDbContext.ChangeTracker.AutoDetectChangesEnabled = false;
            await CentralOpsDbContext.BulkUpdateAsync(entitiesToUpdate.ToList());
            return entitiesToUpdate.Count();
        }
    }
}
