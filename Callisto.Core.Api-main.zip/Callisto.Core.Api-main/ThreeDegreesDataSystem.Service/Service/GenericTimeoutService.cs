﻿using Azure.Identity;
using Azure.Storage.Blobs;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Common.Readers;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using NPOI.XSSF.UserModel;
using System.Linq;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class GenericTimeoutService : Service, IGenericTimeoutService
    {
        public GenericTimeoutService(CentralOpsDbContext centralOpsContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsContext, dwDbContext, baseLogger)
        { }

        public int GetTimeout(int taskId)
        {
            string typeCode = DataMap.GetTaskCode(taskId);
            return CentralOpsDbContext.GenericTimeouts
                .Where(gt => gt.TypeCode == typeCode)
                .Single().Value;
        }

        public int GetTimeout(string typeCode)
        {
            return CentralOpsDbContext.GenericTimeouts
                .Where(gt => gt.TypeCode == typeCode)
                .Single().Value;
        }
    }
}
