﻿using Azure.Storage.Blobs.Models;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;
using Microsoft.Extensions.Logging;
using ThreeDegreesDataSystem.Service.Interface;
using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ThreeDegreesDataSystem.Models.DwModels;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class DateDimService: Service, IDateDimService
    {
        public DateDimService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
           
        }
        //test the IsUsBusinessDate method by passing in a date and checking if it returns true or false based on the IsUsBusinessDay column in the DateDims table
        public async Task<bool> IsUsBusinessDate(DateTime processDate)
        {
            try
            {
                var date = await DwDbContext.DimDates.FirstOrDefaultAsync(x => x.Date == DateOnly.FromDateTime(processDate));
                if (date != null)
                {
                    return date.UsBusinessDayFlag;
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception($"Couldn't retrieve date: {ex.Message}");
            }
        }
    }
}
