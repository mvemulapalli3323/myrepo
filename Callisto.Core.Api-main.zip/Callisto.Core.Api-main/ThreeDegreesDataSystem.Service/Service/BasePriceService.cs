﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using System.Globalization;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using OfficeOpenXml;
using Microsoft.EntityFrameworkCore;
using ThreeDegreesDataSystem.Connectors.Argus;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Connectors.Interface;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;
//using Row = DocumentFormat.OpenXml.Spreadsheet.Row;
//using Cell = DocumentFormat.OpenXml.Spreadsheet.Cell;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class BasePriceService : Service
    {
        public BasePriceService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
            
        }
        public static string GetCellValue(WorkbookPart wbPart, Cell theCell)
        {
            string value = null;

            if (theCell == null)
            {
                return null;
            }

            // If the cell does not exist, return an empty string.
            if (theCell.InnerText.Length > 0)
            {
                value = theCell.InnerText;

                // If the cell represents an integer number, you are done. 
                // For dates, this code returns the serialized value that 
                // represents the date. The code handles strings and 
                // Booleans individually. For shared strings, the code 
                // looks up the corresponding value in the shared string 
                // table. For Booleans, the code converts the value into 
                // the words TRUE or FALSE.
                if (theCell.DataType != null)
                {
                    if (theCell.DataType.Value == CellValues.SharedString)
                    {
                        // For shared strings, look up the value in the shared strings table.
                        var stringTable =
                            wbPart.GetPartsOfType<SharedStringTablePart>()
                                .FirstOrDefault();

                        // If the shared string table is missing, something is wrong. Return the index that is in
                        // the cell. Otherwise, look up the correct text in the table.
                        if (stringTable != null)
                        {
                            value =
                                stringTable.SharedStringTable
                                    .ElementAt(int.Parse(value)).InnerText;
                        }
                    }
                    else if (theCell.DataType.Value == CellValues.Boolean)
                    {
                        switch (value)
                        {
                            case "0":
                                value = "FALSE";
                                break;
                            default:
                                value = "TRUE";
                                break;
                        }
                    }
                }
            }
            return value;
        }
    }
}


