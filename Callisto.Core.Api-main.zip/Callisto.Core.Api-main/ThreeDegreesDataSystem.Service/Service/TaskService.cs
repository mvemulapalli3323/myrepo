﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class TaskService : Service, ITaskService
    {
        public TaskService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger) { }

        public async Task<Dictionary<int, string>> GetTaskIdCodeMap()
        {
            Dictionary<int, string> map = new();
            var tasks = await GetCentralOpsEntities<Models.Models.Task>().AsNoTracking().ToListAsync();
            foreach (var t in tasks)
            {
                System.Diagnostics.Debug.WriteLine($"Adding new kv pair to map {t.TaskId}:{t.TaskCode}");
                map.Add(t.TaskId, t.TaskCode);
            }
            return map;
        }

        public async Task<Models.Models.Task[]> GetTasks(bool topOnly = false, bool uiOnly = false)
        {
            IQueryable<Models.Models.Task> tasks = GetCentralOpsEntities<Models.Models.Task>().Where(t => t.IsActive).AsNoTracking();
            tasks = topOnly
                ? tasks.Include(t => t.ParentTasks).Where(t => !t.ParentTasks.Any())
                : tasks;
            tasks = uiOnly
                ? tasks.Where(t => t.IsUiProcess == true)
                : tasks;

            return await tasks.ToArrayAsync();
        }

        public async Task<Models.Models.Task> GetTask(int taskId)
        {
            return await GetCentralOpsEntities<Models.Models.Task>().AsNoTracking()
                .FirstOrDefaultAsync(t => t.TaskId == taskId);
        }

        public async Task<Models.Models.Task> GetTask(string taskCode)
        {
            return await GetCentralOpsEntities<Models.Models.Task>().AsNoTracking()
                .FirstOrDefaultAsync(t => t.TaskCode == taskCode);
        }

        public int GetTaskId(string taskCode)
        {
            return GetCentralOpsEntities<Models.Models.Task>().AsNoTracking()
                .Where(t => t.TaskCode == taskCode)
                .Single()
                .TaskId;
        }

        public async Task<Models.Models.Task> GetTaskInclusive(int taskId)
        {
            return await GetCentralOpsEntities<Models.Models.Task>().AsNoTracking()
                .Include(t => t.Subtasks)
                    .ThenInclude(s => s.Subtask)
                .FirstOrDefaultAsync(t => t.TaskId == taskId);
        }

        public async Task<Models.Models.TaskSubtask[]> GetTaskSubtasks(int taskId)
        {
            return await CentralOpsDbContext.TaskSubtasks.Where(ts => ts.TaskId == taskId)
                .Include(ts => ts.Subtask)
                .OrderBy(ts => ts.Step)
                .ToArrayAsync();
        }

        public bool IsRunning(int taskId)
        {
            return CentralOpsDbContext.TaskRuns.AsNoTracking()
                .Where(tr => tr.TaskId == taskId && tr.StatusId == DataMap.GetStatusId(StringConstants.InProgress))
                .Any();
        }
    }
}
