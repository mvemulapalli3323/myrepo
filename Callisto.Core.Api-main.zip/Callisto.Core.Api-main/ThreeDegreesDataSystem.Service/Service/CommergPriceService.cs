﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.EntityFrameworkCore;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class CommergPriceService : BasePriceService, ICommergPriceService
    {
        public CommergPriceService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<BasePriceService> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
            
        }

        public async Task<string> LoadCommergPricesToDb(BlobFileReaderParameters blobFileReaderParameters)
        {
            var prices = new List<BrokerPriceQuote>();
            var commergMapper = await CentralOpsDbContext.GenericMaps.Where(m => m.TypeCode == "CommergMap").ToDictionaryAsync(m => m.Value1, m => m.Value2);
            
            var downloadedFilePath = await AzureConnector.DownloadBlob(blobFileReaderParameters.ContainerName, blobFileReaderParameters.FileName);

            var commergProducts = GetCommergData(downloadedFilePath, commergMapper);
            prices.AddRange(commergProducts);

            prices.ForEach(price => price.TaskRunId = blobFileReaderParameters.TaskRunId);

            var pricesLoaded = await BulkCreateCentralOpsEntities(prices);
           
            return $"Succefully loaded {pricesLoaded}.";
        }
        
        private static List<BrokerPriceQuote> GetCommergData(string brokerFilePath, Dictionary<string, string> commergMapper)
        {
            string _bid = commergMapper.Where(c => c.Key == "Bid").Select(c => c.Value).FirstOrDefault();
            string _ask = commergMapper.Where(c => c.Key == "Ask").Select(c => c.Value).FirstOrDefault();
            string _sett = commergMapper.Where(c => c.Key == "Sett").Select(c => c.Value).FirstOrDefault();

            List<BrokerPriceQuote> products = new List<BrokerPriceQuote>();
            List<(DateTime Valuedate, string Product, string Vintage, string Pricetype, decimal Price, DateTime Uploaddate)> rawProds = new List<(DateTime Valuedate, string Product, string Vintage, string Pricetype, decimal Price, DateTime Uploaddate)>();
            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(brokerFilePath, false))
            {
                WorkbookPart wbPart = spreadsheetDocument.WorkbookPart;
                int rowCnt = 0;
                int worksheetPartsCount = 0;
                foreach (WorksheetPart worksheetPart in wbPart.WorksheetParts)
                {
                    worksheetPartsCount++;

                    SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();

                    int totalRowCnt = sheetData.Elements<Row>().Count();

                    for (int r = 1; r < totalRowCnt; r++)
                    {
                        rowCnt++;
                        var row = sheetData.Elements<Row>().ElementAt(r);
                        int cellCnt = 0;
                        int totalCellCnt = row.Elements<Cell>().Count();
                        (DateTime Valuedate, string Product, string Vintage, string Pricetype, decimal Price, DateTime Uploaddate) dataRow = new();
                        for (int i = 0; i < totalCellCnt; i++)
                        {
                            cellCnt++;
                            Cell cell_1 = row.Elements<Cell>().ElementAt(i);

                            var cell_1_Value = GetCellValue(wbPart, cell_1);
                            if (i == 0 && string.IsNullOrEmpty(cell_1_Value))
                                break;

                            // Create new DateTime, January 1st 1900
                            var dt = new DateTime(1900, 1, 1);
                            var s = dt.ToString();

                            switch (i)
                            {
                                case 0:
                                    if (double.TryParse(cell_1_Value, out double AddDays1))
                                    {
                                        dt = dt.AddDays(AddDays1 - 2);
                                        dataRow.Valuedate = dt;
                                    }
                                    break;
                                case 1:
                                    dataRow.Product = cell_1_Value.ToString();
                                    break;
                                case 2:
                                    dataRow.Vintage = cell_1_Value.ToString();
                                    break;
                                case 3:
                                    dataRow.Pricetype = cell_1_Value.ToString();
                                    break;
                                case 4:
                                    decimal.TryParse(cell_1_Value, out dataRow.Price);
                                    break;
                                case 5:
                                    if (double.TryParse(cell_1_Value, out double AddDays2))
                                    {
                                        dt = dt.AddDays(AddDays2 - 2);
                                        dataRow.Uploaddate = dt;
                                    }
                                    break;
                            }
                        }
                        rawProds.Add(dataRow);
                    }
                    //group the products
                    var bids = rawProds.Where(c => c.Pricetype == _bid).ToList();
                    var asks = rawProds.Where(c => c.Pricetype == _ask).ToList();
                    var setts = rawProds.Where(c => c.Pricetype == _sett).ToList();
                    
                    foreach (var b in bids)
                    {
                        products.Add(new BrokerPriceQuote
                        {
                            BrokerName = "Commerg",
                            Exchange = string.Empty,
                            ProductName = b.Product,
                            Term = b.Vintage,
                            BidValue = b.Price,
                            AskValue = asks.Where(c => c.Valuedate == b.Valuedate
                                                    && c.Product == b.Product && c.Vintage == b.Vintage
                                                    && c.Uploaddate == b.Uploaddate).FirstOrDefault().Price,
                            MidValue = setts.Where(c => c.Valuedate == b.Valuedate
                                                    && c.Product == b.Product && c.Vintage == b.Vintage
                                                    && c.Uploaddate == b.Uploaddate).FirstOrDefault().Price,
                            ValueDate = b.Valuedate,
                            UploadDate = DateTime.Now

                        });
                    }
                }
            }
            return products;
        }
    }
}


