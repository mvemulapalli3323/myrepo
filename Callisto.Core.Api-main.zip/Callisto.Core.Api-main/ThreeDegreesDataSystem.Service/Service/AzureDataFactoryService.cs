﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class AzureDataFactoryService : Service, IAzureDataFactoryService
    {
        public AzureDataFactoryService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
            
        }
    }
}
