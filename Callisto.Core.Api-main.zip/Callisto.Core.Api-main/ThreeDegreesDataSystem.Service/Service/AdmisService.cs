﻿using Azure.Storage.Blobs.Models;
using ThreeDegreesDataSystem.Common.Extensions;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;
using Microsoft.Extensions.Logging;
using ThreeDegreesDataSystem.Service.Interface;
using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ThreeDegreesDataSystem.Models.DwModels;
using System.Text.RegularExpressions;
using ThreeDegreesDataSystem.Common;
using NPOI.SS.Formula.Functions;
using System.Text;
using MathNet.Numerics;
using Org.BouncyCastle.Utilities.Encoders;
using ThreeDegreesDataSystem.Common.ReturnValues;
using ThreeDegreesDataSystem.Common.Exceptions;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class AdmisService : Service, IAdmisService
    {
        private readonly ILogger<AdmisService> _admisLogger;
        public AdmisService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext,ILogger<Service> baseLogger, ILogger<AdmisService> admisLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
            _admisLogger = admisLogger;
        }

        public async Task<IEnumerable<AdmisMappingHistory>> GetAdmisMappingHistory()
        {
            try
            {
                return await CentralOpsDbContext.Set<AdmisMapping>().TemporalAll()
                   .Select(e => new AdmisMappingHistory
                   {
                       AdmisMappingId = e.AdmisMappingId,
                       AdmisContract = e.AdmisContract,
                       ArtemisProduct = e.ArtemisProduct,
                       Vintage = e.Vintage,
                       ValidFrom = EF.Property<DateTime>(e, "ValidFrom"),
                       ValidTo = EF.Property<DateTime>(e, "ValidTo")
                   })
                   .OrderByDescending(h => h.ValidTo).ToListAsync();
            }
            catch (Exception ex)
            {
                _admisLogger.LogError(ex, "Error retrieving AdmisMapping history");
                throw new Exception($"Couldn't retrieve AdmisMapping history.");
            }
        }

        public async Task<string> UpdateAdmisProductDimensions(int taskunId)
        {
            try
            {
                List<AdmisMapping> admisMapping = await CentralOpsDbContext.AdmisMappings
                    .AsNoTracking()
                    .ToListAsync();

                Dictionary<string, DimAdmisProduct> admisProducts = await DwDbContext.DimAdmisProducts
                    .Where(p => p.ActiveFlag)
                    .AsNoTracking()
                    .ToDictionaryAsync(t => t.AdmisContractName, t => t);

                List<DimAdmisProduct> newProducts = new List<DimAdmisProduct>();
                List<DimAdmisProduct> updatedProducts = new List<DimAdmisProduct>();

                admisMapping.ForEach(admisMapping =>
                {
                    if (admisProducts.ContainsKey(admisMapping.AdmisContract))
                    {
                        var existingProduct = admisProducts[admisMapping.AdmisContract];
                        if (existingProduct.ProductName.Trim() != admisMapping.ArtemisProduct.Trim() || existingProduct.Vintage.Trim() != admisMapping.Vintage.Trim())
                        {
                            //update existing AdmisProductDim
                            existingProduct.ProductName = admisMapping.ArtemisProduct.Trim();
                            existingProduct.Vintage = admisMapping.Vintage.Trim();
                            existingProduct.LastModifiedDate = DateTime.UtcNow;
                            existingProduct.LastModifiedBy = "UpdateAdmisProductDimensions Task";
                            existingProduct.ValidTo = DateTime.UtcNow.Date.AddDays(-1);
                            existingProduct.ActiveFlag = false;
                            existingProduct.TaskRunId = taskunId;
                            updatedProducts.Add(existingProduct);
                            //add new record that is current since the existing one is not current anymore
                            newProducts.Add(CreateNewAdmisProductDim(admisMapping, taskunId));
                        }
                    }
                    //if admis product not found create a new AdmisProductDim
                    else
                    {
                        newProducts.Add(CreateNewAdmisProductDim(admisMapping, taskunId));
                    }
                });

                await BulkUpdateDwEntities(updatedProducts);
                await BulkCreateDwEntities(newProducts);

                return StringConstants.Succeeded;

            }
            catch (Exception ex)
            {
                _admisLogger.LogError($"Couldn't update Admis product mapping: {ex.Message}");
                throw new Exception($"Couldn't update Admis product mapping");
            }
        }

        private DimAdmisProduct CreateNewAdmisProductDim(AdmisMapping admisMapping, int taskRunId)
        {
            return new DimAdmisProduct
            {
                AdmisContractName = admisMapping.AdmisContract,
                ProductName = admisMapping.ArtemisProduct,
                Vintage = admisMapping.Vintage,
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "UpdateAdmisProductDimensions Task",
                ValidFrom = DateTime.UtcNow.Date,
                ValidTo = DateTime.MaxValue,
                ActiveFlag = true,
                LastModifiedDate = DateTime.UtcNow,
                LastModifiedBy = "UpdateAdmisProductDimensions Task",
                TaskRunId = taskRunId
            };
        }

        public async Task<string> CreateAdmisDailyFacts(int taskRunId, int admisDbLoadTaskRunId, DateOnly businessDate)
        {
            try
            {
                StringBuilder message = new StringBuilder();

                Dictionary<DateOnly, DimDate> dateMapping = await DwDbContext.DimDates
                    .AsNoTracking()
                    .ToDictionaryAsync(t => t.Date, t => t);

                Dictionary<string, DimCurrency> currencyMapping = await DwDbContext.DimCurrencies
                    .AsNoTracking()
                    .ToDictionaryAsync(t => t.CurrencyCode, t => t);

                Dictionary<string, DimAdmisProduct> productMapping = await DwDbContext.DimAdmisProducts.Where(p => p.ActiveFlag)
                    .AsNoTracking()
                    .ToDictionaryAsync(t => t.AdmisContractName, t => t);

                Dictionary<string, DimPositionDirection> positionDirectionMapping = await DwDbContext.DimPositionDirections
                    .AsNoTracking()
                    .ToDictionaryAsync(t => t.PositionDirectionName, t => t);

                Dictionary<string, DimExchange> exchangeMapping = await DwDbContext.DimExchanges.Where(p => p.ActiveFlag)
                    .AsNoTracking()
                    .ToDictionaryAsync(t => t.ExchangeCode, t => t);

                Dictionary<string, DimSettleType> settleTypeMapping = await DwDbContext.DimSettleTypes
                    .AsNoTracking()
                    .ToDictionaryAsync(t => t.SettleTypeCode, t => t);

                //admis data
                List<AdmisDaily> admisDailyData = await CentralOpsDbContext.AdmisDailies.Where(t => t.TaskRunId == admisDbLoadTaskRunId)
                    .AsNoTracking()
                    .ToListAsync();

                List<Adatmny> adatmnies = await CentralOpsDbContext.Adatmnies.Where(t => t.TaskRunId == admisDbLoadTaskRunId)
                    .AsNoTracking()
                    .ToListAsync();

                Dictionary<string, decimal> fxRates = new Dictionary<string, decimal>();
                adatmnies.ForEach(adatmn =>
                {
                    if (!fxRates.ContainsKey(adatmn.AcctBaseCurrCode))
                    {
                        fxRates.Add(adatmn.AcctBaseCurrCode, adatmn.ConvRateToAcctBaseCurr.GetValueOrDefault());
                    }
                });

                //remove leading and trailing whitespace and more than a single whitespace between characters
                admisDailyData.ForEach(admisDaily =>
                {
                    admisDaily.ContDesc = !string.IsNullOrEmpty(admisDaily.ContDesc) ? Regex.Replace(admisDaily.ContDesc, @"\s{2,}", " ").Trim() : admisDaily.ContDesc;
                });

                List<string> unmappedProducts = GetUnmappedProducts(admisDailyData, productMapping);

                if (unmappedProducts.Count > 0)
                {
                    throw new AdmisException($"Unmapped products found: {string.Join(", ", unmappedProducts)}");
                }

                AdmisFactSummary openPositionSummary = await CreateAdmisOpenPositionFacts(
                    admisDailyData.Where(d => d.FileType.ToLower() == StringConstants.AdatPos).ToList(),
                    currencyMapping,
                    productMapping,
                    positionDirectionMapping,
                    exchangeMapping,
                    dateMapping[businessDate].DimDateId,
                    taskRunId
                );

                AdmisFactSummary dailySettleSummary = await CreateAdmisDailySettleFacts(
                     admisDailyData.Where(d => d.FileType.ToLower() == StringConstants.AdatPas).ToList(),
                     currencyMapping,
                     productMapping,
                     settleTypeMapping,
                     dateMapping[businessDate].DimDateId,
                     taskRunId
                 );

                AdmisFactSummary dailyTradeSummary = await CreateAdmisDailyTradeFacts(
                    admisDailyData.Where(d => d.FileType.ToLower() == StringConstants.AdatDtn && d.RecId.Trim() == "T").ToList(),
                    productMapping,
                    dateMapping[businessDate].DimDateId,
                    taskRunId
                );

                AdmisFactSummary accountSummary = await CreateAdmisAccountFacts(
                    adatmnies,
                    dateMapping[businessDate].DimDateId,
                    taskRunId
                );

                message.AppendLine($"Open position facts created:{openPositionSummary.FactCount},");
                message.AppendLine($"Open position source quantity:{Math.Round(openPositionSummary.TotalQuantityRaw)},");
                message.AppendLine($"Open position fact quantity:{Math.Round(openPositionSummary.TotalQuantityFact)},");
                message.AppendLine($"Open position quantity difference:{Math.Round(openPositionSummary.TotalQuantityDiff())},");
                
                message.AppendLine($"Daily settle facts created:{dailySettleSummary.FactCount},");
                //message.AppendLine($"Daily settle source quantity:{Math.Round(dailySettleSummary.TotalQuantityRaw)},");
                //message.AppendLine($"Daily settle fact quantity:{Math.Round(dailySettleSummary.TotalQuantityFact)},");
                //message.AppendLine($"Daily settle quantity difference:{Math.Round(dailySettleSummary.TotalQuantityDiff())},");

                message.AppendLine($"Daily trade facts created:{dailyTradeSummary.FactCount},");
                //message.AppendLine($"Daily trade source quantity:{Math.Round(dailyTradeSummary.TotalQuantityRaw)},");
                //message.AppendLine($"Daily trade fact quantity:{Math.Round(dailyTradeSummary.TotalQuantityFact)},");
                //message.AppendLine($"Daily trade quantity difference:{Math.Round(dailyTradeSummary.TotalQuantityDiff())},");

                message.AppendLine($"Account facts created:{accountSummary.FactCount}");
                //message.AppendLine($"Account source open equity:{Math.Round(accountSummary.TotalQuantityRaw)},");
                //message.AppendLine($"Account fact open equity:{Math.Round(accountSummary.TotalQuantityFact)},");
                //message.AppendLine($"Account open equity difference:{Math.Round(accountSummary.TotalQuantityDiff())},");

                _admisLogger.LogInformation($"Admis Daily Facts created successfully. {message}");
                return message.ToString();
            }
            catch (AdmisException admisEx)
            {
                _admisLogger.LogError($"Admis Exception: {admisEx.Message}");
                throw;
            }
            catch (Exception ex)
            {
                _admisLogger.LogError($"Couldn't create Admis fact data: {ex.Message}");
                throw new Exception($"Couldn't create Admis fact data: {ex.Message}");
            }
        }
        private List<string> GetUnmappedProducts(List<AdmisDaily> admisDailyData, Dictionary<string, DimAdmisProduct> productMapping)
        {
            var unmappedProducts = new List<string>();
            foreach(var row in admisDailyData.Where(d => d.FileType.ToLower() == StringConstants.AdatPos || d.FileType.ToLower() == StringConstants.AdatPas || d.FileType.ToLower() == StringConstants.AdatDtn).ToList())
            {
                if (row.FileType.ToLower() == StringConstants.AdatDtn && row.RecId != "T")
                {
                    continue; // Skip non-trade records in AdatDtnco
                }
                  
                if (!productMapping.ContainsKey(row.ContDesc))
                {
                    unmappedProducts.Add(row.ContDesc);
                }
            }

            return unmappedProducts.Distinct().ToList();
        }
        private async Task<AdmisFactSummary> CreateAdmisOpenPositionFacts(
            List<AdmisDaily> admisDailyData,
            Dictionary<string, DimCurrency> currencyMapping,
            Dictionary<string, DimAdmisProduct> productMapping,
            Dictionary<string, DimPositionDirection> positionDirectionMapping,
            Dictionary<string, DimExchange> exchangeMapping,
            int businessDateKey,
            int taskRunId
            )
        {
            AdmisFactSummary openPositionsSummary = new ();
            
            var groupedOpenPositions = admisDailyData.GroupBy(admisDaily => new
            {
                DateKey = businessDateKey,
                AdmisProductKey = GetProductKey(admisDaily.ContDesc, productMapping),
                PositionDirectionKey = GetPositionDirectionKey(admisDaily.BuySell, positionDirectionMapping),
                ExchangeKey = GetExchangeKey(admisDaily.ContDesc, exchangeMapping),
                CurrencyKey = GetCurrencyKey(admisDaily.ProdCurrSym, currencyMapping),
                AccountNumber = admisDaily.Acct.ToString()
            }, (key, group) => new
            {
                key.DateKey,
                key.AdmisProductKey,
                key.PositionDirectionKey,
                key.ExchangeKey,
                key.CurrencyKey,    
                key.AccountNumber,
                Quantity = group.Sum(g => g.TrdQty * g.Mult),
                TradeQuantity = group.Sum(g => g.TrdQty),
                NotionalValue = group.Sum(g => g.TrdQty * g.Mult * g.TrdPrc),
                TradePrice = group.Sum(g => g.TrdQty * g.Mult * g.TrdPrc).SafeDivide(group.Sum(g => g.TrdQty * g.Mult)),
                Mtm = group.Sum(g => (g.ClsPrc - g.TrdPrc) * g.TrdQty * g.Mult)
            });

            List<dynamic> admisOpenPositionFacts = new();

            groupedOpenPositions.ToList().ForEach(group =>
            {
                admisOpenPositionFacts.Add(new FactAdmisOpenPosition
                {
                    DimDateId = group.DateKey,
                    DimAdmisProductId = group.AdmisProductKey,
                    DimPositionDirectionId = group.PositionDirectionKey,
                    DimExchangeId = group.ExchangeKey,
                    DimCurrencyId = group.CurrencyKey,
                    AccountNumber = group.AccountNumber,
                    Quantity = group.Quantity.GetValueOrDefault(),
                    TradeQuantity = group.TradeQuantity.GetValueOrDefault(),
                    NotionalValue = group.NotionalValue.GetValueOrDefault(),
                    TradePrice = group.TradePrice,
                    ClosePrice = 0m, 
                    Mtm = group.Mtm.GetValueOrDefault(),
                    StrikePrice = 0,
                    Multiplier = 1,
                    PutCall = "N/A",
                    ActiveFlag = true,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "CreateAdmisDailyOpenPositions Task", 
                    TaskRunId = taskRunId
                });
            });

            // Bulk create open position facts
            await BulkCreateDwEntities(admisOpenPositionFacts);
            var previousOpenPositionFacts = await DwDbContext.FactAdmisOpenPositions
                .Where(f => f.DimDateId == businessDateKey && f.TaskRunId != taskRunId)
                .ToListAsync();

            //set all previous facts to IsCurrent = false for the same business date
            previousOpenPositionFacts.ForEach(fact =>
            {
                fact.ActiveFlag = false;
            });

            await BulkUpdateDwEntities(previousOpenPositionFacts);
            
            openPositionsSummary.FactCount = admisOpenPositionFacts.Count();
            openPositionsSummary.TotalQuantityRaw = admisDailyData.Sum(d=> d.TrdQty * d.Mult).GetValueOrDefault(0);
            openPositionsSummary.TotalQuantityFact = admisOpenPositionFacts.Sum(d => (decimal)d.Quantity);

            return openPositionsSummary;
        }

        private async Task<AdmisFactSummary> CreateAdmisDailySettleFacts(
            List<AdmisDaily> admisDailyData,
            Dictionary<string, DimCurrency> currencyMapping,
            Dictionary<string, DimAdmisProduct> productMapping,
            Dictionary<string, DimSettleType> settleTypeMapping,
            int businessDateKey,
            int taskRunId
            )
        {
            AdmisFactSummary dailySettleSummary = new();

            var groupedDailySettles = admisDailyData.GroupBy(admisDaily => new
            {
                DateKey = businessDateKey,
                AdmisProductKey = GetProductKey(admisDaily.ContDesc, productMapping),
                CurrencyKey = GetCurrencyKey(admisDaily.ProdCurrSym, currencyMapping),
                SettleTypeKey = GetSettleTypeKey(admisDaily.SprdCode, settleTypeMapping),
                AccountNumber = admisDaily.Acct.ToString()
            }, (key, group) => new
            {
                key.DateKey,
                key.AdmisProductKey,
                key.CurrencyKey,
                key.SettleTypeKey,
                key.AccountNumber,
                Quantity = group.Sum(g => g.TrdQty * g.Mult),
                LongNotionalValueLocal = group.Sum(g => g.BuySell == "1" ? g.TrdQty * g.Mult * g.TrdPrc : 0),
                LongNotionalValueUsd = group.Sum(g => g.BuySell == "1" ? g.TrdQty * g.Mult * g.TrdPrc : 0),
                ShortNotionalValueLocal = group.Sum(g => g.BuySell == "2" ? g.TrdQty * g.Mult * g.TrdPrc : 0),
                ShortNotionalValueUsd = group.Sum(g => g.BuySell == "2" ? g.TrdQty * g.Mult * g.TrdPrc : 0),
                SettledMarginLocal = group.Sum(g => g.BuySell == "1" ? g.TrdQty * g.Mult * g.TrdPrc * -1 : g.TrdQty * g.Mult * g.TrdPrc),
                SettledMarginUsd = group.Sum(g => g.BuySell == "1" ? g.TrdQty * g.Mult * g.TrdPrc * -1 : g.TrdQty * g.Mult * g.TrdPrc),
                
            });

            List<dynamic> admisDailySettleFacts = new();

            groupedDailySettles.ToList().ForEach(group =>
            {
                admisDailySettleFacts.Add(new FactAdmisDailySettle
                {
                    DimDateId = group.DateKey,
                    DimAdmisProductId = group.AdmisProductKey,
                    DimCurrencyId = group.CurrencyKey,
                    DimSettleTypeId = group.SettleTypeKey,
                    AccountNumber = group.AccountNumber,
                    Quantity = group.Quantity.GetValueOrDefault(),
                    LongNotionalValueLocal = group.LongNotionalValueLocal.GetValueOrDefault(),
                    LongNotionalValueUsd = group.LongNotionalValueUsd.GetValueOrDefault(),
                    ShortNotionalValueLocal = group.ShortNotionalValueLocal.GetValueOrDefault(),
                    ShortNotionalValueUsd = group.ShortNotionalValueUsd.GetValueOrDefault(),
                    SettledMarginLocal = group.SettledMarginLocal.GetValueOrDefault(),
                    SettledMarginUsd = group.SettledMarginUsd.GetValueOrDefault(),
                    SettledMarginUsdPct = (group.ShortNotionalValueUsd.GetValueOrDefault() - group.LongNotionalValueUsd.GetValueOrDefault()).SafeDivide(group.LongNotionalValueUsd.GetValueOrDefault()),
                    ActiveFlag = true,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "CreateAdmisDailySettleFacts Task",
                    TaskRunId = taskRunId
                });
            });

            // Bulk create open position facts
            await BulkCreateDwEntities(admisDailySettleFacts);
            var previousDailySettleFacts = await DwDbContext.FactAdmisDailySettles
                .Where(f => f.DimDateId == businessDateKey && f.TaskRunId != taskRunId)
                .ToListAsync();

            //set all previous facts to IsCurrent = false for the same business date
            previousDailySettleFacts.ForEach(fact =>
            {
                fact.ActiveFlag = false;
            });

            await BulkUpdateDwEntities(previousDailySettleFacts);

            dailySettleSummary.FactCount = admisDailySettleFacts.Count();
            dailySettleSummary.TotalQuantityRaw = admisDailyData.Sum(d => d.TrdQty * d.Mult).GetValueOrDefault(0);
            dailySettleSummary.TotalQuantityFact = admisDailySettleFacts.Sum(d => (decimal)d.Quantity);

            return dailySettleSummary;
        }

        private async Task<AdmisFactSummary> CreateAdmisDailyTradeFacts(
            List<AdmisDaily> admisDailyData,
            Dictionary<string, DimAdmisProduct> productMapping,
            int businessDateKey,
            int taskRunId
            )
        {
            AdmisFactSummary dailyTradeSummary = new();

            var groupedDailyTrades = admisDailyData.GroupBy(admisDaily => new
            {
                DateKey = businessDateKey,
                AdmisProductKey = GetProductKey(admisDaily.ContDesc, productMapping),
                AccountNumber = admisDaily.Acct.ToString()
            }, (key, group) => new
            {
                key.DateKey,
                key.AdmisProductKey,
                key.AccountNumber,
                LongQuantity = group.Sum(g => g.BuySell == "1" ? g.TrdQty * g.Mult : 0),
                LongNotionalValue = group.Sum(g => g.BuySell == "1" ? g.TrdQty * g.Mult * g.TrdPrc : 0),
                LongWeightedAverageTradePrice = group.Sum(g => g.BuySell == "1" ? (g.TrdQty * g.TrdPrc).SafeDivide(group.Sum(g => g.TrdQty)) : 0),
                ShortQuantity = group.Sum(g => g.BuySell == "2" ? g.TrdQty * g.Mult : 0),
                ShortNotionalValue = group.Sum(g => g.BuySell == "2" ? g.TrdQty * g.Mult * g.TrdPrc : 0),
                ShortWeightedAverageTradePrice = group.Sum(g => g.BuySell == "2" ? (g.TrdQty * g.TrdPrc).SafeDivide(group.Sum(g => g.TrdQty)) : 0),
                TradeCommissionFees = group.Sum(g => g.Comm),
                ExchangeFees = group.Sum(g => g.Fee1 + g.Fee2),
                NfaFees = group.Sum(g => g.Fee3 + g.Fee4 + g.Fee5 + g.Fee6 + g.Fee7 + g.Fee8 + g.Fee9 + g.GiGoChg + g.Brkg + g.OthFee + g.Gross + g.Net),
                CashEntries = group.Sum(g => g.RecId.ToUpper() == "C" ? g.Fee1 + g.Fee2 + g.Fee3 + g.Fee4 + g.Fee5 + g.Fee6 + g.Fee7 + g.Fee8 + g.Fee9 + g.GiGoChg + g.Brkg + g.OthFee + g.Gross + g.Net : 0),
                AdjustmentEntries = group.Sum(g => g.RecId.ToUpper() == "A" ? g.Fee1 + g.Fee2 + g.Fee3 + g.Fee4 + g.Fee5 + g.Fee6 + g.Fee7 + g.Fee8 + g.Fee9 + g.GiGoChg + g.Brkg + g.OthFee + g.Gross + g.Net : 0),
            });

            List<dynamic> admisDailyTradeFacts = new();

            groupedDailyTrades.ToList().ForEach(group =>
            {
                admisDailyTradeFacts.Add(new FactAdmisDailyTrade
                {
                    DimDateId = group.DateKey,
                    DimAdmisProductId = group.AdmisProductKey,
                    AccountNumber = group.AccountNumber,
                    LongQuantity = group.LongQuantity.GetValueOrDefault(),
                    LongNotionalValue = group.LongNotionalValue.GetValueOrDefault(),
                    LongWeightedAverageTradePrice = group.LongWeightedAverageTradePrice,
                    ShortQuantity = group.ShortQuantity.GetValueOrDefault(),
                    ShortNotionalValue = group.ShortNotionalValue.GetValueOrDefault(),
                    ShortWeightedAverageTradePrice = group.ShortWeightedAverageTradePrice,
                    TradeCommissionFees = group.TradeCommissionFees.GetValueOrDefault(),
                    ExchangeFees = group.ExchangeFees.GetValueOrDefault(),
                    NfaFees = group.NfaFees.GetValueOrDefault(),
                    CashEntries = group.CashEntries.GetValueOrDefault(),
                    AdjustmentEntries = group.AdjustmentEntries.GetValueOrDefault(),
                    ActiveFlag = true,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "CreateAdmisDailyTrades Task",
                    TaskRunId = taskRunId
                });
            });

            // Bulk create open position facts
            await BulkCreateDwEntities(admisDailyTradeFacts);
            var previousDailyTradesFacts = await DwDbContext.FactAdmisDailyTrades
                .Where(f => f.DimDateId == businessDateKey && f.TaskRunId != taskRunId)
                .ToListAsync();

            //set all previous facts to IsCurrent = false for the same business date
            previousDailyTradesFacts.ForEach(fact =>
            {
                fact.ActiveFlag = false;
            });

            await BulkUpdateDwEntities(previousDailyTradesFacts);

            dailyTradeSummary.FactCount = admisDailyTradeFacts.Count();
            dailyTradeSummary.TotalQuantityRaw = admisDailyData.Sum(d => d.TrdQty * d.Mult).GetValueOrDefault(0);
            dailyTradeSummary.TotalQuantityFact = admisDailyTradeFacts.Sum(d => (decimal)d.LongQuantity + (decimal)d.ShortQuantity);

            return dailyTradeSummary;
        }
        private async Task<AdmisFactSummary> CreateAdmisAccountFacts(
           List<Adatmny> admisMnyData,
           int businessDateKey,
           int taskRunId)
        {
            AdmisFactSummary accountSummary = new();

            // Use DwDbContext to retrieve the daily trade facts.
            // Group by AccountNumber and DateKey to sum the required fields.
            var commissionMap = await DwDbContext.FactAdmisDailyTrades
                .Where(d => d.TaskRunId == taskRunId)
                .GroupBy(d => new NewRecord(d.AccountNumber, d.DimDateId))
                .ToDictionaryAsync(
                    g => g.Key,
                    g => g.Sum(d => d.TradeCommissionFees + d.ExchangeFees + d.NfaFees + d.CashEntries + d.AdjustmentEntries)
                );

            // Step 2: Group the account-level financials from Adatmny (RecId = "M")
            var groupedAccountInfo = admisMnyData
                .Where(m => m.RecId.Trim().ToUpper() == "M")
                .GroupBy(m => new
                {
                    DateKey = businessDateKey,
                    AccountNumber = m.Acct.ToString()
                })
                .Select(g => new
                {
                    g.Key.DateKey,
                    g.Key.AccountNumber,
                    PreviousBalance = g.Sum(x => x.PrevAcctBalance),
                    OpenTradeEquity = g.Sum(x => x.OpenTradeEquity),
                    EndingBalance = g.Sum(x => x.AcctTotalEquity),
                    InitialMarginRequirement = g.Sum(x => x.FutInitMargin),
                    MaintenanceMarginRequirement = g.Sum(x => x.MarginExcessDeficit),
                    MarginExcessDeficit = g.Sum(x => x.MarginExcessDeficit)
                });

            List<FactAdmisAccount> admisAccountFacts = new();

            // Step 3: Build fact rows and apply commission per Account+DateKey
            foreach (var group in groupedAccountInfo)
            {
                // Variable to hold the calculated sum of commissions and fees
                decimal totalCommissionsAndFees = 0m;

                // Try to get the calculated sum from the new commissionMap
                commissionMap.TryGetValue(
                    new NewRecord(AccountNumber: group.AccountNumber, DateKey: group.DateKey),
                    out totalCommissionsAndFees
                );

                admisAccountFacts.Add(new FactAdmisAccount
                {
                    DimDateId = group.DateKey,
                    AccountNumber = group.AccountNumber,
                    PreviousBalance = group.PreviousBalance.GetValueOrDefault(),
                    // Assign the new calculated value here
                    CommissionsAndFees = totalCommissionsAndFees,
                    OpenTradeEquity = group.OpenTradeEquity.GetValueOrDefault(),
                    TradeProfitLoss = 0, // TODO: Add logic if available
                    EndingBalance = group.EndingBalance.GetValueOrDefault(),
                    InitialMarginRequirement = group.InitialMarginRequirement.GetValueOrDefault(),
                    MaintenanceMarginRequirement = group.MaintenanceMarginRequirement.GetValueOrDefault(),
                    MarginExcessDeficit = group.MarginExcessDeficit.GetValueOrDefault(),
                    ActiveFlag = true,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = "CreateAdmisAccountFacts Task",
                    TaskRunId = taskRunId
                });
            }

            // Step 4: Persist new facts
            await BulkCreateDwEntities(admisAccountFacts);

            // Step 5: Mark previous records for the same business date as not current
            var previousFacts = await DwDbContext.FactAdmisAccounts
                .Where(f => f.DimDateId == businessDateKey && f.TaskRunId != taskRunId)
                .ToListAsync();

            previousFacts.ForEach(fact => fact.ActiveFlag = false);
            await BulkUpdateDwEntities(previousFacts);

            // Step 6: Return summary
            accountSummary.FactCount = admisAccountFacts.Count;
            accountSummary.TotalQuantityRaw = admisMnyData.Sum(d => d.OpenTradeEquity).GetValueOrDefault(0);
            accountSummary.TotalQuantityFact = admisAccountFacts.Sum(d => d.OpenTradeEquity);

            return accountSummary;
        }
        private int GetProductKey(string admisContract, Dictionary<string, DimAdmisProduct> productMapping)
        {
            if (productMapping.TryGetValue(admisContract, out var mapping))
            {
                return mapping.DimAdmisProductId;
            }
            else
            { 
                _admisLogger.LogError($"Product mapping not found for contract: {admisContract}");
                throw new Exception($"Product mapping not found for contract: {admisContract}");
            }
        }

        private int GetCurrencyKey(string currencyCode, Dictionary<string, DimCurrency> currencyMapping)
        {
            if (currencyMapping.TryGetValue(currencyCode, out var mapping))
            {
                return mapping.DimCurrencyId;
            }
            else
            {
                _admisLogger.LogError($"Currency mapping not found for currency code: {currencyCode}");
                throw new Exception($"Currency mapping not found for currency code: {currencyCode}");
            }
        }

        private int GetSettleTypeKey(string sprdCode, Dictionary<string, DimSettleType> settleTypeMapping)
        {
            sprdCode = string.IsNullOrEmpty(sprdCode.Trim()) ? "T" : sprdCode.Trim().ToUpper();
            // Default to "T" if sprdCode is null or empty
            if (settleTypeMapping.TryGetValue(sprdCode, out var mapping))
            {
                return mapping.DimSettleTypeId;
            }
            else
            {
                _admisLogger.LogError($"Settle type mapping not found for SPRD code: {sprdCode}");
                throw new Exception($"Settle type mapping not found for SPRD code: {sprdCode}");
            }
        }

        private int GetPositionDirectionKey(string buySell, Dictionary<string, DimPositionDirection> positionDirectionMapping)
        {
            string direction = buySell == "1" ? "Long" : "Short";
            
            if (positionDirectionMapping.TryGetValue(direction, out var mapping))
            {
                return mapping.DimPositionDirectionId;
            }
            else
            {
                _admisLogger.LogError($"Position Direction mapping not found for buy/sell: {buySell}");
                throw new Exception($"Position Direction mapping not found for buy/sell: {buySell}");
            }
        }

        private int GetExchangeKey(string admisContract, Dictionary<string, DimExchange> exchangeMapping)
        {
            string exchangeCode = string.Empty;

            if (admisContract.ToUpper().Contains("ICE"))
            {
                exchangeCode = "ICE";
            }
            else if (admisContract.ToUpper().Contains("NEX"))
            {
                exchangeCode = "Nodal";
            }
            else
            {
                exchangeCode = "Other";
            }

            if (exchangeMapping.TryGetValue(exchangeCode, out var mapping))
            {
                return mapping.DimExchangeId;
            }
            else
            {
                _admisLogger.LogError($"Exchange mapping not found for exchange code: {exchangeCode}");
                throw new Exception($"Exchange mapping not found for exchange code: {exchangeCode}");
            }
        }
    }

    internal record NewRecord(string? AccountNumber, int DateKey);
}
