﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Readers;
using NPOI.HSSF.Record;
using CsvHelper;
using System.Text;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class DataCleansingService : Service, IDataCleansingService
    {
        public DataCleansingService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
            
        }

        public async Task<string> CleanCsvFile(CsvReaderParameters csvReaderParams)
        {
            var downloadedFilePath = await AzureConnector.DownloadBlob(csvReaderParams.ContainerName, csvReaderParams.FileName);

            // Parse csv file, returning if failed
            var reader = new Common.Readers.CsvReader();
            CsvReaderResult csvResult = reader.CsvToList(downloadedFilePath);

            if (csvResult.Status != StringConstants.Succeeded)
            {
                return csvResult.Message;
            }
            else
            {
                //remove header and footer rows
                csvResult.Data = csvResult.Data.Skip(csvReaderParams.HeaderRowsToRemove).SkipLast(csvReaderParams.FooterRowsToRemove).ToList();
                //add taskRunId column to file
                csvResult.Data = csvResult.Data.Select(row => row.Append(csvReaderParams.TaskRunId.ToString()).ToArray()).ToList();
                var lastIndex = csvResult.Data.First().Length - 1;
                csvResult.Data[0][lastIndex] = "TaskRunId";

                using var memStream = new MemoryStream();
                var writer = new StreamWriter(memStream);
                
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    var i = 0;
                    foreach (var row in csvResult.Data)
                    {
                        foreach (var item in row)
                        {
                            csv.WriteField(item);
                        }
                        i++;
                        csv.NextRecord();
                    }

                    writer.Flush();
                    
                    AzureConnector.UploadBlob(memStream, csvReaderParams.ContainerName, csvReaderParams.FileName.Replace(".csv","-clean.csv"));
                }
                
            }
            return StringConstants.Succeeded;
        }
    }
}
