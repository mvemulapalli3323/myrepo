﻿using Azure.Identity;
using Azure.Storage.Blobs;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class SelectOptionsService : Service, ISelectOptionsService
    {
        public SelectOptionsService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {

        }

        public async Task<List<SelectOption>> GetSelectOptions()
        {
            return await GetCentralOpsEntities<SelectOption>().AsNoTracking().Where(o => o.IsActive).ToListAsync();

        }

        public async Task<List<SelectOption>> GetSelectOptionsByTypeCode(string typeCode)
        {
            return await GetCentralOpsEntities<SelectOption>().AsNoTracking().Where(o => (o.SelectOptionTypeCode == typeCode)  && o.IsActive).ToListAsync();

        }


    }
}
