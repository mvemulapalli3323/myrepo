﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using System.Globalization;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using OfficeOpenXml;
using Microsoft.EntityFrameworkCore;
using ThreeDegreesDataSystem.Connectors.Argus;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Connectors.Interface;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;
//using Row = DocumentFormat.OpenXml.Spreadsheet.Row;
//using Cell = DocumentFormat.OpenXml.Spreadsheet.Cell;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class AmerexPriceService : BasePriceService, IAmerexPriceService
    {
        public AmerexPriceService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<BasePriceService> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {
            
        }

        public async Task<string> LoadAmerexPricesToDb(BlobFileReaderParameters blobFileReaderParameters)
        {
            var prices = new List<BrokerPriceQuote>();
            var amerexMapper = await CentralOpsDbContext.GenericMaps.Where(m => m.TypeCode == "AmerexMap").ToDictionaryAsync(m => m.Value1, m => m.Value2);
            
            var downloadedFilePath = await AzureConnector.DownloadBlob(blobFileReaderParameters.ContainerName, blobFileReaderParameters.FileName);

            var column1 = GetAmerexData(downloadedFilePath, amerexMapper, 1,
                                            new string[] { "B", "C", "D", "E" });
            var column2 = GetAmerexData(downloadedFilePath, amerexMapper, 2,
                new string[] { "H", "I", "J", "K" });
            var column3 = GetAmerexData(downloadedFilePath, amerexMapper, 3,
                new string[] { "N", "O", "P", "Q" });
            var column4 = GetAmerexData(downloadedFilePath, amerexMapper, 4,
                new string[] { "T", "U", "V", "W" });
            var column5 = GetAmerexData(downloadedFilePath, amerexMapper, 5,
                new string[] { "Z", "AA", "AB", "AC" });
            var column6 = GetAmerexData(downloadedFilePath, amerexMapper, 6,
                new string[] { "AF", "AG", "AH", "AI" });

            prices.AddRange(column1);
            prices.AddRange(column2);
            prices.AddRange(column3);
            prices.AddRange(column4);
            prices.AddRange(column5);
            prices.AddRange(column6);

            prices.ForEach(price => price.TaskRunId = blobFileReaderParameters.TaskRunId);

            var pricesLoaded = await BulkCreateCentralOpsEntities(prices);
           
            return $"Succefully loaded {pricesLoaded}.";
        }
        private static List<(int row, int cell, string cellRef, string cellVal)> GetAmerexCategoriesInBlueCells(string brokerFilePath)
        {
            Dictionary<string, string> categoryValues = new Dictionary<string, string>();
            List<(int row, int cell, string cellRef, string cellVal)> categoryList
                = new List<(int row, int cell, string cellRef, string cellVal)>();
            string blueValue = null;
            int dataColPosition = 1;
            int rowCnt = 0;

            SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(brokerFilePath, false);

            ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
            //using (var package = new ExcelPackage(@"C:\chk.xlsx"))
            using (var package = new ExcelPackage(brokerFilePath))
            {
                WorkbookPart wbPart = spreadsheetDocument.WorkbookPart;
                ExcelWorkbook workbook = package.Workbook;

                ExcelWorksheet currentWorksheet = workbook.Worksheets.First();

                int worksheetPartsCount = 0;
                int cellStartPosition = (dataColPosition - 1) * 6;
                foreach (WorksheetPart worksheetPart in wbPart.WorksheetParts)
                {
                    SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();

                    int totalRowCnt = sheetData.Elements<Row>().Count();
                    for (int r = 0; r < totalRowCnt; r++)
                    {
                        rowCnt++;
                        var row = sheetData.Elements<Row>().ElementAt(r);
                        int cellCnt = 0;
                        int totalCellCnt = row.Elements<Cell>().Count();
                        int j = 0;
                        for (int i = cellStartPosition; i < totalCellCnt; i++)
                        {
                            var cell_1 = row.Elements<Cell>().ElementAt(i);

                            var cellColor = currentWorksheet.Cells[cell_1.CellReference].Style.Fill.BackgroundColor;
                            if (cellColor != null && cellColor.Rgb == "FF1F4A7E")
                            {
                                var cell_1_Value = GetCellValue(wbPart, cell_1);
                                if (cell_1_Value != null)
                                {
                                    categoryValues.Add(cell_1.CellReference, cell_1_Value);
                                    categoryList.Add((r, i, cell_1.CellReference, cell_1_Value));
                                }
                            }
                        }
                    }
                }

                return categoryList;
            }
        }

        private static string GetCategoryName(List<(int row, int cell, string cellRef, string cellVal)> categoryList,
          (int row, int cell, string subCategoryCellRef, string subCategoryName) subCategoryRef)
        {
            string categoryName = null;
            var categoryListSorted = categoryList.OrderByDescending(c => c.row).OrderByDescending(c => c.cell);
            foreach (var category in categoryListSorted)
            {
                if (subCategoryRef.row > category.row && subCategoryRef.cell >= category.cell)
                {
                    categoryName = category.cellVal;
                    break;
                }
            }

            return categoryName;
        }

        private static List<BrokerPriceQuote> GetAmerexData(string brokerFilePath, Dictionary<string, string> amerexMapper, int dataColPosition, string[] dataCols)
        {
            string _bid = amerexMapper.Where(c => c.Key == "Bid").Select(c => c.Value).FirstOrDefault();
            string _ask = amerexMapper.Where(c => c.Key == "Ask").Select(c => c.Value).FirstOrDefault();
            string _mid = amerexMapper.Where(c => c.Key == "Mid").Select(c => c.Value).FirstOrDefault();

            var categoryList = GetAmerexCategoriesInBlueCells(brokerFilePath);
            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(brokerFilePath, false))
            {
                WorkbookPart wbPart = spreadsheetDocument.WorkbookPart;
                int rowCnt = 0;
                int prodIDStart = dataColPosition * 10000;

                bool isBidAskDataStart = false;
                string cell_1_Value = null;
                string cell_2_Value = null;
                string cell_3_Value = null;
                string cell_4_Value = null;
                string cell_5_Value = null;
                string prev_cell_1_Value = null;
                DateTime? amerexDate = null;

                List<BrokerPriceQuote> products = new List<BrokerPriceQuote>();
                BrokerPriceQuote priceQuoteRawDataItem = null;
                int worksheetPartsCount = 0;
                int cellStartPosition = (dataColPosition - 1) * 6;
                foreach (WorksheetPart worksheetPart in wbPart.WorksheetParts)
                {
                    worksheetPartsCount++;

                    SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();
                    int totalRowCnt = sheetData.Elements<Row>().Count();

                    for (int r = 0; r < totalRowCnt; r++)
                    {
                        rowCnt++;
                        var row = sheetData.Elements<Row>().ElementAt(r);
                        int cellCnt = 0;
                        int totalCellCnt = row.Elements<Cell>().Count();
                        int j = cellStartPosition;

                        Cell cell_1 = row.Elements<Cell>().Where(c => c.CellReference == $"{dataCols[0]}{rowCnt}").FirstOrDefault();
                        Cell cell_2 = row.Elements<Cell>().Where(c => c.CellReference == $"{dataCols[1]}{rowCnt}").FirstOrDefault();
                        Cell cell_3 = row.Elements<Cell>().Where(c => c.CellReference == $"{dataCols[2]}{rowCnt}").FirstOrDefault();
                        Cell cell_4 = row.Elements<Cell>().Where(c => c.CellReference == $"{dataCols[3]}{rowCnt}").FirstOrDefault();


                        cell_1_Value = GetCellValue(wbPart, cell_1);
                        cell_2_Value = GetCellValue(wbPart, cell_2);
                        cell_3_Value = GetCellValue(wbPart, cell_3);
                        cell_4_Value = GetCellValue(wbPart, cell_4);


                        //Read Amerex PriceQuoteDate
                        ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
                        using (var package1 = new ExcelPackage(brokerFilePath))
                        {
                            WorkbookPart wbPart1 = spreadsheetDocument.WorkbookPart;
                            ExcelWorkbook workbook = package1.Workbook;

                            ExcelWorksheet currentWorksheet = workbook.Worksheets.First();
                            var cultureInfo = new CultureInfo("en-US");
                            string amerexDateCapture = currentWorksheet.Cells["P2:U2"].Text;
                            amerexDate = DateTime.ParseExact(amerexDateCapture, "D", cultureInfo);
                        }

                        //add sub category, bid and ask values
                        if (isBidAskDataStart
                            && !string.IsNullOrWhiteSpace(cell_1_Value)
                            && !string.IsNullOrWhiteSpace(cell_2_Value)
                            && !string.IsNullOrWhiteSpace(cell_3_Value)
                            && !string.IsNullOrWhiteSpace(cell_4_Value)
                            )
                        {
                            priceQuoteRawDataItem.ValueDate = Convert.ToDateTime(amerexDate);
                            priceQuoteRawDataItem.Term = cell_1_Value;

                            if (decimal.TryParse(cell_2_Value, out decimal bidValue))
                                priceQuoteRawDataItem.BidValue = bidValue;
                            else
                                priceQuoteRawDataItem.BidValue = null;
                            if (decimal.TryParse(cell_3_Value, out decimal askValue))
                                priceQuoteRawDataItem.AskValue = askValue;
                            else
                                priceQuoteRawDataItem.AskValue = null;
                            if (decimal.TryParse(cell_4_Value, out decimal midValue))
                                priceQuoteRawDataItem.MidValue = midValue;
                            else
                                priceQuoteRawDataItem.MidValue = null;

                            //revisit the following 2 lines
                            if (midValue.ToString() == "0.0")
                                priceQuoteRawDataItem.MidValue = null;

                            products.Add(new BrokerPriceQuote
                            {
                                BrokerName = "Amerex",
                                Exchange = priceQuoteRawDataItem.Exchange,
                                ProductName = priceQuoteRawDataItem.ProductName,
                                //revisit the following line
                                Term = priceQuoteRawDataItem.Term.Replace(".0", "").Trim(),
                                AskValue = priceQuoteRawDataItem.AskValue,
                                BidValue = priceQuoteRawDataItem.BidValue,
                                MidValue = priceQuoteRawDataItem.MidValue,
                                ValueDate = priceQuoteRawDataItem.ValueDate,
                                UploadDate = DateTime.Now
                            });
                        }
                        else
                        {
                            isBidAskDataStart = false;
                        }
                        if (!string.IsNullOrWhiteSpace(cell_2_Value)
                                && cell_2_Value.Contains(_bid)
                                && !string.IsNullOrWhiteSpace(cell_3_Value)
                                && cell_3_Value == _ask)
                        {
                            isBidAskDataStart = true;
                            //previous row
                            var prevRow = sheetData.Elements<Row>().ElementAt(r - 1);
                            Cell prevRowFirstCell = null;
                            if (prevRow != null)
                            {
                                prevRowFirstCell = prevRow.Elements<Cell>().Where(c => c.CellReference == $"{dataCols[0]}{r}").FirstOrDefault();
                                var prevRowFirstCellVal = GetCellValue(wbPart, prevRowFirstCell);

                                //Get Category name
                                if (!string.IsNullOrWhiteSpace(prevRowFirstCellVal))
                                {
                                    prev_cell_1_Value = new string(prevRowFirstCellVal);
                                }

                            }
                            if (prevRowFirstCell != null)
                                priceQuoteRawDataItem = new BrokerPriceQuote
                                {
                                    Exchange = GetCategoryName(categoryList, (r, cellStartPosition, prevRowFirstCell.CellReference, prev_cell_1_Value)),
                                    ProductName = prev_cell_1_Value// cell_1_Value
                                };
                        }
                    }
                    rowCnt = 0;//reset row count
                }

                return products;
            } 
        }
    }
}


