﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using ThreeDegreesDataSystem.Models.DwModels;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class ReferenceDataService : Service, IReferenceDataService
    {
        public ReferenceDataService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger)
        {

        }


        public async Task<List<ReferenceDataEntity>> GetReferenceDataEntities()
        {
            return await CentralOpsDbContext.ReferenceDataEntities
                .Include(r => r.ReferenceDataFields).ThenInclude(r => r.ReferenceDataFieldValues).Where(r => r.IsActive).ToListAsync();

        }

        public async Task<ReferenceDataFieldValue> AddValueAsync(ReferenceDataFieldValue value)
        {
            CentralOpsDbContext.ReferenceDataFieldValues
                .Add(value);
            await CentralOpsDbContext.SaveChangesAsync();
            return value;
        }

        public async Task<List<ReferenceDataFieldValue>> AddRowAsync(List<ReferenceDataFieldValue> values)
        {
            foreach (var value in values)
            {
                CentralOpsDbContext.ReferenceDataFieldValues
                .Add(value);
            }
            await CentralOpsDbContext.SaveChangesAsync();
            return values;
        }

        public async Task<ReferenceDataFieldValue> UpdateValueAsync(ReferenceDataFieldValue value)
        {
            CentralOpsDbContext.ReferenceDataFieldValues
                .Update(value);
            await CentralOpsDbContext.SaveChangesAsync();
            return value;
        }

        public async Task<List<ReferenceDataFieldValue>> UpdateRowAsync(List<ReferenceDataFieldValue> values)
        {
            foreach (var value in values)
            {
                CentralOpsDbContext.ReferenceDataFieldValues
                .Update(value);
            }
            await CentralOpsDbContext.SaveChangesAsync();
            return values;
        }

        public async Task<bool> DeleteValuesAsync(IEnumerable<int> referenceDataFieldValueIds)
        {
            var existing = CentralOpsDbContext.ReferenceDataFieldValues.Where(x => referenceDataFieldValueIds.Contains(x.ReferenceDataFieldValueId)).ToList();
            if (existing.Any())
            {
                CentralOpsDbContext.ReferenceDataFieldValues.RemoveRange(existing);
                await CentralOpsDbContext.SaveChangesAsync();
                return true;
            }

            return false;

        }
    }
}
