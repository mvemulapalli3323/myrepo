﻿using MathNet.Numerics.Statistics.Mcmc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NPOI.OpenXmlFormats.Dml;
using NPOI.SS.Formula.Functions;
using System.Text;
using System.Text.Json;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Connectors.NetSuite;
using ThreeDegreesDataSystem.Models.DwModels;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class MdmProductService : Service, IMdmProductService
    {
        public MdmProductService(CentralOpsDbContext centralOpsDbContext, DwDbContext dwDbContext, ILogger<Service> baseLogger) : base(centralOpsDbContext, dwDbContext, baseLogger) 
        {
            
        }

        public async Task<IEnumerable<MdmProduct>> SyncMdmProductsToDb(IEnumerable<SalesforceMdmProductInfo> products)
        {
            var mdmProducts = new List<MdmProduct>();
            foreach (var product in products)
            {
                try
                {
                    var mdmProduct = MapToMdmProduct(product);

                    //if salesforce id is not null and already exists in the mdm db, update the record
                    if (await CentralOpsDbContext.MdmProducts.AnyAsync(x => x.SalesforceId == mdmProduct.SalesforceId))
                    {
                        var existingProduct = await CentralOpsDbContext.MdmProducts.FirstOrDefaultAsync(x => x.MdmProductCode != null && x.MdmProductCode == mdmProduct.MdmProductCode);
                        if (existingProduct != null)
                        {
                            MapUpdatedToMdmProduct(existingProduct, mdmProduct);
                        }
                        //the mdm product code has changed in salesforce
                        else
                        {
                            existingProduct = await CentralOpsDbContext.MdmProducts.FirstOrDefaultAsync(x => x.SalesforceId != null && x.SalesforceId == mdmProduct.SalesforceId);
                            if (existingProduct != null)
                            {
                                MapUpdatedToMdmProduct(existingProduct, mdmProduct);
                            }
                        }
                    }
                    else
                    {
                        await CentralOpsDbContext.MdmProducts.AddAsync(mdmProduct);
                    }
                    
                    await CentralOpsDbContext.SaveChangesAsync();
                    mdmProducts.Add(mdmProduct);
                }
                catch (DbUpdateException ex)
                {
                    if (ex.InnerException?.Message.Contains("UNIQUE constraint failed") == true || ex.InnerException?.Message.Contains("duplicate key value violates unique constraint") == true)
                    {
                        throw new Exception($"Unique constraint violation: A product with productcode {product.MdmProductCode} already exists.");
                        
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
            //todo return more info
            return mdmProducts;
        }

        public async Task<string> SyncMdmProductsToNetSuite(IEnumerable<MdmProduct> products)
        {
            var connector = new NetSuiteConnector();
            var status = new StringBuilder();

            foreach (var product in products)
            {
                var response = await connector.AddOrUpdateItem(product);
                var mdmProduct = await CentralOpsDbContext.MdmProducts.FirstOrDefaultAsync(x => x.MdmProductCode == product.MdmProductCode);
                //update the netsuite id in the db if needed.
                if (response.Items.Count() == 1 && response.Items.FirstOrDefault().internalId != product.NetSuiteId)
                {
                    mdmProduct.NetSuiteId = response.Items.FirstOrDefault().internalId;
                    await CentralOpsDbContext.SaveChangesAsync();
                }
                status.AppendLine(response.Message);
            }

            //todo return more info
            return status.ToString();
        }

        public async Task<string> NotifyLogicWebhook(string callback,string status)
        {
            using (HttpClient client = new HttpClient())
            {
                string logicAppWebhookUrl = callback;

                var data = new
                {
                    status,
                };

                string json = JsonSerializer.Serialize(data);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(logicAppWebhookUrl, content);

                return $"Response: {response.StatusCode}";
            }
        }
        private void MapUpdatedToMdmProduct(MdmProduct existingProduct, MdmProduct mdmProduct)
        {
            existingProduct.MdmProductName = mdmProduct.MdmProductName;
            existingProduct.MdmProductCode = mdmProduct.MdmProductCode;
            existingProduct.LastModifiedBy = mdmProduct.LastModifiedBy;
            existingProduct.LastModifiedOn = mdmProduct.LastModifiedOn;
            existingProduct.ProductStatus = mdmProduct.ProductStatus;
            
            mdmProduct.NetSuiteId = existingProduct.NetSuiteId;

        }
        private MdmProduct MapToMdmProduct(SalesforceMdmProductInfo salesforceProduct)
        {
            var product = new MdmProduct();
            product.MdmProductCode = salesforceProduct.MdmProductCode;
            product.MdmProductName = salesforceProduct.MdmProductName;
            product.LastModifiedBy = "Data System Sync Process";
            product.LastModifiedOn = DateTime.Now;
            product.GoldenSource = "Salesforce";
            product.SalesforceId = salesforceProduct.SalesforceId;
          
            product.ProductStatus = salesforceProduct.IsActive == "True"  ? "Active" : "InActive";

            return product;
        }
    }
}
