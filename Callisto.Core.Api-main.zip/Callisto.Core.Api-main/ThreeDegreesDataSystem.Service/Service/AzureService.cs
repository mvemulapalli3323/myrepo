﻿using Azure.Storage.Blobs.Models;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;
using Microsoft.Extensions.Logging;
using ThreeDegreesDataSystem.Service.Interface;
using System;
using System.IO;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Service.Service
{
    public class AzureService: IAzureService
    {
        private readonly ILogger<AzureService> _logger;

        public AzureService(ILogger<AzureService> logger)
        {
            _logger = logger;
        }

        public static string AddTimeToFileName(string fileName)
        {
            string[] fileChunks = fileName.Split('.');
            return $"{fileChunks[0]}_{DateTime.UtcNow:yyyyMMdd}.{fileChunks[1]}";
        }

        public static string GetLocalFilePath(string blobPrefix, string blobName)
        {
            string localDirectoryPath = $"./Files/{blobPrefix}";
            string localFilePath = $"{localDirectoryPath}{blobName}";
            return localFilePath;
        }

        public static string GetBlobPrefix(TaskRun taskRun)
        {
            return $"{DataMap.GetTaskCode(taskRun.TaskId)}/{taskRun.CreatedOn:yyyyMMdd}/{taskRun.TaskRunId}/";
        }

        //public async Task<BlobItem[]> GetBlobs(TaskRun taskRun)
        //{
        //    string blobPrefix = GetBlobPrefix(taskRun);
        //    return await AzureConnector.ListBlobs(AzureStringConstants.ExportContainerName, blobPrefix);
        //}

        public async Task<string> DownloadBlob(TaskRun taskRun, string fileName, string containerName)
        {
            string blobPrefix = GetBlobPrefix(taskRun);
            string downloadedFilePath = await AzureConnector.DownloadBlob(containerName, blobPrefix, fileName);
            return downloadedFilePath;
        }
    }
}
