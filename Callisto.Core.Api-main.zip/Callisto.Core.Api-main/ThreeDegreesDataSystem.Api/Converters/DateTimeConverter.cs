﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace ThreeDegreesDataSystem.Api.Converters
{
    public class DateTimeConverter: JsonConverter<DateTime>
    {
        public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return DateTime.Parse(reader.GetString() ?? string.Empty);
        }

        public override void Write(Utf8JsonWriter writer, DateTime date, JsonSerializerOptions options)
        {
            var value = DateTime.SpecifyKind(date, DateTimeKind.Utc).ToString("o");
            writer.WriteStringValue(value);
        }
    }
}
