﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Processor;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using MathNet.Numerics.Statistics.Mcmc;
using System;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CrudController<TEntity> : ControllerBase where TEntity : class, ICentralOpsEntity, new()
    {
        protected readonly ILogger<ControllerBase> _logger;
        protected readonly IService _service;

        protected CrudController(ILogger<ControllerBase> logger, IService service)        
        {
            _service = service ?? throw new ArgumentNullException(nameof(service));
            _logger = logger;
        }

        protected ActionResult<TResult> OkOrNotFound<TResult>(TResult result)
            => result is null ? NotFound() : Ok(result);

        [HttpGet]
        public async virtual Task<ActionResult<IEnumerable<TEntity>>> GetAll()
        {
            var entities = await _service.GetCentralOpsEntitiesAsync<TEntity>();
            return Ok(entities);
        }

        [HttpPost]
        public async virtual Task<ActionResult<TEntity>> Create(TEntity entity)
        {
            return await _service.AddCentralOpsEntityAsync(entity);
            //return CreatedAtAction(nameof(GetById), new { entity.Id }, entity);
        }

        [HttpPut("{id:int}")]
        public async virtual Task<ActionResult<TEntity>> Update(int id, TEntity entity)
        {
            await _service.UpdateCentralOpsEntityAsync(entity);
            return Ok(entity);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<bool>> DeleteAsync(int id)
        {
            try
            {
                return await _service.DeleteCentralOpsEntityAsync<TEntity>(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return false;
            }
        }
    }
}
