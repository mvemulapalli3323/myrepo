﻿using ThreeDegreesDataSystem.Connectors.Azure;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Service.Service;
using NPOI.HPSF;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Common.Reader;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataCleansingController : ControllerBase
    {
        private readonly IDataCleansingService _dataCleansingService;

        public DataCleansingController(IDataCleansingService dataCleansingService)
        {
            _dataCleansingService = dataCleansingService;
        }

        [HttpPost]
        [Route("clean-csv-file")]
        public async Task<ActionResult<string>> CleanCsvFile(CsvReaderParameters csvReaderParams)
        {
            return await _dataCleansingService.CleanCsvFile(csvReaderParams);
        }
    }
}
