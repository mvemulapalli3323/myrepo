﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AzureDataFactoryController : ControllerBase
    {
        private readonly ILogger<AzureDataFactoryController> _logger;
        private readonly IAzureDataFactoryService _service;

        public AzureDataFactoryController(ILogger<AzureDataFactoryController> logger, IAzureDataFactoryService repository)
        {
            _logger = logger;
            _service = repository;

        }
    }
}
