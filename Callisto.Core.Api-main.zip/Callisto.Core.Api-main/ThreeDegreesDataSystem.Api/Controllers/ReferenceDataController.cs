﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReferenceDataController : ControllerBase
    {
        private readonly ILogger<ReferenceDataController> _logger;
        private readonly IReferenceDataService _service;

        public ReferenceDataController(ILogger<ReferenceDataController> logger, IReferenceDataService service)
        {
            _logger = logger;
            _service = service;
            
        }

        [Route("get-reference-data-entities")]
        [AcceptVerbs("GET")]
        [HttpGet]
        public async Task<ActionResult<List<ReferenceDataEntity>>> GetReferencDataEntities()
        { 
            try
            {
                var data = await _service.GetReferenceDataEntities();
                return data;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new List<ReferenceDataEntity>();
            }
        }


        [HttpPost("values")]
        public async Task<ActionResult<ReferenceDataFieldValue>> AddValueAsync(ReferenceDataFieldValue dto)
        {
            try
            {
                return await _service.AddValueAsync(dto);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new ReferenceDataFieldValue();
            }
        }

        [HttpPut("values")]
        public async Task<ActionResult<ReferenceDataFieldValue>> UpdateValueAsync(ReferenceDataFieldValue dto)
        {
            try
            {
                return await _service.UpdateValueAsync(dto);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new ReferenceDataFieldValue();
            }
        }

        [HttpPost("delete-values")]
        public async Task<ActionResult<bool>> DeleteValuesAsync(IEnumerable<int> ids)
        {
            try
            {
                return await _service.DeleteValuesAsync(ids);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return false;
            }
        }


        [HttpPost("rows")]
        public async Task<ActionResult<List<ReferenceDataFieldValue>>> AddRowAsync(List<ReferenceDataFieldValue> dto)
        {
            try
            {
                return await _service.AddRowAsync(dto);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new List<ReferenceDataFieldValue>();
            }
        }

        [HttpPut("rows")]
        public async Task<ActionResult<List<ReferenceDataFieldValue>>> UpdateRowAsync(List<ReferenceDataFieldValue> dto)
        {
            try
            {
                return await _service.UpdateRowAsync(dto);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new List<ReferenceDataFieldValue>();
            }
        }


      }
}
