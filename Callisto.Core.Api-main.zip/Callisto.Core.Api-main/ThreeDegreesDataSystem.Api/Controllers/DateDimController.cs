﻿using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DateDimController : ControllerBase
    {
        private readonly ILogger<DateDimController> _logger;
        private readonly IDateDimService _service;

        public DateDimController(ILogger<DateDimController> logger, IDateDimService service)
        {
            _logger = logger;
            _service = service;

        }

        [Route("us-business-day-check")]
        [AcceptVerbs("GET")]
        [HttpGet]
        public async Task<ActionResult<bool>> IsUsBusinessDay([FromQuery] DateTime date)
        {
            try
            {
                bool isBusinessDay = await _service.IsUsBusinessDate(date);
                _logger.LogInformation("Checked if {Date} is a US business day successfully.", date);
                return isBusinessDay;      
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Message: {Message} Stacktrace: {StackTrace} Inner Exception: {InnerException}", ex.Message, ex.StackTrace, ex.Message);
                return StatusCode(
                    StatusCodes.Status500InternalServerError, 
                    $"An error occurred while checking if {date} is a US business day: {ex.Message}"
                );
            }
        }
    }
}
