﻿using ThreeDegreesDataSystem.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MdmProductController : CrudController<MdmProduct>
    {
        public MdmProductController(ILogger<MdmProductController> logger, IService service) : base(logger, service)
        {
            
        }
    }
}
