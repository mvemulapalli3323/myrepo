﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Processor;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using System.Text;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly ITaskProcessor _taskProcessor;
        private readonly ITaskService _taskService;

        public TaskController(ITaskService TaskService, ITaskProcessor TaskProcessor)
        {
            _taskProcessor = TaskProcessor;
            _taskService = TaskService;
        }

        [Route("")]
        [HttpGet]
        public async Task<ActionResult<Models.Models.Task[]>> GetTasks(bool topOnly, bool uiOnly)
        {
            return await _taskService.GetTasks(topOnly: topOnly, uiOnly: uiOnly);
        }

        [Route("{taskId:int}")]
        [HttpGet]
        public async Task<ActionResult<Models.Models.Task>> GetTask(int taskId, bool inclusive=false)
        {
            return inclusive
                ? await _taskService.GetTaskInclusive(taskId)
                : await _taskService.GetTask(taskId);
        }

        [Route("{taskId:int}")]
        [HttpPost]
        public async Task<ActionResult<TaskRun>> RunTask(int taskId, TaskRun taskRun)
        {
            return await _taskProcessor.RunTask(taskId, taskRun);
        }

        [Route("{taskCode}")]
        [HttpGet]
        public async Task<ActionResult<Models.Models.Task>> GetTask(string taskCode)
        {
            return await _taskService.GetTask(taskCode);
        }

        [Route("{taskCode}/isRunning")]
        [HttpGet]
        public ActionResult<bool> GetTaskRunningStatus(string taskCode)
        {
            return _taskService.IsRunning(DataMap.GetTaskId(taskCode));
        }

        [Route("{taskId:int}/async")]
        [HttpPost]
        public async Task<ActionResult<TaskRun>> RunTaskAsync(int taskId, TaskRun taskRun, [FromServices] IServiceScopeFactory serviceScopeFactory)
        {
            taskRun = await _taskProcessor.CreateTaskRuns(taskId, taskRun);
            _ = System.Threading.Tasks.Task.Run(async () =>
            {
                using IServiceScope scope = serviceScopeFactory.CreateScope();
                ITaskProcessor scopedProcessor = scope.ServiceProvider.GetRequiredService<ITaskProcessor>();
                await scopedProcessor.RunTaskRun(taskRun);
            });
            return taskRun;
        }

        [Route("{taskCode}/async")]
        [HttpPost]
        public async Task<ActionResult<TaskRun>> RunTaskAsync(string taskCode, [FromServices] IServiceScopeFactory serviceScopeFactory)
        {
            string paramContent = string.Empty;
            using (var reader = new StreamReader(Request.Body,encoding: Encoding.UTF8,detectEncodingFromByteOrderMarks: false))
            {
                paramContent = await reader.ReadToEndAsync();
            }

            TaskRun taskRun = new TaskRun();
            taskRun.Parameters = paramContent;

            int taskId = _taskService.GetTaskId(taskCode);
            taskRun = await _taskProcessor.CreateTaskRuns(taskId, taskRun);
            _ = System.Threading.Tasks.Task.Run(async () =>
            {
                using IServiceScope scope = serviceScopeFactory.CreateScope();
                ITaskProcessor scopedProcessor = scope.ServiceProvider.GetRequiredService<ITaskProcessor>();
                await scopedProcessor.RunTaskRun(taskRun);
            });
            return taskRun;
        }

        [Route("{taskId:int}/subtasks")]
        [HttpGet]
        public async Task<ActionResult<TaskSubtask[]>> GetTaskSubtasks(int taskId)
        {
            return await _taskService.GetTaskSubtasks(taskId);
        }

        [Route("test")]
        [HttpPost]
        public async Task<ActionResult<TaskRun>> RunTaskAsync([FromServices] IServiceScopeFactory serviceScopeFactory)
        {
            var taskRun = new TaskRun();
            var taskId = 1;
            taskRun.TaskId = taskId;

            taskRun = await _taskProcessor.CreateTaskRuns(taskId, taskRun);
            _ = System.Threading.Tasks.Task.Run(async () =>
            {
                using IServiceScope scope = serviceScopeFactory.CreateScope();
                ITaskProcessor scopedProcessor = scope.ServiceProvider.GetRequiredService<ITaskProcessor>();
                await scopedProcessor.RunTaskRun(taskRun);
            });
            return taskRun;
        }
    }
}
