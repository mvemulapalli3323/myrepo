﻿using ThreeDegreesDataSystem.Connectors.Azure;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Service.Service;
using NPOI.HPSF;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Common.Reader;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommergPriceController : ControllerBase
    {
        private readonly ICommergPriceService _commergPriceService;

        public CommergPriceController(ICommergPriceService commergPriceService)
        {
            _commergPriceService = commergPriceService;
        }

        [HttpPost]
        [Route("")]
        public async Task<ActionResult<string>> LoadCommergFile(BlobFileReaderParameters blobFileReaderParameters)
        {
            //var test = new BlobFileReaderParameters();
            //test.TaskRunId = 4001;
            //test.ContainerName = "raw";
            //test.FileName = "market_data/commerg/2025/01/09/commerg-prices.xlsx";
            //test.FileDate = new System.DateTime(2025, 01, 09);

            return await _commergPriceService.LoadCommergPricesToDb(blobFileReaderParameters);
        }
    }
}

