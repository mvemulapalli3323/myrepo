﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenericMapController : ControllerBase
    {
        private readonly ILogger<GenericMapController> _logger;
        private readonly IGenericMapService _service;

        public GenericMapController(ILogger<GenericMapController> logger, IGenericMapService repository)
        {
            _logger = logger;
            _service = repository;

        }

        [Route("get-generic-maps")]
        [AcceptVerbs("GET")]
        [HttpGet]
        public async Task<ActionResult<List<GenericMap>>> GetGenericMaps()
        {
            try
            {
                return await _service.GetGenericMaps();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new List<GenericMap>();
            }
        }

        [Route("get-generic-maps-by-type-code/{typeCode}")]
        [AcceptVerbs("GET")]
        [HttpGet]
        public async Task<ActionResult<List<GenericMap>>> GetGenericMapsByType(string typeCode)
        {
            try
            {
                return await _service.GetGenericMapsByTypeCode(typeCode);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new List<GenericMap>();
            }
        }


        [HttpPost]
        public async Task<ActionResult<GenericMap>> CreateAsync(GenericMap dto)
        {
            try
            {
                return await _service.AddCentralOpsEntityAsync(dto);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new GenericMap();
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<GenericMap>> UpdateAsync(long id, GenericMap dto)
        {
            try
            {
                return await _service.UpdateCentralOpsEntityAsync(dto);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new GenericMap();
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<bool>> DeleteAsync(int id)
        {
            try
            {
                return await _service.DeleteAsync(id);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return false;
            }
        }

    }
}
