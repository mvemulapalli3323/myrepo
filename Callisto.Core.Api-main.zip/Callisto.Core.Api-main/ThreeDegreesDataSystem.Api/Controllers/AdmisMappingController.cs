﻿using ThreeDegreesDataSystem.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdmisMappingController : CrudController<AdmisMapping>
    {
        IAdmisService _admisService;
        public AdmisMappingController(ILogger<AdmisMappingController> logger, IService service, IAdmisService admisService) : base(logger, service)
        {
            _admisService = admisService;
        }

        [Route("history")]
        [HttpGet]
        public async virtual Task<ActionResult<IEnumerable<AdmisMapping>>> GetAllHistory()
        {
            var entities = await _admisService.GetAdmisMappingHistory();
            return Ok(entities);
        }
    }
}
