﻿using Azure.Storage.Blobs.Models;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Processor;
using ThreeDegreesDataSystem.Processor.Tasks;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskRunController : ControllerBase
    {
        private readonly IAzureService _azureService;
        private readonly ITaskProcessor _taskProcessor;
        private readonly ITaskRunner _taskRunner;
        private readonly ITaskRunService _taskRunService;

        public TaskRunController(
            IAzureService azureService,
            ITaskProcessor taskProcessor,
            ITaskRunner taskRunner,
            ITaskRunService taskRunService)
        {
            _azureService = azureService;
            _taskProcessor = taskProcessor;
            _taskRunner = taskRunner;
            _taskRunService = taskRunService;
        }

        [Route("")]
        [HttpGet]
        public ActionResult<TaskRun[]> GetTaskRuns(bool topOnly, string taskCode, bool inclusive = true)
        {
            TaskRun[] taskRuns = _taskRunService.GetTaskRuns(topOnly: topOnly, taskCode: taskCode, inclusive: inclusive)
                .OrderByDescending(tr => tr.TaskRunId)
                .ToArray();
            return taskRuns;
        }

        [Route("{taskRunId:int}")]
        [HttpGet]
        public async Task<ActionResult<TaskRun>> GetTaskRun(int taskRunId, bool inclusive=false)
        {
            return await _taskRunService.GetTaskRun(taskRunId, inclusive: inclusive);
        }

        [Route("{taskRunId:int}")]
        [HttpDelete]
        public async Task<ActionResult> DeleteTaskRun(int taskRunId)
        {
            await _taskRunService.DeleteTaskRun(taskRunId);
            return new NoContentResult();
        }

        [Route("{taskRunId:int}/cancel")]
        [HttpPost]
        public async Task<ActionResult<TaskRun>> CancelTaskRun(int taskRunId)
        {
            return await _taskRunService.CancelTaskRun(taskRunId);
        }

        [Route("{taskRunId:int}/{taskCode}")]
        [HttpGet]
        public ActionResult<TaskRun[]> GetTaskRunSubtaskRuns(int taskRunId, string taskCode)
        {
            return _taskRunService.GetTaskRuns(taskRunId, taskCode).ToArray();
        }

        //[Route("{taskRunId:int}/files")]
        //[HttpGet]
        //public async Task<ActionResult<string>> GetTaskRunFiles(int taskRunId)
        //{
        //    TaskRun taskRun = await _taskRunService.GetTaskRun(taskRunId);
        //    BlobItem[] files = await _azureService.GetBlobs(taskRun);
        //    return new ContentResult()
        //    {
        //        Content = JsonSerializer.Serialize(files),
        //        ContentType = "application/json",
        //    };
        //}

        //[Route("{taskRunId:int}/files/{fileName}")]
        //[HttpGet]
        //public async Task<FileResult> GetTaskRunFile(int taskRunId, string fileName)
        //{
        //    TaskRun taskRun = await _taskRunService.GetTaskRun(taskRunId);
        //    string filePath = await _azureService.DownloadBlob(taskRun, fileName);
        //    string currentDirectory = Directory.GetCurrentDirectory();
        //    return PhysicalFile($"{currentDirectory}{filePath}", System.Net.Mime.MediaTypeNames.Application.Octet, $"{fileName}_{taskRunId}");
        //}

        [Route("{taskRunId:int}/rerun")]
        [HttpPost]
        public async Task<ActionResult<TaskRun>> RerunTaskRun(int taskRunId)
        {
            TaskRun taskRun = await _taskRunService.GetTaskRun(taskRunId);
            return await _taskProcessor.RunTaskRun(taskRun, rerun: false);
        }

        [Route("{taskRunId:int}/rerun/async")]
        [HttpPost]
        public async Task<ActionResult<TaskRun>> RerunTaskRunAsync(int taskRunId, [FromServices] IServiceScopeFactory serviceScopeFactory)
        {
            TaskRun taskRun = await _taskRunService.GetTaskRun(taskRunId);
            _ = System.Threading.Tasks.Task.Run(async () =>
            {
                using IServiceScope scope = serviceScopeFactory.CreateScope();
                ITaskProcessor scopedProcessor = scope.ServiceProvider.GetRequiredService<ITaskProcessor>();
                await scopedProcessor.RunTaskRun(taskRun, rerun: true);
            });
            return taskRun;
        }

        [Route("{taskCode}")]
        [HttpGet]
        public async Task<ActionResult<TaskRun[]>> GetTaskRuns(string taskCode)
        {
            return (await _taskRunService.GetTaskRuns(taskCode)).ToArray();
        }

        [Route("{taskCode}/complete")]
        [HttpGet]
        public async Task<ActionResult<TaskRun>> CompleteTaskRun(string taskCode)
        {
            return await _taskRunService.CompleteTaskRun(taskCode);
        }

        [Route("{taskCode}/fail")]
        [HttpGet]
        public async Task<ActionResult<TaskRun>> FailTaskRun(string taskCode, string message)
        {
            return await _taskRunService.FailTaskRun(taskCode, message);
        }

        [Route("validate")]
        [HttpPost]
        public async Task<ActionResult> Validate()
        {
            await _taskRunService.ValidateAllTaskRuns();
            return new NoContentResult();
        }

        [Route("by-criteria")]
        [HttpGet]
        public ActionResult<TaskRun[]> GetTaskRunsByDateRunsByDateRange()
        {
            var startDate = Request.Query["startDate"];
            var endDate = Request.Query["endDate"];
            var taskCode = Request.Query["taskCode"];
            var statusCode = Request.Query["statusCode"];

            TaskRun[] taskRuns = _taskRunService.GetTaskRunsByCriteria(startDate, endDate, taskCode, statusCode);

            return taskRuns;
        }

    }
}
