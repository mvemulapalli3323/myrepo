﻿using ThreeDegreesDataSystem.Connectors.Azure;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Service.Service;
using NPOI.HPSF;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Connectors.NetSuite;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NetSuiteController : ControllerBase
    {
        
        public NetSuiteController()
        {
            
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<string>> GetItem(int id)
        {
            var connector = new NetSuiteConnector();

            return (await connector.GetItem(id)).Message;
        }

        [HttpGet("{mdmProductCode}")]
        public async Task<ActionResult<string>> GetItems(string mdmProductCode)
        {
            var connector = new NetSuiteConnector();

            var items = await connector.GetItems(mdmProductCode);

            return items.Message;
        }

        [HttpGet]
        [Route("bulk-load-test")]
        public async Task<ActionResult<string>> BulkLoadTest()
        {
            var stopWatch = new System.Diagnostics.Stopwatch();
            stopWatch.Start();
            var connector = new NetSuiteConnector();
            var products = new List<MdmProduct>();
            for (int i = 2; i < 100; i++)
            {
                var product = new MdmProduct()
                {
                    MdmProductName = $"Bulk Load Test Product {i}",
                    MdmProductCode = $"BulkLoadTestProduct{i}",
                    ProductStatus = "Active"
                };
                products.Add(product);
                
            }
            var status = await connector.BulkCreateItems(products);
            stopWatch.Stop();   
            var time = stopWatch.Elapsed;

            return ($"Elapsed Time{ time.ToString()}");
            
        }

    }
}

