﻿using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenericListController : ControllerBase
    {
        private readonly ILogger<GenericListController> _logger;
        private readonly IGenericMapService _genericMapService;

        public GenericListController(ILogger<GenericListController> logger, IGenericMapService genericMapService)
        {
            _logger = logger;
            _genericMapService = genericMapService;

        }

        [Route("lists")]
        [HttpGet]
        public ActionResult<string[]> GetLists()
        {
            return _genericMapService.GetLists();
        }

        [Route("lists/{listTypeCode}")]
        [HttpGet]
        public ActionResult<string[]> GetList(string listTypeCode)
        {
            return _genericMapService.GetList(listTypeCode);
        }
    }
}
