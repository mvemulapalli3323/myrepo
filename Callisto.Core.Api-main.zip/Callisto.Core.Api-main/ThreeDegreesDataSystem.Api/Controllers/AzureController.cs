﻿using ThreeDegreesDataSystem.Connectors.Azure;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AzureController : ControllerBase
    {
        public AzureController()
        {
        }

        [Route("blobs/{containerName}")]
        [HttpGet]
        public async Task<ActionResult<string>> GetBlobs(string containerName)
        {
            return JsonSerializer.Serialize(await AzureConnector.ListBlobs(containerName));
        }

        [Route("blobs/{containerName}")]
        [HttpPost]
        [DisableRequestSizeLimit]
        public async Task<ActionResult<string>> UploadBlob(string containerName, string blobPrefix)
        {
            if (!Request.Form.Files.Any())
                return BadRequest();

            foreach(IFormFile file in Request.Form.Files)
            {
                MemoryStream memoryStream = new();
                await file.CopyToAsync(memoryStream);
                string[] fileNameChunks = file.FileName.Split('.');
                string fileName = $"{blobPrefix}{fileNameChunks[0]}_{DateTime.Now:yyyyMMddThhmmss}.{fileNameChunks[1]}";
                AzureConnector.UploadBlob(memoryStream, containerName, fileName);
                return Created(fileName, new { fileName, containerName }); // only do first one for now
            }
            return BadRequest();
        }
    }
}
