﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System;
using ThreeDegreesDataSystem.Connectors.Argus;
using System.Net.Http.Json;
using System.Text;
using ThreeDegreesDataSystem.Common.Reader;
using ThreeDegreesDataSystem.Service.Service;
using Newtonsoft.Json;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LogicAppsController : ControllerBase
    {
        private readonly ILogger<LogicAppsController> _logger;

        private readonly IGenericMapService _genericMapService;
        private readonly ITaskRunService _taskRunService;

        public LogicAppsController(
            ILogger<LogicAppsController> logger,
            IGenericMapService genericMapService,
            ITaskRunService taskRunService
            )
        {
            _logger = logger;
            _genericMapService = genericMapService;
            _taskRunService = taskRunService;
        }

        

        [HttpPost]
        [Route("webhook-subscribe")]
        public async Task<ActionResult<string>> AcceptWebHookSubscription()
        {
            string paramContent = string.Empty;
            using (var reader = new StreamReader(Request.Body, encoding: Encoding.UTF8, detectEncodingFromByteOrderMarks: false))
            {
                paramContent = await reader.ReadToEndAsync();
            }

            return await System.Threading.Tasks.Task.Run(() => Ok("Accepted"));
        }
    }
}
