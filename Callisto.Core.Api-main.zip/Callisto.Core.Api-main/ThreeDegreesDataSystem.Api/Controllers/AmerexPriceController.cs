﻿using ThreeDegreesDataSystem.Connectors.Azure;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Service.Service;
using NPOI.HPSF;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Common.Reader;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AmerexPriceController : ControllerBase
    {
        private readonly IAmerexPriceService _amerexPriceService;

        public AmerexPriceController(IAmerexPriceService amerexPriceService)
        {
            _amerexPriceService = amerexPriceService;
        }

        [HttpPost]
        [Route("")]
        public async Task<ActionResult<string>> LoadAmerexFile(BlobFileReaderParameters blobFileReaderParameters)
        {
            //var test = new BlobFileReaderParameters();
            //test.TaskRunId = 3999;
            //test.ContainerName = "raw";
            //test.FileName = "market_data/amerex/2025/01/24/amerex-prices.xlsx";
            //test.FileDate = new System.DateTime(2025, 01, 24);

            return await _amerexPriceService.LoadAmerexPricesToDb(blobFileReaderParameters);
        }
    }
}

