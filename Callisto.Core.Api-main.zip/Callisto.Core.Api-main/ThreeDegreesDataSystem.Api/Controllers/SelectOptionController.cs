﻿using ThreeDegreesDataSystem.Models;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SelectOptionController : ControllerBase
    {
        private readonly ILogger<SelectOptionController> _logger;
        private readonly ISelectOptionsService _service;

        public SelectOptionController(ILogger<SelectOptionController> logger, ISelectOptionsService service)
        {
            _logger = logger;
            _service = service;

        }

        [Route("get-select-options")]
        [AcceptVerbs("GET")]
        [HttpGet]
        public async Task<ActionResult<List<SelectOption>>> GetSelectOptions()
        {
            try
            {
                return await _service.GetSelectOptions();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new List<SelectOption>();
            }
        }

        [Route("get-select-options-by-type-code/{typeCode}")]
        [AcceptVerbs("GET")]
        [HttpGet]
        public async Task<ActionResult<List<SelectOption>>> GetSelectOptionsByTypeCode(string typeCode)
        {
            try
            {
                return await _service.GetSelectOptionsByTypeCode(typeCode);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                return new List<SelectOption>();
            }
        }




    }
}
