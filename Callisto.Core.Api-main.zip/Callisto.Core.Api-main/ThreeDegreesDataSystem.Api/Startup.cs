using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Connectors.Argus;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Connectors.Email;
using ThreeDegreesDataSystem.Connectors.Interface;
using ThreeDegreesDataSystem.Connectors.NetSuite;
using ThreeDegreesDataSystem.Models.DwModels;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Processor;
using ThreeDegreesDataSystem.Processor.Tasks;
using ThreeDegreesDataSystem.Service;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Service.Service;


namespace ThreeDegreesDataSystem
{
    public class Startup
    {
        public Startup(IWebHostEnvironment environment, IConfiguration configuration)
        {
            Configuration = configuration;
            EnvironmentHelper.Initialize(environment.EnvironmentName, Configuration);
        }

        public IConfiguration Configuration { get; }
        const string corsPolicy = "CorsPolicy";

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Logging
            services.AddApplicationInsightsTelemetry();
            services.AddLogging(loggingBuilder =>
            {
                loggingBuilder.AddApplicationInsights();
                loggingBuilder.SetMinimumLevel(LogLevel.Information);
            });

            // Database
            //var dbConnectionString = EnvironmentHelper.GetDbConnectionString();
            var dbConnectionString = EnvironmentHelper.GetDbConnectionString();
            services.AddDbContext<CentralOpsDbContext>(options => options.UseSqlServer(dbConnectionString,
                sqlServerOptions => sqlServerOptions.CommandTimeout(500)), ServiceLifetime.Transient);
            var dwDbConnectionString = EnvironmentHelper.GetDwDbConnectionString();
            services.AddDbContext<DwDbContext>(options => options.UseSqlServer(dwDbConnectionString,
                sqlServerOptions => sqlServerOptions.CommandTimeout(500)), ServiceLifetime.Transient);
            // Services
            services.AddTransient(typeof(IService), typeof(Service.Service.Service));
            services.AddTransient<IAdmisService, AdmisService>();
            services.AddTransient<IAmerexPriceService, AmerexPriceService>();
            services.AddTransient<IArgusPriceService, ArgusPriceService>();
            services.AddTransient<IAzureDataFactoryService, AzureDataFactoryService>();
            services.AddTransient<IAzureService, AzureService>();
            services.AddTransient<ICommergPriceService, CommergPriceService>();
            services.AddTransient<IDataCleansingService, DataCleansingService>();
            services.AddTransient<IDateDimService, DateDimService>();
            services.AddTransient<IGenericMapService, GenericMapService>();
            services.AddTransient<IGenericTimeoutService, GenericTimeoutService>();
            services.AddTransient<IReferenceDataService, ReferenceDataService>();
            services.AddTransient<ISelectOptionsService, SelectOptionsService>();
            services.AddTransient<IMdmProductService, MdmProductService>();
            services.AddTransient<ITaskService, TaskService>();
            services.AddTransient<ITaskRunService, TaskRunService>();
            // Connectors
            services.AddTransient<IAzureDataFactoryConnector, AzureDataFactoryConnector>();
            services.AddTransient<IArgusConnector, ArgusConnector>();
            services.AddTransient<IEmailConnector, EmailConnector>();
            services.AddTransient<INetSuiteConnector, NetSuiteConnector>();

            //Processor
            services.AddTransient<ITaskProcessor, TaskProcessor>();
            services.AddTransient<ITaskRunner, TaskRunner>();

            services.AddCors(options =>
            {
                options.AddPolicy(name: corsPolicy, builder =>
                {
                    //breadcrumb: CORS policies are set in Callisto.Infrastructure bicep scripts
                    builder.AllowAnyOrigin()
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                });
            });

            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "3Degrees Data System API", Version = "v1" });
            });

            services.AddControllers().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
                options.JsonSerializerOptions.Converters.Add(new Api.Converters.DateTimeConverter());
                options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
            });

            services.AddAuthorization();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, CentralOpsDbContext context, DwDbContext dwcontext, ILogger<ThreeDegreesDataSystem.Service.Service.Service> baseLogger)
        {
            app.UseDeveloperExceptionPage();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "3Degrees Data System API");
            });

            app.UseExceptionHandler(builder =>
            {
                builder.Run(async context =>
                {
                    var feature = context.Features.Get<IExceptionHandlerFeature>();
                    var error = feature?.Error;

                    context.Response.ContentType = "application/json";

                    if (error is ValidationException vex)
                    {
                        context.Response.StatusCode = StatusCodes.Status400BadRequest;
                        await context.Response.WriteAsJsonAsync(new
                        {
                            errorCode = "VALIDATION_ERROR",
                            message = "One or more fields are invalid.",
                            detail = error?.Message
                        });
                    }
                    else
                    {
                        // fallback for all other errors
                        context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                        await context.Response.WriteAsJsonAsync(new
                        {
                            errorCode = "SERVER_ERROR",
                            message = "An unexpected error occurred. Please try again later.",
                            details = error?.Message
                        });
                    }
                });
            });

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseCors(corsPolicy);
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller}/{action=Index}/{id?}");
            });


            // Set up static data map
            var statusService = new StatusService(context,dwcontext, baseLogger);
            var taskService = new TaskService(context,dwcontext, baseLogger );
            System.Threading.Tasks.Task initDataMap = DataMap.Init(statusService, taskService);
            initDataMap.Wait();

        }
    }
}
