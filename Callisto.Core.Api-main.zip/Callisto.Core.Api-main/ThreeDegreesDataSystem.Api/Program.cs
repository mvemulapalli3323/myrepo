using System;
using Azure.Identity;
using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureAppConfiguration((ctx, config) =>
                {
                    // build the interim config so we can read vault name
                    var built = config.Build();
                    var keyVaultName = built["AZURE_KEY_VAULT_NAME"]
                        ?? throw new InvalidOperationException(
                            "Configuration key 'AZURE_KEY_VAULT_NAME' not found");

                    config.AddAzureKeyVault(
                        new Uri($"https://{keyVaultName}.vault.azure.net/"),
                        new DefaultAzureCredential());
                })

                .ConfigureLogging((context, logging) =>
                {
                    logging.ClearProviders();
                    logging.AddConfiguration(context.Configuration.GetSection("Logging"));
                    logging.AddConsole();
                    logging.AddDebug();
                    logging.AddApplicationInsights();
                })
                
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.CaptureStartupErrors(true);
                    webBuilder.UseSetting("detailedErrors", "true");
                    webBuilder.UseStartup<Startup>();
                });

    }
}
