# Callisto Core API

Providing datamanagement endpoints for the callisto project

### Environments
Infrastructure `.bicep` scripts are kept at https://github.com/3DegreesGroupInc/Callisto.Infrastructure

#### Dev

- Resource Group: `rg-callisto-dev`
- Key Vault: `keyvault-callisto-dev`
- Storage Account: `sacallistodev`
- DataSystem API: https://webapp-datasystem-dev.azurewebsites.net/swagger


### Required Key Vault Secrets:

- `ADMIS-SFTP-PASSWORD`
- `ADMIS-SFTP-URL`
- `ADMIS-SFTP-USERNAME`
- `ARGUS-ID`
- `ARGUS-PASSWORD`
- `ARGUS-URI`
- `NETSUITE-ACCOUNT-ID`
- `NETSUITE-CONSUMER-KEY`
- `NETSUITE-CONSUMER-SECRET`
- `NETSUITE-TOKEN-ID`
- `NETSUITE-TOKEN-SECRET`
- `NETSUITE-URI`
- `CALLISTO-ALERT-EMAIL`
- `CALLISTO-ALERT-EMAIL-PWD`
- `CALLISTO-DB-CENTRALOPS`
- `CALLISTO-DB-DATAWAREHOUSE`
- `CALLISTO-STORAGEACCOUNT`
- `AZURE-DATA-FACTORY-CLIENT-ID`
- `AZURE-DATA-FACTORY-CLIENT-SECRET`
- `AZURE-DATA-FACTORY-NAME`
- `AZURE-DATA-FACTORY-RESOURCE-GROUP`
- `AZURE-DATA-FACTORY-SUBSCRIPTION-ID`