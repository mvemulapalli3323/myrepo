﻿CREATE TABLE [OperationalDatabase].[ReferenceDataField]
(
	[ReferenceDataFieldId] INT NOT NULL PRIMARY KEY IDENTITY,
	[ReferenceDataFieldCode] VARCHAR(100) NOT NULL,
	[ReferenceDataEntityId] INT NOT NULL FOREIGN KEY REFERENCES OperationalDatabase.ReferenceDataEntity(ReferenceDataEntityId), 
	[DataType] VARCHAR(100) NOT NULL,
	[SortOrder] INT NOT NULL,
    [IsRequired] BIT NOT NULL,
	[IsTimeSeries] BIT NOT NULL,
	[IsActive] BIT NOT NULL,
)
