﻿CREATE TABLE [OperationalDatabase].[PriceMark]
(
    PriceMarkId INT NOT NULL PRIMARY KEY IDENTITY,
	PriceMarkDate DATE NOT NULL,
    ProductId INT NULL,
    PeriodId INT NOT NULL,
    Bid MONEY NOT NULL,
    Offer MONEY NOT NULL,
    Settle MONEY NOT NULL,
    AddUser SYSNAME NULL,
    AddDateTime DATETIME NULL,
    ChangeUser SYSNAME NULL,
    ChangeDateTime DATETIME NULL, 
    DataTimeStamp TIMESTAMP NULL,
    BidTypeId INT NOT NULL,
    OfferTypeId INT NOT NULL,
    SettleTypeId INT NOT NULL,
    PriceMarkScenarioTypeId INT NULL
    
)

