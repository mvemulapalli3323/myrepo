﻿CREATE TABLE [OperationalDatabase].[PriceSnapshot]
(
    PriceSnapshotId INT NOT NULL PRIMARY KEY IDENTITY,
    TaskRunId INT NOT NULL,
    DateId INT NOT NULL,
    CurrencyId INT NOT NULL,
    PricingSourceId INT NOT NULL,
    ProductId INT NOT NULL,
    PeriodId INT NOT NULL,
    PriceTypeId INT NOT NULL,
    GenerationPeriodStart DATETIME NULL,
    GenerationPeriodEnd DATETIME NULL,
    SettleDate DATE NULL,
    Bid MONEY NULL,
    Ask MONEY NULL,
    LastPrice MONEY NOT NULL
)

