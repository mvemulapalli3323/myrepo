﻿CREATE TABLE [OperationalDatabase].[TaskSubtask]
(
	[TaskSubtaskId] INT NOT NULL PRIMARY KEY IDENTITY,
	[TaskId] INT NOT NULL FOREIGN KEY REFERENCES [OperationalDatabase].Task(TaskId),
	[SubtaskId] INT NOT NULL FOREIGN KEY REFERENCES [OperationalDatabase].Task(TaskId),
	[Step] INT NOT NULL,
	CONSTRAINT TaskStep UNIQUE (TaskId,Step),
)
