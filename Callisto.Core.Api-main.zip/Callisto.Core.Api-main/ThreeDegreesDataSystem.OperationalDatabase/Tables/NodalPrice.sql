﻿CREATE TABLE [OperationalDatabase].[NodalPrice]
(
    NodalPriceId INT NOT NULL PRIMARY KEY IDENTITY,
	TaskRunId INT NULL,
    ContractCode VARCHAR(100),
    Expiry DATETIME NULL,
	OpenPrice MONEY NULL,
	HighPrice MONEY NULL,
	LowPrice MONEY NULL,
	ClosePrice MONEY NULL,
	SettlementPrice MONEY NULL,
	PriceChange DECIMAL(18,4) NULL,
	OpenInterest INT NULL,
	OiChange INT NULL,
	TotalVolume INT NULL,
	EfrpVolume INT NULL,
	BlockVolume INT NULL
)
--CREATE CLUSTERED INDEX IX_NodalPrices_ID ON [OperationalDatabase].[NodalPrice] (NodalPriceId)
