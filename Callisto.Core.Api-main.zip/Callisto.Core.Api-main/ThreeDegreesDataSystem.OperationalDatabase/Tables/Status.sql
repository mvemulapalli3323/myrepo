﻿CREATE TABLE [OperationalDatabase].[Status]
(
	[StatusId] INT NOT NULL PRIMARY KEY,
	[StatusCode] VARCHAR(100) NOT NULL,
	[StatusDescription] VARCHAR(200) NOT NULL,
	[IsActive] BIT NOT NULL
)
