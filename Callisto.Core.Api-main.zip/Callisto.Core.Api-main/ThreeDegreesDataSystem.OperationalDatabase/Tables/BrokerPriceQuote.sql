﻿CREATE TABLE [OperationalDatabase].[BrokerPriceQuote]
(
    [BrokerPriceQuoteId] INT NOT NULL PRIMARY KEY IDENTITY,
	[BrokerName] VARCHAR(100) NOT NULL,
    [PriceQuoteDate] DATETIME NULL,
    [Exchange] VARCHAR(100) NULL,
    [ProductName] VARCHAR(100) NOT NULL,
    [Term] VARCHAR(100) NULL,
    [BidValue] MONEY NULL,
    [AskValue] MONEY NULL,
    [MidValue] MONEY NULL,
    [ValueDate] DATETIME NULL,
    [UploadDate] DATETIME NULL, 
    [TaskRunId] INT NOT NULL
)

