﻿CREATE TABLE [OperationalDatabase].[MdmProduct]
(
	[MdmProductId] INT NOT NULL PRIMARY KEY IDENTITY,
	[MdmProductCode]  VARCHAR(100) NOT NULL UNIQUE, 
    [MdmProductName] VARCHAR(200) NULL,  
    [SalesforceId] INT NULL,  
    [NetSuiteId] INT NULL, 
    [GoldenSource] VARCHAR(100) NOT NULL, 
    [LastModifiedBy] VARCHAR(100) NOT NULL, 
    [LastModifiedOn] DATETIME NOT NULL, 
    [ProductStatus] VARCHAR(100) NOT NULL DEFAULT 'Active',  -- Active, Inactive, Deleted, Ect
    [ValidFrom] DATETIME2 GENERATED ALWAYS AS ROW START HIDDEN NOT NULL,
    [ValidTo] DATETIME2 GENERATED ALWAYS AS ROW END HIDDEN NOT NULL,
    PERIOD FOR SYSTEM_TIME(ValidFrom, ValidTo)  
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = [OperationalDatabase].[MdmProductHistory]));
