﻿CREATE TABLE [OperationalDatabase].[TaskRun]
(
	[TaskRunId] INT NOT NULL PRIMARY KEY IDENTITY,
	[TaskId] INT NOT NULL FOREIGN KEY REFERENCES [OperationalDatabase].Task(TaskId),
	[ParentTaskRunId] INT NULL FOREIGN KEY REFERENCES [OperationalDatabase].TaskRun(TaskRunId),
	[StatusId] INT NOT NULL FOREIGN KEY REFERENCES [OperationalDatabase].Status(StatusId),
	[CreatedBy] VARCHAR(100) NOT NULL DEFAULT 'ADMIN',
	[CreatedOn] DATETIME NOT NULL DEFAULT GETDATE(),
	[LastModifiedBy] VARCHAR(100) NOT NULL DEFAULT 'ADMIN',
	[LastModifiedOn] DATETIME NOT NULL DEFAULT GETDATE(),
	[StartedOn] DATETIME NULL,
	[Parameters] VARCHAR(MAX) NULL,
	[Message] VARCHAR(MAX) NULL,
	[CurrentStep] INT NOT NULL,
	[ParentStep] INT NULL,
    [IsValid] BIT NOT NULL DEFAULT 0,
)
