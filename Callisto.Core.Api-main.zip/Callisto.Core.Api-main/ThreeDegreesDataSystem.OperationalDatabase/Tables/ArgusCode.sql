﻿CREATE TABLE [OperationalDatabase].[ArgusCode]
(
	[ArgusCodeId] INT NOT NULL PRIMARY KEY IDENTITY,
    [CodeId] INT NOT NULL,
    [Description] VARCHAR(200) NOT NULL,
    [UnitId1] INT NOT NULL,
    [UnitId2] INT NULL,
    [DelModeId] INT NOT NULL,
    [ActiveYn] VARCHAR(10) NOT NULL,
    [WefDate] DATETIME NOT NULL,
    [EndDate] DATETIME NULL,
    [WeekendIsHolidayYn] VARCHAR(10) NOT NULL,
    [UploadFreqId] INT NOT NULL,
    [RepTimestamp] DATETIME NOT NULL,
    [Specification] VARCHAR(200) NULL,
    [TaskRunId] INT NOT NULL
)
