﻿CREATE TABLE [OperationalDatabase].[ReferenceDataEntity]
(
	[ReferenceDataEntityId] INT NOT NULL PRIMARY KEY IDENTITY,
	[ReferenceDataEntityCode] VARCHAR(100) NOT NULL,
	[ReferenceDataEntityDescription] VARCHAR(200) NOT NULL, 
    [IsActive] BIT NOT NULL,
)
