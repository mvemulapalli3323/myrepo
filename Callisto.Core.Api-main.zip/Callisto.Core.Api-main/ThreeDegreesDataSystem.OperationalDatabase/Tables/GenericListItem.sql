﻿CREATE TABLE [OperationalDatabase].[GenericListItem]
(
	[GenericListItemId] INT NOT NULL PRIMARY KEY IDENTITY,
	[Value] VARCHAR(300) NOT NULL,
	[TypeCode] VARCHAR(100) NOT NULL,
)
