﻿CREATE TABLE [OperationalDatabase].[GenericMap]
(
	[GenericMapId] INT NOT NULL PRIMARY KEY IDENTITY,
	[Value1] VARCHAR(300) NOT NULL,
	[Value2] VARCHAR(MAX) NOT NULL, 
    [TypeCode] VARCHAR(100) NOT NULL,
)
