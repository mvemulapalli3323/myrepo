﻿CREATE TABLE [OperationalDatabase].[SelectOption]
(
	[SelectOptionId] INT NOT NULL PRIMARY KEY IDENTITY,
	[SelectOptionTypeCode] VARCHAR(100) NOT NULL,
	[SelectOptionValue] VARCHAR(100) NOT NULL,
	[SelectOptionDescription] VARCHAR(200) NOT NULL,
	[IsActive] BIT NOT NULL
)
