﻿CREATE TABLE [OperationalDatabase].[ReferenceDataFieldValue]
(
	[ReferenceDataFieldValueId] INT NOT NULL PRIMARY KEY IDENTITY,
	[ReferenceDataFieldId] INT NOT NULL FOREIGN KEY REFERENCES OperationalDatabase.ReferenceDataField(ReferenceDataFieldId),
	[StringValue] VARCHAR(MAX) NULL, 
	[DateTimeValue] DATETIME NULL,
	[IntegerValue] INT NULL,
    [BooleanValue] BIT NULL,
	[DecimalValue] DECIMAL(28, 10) NULL,
	[StartDate] DATETIME NULL,
	[EndDate] DATETIME NULL,
	[IsActive] BIT NOT NULL DEFAULT(1)
)
