﻿CREATE TABLE [OperationalDatabase].[GenericTimeout]
(
	[GenericTimeoutId] INT NOT NULL PRIMARY KEY IDENTITY,
	[Value] INT NOT NULL,
	[TypeCode] VARCHAR(100) NOT NULL UNIQUE,
)
