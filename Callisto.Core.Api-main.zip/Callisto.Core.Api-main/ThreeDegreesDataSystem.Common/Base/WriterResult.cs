﻿namespace ThreeDegreesDataSystem.Common.Base
{
    public class WriterResult
    {
        public string Status;
        public string Message;
        public dynamic Data;
    }
}
