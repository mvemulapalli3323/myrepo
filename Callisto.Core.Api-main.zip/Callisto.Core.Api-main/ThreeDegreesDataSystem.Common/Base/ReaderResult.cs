﻿namespace ThreeDegreesDataSystem.Common.Base
{
    public class ReaderResult
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }
}
