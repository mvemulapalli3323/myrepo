﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace ThreeDegreesDataSystem.Common.Converters
{
    public class XmlArrayToListConverter
    {
        public static List<T> ConvertXmlToList<T>(XElement[] arrayOfXElement)
        {
            if (arrayOfXElement == null || arrayOfXElement.Length == 0)
            {
                return new List<T>();
            }

            var result = new List<T>();

            foreach (var element in arrayOfXElement)
            {
                try
                {
                    // Deserialize the XElement to the specified type
                    var serializer = new XmlSerializer(typeof(T));
                    using (var reader = element.CreateReader())
                    {
                        var obj = (T)serializer.Deserialize(reader);
                        result.Add(obj);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error converting XElement to {typeof(T)}: {ex.Message}");
                }
            }

            return result;
        }
    }
}
