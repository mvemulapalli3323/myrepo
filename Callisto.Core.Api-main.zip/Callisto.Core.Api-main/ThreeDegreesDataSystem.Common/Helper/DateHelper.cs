﻿namespace ThreeDegreesDataSystem.Common.Helper
{
    
    public static class DateHelper
    {
        public static List<(DateTime, DateTime)> GetMonthStartAndEndDates(DateTime startDate, DateTime endDate)
        {
            List<(DateTime, DateTime)> monthStartAndEndDates = new();
            DateTime currentMonth = startDate;
            while (currentMonth < endDate)
            {
                DateTime currentMonthStart = new(currentMonth.Year, currentMonth.Month, 1);
                DateTime currentMonthEnd = currentMonthStart.AddMonths(1).AddDays(-1);
                // For the first month, use the startDate.
                if (currentMonth.ToString("yyyy MM") == startDate.ToString("yyyy MM"))
                {
                    currentMonthStart = startDate;
                }
                // For the last month, use the endDate.
                else if (currentMonth.Year == endDate.Year && currentMonth.Month == endDate.Month)
                {
                    currentMonthEnd = endDate;
                }

                (DateTime, DateTime) currentMonthStartAndEndDates = new();
                currentMonthStartAndEndDates.Item1 = currentMonthStart;
                currentMonthStartAndEndDates.Item2 = currentMonthEnd;
                monthStartAndEndDates.Add(currentMonthStartAndEndDates);
                currentMonth = currentMonth.AddMonths(1);
            }
            return monthStartAndEndDates;
        }

        public static string ReplaceTimeZone(string dateString)
        {
            foreach (KeyValuePair<string, string> item in _timeZones)
            {
                dateString = dateString.Replace(item.Key, item.Value);
            }
            return dateString;
        }

        private static readonly Dictionary<string, string> _timeZones = new() {
            {"ACDT", "+10:30"},
            {"ACST", "+09:30"},
            {"ADT", "-03:00"},
            {"AEDT", "+11:00"},
            {"AEST", "+10:00"},
            {"AHDT", "-09:00"},
            {"AHST", "-10:00"},
            {"AST", "-04:00"},
            {"AT", "-02:00"},
            {"AWDT", "+09:00"},
            {"AWST", "+08:00"},
            {"BAT", "+03:00"},
            {"BDST", "+02:00"},
            {"BET", "-11:00"},
            {"BST", "-03:00"},
            {"BT", "+03:00"},
            {"BZT2", "-03:00"},
            {"CADT", "+10:30"},
            {"CAST", "+09:30"},
            {"CAT", "-10:00"},
            {"CCT", "+08:00"},
            {"CDT", "-05:00"},
            {"CED", "+02:00"},
            {"CET", "+01:00"},
            {"CEST", "+02:00"},
            {"CST", "-06:00"},
            {"EAST", "+10:00"},
            {"EDT", "-04:00"},
            {"EED", "+03:00"},
            {"EET", "+02:00"},
            {"EEST", "+03:00"},
            {"EST", "-05:00"},
            {"FST", "+02:00"},
            {"FWT", "+01:00"},
            {"GMT", "GMT"},
            {"GST", "+10:00"},
            {"HDT", "-09:00"},
            {"HST", "-10:00"},
            {"IDLE", "+12:00"},
            {"IDLW", "-12:00"},
            {"IST", "+05:30"},
            {"IT", "+03:30"},
            {"JST", "+09:00"},
            {"JT", "+07:00"},
            {"MDT", "-06:00"},
            {"MED", "+02:00"},
            {"MET", "+01:00"},
            {"MEST", "+02:00"},
            {"MEWT", "+01:00"},
            {"MST", "-07:00"},
            {"MT", "+08:00"},
            {"NDT", "-02:30"},
            {"NFT", "-03:30"},
            {"NT", "-11:00"},
            {"NST", "+06:30"},
            {"NZ", "+11:00"},
            {"NZST", "+12:00"},
            {"NZDT", "+13:00"},
            {"NZT", "+12:00"},
            {"PDT", "-07:00"},
            {"PST", "-08:00"},
            {"ROK", "+09:00"},
            {"SAD", "+10:00"},
            {"SAST", "+09:00"},
            {"SAT", "+09:00"},
            {"SDT", "+10:00"},
            {"SST", "+02:00"},
            {"SWT", "+01:00"},
            {"USZ3", "+04:00"},
            {"USZ4", "+05:00"},
            {"USZ5", "+06:00"},
            {"USZ6", "+07:00"},
            {"UT", "-00:00"},
            {"UTC", "-00:00"},
            {"UZ10", "+11:00"},
            {"WAT", "-01:00"},
            {"WET", "-00:00"},
            {"WST", "+08:00"},
            {"YDT", "-08:00"},
            {"YST", "-09:00"},
            {"ZP4", "+04:00"},
            {"ZP5", "+05:00"},
            {"ZP6", "+06:00"}
        };

        public static int GetQtdPeriods(int currentMonth)
        {
            switch(currentMonth)
            {
                case 1:
                case 4:
                case 7:
                case 10:
                    return 1;
                case 2:
                case 5:
                case 8:
                case 11:
                    return 2;
                case 3:
                case 6:
                case 9:
                case 12:
                    return 3;
                default:
                    throw new Exception("Month number is out of range 1-12");
            }
        }

        public static int GetFytdPeriods(int currentMonth)
        {
            if (currentMonth < 7)
            {
                return currentMonth + 6;
            }
            else
            {
                return currentMonth - 6;
            }
        }

    }
}
