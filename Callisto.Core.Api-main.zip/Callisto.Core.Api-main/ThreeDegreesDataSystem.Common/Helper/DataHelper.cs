﻿using System;

namespace ThreeDegreesDataSystem.Common.Helper
{
    public static class DataHelper
    {


        public static dynamic ConvertCsvValue(string type, string item, int index, int rowIndex)
        {
            try
            {
                switch (type)
                {
                    case "Int":
                        return int.Parse(item);
                    case "Bool":
                        if (item == "1")
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    case "NullableBool":
                        if (string.IsNullOrEmpty(item))
                        {
                            return null;
                        }
                        else
                        {
                            if (item == "1")
                            {
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                    case "NullableInt":
                        if (string.IsNullOrEmpty(item))
                        {
                            return null;
                        }
                        else
                        {
                            return int.Parse(item);
                        }
                    case "Decimal":
                        return (decimal)double.Parse(item);
                    case "NullableDecimal":
                        if (string.IsNullOrEmpty(item))
                        {
                            return null;
                        }
                        else
                        {
                            return (decimal)double.Parse(item);
                        }
                    case "DateTime":
                        return DateTime.Parse(item);
                    case "NullableDateTime":
                        if (string.IsNullOrEmpty(item))
                        {
                            return null;
                        }
                        else
                        {
                            return DateTime.Parse(item);
                        }
                    default:
                        return item;
                }
            }
            catch (Exception)
            {
                throw new Exception($"Unable to map - column index: {index} row index: {rowIndex} value: {item}");
            }
        }

        public static decimal GetDecimal(string item, int index)
        {
            try
            {
                return int.Parse(item);
            }
            catch (Exception)
            {
                throw new Exception($"Unable to map to int column index: {index} value: {item}");
            }
        }

        public static DateTime? GetNullableDateTimeFromDataRow(object value)
        {
            return value.ToString() == string.Empty ? null : DateTime.Parse(value.ToString());
        }

        public static int? GetNullableIntFromDataRow(object value)
        {
            return value.ToString() == string.Empty ? null : int.Parse(value.ToString());
        }

        public static bool? GetNullableBoolFromYesNoDataRow(object value)
        {
            switch (value.ToString())
            {
                case "Yes":
                    return true;
                case "No":
                    return false;
                default:
                    return null;
            }
        }

        public static bool GetBoolFromYesNoDataRow(object value)
        {
            if (value.ToString() == "Yes")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
