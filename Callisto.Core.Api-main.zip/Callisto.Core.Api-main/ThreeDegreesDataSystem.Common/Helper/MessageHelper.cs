﻿using System;

namespace ThreeDegreesDataSystem.Common.Helper
{
    public static class MessageHelper
    {
        public static string AppendToMessage(string original, string message)
        {
            if (String.IsNullOrEmpty(original))
            {
                return message;
            }
            return original + $"\n{message}";
        }
    }
}
