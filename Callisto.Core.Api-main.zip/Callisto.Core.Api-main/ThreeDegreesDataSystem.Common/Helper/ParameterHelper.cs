﻿
using ThreeDegreesDataSystem.Common.Exceptions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Models;

#nullable enable

namespace ThreeDegreesDataSystem.Common.Helper
{
    public class RunParameters
    {
        [JsonProperty(PropertyName = "azureBlobContainer")]
        public string? AzureBlobContainer { get; set; }
        
        [JsonProperty(PropertyName = "azureBlobName")]
        public string? AzureBlobName { get; set; }

        [JsonProperty(PropertyName = "businessDate")]
        public DateTime? BusinessDate { get; set; }

        [JsonProperty(PropertyName = "runDate")]
        public DateTime? RunDate { get; set; }

        [JsonProperty(PropertyName = "endDate")]
        public DateTime? EndDate { get; set; }
        
        [JsonProperty(PropertyName = "filePath")]
        public string? FilePath { get; set; }
        
        [JsonProperty(PropertyName = "filePaths")]
        public string[]? FilePaths { get; set; }
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }
        
        [JsonProperty(PropertyName = "taskRunIds")]
        public Dictionary<string, int>? TaskRunIds { get; set; }
        
        [JsonProperty(PropertyName = "timeout")]
        public int? Timeout { get; set; }

        [JsonProperty(PropertyName = "mdmProducts")]
        public SalesforceMdmProductInfo[]? MdmProducts { get; set; }
        
        [JsonProperty(PropertyName = "callback")]
        public string? Callback { get; set; }
    }

    public static class ParameterHelper
    {
        
        public static string GetAzureBlobContainer(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.AzureBlobContainer ?? throw new ParameterNotFoundException("No Azure Blob Container provided!");
        }

        public static string SetAzureBlobContainer(string parameters, string blobContainer)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            parametersObj.AzureBlobContainer = blobContainer;
            return SerializeParameters(parametersObj);
        }

        public static string GetAzureBlobName(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.AzureBlobName ?? throw new ParameterNotFoundException("No Azure Blob Name provided!");
        }

        public static string SetAzureBlobName(string parameters, string blobName)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            parametersObj.AzureBlobName = blobName;
            return SerializeParameters(parametersObj);
        }

        public static DateTime GetBusinessDate(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.BusinessDate ?? throw new ParameterNotFoundException("No Business Date provided!");
        }
        public static DateTime GetStartDate(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.StartDate ?? throw new ParameterNotFoundException("No Start Date provided!");
        }

        public static string SetStartDate(string parameters, DateTime date)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            parametersObj.StartDate = date;
            return SerializeParameters(parametersObj);
        }

        public static DateTime GetEndDate(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.EndDate ?? throw new ParameterNotFoundException("No End Date provided!");
        }

        public static DateTime? GetNullableEndDate(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj?.EndDate ?? null;
        }

        public static DateTime? GetNullableStartDate(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj?.StartDate ?? null;
        }

        public static string SetEndDate(string parameters, DateTime date)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            parametersObj.EndDate = date;
            return SerializeParameters(parametersObj);
        }

        public static string GetFilePath(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.FilePath ?? throw new ParameterNotFoundException("No File Path provided!");
        }

        public static string SetFilePath(string parameters, string filePath)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            parametersObj.FilePath = filePath;
            return SerializeParameters(parametersObj);
        }

        public static string AddFilePath(string parameters, string filePath)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            List<string> filePathList = new();
            if (parametersObj.FilePaths != null) filePathList.AddRange(parametersObj.FilePaths);
            filePathList.Add(filePath);
            parametersObj.FilePaths = filePathList.ToArray();
            return SerializeParameters(parametersObj);
        }

        public static string[] GetFilePaths(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.FilePaths ?? throw new ParameterNotFoundException("No File Paths provided!");
        }

        public static SalesforceMdmProductInfo[] GetMdmProducts(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.MdmProducts ?? throw new ParameterNotFoundException("No mdm products provided!");
        }

        public static string GetCallback(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.Callback ?? throw new ParameterNotFoundException("No Azure Logic Webhook callback provided!");
        }

        public static string SetFilePaths(string parameters, string[] filePaths)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            parametersObj.FilePaths = filePaths;
            return SerializeParameters(parametersObj);
        }

        public static int GetTaskRunId(string parameters, string taskCode)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            Dictionary<string, int> taskRunIds = parametersObj.TaskRunIds ?? throw new ParameterNotFoundException("No Task Run Ids provided!");
            if (taskRunIds.ContainsKey(taskCode))
            {
                return taskRunIds[taskCode];
            }
            throw new ParameterNotFoundException($"No Task Run Id provided for code '{taskCode}'!");
        }

        public static string SetTaskRunId(string parameters, string taskCode, int taskRunId)
        {
            RunParameters parametersObj = DeserializeParameters(parameters ?? "{}");
            parametersObj.TaskRunIds ??= new();
            parametersObj.TaskRunIds[taskCode] = taskRunId;
            return SerializeParameters(parametersObj);
        }

        public static string SetTaskRunIdIfNotSet(string parameters, string taskCode, int taskRunId)
        {
            RunParameters parametersObj = DeserializeParameters(parameters ?? "{}");
            parametersObj.TaskRunIds ??= new();
            if (!parametersObj.TaskRunIds.ContainsKey(taskCode))
            {
                parametersObj.TaskRunIds[taskCode] = taskRunId;
            }
            return SerializeParameters(parametersObj);
        }

        public static int GetTimeout(string parameters)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            return parametersObj.Timeout ?? throw new ParameterNotFoundException("No Timeout provided!");
        }

        public static string SetTimeout(string parameters, int timeout)
        {
            RunParameters parametersObj = DeserializeParameters(parameters);
            parametersObj.Timeout = timeout;
            return SerializeParameters(parametersObj);
        }

        private static RunParameters DeserializeParameters(string parameters)
        {
            try
            {
                RunParameters? parametersObj = JsonConvert.DeserializeObject<RunParameters>(parameters);
                return parametersObj ?? new();
            }
            catch (Exception e)
            {
                throw ;
            }

        }

        private static string SerializeParameters(RunParameters parametersObj)
        {
            return JsonConvert.SerializeObject(parametersObj, new JsonSerializerSettings{ NullValueHandling = NullValueHandling.Ignore });
        }
    }
}
