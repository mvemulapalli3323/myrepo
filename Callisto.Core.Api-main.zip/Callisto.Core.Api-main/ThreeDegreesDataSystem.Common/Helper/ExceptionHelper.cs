﻿using System;

namespace ThreeDegreesDataSystem.Common.Helper
{
    public static class ExceptionHelper
    {
        /// <summary>
        /// Transforms the exception members into a string.
        /// </summary>
        /// <returns>String representation describing the exception.</returns>
        public static string BuildMessage(Exception ex)
        {
            return $"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}";
        }
    }
}
