﻿using ThreeDegreesDataSystem.Common.ConnectionParameters;
using System;
using Microsoft.Extensions.Configuration;

namespace ThreeDegreesDataSystem.Common.Helper
{
    public static class EnvironmentHelper
    {
        private static string _environmentName;
        private static IConfiguration _config;

        public static void Initialize(string environmentName, IConfiguration configuration)
        {
            _environmentName = environmentName
                ?? throw new ArgumentNullException(nameof(environmentName), "Environment name cannot be null");

            _config = configuration
                ?? throw new ArgumentNullException(nameof(configuration));
        }

        private static string Get(string key)
            => _config[key]
               ?? throw new InvalidOperationException($"Configuration key '{key}' not found");

        public static string GetEnvironmentName()
        {
            return _environmentName;
        }

        public static string GetDbConnectionString()
            => Get("CALLISTO-DB-CENTRALOPS");

        public static string GetDwDbConnectionString()
            => Get("CALLISTO-DB-DATAWAREHOUSE");

        public static string GetBlobStorageConnectionString()
            => Get("CALLISTO--STORAGEACCOUNT");

        public static AzureDataFactoryConnectionParameters GetAzureDataFactoryConnectionParameters()
            => new AzureDataFactoryConnectionParameters
            {
                ClientId = Get("AZURE-DATA-FACTORY-CLIENT-ID"),
                ClientSecret = Get("AZURE-DATA-FACTORY-CLIENT-SECRET"),
                TenantId = Get("AZURE-TENANT-ID"),
                ResourceGroup = Get("AZURE-DATA-FACTORY-RESOURCE-GROUP"),
                SubscriptionId = Get("AZURE-DATA-FACTORY-SUBSCRIPTION-ID"),
                DataFactoryName = Get("AZURE-DATA-FACTORY-NAME")
            };

        public static ArgusConnectionParameters GetArgusConnectionParameters()
            => new ArgusConnectionParameters
            {
                Id = Get("ARGUS-ID"),
                Password = Get("ARGUS-PASSWORD"),
                Uri = Get("ARGUS-URI")
            };

        public static NetSuiteConnectionParameters GetNetSuiteConnectionParameters()
            => new NetSuiteConnectionParameters
            {
                AccountId = Get("NETSUITE-ACCOUNT-ID"),
                ConsumerKey = Get("NETSUITE-CONSUMER-KEY"),
                ConsumerSecret = Get("NETSUITE-CONSUMER-SECRET"),
                TokenId = Get("NETSUITE-TOKEN-ID"),
                TokenSecret = Get("NETSUITE-TOKEN-SECRET"),
                Uri = Get("NETSUITE-URI")
            };

        public static EmailConnectionParameters GetEmailConnectionParameters()
            => new EmailConnectionParameters
            {
                EnvironmentName = GetEnvironmentName(),
                AlertEmail = Get("CALLISTO-ALERT-EMAIL"),
                AlertEmailPassword = Get("CALLISTO-ALERT-EMAIL-PWD"),
            };
    }

}
