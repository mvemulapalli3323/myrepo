﻿

using System.ServiceModel;

namespace ThreeDegreesDataSystem.Common.ConnectionParameters
{
    public class NetSuiteConnectionParameters
    {
        public NetSuiteConnectionParameters() 
        { 
            
        }

        public string AccountId { get; set; }
        public string ConsumerKey { get; set; }
        public string ConsumerSecret { get; set; }
        public string TokenId { get; set; }
        public string TokenSecret { get; set; }
        public string Uri { get; set; }


    }
}
