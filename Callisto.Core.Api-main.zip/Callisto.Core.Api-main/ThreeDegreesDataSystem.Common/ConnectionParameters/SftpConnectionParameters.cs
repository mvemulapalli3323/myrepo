﻿

namespace ThreeDegreesDataSystem.Common.ConnectionParameters
{
    public class SftpConnectionParameters
    {
        public SftpConnectionParameters() { }
      
        public string Host { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

    }
}
