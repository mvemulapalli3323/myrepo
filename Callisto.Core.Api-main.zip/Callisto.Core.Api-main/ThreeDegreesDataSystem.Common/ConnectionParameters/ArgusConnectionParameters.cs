﻿

using System.ServiceModel;

namespace ThreeDegreesDataSystem.Common.ConnectionParameters
{
    public class ArgusConnectionParameters
    {
        public ArgusConnectionParameters() 
        { 
            Binding = new BasicHttpsBinding { MaxReceivedMessageSize = int.MaxValue };
        }

        public string Id { get; set; }
        public string Password { get; set; }
        public string Uri { get; set; }
        public BasicHttpsBinding Binding { get; set; }

    }
}
