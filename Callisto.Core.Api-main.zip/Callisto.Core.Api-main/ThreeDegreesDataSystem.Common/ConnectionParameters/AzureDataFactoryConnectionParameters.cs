﻿

namespace ThreeDegreesDataSystem.Common.ConnectionParameters
{
    public class AzureDataFactoryConnectionParameters
    {
        public AzureDataFactoryConnectionParameters() { }

        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string TenantId { get; set; }
        public string ResourceGroup { get; set; }
        public string SubscriptionId { get; set; }
        public string DataFactoryName { get; set; }
    }
}
