﻿

using System.ServiceModel;

namespace ThreeDegreesDataSystem.Common.ConnectionParameters
{
    public class EmailConnectionParameters
    {
        public EmailConnectionParameters() 
        { 
            
        }

        public string? EnvironmentName { get; set; }
        public string? AlertEmail { get; set; }
        public string? AlertEmailPassword { get; set; }
        
    }
}
