﻿namespace ThreeDegreesDataSystem.Common.Writer
{
    public interface IExcelColumnParameter
    {
        public string Header { get; set; }
        public string Format { get; set; }

    }
}
