﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Common.Writer
{
    public class ExcelFileInfo
    {
        public ExcelFileInfo() 
        {
            WorkbookData = new Dictionary<string, List<dynamic>>();
            ColumnParameters = new Dictionary<string, List<ExcelColumnParameter>>();
            TabNames = new List<string>();
            ColumnIndexesToIgnore = new List<int>();
        }

        public Dictionary<string, List<dynamic>> WorkbookData { get; set; }
        public Dictionary<string, List<ExcelColumnParameter>> ColumnParameters { get; set; }
        public List<string> TabNames { get; set; }
        public List<int> ColumnIndexesToIgnore { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string FileName { get; set; }
        public bool IncludeCustomHeaders { get; set; }
        public bool UseCustomStyles { get; set; }
        public bool WriteExpandoObjects { get; set; }
        public bool WriteLocal { get; set; }
        public string BlobStorageConnectionString { get; set; }
        public string BlobStorageContainer { get; set; }

    }
}
