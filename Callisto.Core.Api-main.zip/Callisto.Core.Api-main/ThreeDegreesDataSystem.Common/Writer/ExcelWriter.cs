﻿
using Azure.Storage.Blobs;
using ThreeDegreesDataSystem.Common.Writer;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Base;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Linq;

namespace ThreeDegreesDataSystem.Common.Writers
{
    public class ExcelWriter
    {
        public ExcelWriter()
        {

        }

        private ICellStyle GetCellStyle(string formatCode, IWorkbook workbook)
        {
            ICellStyle cellStyle = workbook.CreateCellStyle();
            switch(formatCode)
            {
                case StringConstants.Integer:
                    cellStyle.DataFormat = HSSFDataFormat.GetBuiltinFormat("0");
                    break;
                case StringConstants.Decimal:
                    cellStyle.DataFormat = HSSFDataFormat.GetBuiltinFormat("0.00");
                    break;
                case StringConstants.Percent:
                    cellStyle.DataFormat = HSSFDataFormat.GetBuiltinFormat("0.00%");
                    break;

            }

            return cellStyle; 
        }

        public WriterResult WriteToExcel(ExcelFileInfo excelFileInfo)
        {
            var result = new WriterResult();
            try
            {
                IWorkbook workbook;

                switch (excelFileInfo.FileType)
                {
                    case StringConstants.Xlsx:
                        workbook = new XSSFWorkbook();
                        break;
                    case StringConstants.Xls:
                        workbook = new HSSFWorkbook();
                        break;
                    default:
                        workbook = new XSSFWorkbook();
                        break;
                }
                
                foreach(var tabName in excelFileInfo.TabNames)
                {
                    ISheet sheet = workbook.CreateSheet(tabName);
                    var index = 0;
                    var columnStyles = new List<ICellStyle>();
                    

                    foreach (var item in excelFileInfo.WorkbookData[tabName])
                    {
                        if (excelFileInfo.IncludeCustomHeaders && index == 0)
                        {
                            var cell = 0;
                            IRow headerRow = sheet.CreateRow(index);

                            if (excelFileInfo.ColumnParameters[tabName] != null)
                            {
                                ICell headerCell;
                                IFont font = workbook.CreateFont();
                                font.IsBold = true;

                                ICellStyle headerCellStyle = workbook.CreateCellStyle();
                                headerCellStyle.SetFont(font);

                                foreach (var column in excelFileInfo.ColumnParameters[tabName])
                                {
                                    headerCell = headerRow.CreateCell(cell);
                                    headerCell.SetCellValue(column.Header);
                                    headerCell.CellStyle = headerCellStyle;
                                    if (excelFileInfo.UseCustomStyles)
                                    {
                                        columnStyles.Add(GetCellStyle(column.Format, workbook));
                                    }
                                    
                                    cell++;
                                }
                            }
                            else
                            {
                                
                                foreach (PropertyInfo property in item.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
                                {
                                    if (excelFileInfo.ColumnIndexesToIgnore.Contains(cell)) continue;

                                    headerRow.CreateCell(cell).SetCellValue((property.Name));
                                    cell++;
                                }
                            }

                            index++;
                        }

                        IRow row = sheet.CreateRow(index);

                        if (excelFileInfo.WriteExpandoObjects)
                        {
                            WriteExpandoRow(row, item, excelFileInfo, columnStyles);
                        }
                        else
                        {
                            WriteRow(row, item, excelFileInfo, columnStyles);
                        }
                        
                        index++;

                    }

                    var numberOfColumns = sheet.GetRow(0)?.PhysicalNumberOfCells;
                    if (numberOfColumns != null)
                    {
                        for (int i = 1; i <= numberOfColumns; i++)
                        {
                            sheet.AutoSizeColumn(i);
                            GC.Collect();
                        }
                    }
                }
                //write local for testing
                if (excelFileInfo.WriteLocal)
                {
                    using (FileStream stream = new FileStream($"C:\\Temp\\TestFile.xlsx", FileMode.Create, FileAccess.Write))
                    {
                        workbook.Write(stream);
                    }
                }
                else
                {
                    string containerName = excelFileInfo.BlobStorageContainer;
                    var serviceClient = new BlobServiceClient(excelFileInfo.BlobStorageConnectionString);
                    var containerClient = serviceClient.GetBlobContainerClient(containerName);

                    var blobClient = containerClient.GetBlobClient($"{excelFileInfo.FileName}.{excelFileInfo.FileType}");

                    using (var ms = new MemoryStream())
                    {
                        workbook.Write(ms);
                        var fs = new MemoryStream(ms.ToArray());
                        blobClient.Upload(fs, overwrite: true);
                    }
                }

                result.Status = StringConstants.Succeeded;
                result.Message = @"{""messageType"":""fileLinks"",""message"":""Reports""}";
            }
            catch (Exception ex)
            {
                result.Status = StringConstants.Failed;
                result.Message = $"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}";
            }

            return result;
        }

        private void WriteRow(IRow row, dynamic item, ExcelFileInfo excelFileInfo, List<ICellStyle> columnStyles)
        {
            var cellIndex = 0;
            var propertyIndex = 0;
            var styleIndex = 0;
            foreach (PropertyInfo property in item.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (excelFileInfo.ColumnIndexesToIgnore.Contains(propertyIndex))
                {
                    propertyIndex++;
                    continue;
                }

                object value;
                if (property.GetValue(item) != null)
                {
                    value = property.GetValue(item);
                    if (excelFileInfo.UseCustomStyles)
                    {
                        var cellStyle = columnStyles[styleIndex];
                        WriteCell(row, cellIndex, property.PropertyType, value, cellStyle);
                    }
                    else
                    {
                        WriteCell(row, cellIndex, property.PropertyType, value);
                    }   
                }

                cellIndex++;
                propertyIndex++;
                styleIndex++;
            }
        }

        private void WriteCell(IRow row, int cellIndex, Type type,object value, ICellStyle cellStyle = null)
        {
            ICell cell;

            switch (type.Name)
            {
                case "Int32":
                case "Double":
                case "Decimal":
                case "Nullable`1":
                    if (type.FullName.Contains("DateTime"))
                    {
                        cell = row.CreateCell(cellIndex);
                        cell.SetCellValue(((DateTime)value).ToShortDateString().ToString());
                    }
                    else
                    {
                        cell = row.CreateCell(cellIndex);
                        if (cellStyle != null) { cell.CellStyle = cellStyle; }
                        cell.SetCellValue(Convert.ToDouble(value));
                    }
                    break;
                case "DateTime":
                    cell = row.CreateCell(cellIndex);
                    cell.SetCellValue(((DateTime)value).ToShortDateString().ToString());
                    break;
                case "Null":
                    cell = row.CreateCell(cellIndex);
                    cell.SetCellValue(string.Empty);
                    break;
                case "String":
                    cell = row.CreateCell(cellIndex);
                    value = value == null ? string.Empty : value.ToString();
                    cell.SetCellValue(value.ToString());
                    break;
                default:
                    //deals with types that might be string or decimal
                    if (value.ToString().Contains("_DYNAMICTYPE"))
                    {
                        var updatedValue = value.ToString().Replace("_DYNAMICTYPE", "");
                        double doubleValue;
                        if (double.TryParse(updatedValue, out doubleValue))
                        {
                            row.CreateCell(cellIndex).SetCellValue(doubleValue);
                            cell = row.CreateCell(cellIndex);
                            if (cellStyle != null) { cell.CellStyle = cellStyle; }
                            cell.SetCellValue(doubleValue);
                        }
                        else
                        {
                            cell = row.CreateCell(cellIndex);
                            cell.SetCellValue(updatedValue.ToString());
                        }
                    }
                    else
                    {
                        cell = row.CreateCell(cellIndex);
                        cell.SetCellValue(value.ToString());
                    }

                    break;
            }
        }
        private void WriteExpandoRow(IRow row, dynamic item, ExcelFileInfo excelFileInfo , List<ICellStyle> columnStyles)
        {
            var cellIndex = 0;
            var propertyIndex = 0;
            var styleIndex = 0;
            foreach (KeyValuePair<string,object> kvp in item)
            {
                if (excelFileInfo.ColumnIndexesToIgnore.Contains(propertyIndex))
                {
                    propertyIndex++;
                    continue;
                }

                var cellStyle = columnStyles[styleIndex];
                Type type = typeof(string);
                string typeName;
                
                if (kvp.Value == null)
                {
                    typeName = "Null";
                }
                else
                {
                    type = kvp.Value.GetType();
                    typeName = type.Name;
                }

                WriteCell(row, cellIndex, type, kvp.Value,cellStyle);

                cellIndex++;
                propertyIndex++;
                styleIndex++;
            }

        }
    }
}
