﻿namespace ThreeDegreesDataSystem.Common.Writer
{
    public class ExcelColumnParameter : IExcelColumnParameter
    {
        public ExcelColumnParameter() { }

        public ExcelColumnParameter(string header, string format) 
        {
            Header = header;
            Format = format;
        }

        public string Header { get; set; }
        public string Format { get; set; }
    }
}
