﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Common.Reader
{
    public class ExcelReaderParameters
    {
        public ExcelReaderParameters() { }
        public ExcelReaderParameters(string filePath, int tabIndex = 0,int headerRowsToIgnore = 0, int footerRowsToIgnore = 0, int headerRowIndex = 0 )
        {
            FilePath = filePath;
            TabIndex = tabIndex;
            HeaderRowsToIgnore = headerRowsToIgnore;
            FooterRowsToIgnore = footerRowsToIgnore;
            HeaderRowIndex = headerRowIndex;
        }
        
        public string FilePath { get; set; }
        public int TabIndex { get; set; }
        public int HeaderRowsToIgnore { get; set; }
        public int FooterRowsToIgnore { get; set; }
        public int HeaderRowIndex { get; set; }
    }
}
