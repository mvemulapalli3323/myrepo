﻿using ThreeDegreesDataSystem.Common.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace ThreeDegreesDataSystem.Common
{
    public class ExcelReaderResult : ReaderResult
    {
        public ExcelReaderResult()
        {
            Data = new List<dynamic>();
        }

        public List<dynamic> Data { get; set; }
    }
}
