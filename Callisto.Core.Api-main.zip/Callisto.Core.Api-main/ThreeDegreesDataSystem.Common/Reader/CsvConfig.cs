﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Common.Readers
{
    public class CsvConfigField
    {
        public CsvConfigField(int index, TypeCode typeCode, bool isRequired)
        {
            Index = index;
            TypeCode = typeCode;
            IsRequired = isRequired;
        }

        public int Index { get; set; }
        public TypeCode TypeCode { get; set; }
        public bool IsRequired { get; set; }
    }

    public class CsvConfig
    {
        public CsvConfig()
        {
            Fields = new();
        }

        public List<CsvConfigField> Fields { get; set; }

        public void AddField(int index, TypeCode typeCode, bool isRequired)
        {
            Fields.Add(new(index, typeCode, isRequired));
        }
    }
}
