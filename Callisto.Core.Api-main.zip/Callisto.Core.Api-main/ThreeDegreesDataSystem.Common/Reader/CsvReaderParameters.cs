﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Common.Reader
{
    public class CsvReaderParameters : BlobFileReaderParameters
    {
        public int HeaderRowsToRemove { get; set; }
        public int FooterRowsToRemove { get; set; }
        
    }
}
