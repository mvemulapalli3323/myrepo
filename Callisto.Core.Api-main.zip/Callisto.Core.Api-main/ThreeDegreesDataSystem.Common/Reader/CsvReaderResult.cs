﻿using ThreeDegreesDataSystem.Common.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace ThreeDegreesDataSystem.Common
{
    public class CsvReaderResult : ReaderResult
    {
        public CsvReaderResult()
        {
            Data = new List<string[]>();
        }

        public List<string[]> Data { get; set; }
    }
}
