﻿using ThreeDegreesDataSystem.Common.Reader;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using System.Data;

namespace ThreeDegreesDataSystem.Common.Readers
{
    public class ExcelReader
    {
        public DataTable ExcelToDataTable(ExcelReaderParameters parameters)
        {

            DataTable table = null;
            try
            {
                if (System.IO.File.Exists(parameters.FilePath))
                {

                    IWorkbook workbook = null;
                    ISheet worksheet = null;
                    string first_sheet_name = "";

                    using (FileStream FS = new FileStream(parameters.FilePath, FileMode.Open, FileAccess.Read))
                    {
                        workbook = WorkbookFactory.Create(FS);
                        worksheet = workbook.GetSheetAt(parameters.TabIndex);
                        first_sheet_name = worksheet.SheetName;

                        table = new DataTable(first_sheet_name);
                        table.Rows.Clear();
                        table.Columns.Clear();

                        for (int rowIndex = 0+parameters.HeaderRowsToIgnore; rowIndex < (worksheet.LastRowNum - parameters.FooterRowsToIgnore); rowIndex++)
                        {
                            DataRow NewReg = null;
                            IRow row = worksheet.GetRow(rowIndex);
                            IRow row2 = null;
                            IRow row3 = null;

                            if (rowIndex == parameters.HeaderRowIndex)
                            {
                                row2 = worksheet.GetRow(rowIndex + 1);
                                row3 = worksheet.GetRow(rowIndex + 2);
                            }

                            if (row != null)
                            {
                                if (rowIndex > parameters.HeaderRowIndex) NewReg = table.NewRow();

                                int colIndex = 0;

                                foreach (ICell cell in row.Cells)
                                {
                                    object valueCell = null;
                                    string cellType = "";
                                    string[] cellType2 = new string[2];

                                    if (rowIndex == parameters.HeaderRowIndex)
                                    {
                                        for (int i = 0; i < 2; i++)
                                        {
                                            ICell cell2 = null;
                                            if (i == 0) { cell2 = row2.GetCell(cell.ColumnIndex); }
                                            else { cell2 = row3.GetCell(cell.ColumnIndex); }

                                            if (cell2 != null)
                                            {
                                                switch (cell2.CellType)
                                                {
                                                    case CellType.Blank: break;
                                                    case CellType.Boolean: cellType2[i] = "System.Boolean"; break;
                                                    case CellType.String: cellType2[i] = "System.String"; break;
                                                    case CellType.Numeric:
                                                        if (HSSFDateUtil.IsCellDateFormatted(cell2)) { cellType2[i] = "System.DateTime"; }
                                                        else
                                                        {
                                                            cellType2[i] = "System.Double";
                                                        }
                                                        break;

                                                    case CellType.Formula:
                                                        bool continuar = true;
                                                        switch (cell2.CachedFormulaResultType)
                                                        {
                                                            case CellType.Boolean: cellType2[i] = "System.Boolean"; break;
                                                            case CellType.String: cellType2[i] = "System.String"; break;
                                                            case CellType.Numeric:
                                                                if (HSSFDateUtil.IsCellDateFormatted(cell2)) { cellType2[i] = "System.DateTime"; }
                                                                else
                                                                {
                                                                    try
                                                                    {
                                                                        if (cell2.CellFormula == "TRUE()") { cellType2[i] = "System.Boolean"; continuar = false; }
                                                                        if (continuar && cell2.CellFormula == "FALSE()") { cellType2[i] = "System.Boolean"; continuar = false; }
                                                                        if (continuar) { cellType2[i] = "System.Double"; continuar = false; }
                                                                    }
                                                                    catch { }
                                                                }
                                                                break;
                                                        }
                                                        break;
                                                    default:
                                                        cellType2[i] = "System.String"; break;
                                                }
                                            }
                                        }

                                        if (cellType2[0] == cellType2[1]) { cellType = cellType2[0]; }
                                        else
                                        {
                                            if (cellType2[0] == null) cellType = cellType2[1];
                                            if (cellType2[1] == null) cellType = cellType2[0];
                                            if (cellType == "") cellType = "System.String";
                                        }

                                        string colName = "Column_{0}";
                                        try { colName = cell.StringCellValue; }
                                        catch { colName = string.Format(colName, colIndex); }

                                        foreach (DataColumn col in table.Columns)
                                        {
                                            if (col.ColumnName == colName) colName = string.Format("{0}_{1}", colName, colIndex);
                                        }

                                        if (cellType == null) { cellType = "System.String"; }

                                        DataColumn column = new DataColumn(colName, System.Type.GetType(cellType));
                                        table.Columns.Add(column); colIndex++;
                                    }
                                    else
                                    {
                                        switch (cell.CellType)
                                        {
                                            case CellType.Blank: valueCell = DBNull.Value; break;
                                            case CellType.Boolean: valueCell = cell.BooleanCellValue; break;
                                            case CellType.String: valueCell = cell.StringCellValue; break;
                                            case CellType.Numeric:
                                                if (HSSFDateUtil.IsCellDateFormatted(cell)) { valueCell = cell.DateCellValue; }
                                                else { valueCell = cell.NumericCellValue; }
                                                break;
                                            case CellType.Formula:
                                                switch (cell.CachedFormulaResultType)
                                                {
                                                    case CellType.Blank: valueCell = DBNull.Value; break;
                                                    case CellType.String: valueCell = cell.StringCellValue; break;
                                                    case CellType.Boolean: valueCell = cell.BooleanCellValue; break;
                                                    case CellType.Numeric:
                                                        if (HSSFDateUtil.IsCellDateFormatted(cell)) { valueCell = cell.DateCellValue; }
                                                        else { valueCell = cell.NumericCellValue; }
                                                        break;
                                                }
                                                break;
                                            default: valueCell = cell.StringCellValue; break;
                                        }

                                        if (cell.ColumnIndex <= table.Columns.Count - 1) NewReg[cell.ColumnIndex] = valueCell;
                                    }
                                }
                            }
                            if (rowIndex > parameters.HeaderRowIndex) table.Rows.Add(NewReg);
                        }
                        table.AcceptChanges();
                    }
                }
                else
                {
                    throw new Exception("This file does not exist");
                }
            }
            catch (Exception)
            {
                throw;
            }
            return table;
        }

    }
}
