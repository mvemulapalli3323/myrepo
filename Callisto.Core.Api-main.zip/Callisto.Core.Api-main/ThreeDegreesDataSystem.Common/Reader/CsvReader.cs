﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Common.Readers
{
    public class CsvReader
    {
        public CsvReaderResult CsvDataToList(string csvData)
        {
            using TextFieldParser csvReader = new(new StringReader(csvData));
            return CsvToList(csvReader);
        }

        public  CsvReaderResult CsvToList(string filePath)
        {
            using TextFieldParser csvReader = new(filePath);
            return CsvToList(csvReader);
        }

        public CsvReaderResult CsvToList(TextFieldParser parser)
        {
            var data = new CsvReaderResult();
            try
            {
                {
                    parser.SetDelimiters(",");
                    parser.HasFieldsEnclosedInQuotes = true;

                    string[] fields;
                    while (!parser.EndOfData)
                    {
                        fields = parser.ReadFields();
                        // Don't add empty or non-existent rows
                        if (fields.Length > 0 && !fields.All("".Contains))
                        {
                            data.Data.Add(fields);
                        }
                    }
                }

                data.Status = StringConstants.Succeeded;
                data.Message = $"{data.Data.Count} rows read";
                return data;
            }
            catch (Exception ex)
            {
                data.Status = StringConstants.Failed;
                data.Message = $"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}";
                throw;
            }
            finally
            {
                parser.Close();
            }
        }

        public static CsvReaderResult CsvToList(string filePath, CsvConfig csvConfig)
        {
            CsvReaderResult result = new();
            result.Status = StringConstants.Succeeded;
            List<string> errors = new();

            using (var csvreader = new TextFieldParser(filePath))
            {
                csvreader.SetDelimiters(",");
                csvreader.HasFieldsEnclosedInQuotes = true;

                // Number of fields must match number of config fields
                string[] headers = csvreader.ReadFields();
                if (headers.Length != csvConfig.Fields.Count)
                {
                    result.Status = StringConstants.Failed;
                    errors.Add($"Number of fields in csv file ({headers.Length}) doesn't match number of expected fields ({csvConfig.Fields.Count}).");
                }
                result.Data.Add(headers);

                int row = 1;
                while (!csvreader.EndOfData)
                {
                    row++;
                    string[] fields = csvreader.ReadFields();
                    Parallel.ForEach(fields, (field, state, index) =>
                    {
                        // If entire row is blank, don't check configuration
                        if (fields.All("".Contains)) return;

                        // Get config for index
                        CsvConfigField config;
                        try
                        {
                            config = csvConfig.Fields.Where(c => c.Index == index).Single();
                        }
                        catch (InvalidOperationException)
                        {
                            result.Status = StringConstants.Failed;
                            errors.Add($"No csv config found for index ({index}).");
                            return;
                        }

                        // Check if required field is present
                        if (config.IsRequired && string.IsNullOrEmpty(fields[index]))
                        {
                            result.Status = StringConstants.Failed;
                            errors.Add($"Null value for required field at row:index ({row}:{index}).");
                            return;
                        }

                        // Check if field is correct type
                        try
                        {
                            if (string.IsNullOrEmpty(fields[index])) return;
                            switch (config.TypeCode)
                            {
                                case TypeCode.DateTime:
                                    DateTime.Parse(fields[index]);
                                    break;
                                case TypeCode.Decimal:
                                    decimal.Parse(fields[index], NumberStyles.Any);
                                    break;
                            }
                        }
                        catch (FormatException)
                        {
                            result.Status = StringConstants.Failed;
                            errors.Add($"Invalid ({config.TypeCode}) value ({fields[index]}) for field at row:index ({row}:{index}).");
                        }
                    });

                    // Don't add empty or non-existent rows
                    if (fields.Length > 0 && !fields.All("".Contains))
                    {
                        result.Data.Add(fields);
                    }
                }
                csvreader.Close();
            }

            result.Message = result.Status == StringConstants.Succeeded
                ? $"{result.Data.Count} rows read"
                : String.Join('\n', errors);
            return result;
        }
    }
}
