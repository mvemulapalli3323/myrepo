﻿using System;

namespace ThreeDegreesDataSystem.Common.Exceptions
{
    public class AdmisException : Exception
    {
        public AdmisException()
        {
        }

        public AdmisException(string message)
            : base(message)
        {
        }

        public AdmisException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
