﻿using System;

namespace ThreeDegreesDataSystem.Common.Exceptions
{
    public class TaskFailedException : Exception
    {
        public TaskFailedException()
        {
        }

        public TaskFailedException(string message)
            : base(message)
        {
        }

        public TaskFailedException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
