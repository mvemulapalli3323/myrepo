﻿using System;

namespace ThreeDegreesDataSystem.Common.Exceptions
{
    public class HttpClientRequestTimedOutException : Exception
    {
        public HttpClientRequestTimedOutException()
        {
        }

        public HttpClientRequestTimedOutException(string message)
            : base(message)
        {
        }

        public HttpClientRequestTimedOutException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
