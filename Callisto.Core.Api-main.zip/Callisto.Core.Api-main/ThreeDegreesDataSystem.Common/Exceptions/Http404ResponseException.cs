﻿using System;

namespace ThreeDegreesDataSystem.Common.Exceptions
{
    public class Http404ResponseException : Exception
    {
        public Http404ResponseException()
        {
        }

        public Http404ResponseException(string message)
            : base(message)
        {
        }

        public Http404ResponseException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
