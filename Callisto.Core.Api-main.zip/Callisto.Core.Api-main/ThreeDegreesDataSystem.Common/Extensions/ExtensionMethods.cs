﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Common.Extensions
{
    public static class ExtensionMethods
    {
        public static IEnumerable<(T item, int index)> WithIndex<T>(this IEnumerable<T> source)
        {
            return source.Select((item, index) => (item, index));
        }

        public static T PopAt<T>(this List<T> list, int index)
        {
            T r = list[index];
            list.RemoveAt(index);
            return r;
        }

        public static decimal SafeDivide(this decimal numerator, decimal denominator, decimal fallback = 0)
        {
            return denominator == 0 ? fallback : numerator / denominator;
        }

        public static decimal SafeDivide(this decimal? numerator, decimal? denominator, decimal fallback = 0)
        {
            if (!numerator.HasValue || !denominator.HasValue || denominator == 0)
                return fallback;

            return numerator.Value / denominator.Value;
        }

        public static string GetNumbers(this string text)
        {
            text = text ?? string.Empty;
            return new string(text.Where(p => char.IsDigit(p)).ToArray());
        }

        public static string RemoveWhitespace(this string original)
        {
            return new(original.ToString().Where(c => !char.IsWhiteSpace(c)).ToArray());
        }

        public static string[] SplitAndTrimAndLower(this string original, char delimiter)
        {
            return original.Split(delimiter).Select(c => c.Trim().ToLower()).ToArray();
        }

        public static List<T> ToList<T>(this DataTable dataTable) where T : new()
        {
            var list = new List<T>();

            if (dataTable == null || dataTable.Rows.Count == 0)
            {
                return list;
            }

            // Get properties of the type T
            var properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (DataRow row in dataTable.Rows)
            {
                var obj = new T();

                foreach (var property in properties)
                {
                    if (dataTable.Columns.Contains(property.Name) && !row.IsNull(property.Name))
                    {
                        // Set the value of the property using reflection
                        var value = Convert.ChangeType(row[property.Name], property.PropertyType);
                        property.SetValue(obj, value);
                    }
                }

                list.Add(obj);
            }

            return list;
        }
    }
}
