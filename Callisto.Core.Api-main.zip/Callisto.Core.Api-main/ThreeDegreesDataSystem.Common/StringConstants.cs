﻿using System;

namespace ThreeDegreesDataSystem.Common
{
    public static class FileExtensions
    {
        public const string Csv = ".csv";
        public const string Xls = ".xls";
        public const string Xlsx = ".xlsx";
    }

    public static class StringConstants
    {
        // Admis
        public const string AdatPos = "adatpos.csv";
        public const string AdatPas = "adatpas.csv";
        public const string AdatDtn = "adatdtn.csv";

        // Data types
        public const string Int = "Int";
        public const string Bool = "Bool";
        public const string NullableBool = "NullableBool";
        public const string NullableInt = "NullableInt";
        public const string Decimal = "Decimal";
        public const string NullableDecimal = "NullableDecimal";
        public const string DateTime = "DateTime";
        public const string NullableDateTime = "NullableDateTime";
        public const string Xls = "xls";
        public const string Xlsx = "xlsx";
        // Statuses
        public const string Succeeded = "Succeeded";
        public const string Failed = "Failed";
        public const string InProgress = "In Progress";
        public const string Cancelled = "Cancelled";
        public const string NotStarted = "Not Started";
        public const string Waiting = "Waiting";
        public const string Skipped = "Skipped";
        
        public const string CleanUpTaskRuns = "CleanUpTaskRuns";
        // Tasks
        
        //Maps
        
        public const string FiscalYear = "FiscalYear";
        public const string CurrentYear = "CurrentYear";
        public const string String = "String";
        public const string Integer = "Integer";
        public const string ShortDate = "ShortDate";
        public const string Percent = "Percent";
        public const string Portfolio = "Portfolio";
        public const string Benchmark = "Benchmark";
        public const string Net = "Net";
        public const string Gross = "Gross";
        public const string Manual = "Manual";

        // Tasks
        public const string AdfTest = "AdfTest";
        public const string LoadEtrmPositions = "LoadEtrmPositions";
        public const string PublishPositions = "PublishPositions";
        public const string RunDailyPositions = "RunDailyPositions";
        public const string TransformPositions = "TransformPositions";
        
        //Azure Data Factory Pipeline Names
        public const string LoadEtrmPositionsPipeline = "LoadEtrmPositionsPipeline";
        public const string PublishPositionsPipeline = "PublishPositionsPipeline";
        public const string TransformPositionsPipeline = "TransformPositionsPipeline";

    }
}
