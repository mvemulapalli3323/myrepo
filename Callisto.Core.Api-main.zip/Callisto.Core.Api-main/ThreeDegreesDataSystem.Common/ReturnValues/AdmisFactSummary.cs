﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Common.ReturnValues
{
    public class AdmisFactSummary
    {
        public AdmisFactSummary()
        {
            FactCount = 0;
            TotalQuantityRaw = 0;
            TotalQuantityFact = 0;
        }

        public int FactCount { get; set; } = 0;
        public decimal TotalQuantityRaw { get; set; } = 0;
        public decimal TotalQuantityFact { get; set; } = 0;
        public decimal TotalQuantityDiff()
        {
            return TotalQuantityRaw - TotalQuantityFact;
        }
    }
}
