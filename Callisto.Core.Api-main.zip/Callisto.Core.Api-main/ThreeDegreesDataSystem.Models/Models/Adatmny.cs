﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class Adatmny
{
    public int AdatmnyId { get; set; }

    public int? TaskRunId { get; set; }

    public string? RecId { get; set; }

    public string? Firm { get; set; }

    public int? Office { get; set; }

    public int? Acct { get; set; }

    public string? Atype { get; set; }

    public int? RegRep { get; set; }

    public string? CurrAtype { get; set; }

    public string? PrdCurrCode { get; set; }

    public string? AcctBaseCurrCode { get; set; }

    public string? AcctCountryCode { get; set; }

    public int? LastActDate { get; set; }

    public decimal? AcctBalance { get; set; }

    public decimal? SecMarketValue { get; set; }

    public decimal? LongOptValue { get; set; }

    public decimal? ShortOptValue { get; set; }

    public decimal? TotalMarginCalls { get; set; }

    public decimal? FutInitMargin { get; set; }

    public decimal? FutMaintMargin { get; set; }

    public decimal? OpenTradeEquity { get; set; }

    public decimal? MtdProfitLoss { get; set; }

    public decimal? MtdCommissions { get; set; }

    public decimal? FutStyleOptOte { get; set; }

    public decimal? AcctLiquidValue { get; set; }

    public decimal? OptPremiumValue { get; set; }

    public decimal? MarketValueUsTreas { get; set; }

    public decimal? AcctTotalEquity { get; set; }

    public decimal? ConvRateToAcctBaseCurr { get; set; }

    public decimal? MarginExcessDeficit { get; set; }

    public decimal? EquityInitMargin { get; set; }

    public decimal? EquityMaintMargin { get; set; }

    public decimal? MarginCollateralValue { get; set; }

    public decimal? UnsettUnrealizedPl { get; set; }

    public decimal? ShortMarketValueSecs { get; set; }

    public decimal? ConvRateToFirmBaseCurr { get; set; }

    public string? AcctClassCode { get; set; }

    public decimal? PrevAcctBalance { get; set; }
}
