﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class GenericListItem
{
    public int GenericListItemId { get; set; }

    public string Value { get; set; } = null!;

    public string TypeCode { get; set; } = null!;
}
