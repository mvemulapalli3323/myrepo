﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class AdmisPositionDetail
{
    public int AdmisPositionDetailId { get; set; }

    public int? TaskRunId { get; set; }

    public int? Cob { get; set; }

    public string? Account { get; set; }

    public int? TradeDate { get; set; }

    public decimal? Quantity { get; set; }

    public int? Multiplier { get; set; }

    public decimal? Units { get; set; }

    public string? UnitDesc { get; set; }

    public string? ExchangeNameShort { get; set; }

    public string? ExchangeCommodityCode { get; set; }

    public string? Product { get; set; }

    public string? PeakOffPeak { get; set; }

    public int? ContractMonthYear { get; set; }

    public string? OptionType { get; set; }

    public decimal? Tradeprice { get; set; }

    public decimal? Strike { get; set; }

    public decimal? Settlementprice { get; set; }

    public decimal? Marktomarket { get; set; }

    public int? Lasttradingdate { get; set; }

    public string? UnderlyingFuture { get; set; }

    public int? UnderlyingContractMonthYear { get; set; }

    public decimal? Tradepricedec { get; set; }

    public decimal? Settlementpricedec { get; set; }

    public decimal? Excfees { get; set; }

    public decimal? Clearfees { get; set; }

    public decimal? Nfafees { get; set; }

    public decimal? Commi { get; set; }

    public decimal? Otherfees { get; set; }

    public string? Userid { get; set; }

    public string? Subacct { get; set; }

    public string? RefNo { get; set; }

    public string? Currency { get; set; }

    public decimal? OptionsPnL { get; set; }
}
