﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class AdmisRealizedDetailMtd
{
    public int AdmisRealizedDetailMtd1 { get; set; }

    public int? TaskRunId { get; set; }

    public int? Cob { get; set; }

    public string? Account { get; set; }

    public string? SegType { get; set; }

    public string? TradeType { get; set; }

    public int? TradeDate { get; set; }

    public string? Side { get; set; }

    public decimal? Quantity { get; set; }

    public decimal? Units { get; set; }

    public string? UnitsDescription { get; set; }

    public int? ContractMonthYear { get; set; }

    public string? ExchCommodityCode { get; set; }

    public string? Product { get; set; }

    public decimal? StrikePrice { get; set; }

    public string? OptionType { get; set; }

    public decimal? TradePrice { get; set; }

    public decimal? SettlementPrice { get; set; }

    public decimal? Realized { get; set; }

    public decimal? TotalFees { get; set; }

    public decimal? RealizedWithFees { get; set; }

    public decimal? ExcFees { get; set; }

    public decimal? ClearFees { get; set; }

    public decimal? NfaFees { get; set; }

    public decimal? Commi { get; set; }

    public decimal? OtherFees { get; set; }

    public string? OtherSysSrcCd { get; set; }

    public string? GiveUpFirm { get; set; }

    public string? TradeProcessType { get; set; }

    public string? Spread { get; set; }

    public string? LiquidityType { get; set; }

    public string? ChargedAtOffset { get; set; }

    public string? OrderId { get; set; }

    public string? TradeId { get; set; }

    public string? OtherAccount { get; set; }

    public string? OtherSource { get; set; }

    public string? UserId { get; set; }

    public string? SubAcct { get; set; }

    public string? PrefNo { get; set; }

    public string? Currency { get; set; }
}
