﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Models.Models
{
    public partial class ArgusCode
    {
        public int ArgusCodeId { get; set; }
        public int CodeId { get; set; }
        public string Description { get; set; }
        public int UnitId1 { get; set; }
        public int? UnitId2 { get; set; }
        public int DelModeId { get; set; }
        public string ActiveYn { get; set; }
        public DateTime WefDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string WeekendIsHolidayYn { get; set; }
        public int UploadFreqId { get; set; }
        public DateTime RepTimestamp { get; set; }
        public string Specification { get; set; }
        public int TaskRunId { get; set; }
    }
}
