﻿using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Models;

namespace ThreeDegreesDataSystem.Models;

public partial class BloombergPricingSnapshot
{
    public int BloombergPricingSnapshotId { get; set; }

    public int TaskRunId { get; set; }

    public DateOnly DateRun { get; set; }

    public string Securities { get; set; } = null!;

    public int ErrorCode { get; set; }

    public int NumberOfFields { get; set; }

    public decimal OpenPrice { get; set; }

    public decimal HighPrice { get; set; }

    public decimal LowPrice { get; set; }

    public decimal BidPrice { get; set; }

    public decimal MidPrice { get; set; }

    public decimal AskPrice { get; set; }

    public decimal BidYield { get; set; }

    public decimal MidYield { get; set; }

    public decimal AskYield { get; set; }

    public decimal LastPrice { get; set; }

    public decimal LastYield { get; set; }

    public DateTime LastUpdateTime { get; set; }

    public decimal PreviousClosePrice { get; set; }

    public DateOnly PreviousCloseDate { get; set; }

    public string PricingSource { get; set; } = null!;

    public virtual TaskRun TaskRun { get; set; } = null!;
}
