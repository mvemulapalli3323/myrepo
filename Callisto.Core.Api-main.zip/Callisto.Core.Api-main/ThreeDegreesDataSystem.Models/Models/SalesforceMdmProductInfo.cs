﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Models.Models
{
    public class SalesforceMdmProductInfo
    {
        public string MdmProductCode { get; set; }
        public string MdmProductName { get; set; }
        public string SalesforceId { get; set; }
        public string IsActive { get; set; }
    }
}
