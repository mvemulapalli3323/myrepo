﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class GenericTimeout
{
    public int GenericTimeoutId { get; set; }

    public int Value { get; set; }

    public string TypeCode { get; set; } = null!;
}
