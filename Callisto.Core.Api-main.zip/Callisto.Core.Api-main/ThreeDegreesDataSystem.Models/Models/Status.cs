﻿using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class Status: ICentralOpsEntity
{
    public int StatusId { get; set; }

    public string StatusCode { get; set; } = null!;

    public string StatusDescription { get; set; } = null!;

    public bool IsActive { get; set; }

    public virtual ICollection<TaskRun> TaskRuns { get; set; } = new List<TaskRun>();
}
