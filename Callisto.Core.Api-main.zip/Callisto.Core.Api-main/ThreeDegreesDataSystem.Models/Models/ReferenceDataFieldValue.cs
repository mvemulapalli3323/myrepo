﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class ReferenceDataFieldValue
{
    public int ReferenceDataFieldValueId { get; set; }

    public int ReferenceDataFieldId { get; set; }

    public string? StringValue { get; set; }

    public DateTime? DateTimeValue { get; set; }

    public int? IntegerValue { get; set; }

    public bool? BooleanValue { get; set; }

    public decimal? DecimalValue { get; set; }

    public DateTime? StartDate { get; set; }

    public DateTime? EndDate { get; set; }

    public bool IsActive { get; set; }

    public virtual ReferenceDataField? ReferenceDataField { get; set; } = null!;
}
