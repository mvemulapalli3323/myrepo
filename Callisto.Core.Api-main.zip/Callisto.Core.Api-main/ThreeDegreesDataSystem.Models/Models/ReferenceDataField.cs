﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class ReferenceDataField
{
    public int ReferenceDataFieldId { get; set; }

    public string ReferenceDataFieldCode { get; set; } = null!;

    public int ReferenceDataEntityId { get; set; }

    public string DataType { get; set; } = null!;

    public int SortOrder { get; set; }

    public bool IsRequired { get; set; }

    public bool IsTimeSeries { get; set; }

    public bool IsActive { get; set; }

    public virtual ReferenceDataEntity? ReferenceDataEntity { get; set; } = null!;

    public virtual ICollection<ReferenceDataFieldValue>? ReferenceDataFieldValues { get; set; } = new List<ReferenceDataFieldValue>();
}
