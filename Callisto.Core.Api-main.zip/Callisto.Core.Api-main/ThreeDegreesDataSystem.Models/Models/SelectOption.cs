﻿using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class SelectOption:ICentralOpsEntity
{
    public int SelectOptionId { get; set; }

    public string SelectOptionTypeCode { get; set; } = null!;

    public string SelectOptionValue { get; set; } = null!;

    public string SelectOptionDescription { get; set; } = null!;

    public bool IsActive { get; set; }
}
