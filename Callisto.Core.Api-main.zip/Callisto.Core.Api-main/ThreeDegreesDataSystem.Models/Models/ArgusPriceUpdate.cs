﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Models.Models
{
    public partial class ArgusPriceUpdate
    {
        public int ArgusPriceUpdateId { get; set; }
        public int RepositoryId { get; set; }
        public int CorrectionId { get; set; }
        public int QuoteId { get; set; }
        public int CodeId { get; set; }
        public int TimestampId { get; set; }
        public int ContinuousForward { get; set; }
        public DateTime PublicationDate { get; set; }
        public decimal Value { get; set; }
        public int ForwardPeriod { get; set; }
        public int ForwardYear { get; set; }
        public int DiffBaseRoll { get; set; }
        public int PriceTypeId { get; set; }
        public int PriceReportItemId { get; set; }
        public int? ErrorId { get; set; }
        public int UnitId1 { get; set; }
        public int UnitId2 { get; set; }
        public int DecimalPlaces { get; set; }
        public string DiffBaseValue { get; set; }
        public int DiffBaseTimingId { get; set; }
        public string Correction { get; set; }
        public DateTime DateModified { get; set; }
        public int TaskRunId { get; set; }
    }
}
