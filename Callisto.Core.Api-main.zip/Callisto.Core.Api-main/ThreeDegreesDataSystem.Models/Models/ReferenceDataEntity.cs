﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class ReferenceDataEntity
{
    public int ReferenceDataEntityId { get; set; }

    public string ReferenceDataEntityCode { get; set; } = null!;

    public string ReferenceDataEntityDescription { get; set; } = null!;

    public bool IsActive { get; set; }

    public virtual ICollection<ReferenceDataField>? ReferenceDataFields { get; set; } = new List<ReferenceDataField>();
}
