﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class NodalPrice
{
    public int Id { get; set; }

    public string? Instrument { get; set; }

    public string? Price { get; set; }
}
