﻿using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class AdmisMapping : ICentralOpsEntity
{
    public int AdmisMappingId { get; set; }
    public string AdmisContract { get; set; } = null!;
    public string? ArtemisProduct { get; set; }
    public string? Vintage { get; set; }
    public DateTime CreatedOn { get; set; }
    public string CreatedBy { get; set; } = null!;
    public DateTime LastModifiedOn { get; set; }
    public string LastModifiedBy { get; set; } = null!;

}
