﻿using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class GenericMap: ICentralOpsEntity
{
    public int GenericMapId { get; set; }

    public string Value1 { get; set; } = null!;

    public string Value2 { get; set; } = null!;

    public string TypeCode { get; set; } = null!;
}
