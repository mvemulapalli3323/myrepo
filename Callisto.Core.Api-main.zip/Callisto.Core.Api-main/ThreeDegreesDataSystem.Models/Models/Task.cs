﻿using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class Task: ICentralOpsEntity
{
    public int TaskId { get; set; }

    public string TaskCode { get; set; } = null!;

    public string TaskDescription { get; set; } = null!;

    public string TaskName { get; set; } = null!;
    public string TaskMethod { get; set; } = null!;

    public bool IsActive { get; set; }

    public bool AllowMultiple { get; set; }

    public string? Parameters { get; set; }

    public bool IsUiProcess { get; set; }

    public virtual ICollection<TaskSubtask> ParentTasks { get; set; } = new List<TaskSubtask>();

    public virtual ICollection<TaskSubtask> Subtasks { get; set; } = new List<TaskSubtask>();
}
