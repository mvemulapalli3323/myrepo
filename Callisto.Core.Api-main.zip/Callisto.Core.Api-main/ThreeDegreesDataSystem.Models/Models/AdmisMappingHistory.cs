﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public class AdmisMappingHistory : AdmisMapping
{
    public DateTime ValidFrom { get; set; }
    public DateTime ValidTo { get; set; }

}
