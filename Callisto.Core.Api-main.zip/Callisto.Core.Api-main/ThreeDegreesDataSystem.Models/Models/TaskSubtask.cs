﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class TaskSubtask
{
    public int TaskSubtaskId { get; set; }

    public int TaskId { get; set; }

    public int SubtaskId { get; set; }

    public int Step { get; set; }

    public virtual Task Subtask { get; set; } = null!;

    public virtual Task Task { get; set; } = null!;
}
