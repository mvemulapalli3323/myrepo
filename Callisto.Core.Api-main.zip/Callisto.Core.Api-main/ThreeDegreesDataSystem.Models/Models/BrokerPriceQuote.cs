﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Models.Models
{
    public class BrokerPriceQuote
    {
        public int BrokerPriceQuoteId { get; set; }
        public string BrokerName { get; set; }
        public DateTime? PriceQuoteDate { get; set; }
        public string Exchange { get; set; }
        public string ProductName { get; set; }
        public string Term { get; set; }
        public decimal? BidValue { get; set; }
        public decimal? AskValue { get; set; }
        public decimal? MidValue { get; set; }
        public DateTime? ValueDate { get; set; }
        public DateTime? UploadDate { get; set; }
        public int TaskRunId { get; set; }
    }
}
