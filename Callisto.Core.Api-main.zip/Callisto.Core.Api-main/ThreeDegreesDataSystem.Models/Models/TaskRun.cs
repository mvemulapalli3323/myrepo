﻿using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class TaskRun : ICentralOpsEntity
{
    public int TaskRunId { get; set; }

    public int TaskId { get; set; }

    public int? ParentTaskRunId { get; set; }

    public int StatusId { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime CreatedOn { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public DateTime LastModifiedOn { get; set; }

    public DateTime? StartedOn { get; set; }

    public string? Parameters { get; set; }

    public string? Message { get; set; }

    public int CurrentStep { get; set; }

    public int? ParentStep { get; set; }

    public bool IsValid { get; set; }

    // Navigation
    public virtual TaskRun? ParentTaskRun { get; set; }
    public virtual Status? Status { get; set; }
    public virtual ICollection<TaskRun>? SubtaskRuns { get; set; }
    public virtual Task? Task { get; set; }

    public void AppendToMessage(string message, bool withNewline = true)
    {
        string newline = withNewline ? "\n" : " ";
        Message = String.IsNullOrEmpty(Message) ? message : $"{Message}{newline}{message}";
    }

    public void PrependToMessage(string message, bool withNewline = true)
    {
        string newline = withNewline ? "\n" : " ";
        Message = String.IsNullOrEmpty(Message) ? message : $"\n{message}{newline}{Message}";
    }
}
