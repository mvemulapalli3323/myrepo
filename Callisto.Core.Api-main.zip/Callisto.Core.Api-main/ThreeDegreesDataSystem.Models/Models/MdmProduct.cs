﻿
using Azure.Identity;
using System;
using System.Collections.Generic;
using ThreeDegreesDataSystem.Models.Interface;

namespace ThreeDegreesDataSystem.Models.Models;
public partial class MdmProduct : ICentralOpsEntity
{
    public int MdmProductId { get; set; }
    public string MdmProductCode { get; set; }
    public string MdmProductName { get; set; }
    public string? SalesforceId { get; set; }
    public string? NetSuiteId { get; set; }
    public string GoldenSource { get; set; }
    public string LastModifiedBy { get; set; }
    public DateTime LastModifiedOn { get; set; }
    public string ProductStatus { get; set; } = "Active";

}
