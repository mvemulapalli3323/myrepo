﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class CentralOpsDbContext : DbContext
{
    public CentralOpsDbContext()
    {
    }

    public CentralOpsDbContext(DbContextOptions<CentralOpsDbContext> options)
        : base(options)
    {
    }
    public virtual DbSet<Adatmny> Adatmnies { get; set; }
    public virtual DbSet<AdmisDaily> AdmisDailies { get; set; }
    public virtual DbSet<AdmisMapping> AdmisMappings { get; set; }
    public virtual DbSet<AdmisPositionDetail> AdmisPositionDetails { get; set; }
    public virtual DbSet<AdmisRealizedDetailMtd> AdmisRealizedDetailMtds { get; set; }
    public virtual DbSet<AdmisTradesMtd> AdmisTradesMtds { get; set; }
    public virtual DbSet<ArgusCode> ArgusCodes { get; set; }
    public virtual DbSet<ArgusPriceUpdate> ArgusPriceUpdates { get; set; }
    public virtual DbSet<BloombergPricingSnapshot> BloombergPricingSnapshots { get; set; }
    public virtual DbSet<BrokerPriceQuote> BrokerPriceQuotes { get; set; }
    public virtual DbSet<GenericListItem> GenericListItems { get; set; }
    public virtual DbSet<GenericMap> GenericMaps { get; set; }
    public virtual DbSet<GenericTimeout> GenericTimeouts { get; set; }
    public virtual DbSet<MdmProduct> MdmProducts { get; set; }
    public virtual DbSet<ReferenceDataEntity> ReferenceDataEntities { get; set; }
    public virtual DbSet<ReferenceDataField> ReferenceDataFields { get; set; }
    public virtual DbSet<ReferenceDataFieldValue> ReferenceDataFieldValues { get; set; }
    public virtual DbSet<SelectOption> SelectOptions { get; set; }
    public virtual DbSet<Status> Statuses { get; set; }
    public virtual DbSet<Task> Tasks { get; set; }
    public virtual DbSet<TaskRun> TaskRuns { get; set; }
    public virtual DbSet<TaskSubtask> TaskSubtasks { get; set; }
    public IEnumerable<object> AdmisDailyTradeFact { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Adatmny>(entity =>
        {
            entity.HasKey(e => e.AdatmnyId).HasName("PK__Adatmny__F0459EB1DE49DB0A");

            entity.ToTable("Adatmny", "OperationalDatabase");

            entity.Property(e => e.AcctBalance).HasColumnType("money");
            entity.Property(e => e.AcctBaseCurrCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.AcctClassCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.AcctCountryCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.AcctLiquidValue).HasColumnType("money");
            entity.Property(e => e.AcctTotalEquity).HasColumnType("money");
            entity.Property(e => e.Atype)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("AType");
            entity.Property(e => e.ConvRateToAcctBaseCurr).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.ConvRateToFirmBaseCurr).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.CurrAtype)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("CurrAType");
            entity.Property(e => e.EquityInitMargin).HasColumnType("money");
            entity.Property(e => e.EquityMaintMargin).HasColumnType("money");
            entity.Property(e => e.Firm)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.FutInitMargin).HasColumnType("money");
            entity.Property(e => e.FutMaintMargin).HasColumnType("money");
            entity.Property(e => e.FutStyleOptOte).HasColumnType("money");
            entity.Property(e => e.LongOptValue).HasColumnType("money");
            entity.Property(e => e.MarginCollateralValue).HasColumnType("money");
            entity.Property(e => e.MarginExcessDeficit).HasColumnType("money");
            entity.Property(e => e.MarketValueUsTreas).HasColumnType("money");
            entity.Property(e => e.MtdCommissions).HasColumnType("money");
            entity.Property(e => e.MtdProfitLoss).HasColumnType("money");
            entity.Property(e => e.OpenTradeEquity).HasColumnType("money");
            entity.Property(e => e.OptPremiumValue).HasColumnType("money");
            entity.Property(e => e.PrdCurrCode)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.PrevAcctBalance).HasColumnType("money");
            entity.Property(e => e.RecId)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.SecMarketValue).HasColumnType("money");
            entity.Property(e => e.ShortMarketValueSecs).HasColumnType("money");
            entity.Property(e => e.ShortOptValue).HasColumnType("money");
            entity.Property(e => e.TotalMarginCalls).HasColumnType("money");
            entity.Property(e => e.UnsettUnrealizedPl)
                .HasColumnType("money")
                .HasColumnName("UnsettUnrealizedPL");
        });

        modelBuilder.Entity<AdmisDaily>(entity =>
        {
            entity.HasKey(e => e.AdmisDailyId).HasName("PK__AdmisDai__140C7EAD5D0078B4");

            entity.ToTable("AdmisDaily", "OperationalDatabase");

            entity.Property(e => e.AcCls)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AcCntry)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypBkg)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypComm)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypCurr)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypFee1)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypFee2)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypFee3)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypFee6)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypGiFee)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AtypOthFee)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Atype)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("AType");
            entity.Property(e => e.Basis).HasColumnType("money");
            entity.Property(e => e.BlmbgCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.BlmbgExch)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.BlmbgTickerSymb)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.BlmbgTickerSymbYellow)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.BlmbgYellow)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Brkg).HasColumnType("money");
            entity.Property(e => e.BuySell)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.BuyQty).HasColumnType("money");
            entity.Property(e => e.CardNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ClsPrc).HasColumnType("money");
            entity.Property(e => e.Cmmt1)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Cmmt2)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Cmmt3)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Comm).HasColumnType("money");
            entity.Property(e => e.CommCalc)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CompReuterExch)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CompReuterRootRic)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CompReuterUnderRic)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContDesc)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ContDesc2)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Cusip)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Delta).HasColumnType("money");
            entity.Property(e => e.ElectReuterExch)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ElectReuterUnderRic)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ElectRootRic)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Exch)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ExecTime)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Fee1).HasColumnType("money");
            entity.Property(e => e.Fee2).HasColumnType("money");
            entity.Property(e => e.Fee3).HasColumnType("money");
            entity.Property(e => e.Fee4).HasColumnType("money");
            entity.Property(e => e.Fee5).HasColumnType("money");
            entity.Property(e => e.Fee6).HasColumnType("money");
            entity.Property(e => e.Fee7).HasColumnType("money");
            entity.Property(e => e.Fee8).HasColumnType("money");
            entity.Property(e => e.Fee9).HasColumnType("money");
            entity.Property(e => e.FileType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Firm)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FutCod)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FutOpt)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.GiGoChg).HasColumnType("money");
            entity.Property(e => e.GivFrm)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.GivInOut)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Gross).HasColumnType("money");
            entity.Property(e => e.IsinNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.LevelCde)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.LinkNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.LocCd)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.MktVal).HasColumnType("money");
            entity.Property(e => e.MktVar).HasColumnType("money");
            entity.Property(e => e.Mult).HasColumnType("money");
            entity.Property(e => e.Net).HasColumnType("money");
            entity.Property(e => e.OpnCls)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OthFee).HasColumnType("money");
            entity.Property(e => e.PrcDate)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrdCurrCde)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrdType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrevClsPrc).HasColumnType("money");
            entity.Property(e => e.PrevMktVal).HasColumnType("money");
            entity.Property(e => e.PrmtDate)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrntClsPrc)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrntPrc)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrntUndClsPrc)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ProdCurr)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ProdCurrSym)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PutCall)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.RecId)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.RefNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.RndHlfTrn)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SecType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SecType2)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SellQty).HasColumnType("money");
            entity.Property(e => e.SprdCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Strike).HasColumnType("money");
            entity.Property(e => e.SubEx)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Symbl)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TracerId)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TradeType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TrdPrc).HasColumnType("money");
            entity.Property(e => e.TrdQty).HasColumnType("money");
            entity.Property(e => e.UndrlyClsPrc).HasColumnType("money");
            entity.Property(e => e.YyyyMm)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<AdmisMapping>(entity =>
        {
            entity.HasKey(e => e.AdmisMappingId).HasName("PK__AdmisMap__D33BF54E6E03EC2E");

            entity.ToTable("AdmisMapping", "OperationalDatabase")
            .ToTable(tb => tb.IsTemporal(ttb =>
             {
                 ttb.UseHistoryTable("AdmisMappingHistory", "OperationalDatabase");
                 ttb
                     .HasPeriodStart("ValidFrom")
                     .HasColumnName("ValidFrom");
                 ttb
                     .HasPeriodEnd("ValidTo")
                     .HasColumnName("ValidTo");
             }));

            entity.HasIndex(e => e.AdmisContract, "UQ__AdmisMap__43B6D104641FC9CF").IsUnique();

            entity.Property(e => e.AdmisContract)
                .HasMaxLength(200);
            entity.Property(e => e.ArtemisProduct)
                .HasMaxLength(200);
            entity.Property(e => e.Vintage)
                .HasMaxLength(100);
            entity.Property(e => e.CreatedOn).HasColumnType("datetime");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100);
            entity.Property(e => e.LastModifiedOn).HasColumnType("datetime");
            entity.Property(e => e.LastModifiedBy)
                .HasMaxLength(100);
        });

        modelBuilder.Entity<AdmisPositionDetail>(entity =>
        {
            entity.HasKey(e => e.AdmisPositionDetailId).HasName("PK__AdmisPos__1DF06E69E7C9DB15");

            entity.ToTable("AdmisPositionDetail", "OperationalDatabase");

            entity.Property(e => e.Account)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Clearfees).HasColumnType("money");
            entity.Property(e => e.Commi).HasColumnType("money");
            entity.Property(e => e.Currency)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Excfees).HasColumnType("money");
            entity.Property(e => e.ExchangeCommodityCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ExchangeNameShort)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Marktomarket).HasColumnType("money");
            entity.Property(e => e.Nfafees).HasColumnType("money");
            entity.Property(e => e.OptionType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OptionsPnL).HasColumnType("money");
            entity.Property(e => e.Otherfees).HasColumnType("money");
            entity.Property(e => e.PeakOffPeak)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Product)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Quantity).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.RefNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Settlementprice).HasColumnType("money");
            entity.Property(e => e.Settlementpricedec).HasColumnType("money");
            entity.Property(e => e.Strike).HasColumnType("money");
            entity.Property(e => e.Subacct)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Tradeprice).HasColumnType("money");
            entity.Property(e => e.Tradepricedec).HasColumnType("money");
            entity.Property(e => e.UnderlyingFuture)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.UnitDesc)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Units).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.Userid)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<AdmisRealizedDetailMtd>(entity =>
        {
            entity.HasKey(e => e.AdmisRealizedDetailMtd1).HasName("PK__AdmisRea__EC368BEFBB1879D7");

            entity.ToTable("AdmisRealizedDetailMtd", "OperationalDatabase");

            entity.Property(e => e.AdmisRealizedDetailMtd1).HasColumnName("AdmisRealizedDetailMtd");
            entity.Property(e => e.Account)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ChargedAtOffset)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ClearFees).HasColumnType("money");
            entity.Property(e => e.Commi).HasColumnType("money");
            entity.Property(e => e.Currency)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ExcFees).HasColumnType("money");
            entity.Property(e => e.ExchCommodityCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.GiveUpFirm)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.LiquidityType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.NfaFees).HasColumnType("money");
            entity.Property(e => e.OptionType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OrderId)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OtherAccount)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OtherFees).HasColumnType("money");
            entity.Property(e => e.OtherSource)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OtherSysSrcCd)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrefNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Product)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Quantity).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.Realized).HasColumnType("money");
            entity.Property(e => e.RealizedWithFees).HasColumnType("money");
            entity.Property(e => e.SegType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SettlementPrice).HasColumnType("money");
            entity.Property(e => e.Side)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Spread)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.StrikePrice).HasColumnType("money");
            entity.Property(e => e.SubAcct)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TotalFees).HasColumnType("money");
            entity.Property(e => e.TradeId)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TradePrice).HasColumnType("money");
            entity.Property(e => e.TradeProcessType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TradeType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Units).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.UnitsDescription)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.UserId)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<AdmisTradesMtd>(entity =>
        {
            entity.HasKey(e => e.AdmisTradesMtdId).HasName("PK__AdmisTra__6996BA7310B49A07");

            entity.ToTable("AdmisTradesMtd", "OperationalDatabase");

            entity.Property(e => e.Account)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ChargedAtOffset)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ClearFees).HasColumnType("money");
            entity.Property(e => e.Commi).HasColumnType("money");
            entity.Property(e => e.ContractMonthYear).HasColumnType("money");
            entity.Property(e => e.Currency)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ExcFees).HasColumnType("money");
            entity.Property(e => e.ExchCommodityCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Exchange)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.FloorBroker)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.GiveUpFirm)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.InternalNumber)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.LiquidityType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Multiplier).HasColumnType("money");
            entity.Property(e => e.NfaFees).HasColumnType("money");
            entity.Property(e => e.OptionType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OrderId)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OtherAccount)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OtherFees).HasColumnType("money");
            entity.Property(e => e.OtherSource)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.OtherSysSrcCd)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PeakOffPeak)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.PrefNo)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Product)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Quantity).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.SegType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Side)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Spread)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Strike).HasColumnType("money");
            entity.Property(e => e.SubAcct)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TotalFees).HasColumnType("money");
            entity.Property(e => e.TradeId)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TradePrice).HasColumnType("money");
            entity.Property(e => e.TradeProcessType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TradeType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Type)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Units).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.UnitsDescription)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.UserId)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<ArgusCode>(entity =>
        {
            
            entity.ToTable("ArgusCode", "OperationalDatabase");

            entity.Property(e => e.CodeId).IsRequired();
            entity.Property(e => e.Description)
                .HasMaxLength(200)
                .IsUnicode(false)
                .IsRequired();
            entity.Property(e => e.UnitId1).IsRequired();
            entity.Property(e => e.UnitId2);
            entity.Property(e => e.DelModeId).IsRequired();
            entity.Property(e => e.ActiveYn)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsRequired();
            entity.Property(e => e.WefDate).HasColumnType("datetime");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.WeekendIsHolidayYn)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsRequired();
            entity.Property(e => e.UploadFreqId).IsRequired();
            entity.Property(e => e.RepTimestamp).HasColumnType("datetime");
            entity.Property(e => e.Specification)
                .HasMaxLength(100)
                .IsUnicode(false);
           entity.Property(e => e.TaskRunId).IsRequired();
        });

        modelBuilder.Entity<ArgusPriceUpdate>(entity =>
        {
            entity.ToTable("ArgusPriceUpdate", "OperationalDatabase");

            entity.Property(e => e.RepositoryId).IsRequired();
            entity.Property(e => e.CorrectionId).IsRequired();
            entity.Property(e => e.QuoteId).IsRequired();
            entity.Property(e => e.CodeId).IsRequired();
            entity.Property(e => e.TimestampId).IsRequired();
            entity.Property(e => e.ContinuousForward).IsRequired();
            entity.Property(e => e.PublicationDate).HasColumnType("datetime").IsRequired();
            entity.Property(e => e.Value).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.ForwardPeriod).IsRequired();
            entity.Property(e => e.ForwardYear).IsRequired();
            entity.Property(e => e.DiffBaseRoll).IsRequired();
            entity.Property(e => e.PriceTypeId).IsRequired();
            entity.Property(e => e.PriceReportItemId).IsRequired();
            entity.Property(e => e.ErrorId);
            entity.Property(e => e.UnitId1).IsRequired();
            entity.Property(e => e.UnitId2).IsRequired();
            entity.Property(e => e.DecimalPlaces).IsRequired();
            entity.Property(e => e.DiffBaseValue)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsRequired();
            entity.Property(e => e.DiffBaseTimingId).IsRequired();
            entity.Property(e => e.Correction)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsRequired();
            entity.Property(e => e.DateModified).HasColumnType("datetime").IsRequired();
            entity.Property(e => e.TaskRunId).IsRequired();
        });

        modelBuilder.Entity<BloombergPricingSnapshot>(entity =>
        {
            entity.HasKey(e => e.BloombergPricingSnapshotId).HasName("PK__Bloomber__C4A300BB0B603A7A");

            entity.ToTable("BloombergPricingSnapshot", "OperationalDatabase");

            entity.HasIndex(e => e.TaskRunId, "taskRunIdIndex");

            entity.Property(e => e.AskPrice).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.AskYield).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.BidPrice).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.BidYield).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.HighPrice).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.LastPrice).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.LastUpdateTime).HasColumnType("datetime");
            entity.Property(e => e.LastYield).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.LowPrice).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.MidPrice).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.MidYield).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.OpenPrice).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.PreviousClosePrice).HasColumnType("decimal(18, 6)");
            entity.Property(e => e.PricingSource)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Securities)
                .HasMaxLength(100)
                .IsUnicode(false);

            
        });

        modelBuilder.Entity<BrokerPriceQuote>(entity =>
        {
            entity.ToTable("BrokerPriceQuote", "OperationalDatabase");

            entity.Property(e => e.AskValue).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.BidValue).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.BrokerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Exchange)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.MidValue).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.PriceQuoteDate).HasColumnType("datetime");
            entity.Property(e => e.ProductName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TaskRunId).IsRequired();
            entity.Property(e => e.Term)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.UploadDate).HasColumnType("datetime");
            entity.Property(e => e.ValueDate).HasColumnType("datetime");
            
        });

        modelBuilder.Entity<GenericListItem>(entity =>
        {
            entity.HasKey(e => e.GenericListItemId).HasName("PK__GenericL__9634453904994F37");

            entity.ToTable("GenericListItem", "OperationalDatabase");

            entity.Property(e => e.TypeCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Value)
                .HasMaxLength(300)
                .IsUnicode(false);
        });

        modelBuilder.Entity<GenericMap>(entity =>
        {
            entity.HasKey(e => e.GenericMapId).HasName("PK__GenericM__5B69F21A117520EC");

            entity.ToTable("GenericMap", "OperationalDatabase");

            entity.Property(e => e.TypeCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Value1)
                .HasMaxLength(300)
                .IsUnicode(false);
            entity.Property(e => e.Value2).IsUnicode(false);
        });

        modelBuilder.Entity<GenericTimeout>(entity =>
        {
            entity.HasKey(e => e.GenericTimeoutId).HasName("PK__GenericT__92883418AA093B7F");

            entity.ToTable("GenericTimeout", "OperationalDatabase");

            entity.HasIndex(e => e.TypeCode, "UQ__GenericT__3E1CDC7C2726419B").IsUnique();

            entity.Property(e => e.TypeCode)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<MdmProduct>(entity =>
        {
            entity.HasKey(e => e.MdmProductId);

            entity
            .ToTable("MdmProduct", "OperationalDatabase")
            .ToTable(tb => tb.IsTemporal(ttb =>
             {
                 ttb.UseHistoryTable("MdmProductHistory", "OperationalDatabase");
                 ttb
                     .HasPeriodStart("ValidFrom")
                     .HasColumnName("ValidFrom");
                 ttb
                     .HasPeriodEnd("ValidTo")
                     .HasColumnName("ValidTo");
             }));

            entity.Property(e => e.MdmProductCode)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.MdmProductName)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.Property(e => e.GoldenSource)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.ProductStatus)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.SalesforceId)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.NetSuiteId)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.LastModifiedBy)
                .HasMaxLength(100)
                .IsUnicode(false);
            
            entity.Property(e => e.LastModifiedOn)
                .HasColumnType("datetime");
        });

        modelBuilder.Entity<ReferenceDataEntity>(entity =>
        {
            entity.HasKey(e => e.ReferenceDataEntityId).HasName("PK__Referenc__64877A0A204994F4");

            entity.ToTable("ReferenceDataEntity", "OperationalDatabase");

            entity.Property(e => e.ReferenceDataEntityCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ReferenceDataEntityDescription)
                .HasMaxLength(200)
                .IsUnicode(false);
        });

        modelBuilder.Entity<ReferenceDataField>(entity =>
        {
            entity.HasKey(e => e.ReferenceDataFieldId).HasName("PK__Referenc__C32A989FEA8EA289");

            entity.ToTable("ReferenceDataField", "OperationalDatabase");

            entity.Property(e => e.DataType)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.ReferenceDataFieldCode)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.HasOne(d => d.ReferenceDataEntity).WithMany(p => p.ReferenceDataFields)
                .HasForeignKey(d => d.ReferenceDataEntityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reference__Refer__06CD04F7");
        });

        modelBuilder.Entity<ReferenceDataFieldValue>(entity =>
        {
            entity.HasKey(e => e.ReferenceDataFieldValueId).HasName("PK__Referenc__4E48A093BC67A404");

            entity.ToTable("ReferenceDataFieldValue", "OperationalDatabase");

            entity.Property(e => e.DateTimeValue).HasColumnType("datetime");
            entity.Property(e => e.DecimalValue).HasColumnType("decimal(28, 10)");
            entity.Property(e => e.EndDate).HasColumnType("datetime");
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.StartDate).HasColumnType("datetime");
            entity.Property(e => e.StringValue).IsUnicode(false);

            entity.HasOne(d => d.ReferenceDataField).WithMany(p => p.ReferenceDataFieldValues)
                .HasForeignKey(d => d.ReferenceDataFieldId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reference__Refer__05D8E0BE");
        });

        modelBuilder.Entity<SelectOption>(entity =>
        {
            entity.HasKey(e => e.SelectOptionId).HasName("PK__SelectOp__827E80BE0B6334E2");

            entity.ToTable("SelectOption", "OperationalDatabase");

            entity.Property(e => e.SelectOptionDescription)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.SelectOptionTypeCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.SelectOptionValue)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Status>(entity =>
        {
            entity.HasKey(e => e.StatusId).HasName("PK__Status__C8EE2063033A9DAC");

            entity.ToTable("Status", "OperationalDatabase");

            entity.Property(e => e.StatusId).ValueGeneratedNever();
            entity.Property(e => e.StatusCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.StatusDescription)
                .HasMaxLength(200)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Task>(entity =>
        {
            entity.HasKey(e => e.TaskId).HasName("PK__Task__7C6949B191E0A29B");

            entity.ToTable("Task", "OperationalDatabase");

            entity.HasIndex(e => e.TaskName, "UQ__Task__1E0558899073B706").IsUnique();

            entity.HasIndex(e => e.TaskCode, "UQ__Task__251D069902D85EC3").IsUnique();

            entity.Property(e => e.Parameters).IsUnicode(false);
            entity.Property(e => e.TaskCode)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.TaskDescription)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.TaskMethod)
                .HasMaxLength(200)
                .IsUnicode(false);
            entity.Property(e => e.TaskName)
                .HasMaxLength(200)
                .IsUnicode(false);
        });

        modelBuilder.Entity<TaskRun>(entity =>
        {
            entity.HasKey(e => e.TaskRunId).HasName("PK__TaskRun__86F4BB06AF704E3B");

            entity.ToTable("TaskRun", "OperationalDatabase");

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasDefaultValue("ADMIN");
            entity.Property(e => e.CreatedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.LastModifiedBy)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasDefaultValue("ADMIN");
            entity.Property(e => e.LastModifiedOn)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Message).IsUnicode(false);
            entity.Property(e => e.Parameters).IsUnicode(false);
            entity.Property(e => e.StartedOn).HasColumnType("datetime");

            entity.HasOne(e => e.ParentTaskRun)
                 .WithMany(p => p.SubtaskRuns)
                 .HasForeignKey(e => e.ParentTaskRunId)
                 .OnDelete(DeleteBehavior.ClientSetNull);
            entity.HasOne(e => e.Status)
                .WithMany(s => s.TaskRuns)
                .HasForeignKey(e => e.StatusId)
                .OnDelete(DeleteBehavior.ClientSetNull);
            entity.HasMany(e => e.SubtaskRuns)
                .WithOne(s => s.ParentTaskRun)
                .HasForeignKey(s => s.ParentTaskRunId);
            entity.HasOne(e => e.Task)
                .WithMany()
                .HasForeignKey(e => e.TaskId)
                .OnDelete(DeleteBehavior.ClientSetNull);
        });

        modelBuilder.Entity<TaskSubtask>(entity =>
        {
            entity.HasKey(e => e.TaskSubtaskId).HasName("PK__TaskSubt__042A90340A7D95A2");

            entity.ToTable("TaskSubtask", "OperationalDatabase");

            entity.HasIndex(e => new { e.TaskId, e.Step }, "TaskStep").IsUnique();

            entity.HasOne(e => e.Subtask)
                .WithMany(p => p.ParentTasks)
                .HasForeignKey(e => e.SubtaskId)
                .OnDelete(DeleteBehavior.ClientSetNull);

            entity.HasOne(e => e.Task)
                .WithMany(s => s.Subtasks)
                .HasForeignKey(e => e.TaskId)
                .OnDelete(DeleteBehavior.ClientSetNull);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
