﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.Models;

public partial class AdmisDaily
{
    public int AdmisDailyId { get; set; }

    public string? FileType { get; set; }

    public int? TaskRunId { get; set; }

    public string? RecId { get; set; }

    public string? Firm { get; set; }

    public int? Office { get; set; }

    public int? Acct { get; set; }

    public string? Atype { get; set; }

    public string? Cusip { get; set; }

    public string? YyyyMm { get; set; }

    public string? PrmtDate { get; set; }

    public string? SecType { get; set; }

    public string? PutCall { get; set; }

    public string? SecType2 { get; set; }

    public decimal? Strike { get; set; }

    public int? ExpDate { get; set; }

    public int? TrdDate { get; set; }

    public decimal? TrdPrc { get; set; }

    public string? BuySell { get; set; }

    public string? SprdCode { get; set; }

    public string? AcCntry { get; set; }

    public int? RegRep { get; set; }

    public decimal? TrdQty { get; set; }

    public string? ContDesc { get; set; }

    public string? ContDesc2 { get; set; }

    public decimal? MktVal { get; set; }

    public decimal? PrevMktVal { get; set; }

    public decimal? Mult { get; set; }

    public int? SetlDate { get; set; }

    public decimal? Delta { get; set; }

    public int? LstTrdDate { get; set; }

    public string? ProdCurr { get; set; }

    public string? Exch { get; set; }

    public string? FutCod { get; set; }

    public string? FutOpt { get; set; }

    public string? Symbl { get; set; }

    public string? PrdType { get; set; }

    public string? SubEx { get; set; }

    public int? MatDate { get; set; }

    public string? PrntPrc { get; set; }

    public decimal? Basis { get; set; }

    public decimal? ClsPrc { get; set; }

    public string? PrcDate { get; set; }

    public string? PrntClsPrc { get; set; }

    public decimal? UndrlyClsPrc { get; set; }

    public string? PrntUndClsPrc { get; set; }

    public decimal? PrevClsPrc { get; set; }

    public string? ProdCurrSym { get; set; }

    public string? PrdCurrCde { get; set; }

    public string? Cmmt1 { get; set; }

    public string? Cmmt2 { get; set; }

    public string? Cmmt3 { get; set; }

    public string? RndHlfTrn { get; set; }

    public string? OpnCls { get; set; }

    public string? GivInOut { get; set; }

    public string? GivFrm { get; set; }

    public string? CardNo { get; set; }

    public decimal? Comm { get; set; }

    public decimal? Fee1 { get; set; }

    public decimal? Fee2 { get; set; }

    public decimal? Fee3 { get; set; }

    public decimal? Fee4 { get; set; }

    public decimal? Fee5 { get; set; }

    public decimal? Fee6 { get; set; }

    public decimal? Fee7 { get; set; }

    public decimal? Fee8 { get; set; }

    public decimal? Fee9 { get; set; }

    public decimal? GiGoChg { get; set; }

    public decimal? Brkg { get; set; }

    public decimal? OthFee { get; set; }

    public decimal? Gross { get; set; }

    public decimal? Net { get; set; }

    public string? AtypComm { get; set; }

    public string? AtypFee1 { get; set; }

    public decimal? BuyQty { get; set; }

    public decimal? SellQty { get; set; }

    public string? TracerId { get; set; }

    public decimal? MktVar { get; set; }

    public string? IsinNo { get; set; }

    public string? AtypCurr { get; set; }

    public string? LocCd { get; set; }

    public string? AcCls { get; set; }

    public string? ExecTime { get; set; }

    public string? AtypFee2 { get; set; }

    public string? AtypOthFee { get; set; }

    public string? CommCalc { get; set; }

    public string? LevelCde { get; set; }

    public string? RefNo { get; set; }

    public string? LinkNo { get; set; }

    public string? TradeType { get; set; }

    public string? BlmbgExch { get; set; }

    public string? BlmbgCode { get; set; }

    public string? BlmbgYellow { get; set; }

    public string? CompReuterExch { get; set; }

    public string? CompReuterUnderRic { get; set; }

    public string? CompReuterRootRic { get; set; }

    public string? ElectReuterExch { get; set; }

    public string? ElectReuterUnderRic { get; set; }

    public string? ElectRootRic { get; set; }

    public string? BlmbgTickerSymb { get; set; }

    public string? BlmbgTickerSymbYellow { get; set; }

    public string? AtypFee3 { get; set; }

    public string? AtypFee6 { get; set; }

    public string? AtypGiFee { get; set; }

    public string? AtypBkg { get; set; }
}
