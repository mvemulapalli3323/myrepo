﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimAdmisProduct
{
    public int DimAdmisProductId { get; set; }

    public string AdmisContractName { get; set; } = null!;

    public string ProductName { get; set; } = null!;

    public string Vintage { get; set; } = null!;

    public DateTime ValidFrom { get; set; }

    public DateTime ValidTo { get; set; }

    public bool ActiveFlag { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int TaskRunId { get; set; }
}
