﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class FactAdmisDailyTrade
{
    public int DimAdmisDailyTradeId { get; set; }

    public int DimDateId { get; set; }

    public int DimAdmisProductId { get; set; }

    public string AccountNumber { get; set; } = null!;

    public decimal LongNotionalValue { get; set; }

    public decimal LongQuantity { get; set; }

    public decimal LongWeightedAverageTradePrice { get; set; }

    public decimal ShortNotionalValue { get; set; }

    public decimal ShortQuantity { get; set; }

    public decimal ShortWeightedAverageTradePrice { get; set; }

    public decimal TradeCommissionFees { get; set; }

    public decimal ExchangeFees { get; set; }

    public decimal NfaFees { get; set; }

    public decimal CashEntries { get; set; }

    public decimal AdjustmentEntries { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public bool ActiveFlag { get; set; }

    public int TaskRunId { get; set; }

    public virtual DimAdmisProduct AdmisProductKeyNavigation { get; set; } = null!;

    public virtual DimDate DimDate { get; set; } = null!;
}
