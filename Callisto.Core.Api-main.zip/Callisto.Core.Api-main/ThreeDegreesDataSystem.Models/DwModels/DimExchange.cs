﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimExchange
{
    public int DimExchangeId { get; set; }

    public string ExchangeCode { get; set; } = null!;

    public string ExchangeName { get; set; } = null!;

    public DateTime ValidFrom { get; set; }

    public DateTime ValidTo { get; set; }

    public bool ActiveFlag { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int TaskRunId { get; set; }

    public virtual ICollection<FactPosition> PositionFacts { get; set; } = new List<FactPosition>();
}
