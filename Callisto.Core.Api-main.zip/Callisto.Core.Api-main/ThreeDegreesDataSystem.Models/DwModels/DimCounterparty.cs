﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimCounterparty
{
    public int DimCounterpartyId { get; set; }

    public int CounterpartyId { get; set; }

    public string CounterpartyName { get; set; } = null!;

    public DateTime ValidFrom { get; set; }

    public DateTime ValidTo { get; set; }

    public bool ActiveFlag { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int TaskRunId { get; set; }

    public virtual ICollection<FactPosition> PositionFacts { get; set; } = new List<FactPosition>();
}
