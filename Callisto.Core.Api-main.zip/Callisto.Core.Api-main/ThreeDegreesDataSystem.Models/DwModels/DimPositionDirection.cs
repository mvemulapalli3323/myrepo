﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimPositionDirection
{
    public int DimPositionDirectionId { get; set; }

    public string PositionDirectionCode { get; set; } = null!;

    public string PositionDirectionName { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int TaskRunId { get; set; }

    public virtual ICollection<FactPosition> PositionFacts { get; set; } = new List<FactPosition>();
}
