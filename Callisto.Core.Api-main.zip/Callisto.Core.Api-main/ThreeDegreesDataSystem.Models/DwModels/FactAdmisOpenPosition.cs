﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class FactAdmisOpenPosition
{
    public int DimAdmisOpenPositionId { get; set; }

    public int DimDateId { get; set; }

    public int DimAdmisProductId { get; set; }

    public int DimPositionDirectionId { get; set; }

    public int DimCurrencyId { get; set; }

    public int DimExchangeId { get; set; }

    public string AccountNumber { get; set; } = null!;

    public decimal Quantity { get; set; }

    public decimal TradeQuantity { get; set; }

    public decimal NotionalValue { get; set; }

    public decimal TradePrice { get; set; }

    public decimal ClosePrice { get; set; }

    public decimal Mtm { get; set; }

    public decimal StrikePrice { get; set; }

    public decimal Multiplier { get; set; }

    public string PutCall { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public bool ActiveFlag { get; set; }

    public int TaskRunId { get; set; }

    public virtual DimAdmisProduct DimAdmisProduct { get; set; } = null!;

    public virtual DimCurrency DimCurrency { get; set; } = null!;

    public virtual DimDate DimDate { get; set; } = null!;

    public virtual DimExchange DimExchange { get; set; } = null!;

    public virtual DimPositionDirection DimPositionDirection { get; set; } = null!;
}
