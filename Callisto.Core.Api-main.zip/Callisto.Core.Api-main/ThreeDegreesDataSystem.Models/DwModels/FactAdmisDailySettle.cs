﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class FactAdmisDailySettle
{
    public int DimAdmisDailySettleId { get; set; }

    public int DimDateId { get; set; }

    public int DimAdmisProductId { get; set; }

    public int DimCurrencyId { get; set; }

    public int DimSettleTypeId { get; set; }

    public string AccountNumber { get; set; } = null!;

    public decimal Quantity { get; set; }

    public decimal LongNotionalValueLocal { get; set; }

    public decimal ShortNotionalValueLocal { get; set; }

    public decimal LongNotionalValueUsd { get; set; }

    public decimal ShortNotionalValueUsd { get; set; }

    public decimal SettledMarginLocal { get; set; }

    public decimal SettledMarginUsd { get; set; }

    public decimal SettledMarginUsdPct { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public bool ActiveFlag { get; set; }

    public int TaskRunId { get; set; }

    public virtual DimAdmisProduct DimAdmisProduct { get; set; } = null!;

    public virtual DimCurrency DimCurrency { get; set; } = null!;

    public virtual DimDate DimDate { get; set; } = null!;

    public virtual DimSettleType DimSettleType { get; set; } = null!;
}
