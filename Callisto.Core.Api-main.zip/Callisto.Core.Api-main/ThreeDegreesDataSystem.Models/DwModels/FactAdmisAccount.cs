﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class FactAdmisAccount
{
    public int DimAdmisAccountId { get; set; }

    public int DimDateId { get; set; }

    public string AccountNumber { get; set; } = null!;

    public decimal PreviousBalance { get; set; }

    public decimal CommissionsAndFees { get; set; }

    public decimal OpenTradeEquity { get; set; }

    public decimal TradeProfitLoss { get; set; }

    public decimal EndingBalance { get; set; }

    public decimal InitialMarginRequirement { get; set; }

    public decimal MaintenanceMarginRequirement { get; set; }

    public decimal MarginExcessDeficit { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public bool ActiveFlag { get; set; }

    public int TaskRunId { get; set; }

    public virtual DimDate DimDate { get; set; } = null!;
}
