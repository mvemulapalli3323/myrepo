﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimGenerationPeriod
{
    public int DimGenerationPeriodId { get; set; }

    public int GenerationPeriodId { get; set; }

    public bool ActiveFlag { get; set; }

    public DateOnly StartDate { get; set; }

    public DateOnly EndDate { get; set; }

    public string CheckSum { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public string GenerationPeriodName { get; set; } = null!;

    public DateOnly? PeriodStartDate { get; set; }

    public DateOnly? PeriodEndDate { get; set; }

    public string? AmerexName { get; set; }

    public string? Icapname { get; set; }

    public string? SpectronmeterName { get; set; }

    public string? KarboneName { get; set; }

    public string? EvolutionName { get; set; }

    public string? CommergName { get; set; }


}
