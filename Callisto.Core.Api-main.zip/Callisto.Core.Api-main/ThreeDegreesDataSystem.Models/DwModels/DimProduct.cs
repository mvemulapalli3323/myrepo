﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimProduct
{
    public int DimProductId { get; set; }

    public int ProductId { get; set; }

    public bool ActiveFlag { get; set; }

    public DateOnly StartDate { get; set; }

    public DateOnly EndDate { get; set; }

    public string CheckSum { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int PortfolioProductId { get; set; }

    public string? ProductName { get; set; }

    public string? RetailProductName { get; set; }

    public string? CommodityName { get; set; }

    public string? PortfolioProductName { get; set; }

    public bool? MarketProductFlag { get; set; }

    public string? BidVolumeGoal { get; set; }

    public string? OfferVolumeGoal { get; set; }

    public string? SettleVolumeGoal { get; set; }

    public string? PriceQuoteLot { get; set; }

    public virtual ICollection<FactPosition> FactPositions { get; set; } = new List<FactPosition>();
}
