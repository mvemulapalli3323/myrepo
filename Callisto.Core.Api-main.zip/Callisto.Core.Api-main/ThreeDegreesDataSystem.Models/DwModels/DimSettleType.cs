﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimSettleType
{
    public int DimSettleTypeId { get; set; }

    public string SettleTypeCode { get; set; } = null!;

    public string SettleTypeName { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int TaskRunId { get; set; }
}
