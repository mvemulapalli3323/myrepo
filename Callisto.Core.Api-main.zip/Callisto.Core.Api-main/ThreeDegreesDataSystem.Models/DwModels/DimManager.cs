﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimManager
{
    public int DimManagerId { get; set; }

    public int ManagerId { get; set; }

    public bool ActiveFlag { get; set; }

    public DateOnly StartDate { get; set; }

    public DateOnly EndDate { get; set; }

    public string CheckSum { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int? SupervisorManagerId { get; set; }

    public string ManagerName { get; set; } = null!;

    public string? Title { get; set; }

    public string? EmailAddress { get; set; }

    public bool? Status { get; set; }

    public string? DivisionName { get; set; }

}
