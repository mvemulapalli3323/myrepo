﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimDate
{
    public int DimDateId { get; set; }

    public DateOnly Date { get; set; }

    public int Year { get; set; }

    public int Quarter { get; set; }

    public int Month { get; set; }

    public string MonthName { get; set; } = null!;

    public string MonthAbbreviation { get; set; } = null!;

    public int Day { get; set; }

    public int DayOfWeek { get; set; }

    public string DayName { get; set; } = null!;

    public string DayAbbreviation { get; set; } = null!;

    public int Week { get; set; }

    public bool WeekendFlag { get; set; }

    public int FiscalYear { get; set; }

    public int FiscalQuarter { get; set; }

    public bool UsHolidayFlag { get; set; }

    public string? UsHolidayName { get; set; }

    public bool UsBusinessDayFlag { get; set; }

    public bool LeapYearFlag { get; set; }

    public int DaysInMonth { get; set; }

    public DateOnly FirstDayOfMonth { get; set; }

    public DateOnly LastDayOfMonth { get; set; }

    public DateOnly FirstDayOfQuarter { get; set; }

    public DateOnly LastDayOfQuarter { get; set; }

    public DateOnly FirstDayOfYear { get; set; }

    public DateOnly LastDayOfYear { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;
}
