﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class FactPosition
{
    public int FactPositionId { get; set; }

    public int ReportingDateId { get; set; }

    public int DimPositionId { get; set; }

    public bool ActiveFlag { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int? DimPositionSideId { get; set; }

    public int? DimPortfolioId { get; set; }

    public int? DimProductId { get; set; }

    public int? DimEcProductListId { get; set; }

    public int? DimCounterpartyId { get; set; }

    public int? DimConfirmId { get; set; }

    public int? DimAgreementId { get; set; }

    public int? DimGenerationPeriodId { get; set; }

    public int? DimTransactionManagerId { get; set; }

    public int? DimContractManagerId { get; set; }

    public int? DimContractProductId { get; set; }

    public int? DimOperatingCompanyId { get; set; }

    public int? DimBillId { get; set; }

    public int? DimOptionId { get; set; }

    public int? DimCurrencyId { get; set; }

    public int? DimConsumptionCountryId { get; set; }

    public int? DimCancellationCountryId { get; set; }

    public bool? WorkingFlag { get; set; }

    public string? TradeYear { get; set; }

    public int? ReportingYear { get; set; }

    public int? Vintage { get; set; }

    public decimal? OverrideRate { get; set; }

    public decimal? LateRatePremium { get; set; }

    public decimal? PositionQuantity { get; set; }

    public decimal? RateUsd { get; set; }

    public decimal? RateLocal { get; set; }

    public decimal? BidCurrent { get; set; }

    public decimal? SettleCurrent { get; set; }

    public decimal? OfferCurrent { get; set; }

    public decimal? HedgeRate { get; set; }

    public decimal? MarketCover { get; set; }

    public DateOnly? PriceMarkDate { get; set; }

    public DateOnly? PriceFinalizedDate { get; set; }

    public decimal? DealPriceMarkBid { get; set; }

    public decimal? DealPriceMarkSettle { get; set; }

    public decimal? DealPriceMarkOffer { get; set; }

    public decimal? RevenueSharePercent { get; set; }

    public decimal? FloorPrice { get; set; }

    public decimal? TotalQuantity { get; set; }

    public decimal? OpenQuantity { get; set; }

    public decimal? AttestedQuantity { get; set; }

    public decimal? AssignedOpenQuantity { get; set; }

    public decimal? DeliveredQuantity { get; set; }

    public decimal? InvoicedQuantity { get; set; }

    public decimal? UnassignedQuantity { get; set; }

    public decimal? UncommittedQuantity { get; set; }

    public decimal? UninvoicedQuantity { get; set; }

    public decimal? GrossProfit { get; set; }

    public decimal? EkoadderUsd { get; set; }

    public decimal? NotionalUsd { get; set; }

    public decimal? NotionalLocal { get; set; }

    public decimal? Mtm { get; set; }

    public decimal? DealFxRate { get; set; }

    public decimal? CurrentFxRate { get; set; }


    public virtual DimManager? DimContractManager { get; set; }

    public virtual DimCounterparty? DimCounterparty { get; set; }

    public virtual DimGenerationPeriod? DimGenerationPeriod { get; set; }

    public virtual DimProduct? DimProduct { get; set; }

    public virtual DimManager? DimTransactionManager { get; set; }

    public virtual DimDate ReportingDate { get; set; } = null!;
}
