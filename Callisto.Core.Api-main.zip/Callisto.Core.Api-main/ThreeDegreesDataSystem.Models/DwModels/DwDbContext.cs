﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DwDbContext : DbContext
{
    public DwDbContext()
    {
    }

    public DwDbContext(DbContextOptions<DwDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<DimAdmisProduct> DimAdmisProducts { get; set; }


    public virtual DbSet<DimCounterparty> DimCounterparties { get; set; }

    public virtual DbSet<DimCountry> DimCountries { get; set; }

    public virtual DbSet<DimCurrency> DimCurrencies { get; set; }

    public virtual DbSet<DimDate> DimDates { get; set; }

    public virtual DbSet<DimExchange> DimExchanges { get; set; }

    public virtual DbSet<DimGenerationPeriod> DimGenerationPeriods { get; set; }

    public virtual DbSet<DimManager> DimManagers { get; set; }

    public virtual DbSet<DimPositionDirection> DimPositionDirections { get; set; }


    public virtual DbSet<DimProduct> DimProducts { get; set; }

    public virtual DbSet<DimSettleType> DimSettleTypes { get; set; }


    public virtual DbSet<FactAdmisAccount> FactAdmisAccounts { get; set; }


    public virtual DbSet<FactAdmisDailySettle> FactAdmisDailySettles { get; set; }


    public virtual DbSet<FactAdmisDailyTrade> FactAdmisDailyTrades { get; set; }


    public virtual DbSet<FactAdmisOpenPosition> FactAdmisOpenPositions { get; set; }


    public virtual DbSet<FactPosition> FactPositions { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<DimAdmisProduct>(entity =>
        {
            entity.HasKey(e => e.DimAdmisProductId).HasName("PK__tmp_ms_x__8AE033736689D7F1");

            entity.ToTable("DimAdmisProduct", "DW");

            entity.HasIndex(e => new { e.AdmisContractName, e.ActiveFlag }, "DimAdmisProduct_AdmisContractName_ActiveFlag_IX");

            entity.HasIndex(e => new { e.AdmisContractName, e.ValidFrom }, "DimAdmisProduct_AdmisContractName_ValidFrom_IX").IsUnique();

            entity.HasIndex(e => new { e.AdmisContractName, e.ValidTo }, "DimAdmisProduct_AdmisContractName_ValidTo_IX");

            entity.HasIndex(e => new { e.AdmisContractName, e.ValidFrom }, "DimAdmisProduct_AdmisContract_ValidFrom_UQ").IsUnique();

            entity.Property(e => e.ActiveFlag).HasDefaultValue(true);
            entity.Property(e => e.AdmisContractName).HasMaxLength(200);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.LastModifiedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.LastModifiedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ProductName).HasMaxLength(200);
            entity.Property(e => e.ValidFrom).HasColumnType("datetime");
            entity.Property(e => e.ValidTo).HasColumnType("datetime");
            entity.Property(e => e.Vintage).HasMaxLength(50);
        });


        modelBuilder.Entity<DimCounterparty>(entity =>
        {
            entity.HasKey(e => e.DimCounterpartyId).HasName("PK_dimCounterparty_DimCounterpartyID");

            entity.ToTable("DimCounterparty", "DW");

            entity.Property(e => e.DimCounterpartyId).HasColumnName("DimCounterpartyID");
            entity.Property(e => e.CounterpartyId).HasColumnName("CounterpartyID");
            entity.Property(e => e.CounterpartyName).HasMaxLength(200);
            entity.Property(e => e.CreatedBy).HasMaxLength(100);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.LastModifiedBy).HasMaxLength(100);
            entity.Property(e => e.LastModifiedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<DimCountry>(entity =>
        {
            entity.HasKey(e => e.DimCountryId)
                .HasName("PK_DimCountry_DimCountryID")
                .IsClustered(false);

            entity.ToTable("DimCountry", "DW");

            entity.HasIndex(e => e.CountryCode, "UQ_DimCountry_CountryCode").IsUnique();

            entity.HasIndex(e => e.CountryId, "UQ_DimCountry_CountryID").IsUnique();

            entity.HasIndex(e => e.CountryName, "UQ_DimCountry_CountryName").IsUnique();

            entity.HasIndex(e => e.CountryShortCode, "UQ_DimCountry_CountryShortCode").IsUnique();

            entity.HasIndex(e => e.CountryCode, "UQ__CountryD__5D9B0D2C46451A91").IsUnique();

            entity.HasIndex(e => e.CountryName, "UQ__CountryD__E056F2016CAC3942").IsUnique();

            entity.Property(e => e.CountryCode).HasMaxLength(100);
            entity.Property(e => e.CountryId).HasColumnName("CountryID");
            entity.Property(e => e.CountryName).HasMaxLength(200);
            entity.Property(e => e.CountryShortCode).HasMaxLength(100);
            entity.Property(e => e.CreatedBy).HasMaxLength(100);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.LastModifiedBy).HasMaxLength(100);
            entity.Property(e => e.LastModifiedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Region).HasMaxLength(100);
        });

        modelBuilder.Entity<DimCurrency>(entity =>
        {
            entity.HasKey(e => e.DimCurrencyId)
                .HasName("PK_DimCurrency_DimCurrencyID")
                .IsClustered(false);

            entity.ToTable("DimCurrency", "DW");

            entity.HasIndex(e => e.CurrencyCode, "UQ_DimCurrency_CurrencyCode").IsUnique();

            entity.HasIndex(e => e.CurrencyName, "UQ_DimCurrency_CurrencyName").IsUnique();

            entity.HasIndex(e => e.CurrencyName, "UQ__Currency__3D13D2988E67B7C7").IsUnique();

            entity.HasIndex(e => e.CurrencyCode, "UQ__Currency__408426BF42A54746").IsUnique();

            entity.Property(e => e.ActiveFlag).HasDefaultValue(true);
            entity.Property(e => e.CreatedBy).HasMaxLength(100);
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.CurrencyCode).HasMaxLength(100);
            entity.Property(e => e.CurrencyId).HasColumnName("CurrencyID");
            entity.Property(e => e.CurrencyName).HasMaxLength(100);
            entity.Property(e => e.CurrencySymbol).HasMaxLength(5);
            entity.Property(e => e.LastModifiedBy).HasMaxLength(100);
            entity.Property(e => e.LastModifiedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
        });

        modelBuilder.Entity<DimDate>(entity =>
        {
            entity.HasKey(e => e.DimDateId).HasName("PK__DimDate__9179DF902679149F");

            entity.ToTable("DimDate", "DW");

            entity.HasIndex(e => e.Date, "UQ__DimDate__77387D0703BDED5B").IsUnique();

            entity.Property(e => e.DimDateId).ValueGeneratedNever();
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.DayAbbreviation).HasMaxLength(10);
            entity.Property(e => e.DayName).HasMaxLength(20);
            entity.Property(e => e.LastModifiedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.LastModifiedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.MonthAbbreviation).HasMaxLength(10);
            entity.Property(e => e.MonthName).HasMaxLength(20);
            entity.Property(e => e.UsHolidayName).HasMaxLength(100);
        });


        modelBuilder.Entity<DimExchange>(entity =>
        {
            entity.HasKey(e => e.DimExchangeId).HasName("PK__DimExcha__30B80792F5E4B74F");

            entity.ToTable("DimExchange", "DW");

            entity.HasIndex(e => new { e.ExchangeCode, e.ActiveFlag }, "IX_DimExchange_ExchangeCode_ActiveFlag");

            entity.HasIndex(e => new { e.ExchangeCode, e.ValidFrom }, "IX_DimExchange_ExchangeCode_ValidFrom").IsUnique();

            entity.HasIndex(e => new { e.ExchangeCode, e.ValidTo }, "IX_DimExchange_ExchangeCode_ValidTo");

            entity.HasIndex(e => new { e.ExchangeCode, e.ValidFrom }, "UQ_DimExchange_ExchangeCode_ValidFrom_New").IsUnique();

            entity.Property(e => e.ActiveFlag).HasDefaultValue(true);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ExchangeCode).HasMaxLength(100);
            entity.Property(e => e.ExchangeName).HasMaxLength(100);
            entity.Property(e => e.LastModifiedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.LastModifiedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ValidFrom).HasColumnType("datetime");
            entity.Property(e => e.ValidTo).HasColumnType("datetime");
        });

        modelBuilder.Entity<DimGenerationPeriod>(entity =>
        {
            entity.HasKey(e => e.DimGenerationPeriodId).HasName("PK_DimGenerationPeriod_DimGenerationPeriodID");

            entity.ToTable("DimGenerationPeriod", "DW");

            entity.Property(e => e.DimGenerationPeriodId).HasColumnName("DimGenerationPeriodID");
            entity.Property(e => e.AmerexName).HasMaxLength(100);
            entity.Property(e => e.CheckSum)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CommergName).HasMaxLength(100);
            entity.Property(e => e.CreatedBy).HasMaxLength(100);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.EvolutionName).HasMaxLength(100);
            entity.Property(e => e.GenerationPeriodId).HasColumnName("GenerationPeriodID");
            entity.Property(e => e.GenerationPeriodName).HasMaxLength(100);
            entity.Property(e => e.Icapname)
                .HasMaxLength(100)
                .HasColumnName("ICAPName");
            entity.Property(e => e.KarboneName).HasMaxLength(100);
            entity.Property(e => e.LastModifiedBy).HasMaxLength(100);
            entity.Property(e => e.LastModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.SpectronmeterName).HasMaxLength(100);
        });

        modelBuilder.Entity<DimManager>(entity =>
        {
            entity.HasKey(e => e.DimManagerId).HasName("PK_DimManager_DimManagerID");

            entity.ToTable("DimManager", "DW");

            entity.Property(e => e.DimManagerId).HasColumnName("DimManagerID");
            entity.Property(e => e.CheckSum)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CreatedBy).HasMaxLength(100);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.DivisionName).HasMaxLength(200);
            entity.Property(e => e.EmailAddress).HasMaxLength(100);
            entity.Property(e => e.LastModifiedBy).HasMaxLength(100);
            entity.Property(e => e.LastModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.ManagerId).HasColumnName("ManagerID");
            entity.Property(e => e.ManagerName).HasMaxLength(100);
            entity.Property(e => e.SupervisorManagerId).HasColumnName("SupervisorManagerID");
            entity.Property(e => e.Title).HasMaxLength(50);
        });


        modelBuilder.Entity<DimPositionDirection>(entity =>
        {
            entity.HasKey(e => e.DimPositionDirectionId).HasName("PK__DimPosit__EF438F5181A595D4");

            entity.ToTable("DimPositionDirection", "DW");

            entity.HasIndex(e => e.PositionDirectionName, "UQ__DimPosit__1CB63BEBDC559008").IsUnique();

            entity.HasIndex(e => e.PositionDirectionCode, "UQ__DimPosit__8C890C808CBB741D").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.LastModifiedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.LastModifiedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.PositionDirectionCode).HasMaxLength(100);
            entity.Property(e => e.PositionDirectionName).HasMaxLength(100);
        });

        modelBuilder.Entity<DimProduct>(entity =>
        {
            entity.HasKey(e => e.DimProductId).HasName("PK_dimProduct_DimProductID");

            entity.ToTable("DimProduct", "DW");

            entity.Property(e => e.DimProductId).HasColumnName("DimProductID");
            entity.Property(e => e.BidVolumeGoal).HasMaxLength(50);
            entity.Property(e => e.CheckSum)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.CommodityName).HasMaxLength(100);
            entity.Property(e => e.CreatedBy).HasMaxLength(100);
            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.LastModifiedBy).HasMaxLength(100);
            entity.Property(e => e.LastModifiedDate).HasColumnType("datetime");
            entity.Property(e => e.OfferVolumeGoal).HasMaxLength(50);
            entity.Property(e => e.PortfolioProductId).HasColumnName("PortfolioProductID");
            entity.Property(e => e.PortfolioProductName).HasMaxLength(200);
            entity.Property(e => e.PriceQuoteLot).HasMaxLength(50);
            entity.Property(e => e.ProductId).HasColumnName("ProductID");
            entity.Property(e => e.RetailProductName).HasMaxLength(200);
            entity.Property(e => e.SettleVolumeGoal).HasMaxLength(50);
        });

        modelBuilder.Entity<DimSettleType>(entity =>
        {
            entity.HasKey(e => e.DimSettleTypeId).HasName("PK__DimSettl__069320CA91252C2E");

            entity.ToTable("DimSettleType", "DW");

            entity.HasIndex(e => e.SettleTypeName, "UQ__DimSettl__88733A9770A62D2C").IsUnique();

            entity.HasIndex(e => e.SettleTypeCode, "UQ__DimSettl__CD5F339E5142B2E9").IsUnique();

            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.LastModifiedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.LastModifiedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.SettleTypeCode).HasMaxLength(100);
            entity.Property(e => e.SettleTypeName).HasMaxLength(100);
        });

        modelBuilder.Entity<FactAdmisAccount>(entity =>
        {

            entity.HasKey(e => e.DimAdmisAccountId).HasName("PK_FactAdmisAccount_DimAdmisAccountId"); ;

            entity.ToTable("FactAdmisAccount", "DW");

            entity.Property(e => e.AccountNumber).HasMaxLength(100);
            entity.Property(e => e.ActiveFlag).HasDefaultValue(true);
            entity.Property(e => e.CommissionsAndFees).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EndingBalance).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.InitialMarginRequirement).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.MaintenanceMarginRequirement).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.MarginExcessDeficit).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.OpenTradeEquity).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.PreviousBalance).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.TradeProfitLoss).HasColumnType("decimal(20, 4)");

        });


        modelBuilder.Entity<FactAdmisDailySettle>(entity =>
        {
            entity.HasKey(e => e.DimAdmisDailySettleId).HasName("PK__FactAdmi__36FA8AC2714802DB");

            entity.ToTable("FactAdmisDailySettle", "DW");
            entity.Property(e => e.TaskRunId);
            entity.Property(e => e.AccountNumber).HasMaxLength(100);
            entity.Property(e => e.ActiveFlag).HasDefaultValue(true);
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.LongNotionalValueLocal).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.LongNotionalValueUsd).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.Quantity).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.SettledMarginLocal).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.SettledMarginUsd).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.SettledMarginUsdPct).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.ShortNotionalValueLocal).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.ShortNotionalValueUsd).HasColumnType("decimal(20, 4)");

        });

        modelBuilder.Entity<FactAdmisDailyTrade>(entity =>
        {
            entity.HasKey(e => e.DimAdmisDailyTradeId).HasName("PK__FactAdmi__93E43C6F4AF8F617");

            entity.ToTable("FactAdmisDailyTrade", "DW");
            entity.Property(e => e.TaskRunId);
            entity.Property(e => e.AccountNumber).HasMaxLength(100);
            entity.Property(e => e.ActiveFlag).HasDefaultValue(true);
            entity.Property(e => e.AdjustmentEntries).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.CashEntries).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.ExchangeFees).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.LongNotionalValue).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.LongQuantity).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.LongWeightedAverageTradePrice).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.NfaFees).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.ShortNotionalValue).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.ShortQuantity).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.ShortWeightedAverageTradePrice).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.TradeCommissionFees).HasColumnType("decimal(20, 4)");

        });


        modelBuilder.Entity<FactAdmisOpenPosition>(entity =>
        {
            entity.HasKey(e => e.DimAdmisOpenPositionId).HasName("PK__FactAdmi__958B09658DA177E7");

            entity.ToTable("FactAdmisOpenPosition", "DW");
            entity.Property(e => e.TaskRunId);
            entity.Property(e => e.AccountNumber).HasMaxLength(100);
            entity.Property(e => e.ActiveFlag).HasDefaultValue(true);
            entity.Property(e => e.ClosePrice).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.CreatedBy)
                .HasMaxLength(100)
                .HasDefaultValue("Dw Admin");
            entity.Property(e => e.CreatedDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Mtm).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.Multiplier).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.NotionalValue).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.PutCall).HasMaxLength(100);
            entity.Property(e => e.Quantity).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.StrikePrice).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.TradePrice).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.TradeQuantity).HasColumnType("decimal(20, 4)");

        });


        modelBuilder.Entity<FactPosition>(entity =>
        {
            entity.HasKey(e => e.FactPositionId).HasName("PK_FactPosition_FactPositionID");

            entity.ToTable("FactPosition", "DW");

            entity.Property(e => e.FactPositionId).HasColumnName("FactPositionID");
            entity.Property(e => e.AssignedOpenQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.AttestedQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.BidCurrent).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.CreatedBy).HasMaxLength(100);
            entity.Property(e => e.CurrentFxRate).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.DealFxRate).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.DealPriceMarkBid).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.DealPriceMarkOffer).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.DealPriceMarkSettle).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.DeliveredQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.DimAgreementId).HasColumnName("DimAgreementID");
            entity.Property(e => e.DimBillId).HasColumnName("DimBillID");
            entity.Property(e => e.DimCancellationCountryId).HasColumnName("DimCancellationCountryID");
            entity.Property(e => e.DimConfirmId).HasColumnName("DimConfirmID");
            entity.Property(e => e.DimConsumptionCountryId).HasColumnName("DimConsumptionCountryID");
            entity.Property(e => e.DimContractManagerId).HasColumnName("DimContractManagerID");
            entity.Property(e => e.DimContractProductId).HasColumnName("DimContractProductID");
            entity.Property(e => e.DimCounterpartyId).HasColumnName("DimCounterpartyID");
            entity.Property(e => e.DimCurrencyId).HasColumnName("DimCurrencyID");
            entity.Property(e => e.DimEcProductListId).HasColumnName("DimEcProductListID");
            entity.Property(e => e.DimGenerationPeriodId).HasColumnName("DimGenerationPeriodID");
            entity.Property(e => e.DimOperatingCompanyId).HasColumnName("DimOperatingCompanyID");
            entity.Property(e => e.DimOptionId).HasColumnName("DimOptionID");
            entity.Property(e => e.DimPortfolioId).HasColumnName("DimPortfolioID");
            entity.Property(e => e.DimPositionId).HasColumnName("DimPositionID");
            entity.Property(e => e.DimPositionSideId).HasColumnName("DimPositionSideID");
            entity.Property(e => e.DimProductId).HasColumnName("DimProductID");
            entity.Property(e => e.DimTransactionManagerId).HasColumnName("DimTransactionManagerID");
            entity.Property(e => e.EkoadderUsd)
                .HasColumnType("decimal(20, 4)")
                .HasColumnName("EKOAdderUSD");
            entity.Property(e => e.FloorPrice).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.GrossProfit).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.HedgeRate).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.InvoicedQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.LastModifiedBy).HasMaxLength(100);
            entity.Property(e => e.LateRatePremium).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.MarketCover).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.Mtm)
                .HasColumnType("decimal(20, 4)")
                .HasColumnName("MTM");
            entity.Property(e => e.NotionalLocal).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.NotionalUsd)
                .HasColumnType("decimal(20, 4)")
                .HasColumnName("NotionalUSD");
            entity.Property(e => e.OfferCurrent).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.OpenQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.OverrideRate).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.PositionQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.RateLocal).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.RateUsd)
                .HasColumnType("decimal(20, 4)")
                .HasColumnName("RateUSD");
            entity.Property(e => e.ReportingDateId).HasColumnName("ReportingDateID");
            entity.Property(e => e.RevenueSharePercent).HasColumnType("decimal(5, 4)");
            entity.Property(e => e.SettleCurrent).HasColumnType("decimal(20, 4)");
            entity.Property(e => e.TotalQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.TradeYear).HasMaxLength(50);
            entity.Property(e => e.UnassignedQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.UncommittedQuantity).HasColumnType("decimal(20, 8)");
            entity.Property(e => e.UninvoicedQuantity).HasColumnType("decimal(20, 8)");

            
            entity.HasOne(d => d.DimProduct).WithMany(p => p.FactPositions)
                .HasForeignKey(d => d.DimProductId)
                .HasConstraintName("FK_DimProduct_DimProductID");

        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
