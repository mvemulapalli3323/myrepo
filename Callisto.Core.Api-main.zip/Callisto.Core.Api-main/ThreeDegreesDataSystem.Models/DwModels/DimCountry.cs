﻿using System;
using System.Collections.Generic;

namespace ThreeDegreesDataSystem.Models.DwModels;

public partial class DimCountry
{
    public int DimCountryId { get; set; }

    public string CountryCode { get; set; } = null!;

    public string CountryName { get; set; } = null!;

    public string CountryShortCode { get; set; } = null!;

    public int CountryId { get; set; }

    public string Region { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public string CreatedBy { get; set; } = null!;

    public DateTime LastModifiedDate { get; set; }

    public string LastModifiedBy { get; set; } = null!;

    public int TaskRunId { get; set; }

    public virtual ICollection<FactPosition> PositionFactCancelCountryKeyNavigations { get; set; } = new List<FactPosition>();

    public virtual ICollection<FactPosition> PositionFactConsumptionCountryKeyNavigations { get; set; } = new List<FactPosition>();
}
