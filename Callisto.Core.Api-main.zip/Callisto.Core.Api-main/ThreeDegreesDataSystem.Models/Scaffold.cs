﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.DataAccess
{
    class Scaffold
    {

        //Scaffold-DbContext "Server=sql-data-system-dev-westus2-01.database.windows.net;database=CentralOpsDb;User Id = DataSystemAdmin; Password=3dDataSysDev!!" Microsoft.EntityFrameworkCore.SqlServer -Force -OutputDir Models
        //Scaffold-DbContext "Server=dw-data-system-dev-westus2-01.database.windows.net;database=DwDb;User Id=DwDataSystemAdmin;Password=3dDwDataSysDev!!" Microsoft.EntityFrameworkCore.SqlServer -Force -OutputDir DwModels


        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    var connectionString = Environment.GetEnvironmentVariable("DB_CONNECTION_STRING");

        //    optionsBuilder.UseSqlServer(connectionString, builder =>
        //    {
        //        builder.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null);
        //    });
        //    base.OnConfiguring(optionsBuilder);
        //}
    }
}