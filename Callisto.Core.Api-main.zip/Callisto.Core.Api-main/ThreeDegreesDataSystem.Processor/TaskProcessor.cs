﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Exceptions;
using ThreeDegreesDataSystem.Common.Helper;
//using ThreeDegreesDataSystem.Connectors.Email;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Processor.Tasks;
using ThreeDegreesDataSystem.Service;
using ThreeDegreesDataSystem.Service.Interface;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ThreeDegreesDataSystem.Connectors.Interface;

namespace ThreeDegreesDataSystem.Processor
{
    public class TaskProcessor : ITaskProcessor
    {
        private readonly IEmailConnector _emailConnector;
        private readonly ILogger<TaskProcessor> _logger;
        private readonly ITaskRunner _taskRunner;
        private readonly ITaskService _taskService;
        private readonly ITaskRunService _taskRunService;

        public TaskProcessor(
            IEmailConnector emailConnector,
            ILogger<TaskProcessor> logger,
            ITaskRunner taskRunner,
            ITaskService taskService,
            ITaskRunService taskRunService
            )
        {
            _emailConnector = emailConnector;
            _logger = logger;
            _taskRunner = taskRunner;
            _taskService = taskService;
            _taskRunService = taskRunService;
        }

        public async Task<TaskRun> CreateTaskRuns(int taskId, TaskRun taskRun, int? parentTaskRunId = null, int? parentStep = null)
        {
            Models.Models.Task task = await _taskService.GetTask(taskId);
            // Set defaults
            taskRun.StatusId = (task.IsActive)
                ? DataMap.GetStatusId(StringConstants.NotStarted)
                : DataMap.GetStatusId(StringConstants.Skipped);
            // Create to get ID for subtasks
            TaskRun parentTaskRun = await _taskRunService.CreateTaskRun(taskId, taskRun, parentTaskRunId, parentStep);
            // Set Parameters for children
            taskRun.Parameters = ParameterHelper.SetTaskRunId(taskRun.Parameters, DataMap.GetTaskCode(taskId), parentTaskRun.TaskRunId);
            parentTaskRun.Parameters = taskRun.Parameters;
            // Update current Task Run
            await _taskRunService.UpdateCentralOpsEntityAsync(parentTaskRun);
            // Create subtasks
            TaskSubtask[] subtasks = await _taskService.GetTaskSubtasks(taskId);
            foreach (TaskSubtask taskSubtask in subtasks)
            {
                await CreateTaskRuns(taskSubtask.SubtaskId, taskRun, parentTaskRun.TaskRunId, taskSubtask.Step);
            }
            return parentTaskRun;
        }

        public async Task<TaskRun> RunTask(int taskId, TaskRun taskRun)
        {
            taskRun = await CreateTaskRuns(taskId, taskRun);
            taskRun = await RunTaskRun(taskRun);
            return taskRun;
        }

        public async Task<TaskRun> RunTaskRun(TaskRun taskRun, int recursionLevel = 0, bool rerun = false)
        {
            taskRun = await _taskRunService.GetTaskRun(taskRun.TaskRunId, inclusive: true, tracking: true);

            // If we allow multiple instances of the same task...
            if (!taskRun.Task.AllowMultiple)
            {
                // ...check if the task is already running.
                if (_taskService.IsRunning(taskRun.TaskId))
                {
                    // Another instance is running. Fail this new instance
                    return await FailTaskRun(taskRun, recursionLevel,
                        $"Instance of task {taskRun.Task.TaskCode} already running!");
                }
            }

            // Skip Task Runs
            int[] skipStatusIds = new[]
            {
                DataMap.GetStatusId(StringConstants.Skipped),
                DataMap.GetStatusId(StringConstants.Succeeded)
            };
            if (skipStatusIds.Contains(taskRun.StatusId))
            {
                return taskRun;
            }

            // Before setting to in progress, check if clean up is needed
            bool needsCleanUp = (DataMap.GetStatusCode(taskRun.StatusId) != StringConstants.NotStarted);
            if (rerun)
            {
                await _taskRunService.RestartTaskRun(taskRun);
            }
            else
            {
                await _taskRunService.StartTaskRun(taskRun);
            }

            // Run current task run
            // Clean up previously ran
            if (needsCleanUp)
            {
                try
                {
                    taskRun.AppendToMessage("\nTASKRUN RERUN: Clean up starting\n");
                    await _taskRunner.RunTaskCleanUp(taskRun);
                    taskRun.AppendToMessage("Clean up finished\n");
                }
                catch (Exception ex)
                {
                    string message = ExceptionHelper.BuildMessage(ex);
                    return await FailTaskRun(taskRun, recursionLevel, message);
                }
            }

            // Run task run
            try
            { 
                try
                {
                    await _taskRunService.SetStep(taskRun, 1);
                    await _taskRunner.RunTask(taskRun);
                }
                catch (TaskNotFoundException ex)
                {
                    // Only an issue if there are no subtasks
                    if (taskRun.SubtaskRuns.Count == 0)
                    {
                        throw ex;
                    }
                }
            }
            catch (Exception ex)
            {
                string message = ExceptionHelper.BuildMessage(ex);
                return await FailTaskRun(taskRun, recursionLevel, message);
            }

            // Wait for something (logic apps) to set status to continue
            if (taskRun.StatusId == DataMap.GetStatusId(StringConstants.Waiting))
            {
                int timeout = ParameterHelper.GetTimeout(taskRun.Parameters);
                await WaitUntilStatusChange(taskRun, timeout);
            }

            // If cancelling, set to cancelled and return
            bool isCanceled = await _taskRunService.IsCanceled(taskRun.TaskRunId);
            if (isCanceled)
            {
                return await _taskRunService.GetTaskRun(taskRun.TaskRunId, inclusive: true);
            }

            // Persist failures
            if (taskRun.StatusId == DataMap.GetStatusId(StringConstants.Failed))
            {
                return await FailTaskRun(taskRun, recursionLevel);
            }

            // Run subtask runs
            int step = 0;
            foreach (TaskRun subtaskRun in taskRun.SubtaskRuns)
            {
                // Check if canceled before running subtask
                bool isCanceledBefore = await _taskRunService.IsCanceled(taskRun.TaskRunId);
                if (isCanceledBefore)
                {
                    return await _taskRunService.GetTaskRun(taskRun.TaskRunId, inclusive: true);
                }

                // Increment step and run subtask run
                // Note: RunTaskRun will set the subtask runs status
                await _taskRunService.SetStep(taskRun, ++step);
                await RunTaskRun(subtaskRun, recursionLevel + 1);

                // Check if parent task run was canceled while running subtask, before setting status
                bool isCanceledAfter = await _taskRunService.IsCanceled(taskRun.TaskRunId);
                if (isCanceledAfter)
                {
                    return await _taskRunService.GetTaskRun(taskRun.TaskRunId, inclusive: true);
                }

                // Check if subtask run failed
                if (subtaskRun.StatusId == DataMap.GetStatusId(StringConstants.Failed))
                {
                    // Fail current task run and return
                    return await FailTaskRun(taskRun, recursionLevel, subtaskRun.Message);
                }

            }

            // If we make it here, all tasks have succeeded
            return await CompleteTaskRun(taskRun, recursionLevel);
        }

        private async Task<TaskRun> CompleteTaskRun(TaskRun taskRun, int recursionLevel)
        {
            await _taskRunService.CompleteTaskRun(taskRun);
            if (recursionLevel == 0) await _taskRunService.ValidateTaskRun(taskRun);
            if (recursionLevel == 0)
            {
                await _emailConnector.SendEmailAlert(taskRun.Message, $"{taskRun.Task.TaskCode} Succeeded", taskRun.Task.TaskCode);
            }
            _logger.LogInformation("Task '{taskCode}' complete", taskRun.Task.TaskCode);
            return taskRun;
        }

        private async Task<TaskRun> FailTaskRun(TaskRun taskRun, int recursionLevel, string message = null)
        {
            message ??= taskRun.Message;
            await _taskRunService.FailTaskRun(taskRun, message);
            // Only send emails for the overall failure
            if (recursionLevel == 0)
            {
                await _emailConnector.SendEmailAlert(taskRun.Message, $"{taskRun.Task.TaskCode} Failed", taskRun.Task.TaskCode);
            }
            _logger.LogError("Task '{taskCode}' failed", taskRun.Task.TaskCode);
            return taskRun;
        }

        private async Task<TaskRun> WaitUntilStatusChange(TaskRun taskRun, int timeoutInSeconds)
        {
            int secondsLeft = timeoutInSeconds;
            while (secondsLeft > 0)
            {
                secondsLeft--;
                Thread.Sleep(1000);
                // Check to see if changed in another context
                await _taskRunService.ReloadCentralOpsEntityAsync(taskRun);
                if (taskRun.StatusId != DataMap.GetStatusId(StringConstants.InProgress))
                {
                    return taskRun;
                }
            }
            taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
            taskRun.Message = $"Waiting TaskRun timed out after {timeoutInSeconds} seconds.";
            return taskRun;
        }
    }
}
