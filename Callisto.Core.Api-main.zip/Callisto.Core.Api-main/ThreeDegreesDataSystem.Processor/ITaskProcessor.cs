﻿using ThreeDegreesDataSystem.Models.Models;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Processor
{
    public interface ITaskProcessor
    {
        public Task<TaskRun> CreateTaskRuns(int taskId, TaskRun taskRun, int? parentTaskRunId = null, int? parentStep = null);
        public Task<TaskRun> RunTask(int taskId, TaskRun taskRun);
        public Task<TaskRun> RunTaskRun(TaskRun taskRun, int recursionLevel = 0, bool rerun = false);
    }
}
