﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service;

namespace ThreeDegreesDataSystem.Processor.Tasks
{
    public partial class TaskRunner
    {
        private async Task<TaskRun> UpdateAdmisProductDimensions(TaskRun taskRun)
        {
            try
            {
                //var admisDbLoadTaskRunId = 1385;
                //var businessDate = new DateOnly(2025, 4, 11);      
                var message = await _admisService.UpdateAdmisProductDimensions(taskRun.TaskRunId);
                
                taskRun.AppendToMessage($"Message: {message} {Environment.NewLine}");
                return taskRun;
            }
            catch (Exception ex)
            {
                //_logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                taskRun.AppendToMessage($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                
                return taskRun;
            }
        }
    }
}
