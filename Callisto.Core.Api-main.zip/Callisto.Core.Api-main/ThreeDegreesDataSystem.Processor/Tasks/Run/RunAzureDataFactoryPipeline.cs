﻿
using Microsoft.Extensions.Logging;
using System.Text.Json;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Exceptions;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service;

namespace ThreeDegreesDataSystem.Processor.Tasks
{
    public partial class TaskRunner
    {
        private async Task<TaskRun> RunAzureDataFactoryPipeline(TaskRun taskRun)
        {
            var response = string.Empty;
            try
            {
                var pipelineName = taskRun.Task.TaskCode;

                taskRun.AppendToMessage($"Starting ADF Pipeline {pipelineName}");
                response = await _azureDataFactoryConnector.TriggerPipeline(taskRun);
                var runInfo = JsonSerializer.Deserialize<Dictionary<string, string>>(response);
                PipelineStatus runStatus = new PipelineStatus(StringConstants.NotStarted,String.Empty);

                if (runInfo != null && runInfo.ContainsKey("runId"))
                {
                    taskRun.AppendToMessage($"ADF RunId: {runInfo["runId"]}");
                    runStatus.Status = AzureDataFactoryStatus.InProgress;

                    while (runStatus.Status == AzureDataFactoryStatus.InProgress || runStatus.Status == AzureDataFactoryStatus.Queued)
                    {
                        await System.Threading.Tasks.Task.Delay(5000);
                        runStatus = await _azureDataFactoryConnector.GetPipelineStatus(runInfo["runId"]);
                    }
                }
                switch (runStatus.Status)
                {
                    case AzureDataFactoryStatus.Succeeded:
                        taskRun.AppendToMessage($"ADF Pipeline Run {pipelineName} Succeeded");
                        taskRun.StatusId = DataMap.GetStatusId(StringConstants.Succeeded);
                        return taskRun;
                    case AzureDataFactoryStatus.Failed:
                        taskRun.AppendToMessage($"ADF Pipeline Run {pipelineName} Failed.  Error Message: {runStatus.Message}");
                        taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                        return taskRun;
                    default:
                        taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                        throw new TaskFailedException($"ADF Pipeline Run {pipelineName} Failed.  Error Message: {runStatus.Message}");
                }
            }
            catch (Exception ex)
            {
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                _logger.LogError(ex, "Error running ADF Pipeline");
                throw new TaskFailedException($"ADF Pipeline Run Failed {response}{ex.StackTrace} {ex.InnerException}");
            }
        }
    }
}
