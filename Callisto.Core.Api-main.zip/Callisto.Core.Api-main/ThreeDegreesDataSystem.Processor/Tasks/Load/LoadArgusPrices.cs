﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Connectors.Argus;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service;

namespace ThreeDegreesDataSystem.Processor.Tasks
{
    public partial class TaskRunner
    {
        private async Task<TaskRun> LoadArgusPrices(TaskRun taskRun)
        {
            try
            {
                //taskRun.Parameters = "{\"endDate\":\"2025-03-11T00:30:36.2261475Z\",\"startDate\":\"2025-03-14T00:30:36.2232046Z\",\"taskRunIds\":{\"LoadArgusPrices\":580}}";


                DateTime startDate = ParameterHelper.GetStartDate(taskRun.Parameters);
                DateTime endDate = ParameterHelper.GetEndDate(taskRun.Parameters);
                
                var taskRunId = taskRun.TaskRunId;

                var argusParameters = new PriceParameters(startDate,endDate,taskRunId);

                var message = await _argusPriceService.LoadArgusPricesToDb(argusParameters);
                taskRun.AppendToMessage(message);
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Succeeded);

                return taskRun;
            }
            catch (Exception ex)
            {
                //_logger.LogError($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                taskRun.AppendToMessage($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                
                return taskRun;
            }
        }
    }
}
