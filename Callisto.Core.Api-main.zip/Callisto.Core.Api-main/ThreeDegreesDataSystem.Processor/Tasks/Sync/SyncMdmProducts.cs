﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using NPOI.SS.Formula.Functions;
using System.Diagnostics;
using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Exceptions;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Connectors.Azure;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service;

namespace ThreeDegreesDataSystem.Processor.Tasks
{
    public partial class TaskRunner
    {
        private async Task<TaskRun> SyncMdmProducts(TaskRun taskRun)
        {
            string callback = ParameterHelper.GetCallback(taskRun.Parameters);
            try
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                taskRun.AppendToMessage($"Starting MDM Product Sync initialization.  Elapsed time:{stopwatch.Elapsed.Seconds} seconds.");
                
                var products = ParameterHelper.GetMdmProducts(taskRun.Parameters).ToList();
                
                taskRun.AppendToMessage($"Starting MDM Product Sync initialization completed.  Elapsed time:{stopwatch.Elapsed.Seconds} seconds.");
                taskRun.AppendToMessage($"Starting MDM Product Sync to DB.  Elapsed time:{stopwatch.Elapsed.Seconds} seconds.");
                
                var mdmProducts = await _mdmProductService.SyncMdmProductsToDb(products);
                
                taskRun.AppendToMessage($"MDM Product Sync to DB completed.  Elapsed time:{stopwatch.Elapsed.Seconds} seconds.");

                taskRun.AppendToMessage($"Starting MDM Product Sync to NetSuite.  Elapsed time:{stopwatch.Elapsed.Seconds} seconds.");
                
                var message = await _mdmProductService.SyncMdmProductsToNetSuite(mdmProducts);
                taskRun.AppendToMessage(message);
                taskRun.AppendToMessage($"MDM Product Sync to NetSuite completed.  Elapsed time:{stopwatch.Elapsed.Seconds} seconds.");
                
                var callbackResponse = await _mdmProductService.NotifyLogicWebhook(callback, StringConstants.Succeeded);
                stopwatch.Stop();
                taskRun.AppendToMessage($"MDM Product Sync to NetSuite.  Elapsed time:{stopwatch.Elapsed.Seconds} seconds.");
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Succeeded);
                return taskRun;
            }
            catch (Exception ex)
            {
                var callbackResponse = await _mdmProductService.NotifyLogicWebhook(callback, StringConstants.Succeeded);
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                _logger.LogError($"MDM Product Sync {ex.StackTrace}");
                throw new TaskFailedException($"MDM Product Sync Failed {ex.StackTrace}");
            }
        }
    }
}
