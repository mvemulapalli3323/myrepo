﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Exceptions;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service;
using ThreeDegreesDataSystem.Service.Interface;
using ThreeDegreesDataSystem.Service.Service;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Reflection;
using ThreeDegreesDataSystem.Connectors.Interface;

namespace ThreeDegreesDataSystem.Processor.Tasks
{
    public partial class TaskRunner : ITaskRunner
    {
        private readonly ILogger<TaskRunner> _logger;
        // Connectors
        private readonly IAzureDataFactoryConnector _azureDataFactoryConnector;
        private readonly IArgusConnector _argusConnector;
        private readonly IEmailConnector _emailConnector;
        private readonly INetSuiteConnector _netSuiteConnector;

        // Services
        private readonly IAmerexPriceService _amerexPriceService;
        private readonly IAdmisService _admisService;
        private readonly IArgusPriceService _argusPriceService; 
        private readonly IAzureDataFactoryService _azureDataFactoryService;
        private readonly IGenericMapService _genericMapService;
        private readonly IGenericTimeoutService _genericTimeoutService;
        private readonly IMdmProductService _mdmProductService;
        private readonly ITaskRunService _taskRunService;
        private readonly ITaskService _taskService;

        private readonly Dictionary<string, Func<TaskRun, Task<TaskRun>>> _taskCodeCleanUpMap;

        public TaskRunner(
            ILogger<TaskRunner> logger,
            // Connectors
            IAzureDataFactoryConnector azureDataFactoryConnector,
            IArgusConnector argusConnector,
            IEmailConnector emailConnector,
            INetSuiteConnector netSuiteConnector,
            // Services
            IAdmisService admisService,
            IAmerexPriceService amerexPriceService,
            IArgusPriceService argusPriceService,
            IAzureDataFactoryService azureDataFactoryService,
            IGenericMapService genericMapService,
            IGenericTimeoutService genericTimeoutService,
            IMdmProductService mdmProductService,
            ITaskService taskService,
            ITaskRunService taskRunService
            )
        {
            _logger = logger;
            
            _argusConnector = argusConnector;
            _azureDataFactoryConnector = azureDataFactoryConnector;
            _emailConnector = emailConnector;
            _netSuiteConnector = netSuiteConnector;

            _admisService = admisService;
            _amerexPriceService = amerexPriceService;
            _argusPriceService = argusPriceService;
            _azureDataFactoryService = azureDataFactoryService;
            _genericMapService = genericMapService;
            _genericTimeoutService = genericTimeoutService;
            _mdmProductService = mdmProductService;
            _taskService = taskService;
            _taskRunService = taskRunService;
            
            _taskCodeCleanUpMap = new()
            {
                
            };
        }

        public async Task<TaskRun> RunTaskCleanUp(int taskRunId)
        {
            TaskRun taskRun = await _taskRunService.GetTaskRun(taskRunId);
            return await RunTaskCleanUp(taskRun);
        }

        public async Task<TaskRun> RunTaskCleanUp(TaskRun taskRun)
        {
            string taskCode = DataMap.GetTaskCode(taskRun.TaskId);
            if (_taskCodeCleanUpMap.ContainsKey(taskCode))
            {
                _logger.LogInformation("Clean up for task '{taskCode}'", taskCode);
                return await _taskCodeCleanUpMap[taskCode](taskRun);
            }
            throw new TaskNotFoundException($"Task code '{taskCode}' has no matching clean up function.");
        }

        private MethodInfo? GetMethodInfo(string methodName)
        {
            return GetType().GetMethod(methodName, BindingFlags.NonPublic | BindingFlags.Instance);
        }   

        public async Task<TaskRun> RunTask(TaskRun taskRun)
        {
            ThreeDegreesDataSystem.Models.Models.Task task = await _taskService.GetTask(taskRun.TaskId);

            if (task == null)
            {
                throw new TaskNotFoundException($"Task Definition for '{taskRun.TaskId}' not found.");
            }

            var taskMethodInfo = GetMethodInfo(task.TaskMethod);

            if (taskMethodInfo == null)
            {
                throw new TaskNotFoundException($"Task Method Implementation '{task.TaskMethod}' not found.");
            }

            _logger.LogInformation("Running task '{taskCode}'", task.TaskCode);
            return await (Task<TaskRun>)taskMethodInfo.Invoke(this, [taskRun]);
        }

        private TaskRun SetTaskRunWaiting(TaskRun taskRun, int duration)
        {
            taskRun.StatusId = DataMap.GetStatusId(StringConstants.Waiting);
            taskRun.Parameters = ParameterHelper.SetTimeout(taskRun.Parameters, duration);
            return taskRun;
        }

#pragma warning disable CS1998 // Async method lacks 'await' operators and will run synchronously
        private static async Task<TaskRun> NoCleanUp(TaskRun taskRun)
        {
            return taskRun;
        }
#pragma warning restore CS1998 // Async method lacks 'await' operators and will run synchronously
    }
}
