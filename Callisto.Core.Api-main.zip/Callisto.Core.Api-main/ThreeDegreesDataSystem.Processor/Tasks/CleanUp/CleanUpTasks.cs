﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service;
using ThreeDegreesDataSystem.Service.Service;

namespace ThreeDegreesDataSystem.Processor.Tasks
{
    public partial class TaskRunner
    {
        private async Task<TaskRun> CleanUpTaskRuns(TaskRun taskRun)
        {
            DateTime protectedDate = DateTime.UtcNow.AddMonths(-3).Date;
            DateTime endDate = ParameterHelper.GetEndDate(taskRun.Parameters);

            if (endDate >= protectedDate)
            {
                taskRun.Message = $"End date '{endDate:d}' must be earlier than protected date '{protectedDate:d}' (3 months prior to today).";
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                return taskRun;
            }

            TaskRunCriteria criteria = new();
            criteria.IsTopOnly = true;
            criteria.LastModifiedOnLessThan = endDate;
            criteria.StatusIds = new int[] { DataMap.GetStatusId(StringConstants.Failed), DataMap.GetStatusId(StringConstants.Cancelled) };
            IQueryable<TaskRun> taskRuns = _taskRunService.GetTaskRunsByCriteria(criteria);

            List<int> couldntDeleteIds = new();
            List<TaskRun> failedTaskRuns = taskRuns
                .Where(tr => tr.StatusId == DataMap.GetStatusId(StringConstants.Failed))
                .ToList();
            int numToDelete = failedTaskRuns.Count;
            foreach (TaskRun failedTaskRun in failedTaskRuns)
            {
                bool result = await DeleteTaskRun(failedTaskRun);
                if (!result)
                {
                    couldntDeleteIds.Add(failedTaskRun.TaskRunId);
                }
            }
            taskRun.AppendToMessage($"{numToDelete - couldntDeleteIds.Count} failed task runs deleted.");
            if (couldntDeleteIds.Any()) taskRun.AppendToMessage($"Couldn't delete: {string.Join(',',couldntDeleteIds)}");

            couldntDeleteIds.Clear();
            List<TaskRun> canceledTaskRuns = taskRuns
                .Where(tr => tr.StatusId == DataMap.GetStatusId(StringConstants.Cancelled))
                .ToList();
            numToDelete = canceledTaskRuns.Count;
            foreach (TaskRun canceledTaskRun in canceledTaskRuns)
            {
                bool result = await DeleteTaskRun(canceledTaskRun);
                if (!result)
                {
                    couldntDeleteIds.Add(canceledTaskRun.TaskRunId);
                }
            }
            taskRun.AppendToMessage($"{numToDelete - couldntDeleteIds.Count} canceled task runs deleted.");
            if (couldntDeleteIds.Any()) taskRun.AppendToMessage($"Couldn't delete: {string.Join(',', couldntDeleteIds)}");

            return taskRun;
        }

        private async Task<bool> DeleteTaskRun(TaskRun taskRunToDelete)
        {
            try
            {
                await _taskRunService.DeleteTaskRun(taskRunToDelete);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
