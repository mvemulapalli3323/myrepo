﻿using ThreeDegreesDataSystem.Common;
using ThreeDegreesDataSystem.Common.Exceptions;
using ThreeDegreesDataSystem.Common.Helper;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Service;

namespace ThreeDegreesDataSystem.Processor.Tasks
{
    public partial class TaskRunner
    {
        private async Task<TaskRun> CreateAdmisDailyFacts(TaskRun taskRun)
        {
            try
            {
                DateOnly businessDate = DateOnly.FromDateTime(ParameterHelper.GetBusinessDate(taskRun.Parameters));
                int admisDbLoadTaskRunId = ParameterHelper.GetTaskRunId(taskRun.Parameters, "LoadAdmisFilesToDb");

                var taskRunId = taskRun.TaskRunId;
                //var taskRunId = 1942;
                //var admisDbLoadTaskRunId = 1940;
                //var businessDate = new DateOnly(2025, 5, 1);      
                var message = await _admisService.CreateAdmisDailyFacts(taskRunId,admisDbLoadTaskRunId,  businessDate);
                
                taskRun.AppendToMessage($"Message: {message} {Environment.NewLine}");
                return taskRun;
            }
            catch (AdmisException admisEx)
            {
                taskRun.AppendToMessage($"Message: {admisEx.Message}");
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                return taskRun;
            }
            catch (Exception ex)
            {
                taskRun.AppendToMessage($"Message: {ex.Message} {Environment.NewLine} Stacktrace: {ex.StackTrace} {Environment.NewLine} Inner Exception: {ex.InnerException}");
                taskRun.StatusId = DataMap.GetStatusId(StringConstants.Failed);
                
                return taskRun;
            }
        }
    }
}
