﻿using ThreeDegreesDataSystem.Models.Models;
using System.Threading.Tasks;

namespace ThreeDegreesDataSystem.Processor.Tasks
{
    public interface ITaskRunner
    {
        public Task<TaskRun> RunTaskCleanUp(int taskRunId);
        public Task<TaskRun> RunTaskCleanUp(TaskRun taskRun);
        public Task<TaskRun> RunTask(TaskRun taskRun);
    }
}
