﻿using NUnit.Framework;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ThreeDegreesDataSystem.Service.Service;
using ThreeDegreesDataSystem.Models.DwModels;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Common;
using DocumentFormat.OpenXml.InkML;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Tests
{
    [TestFixture]
    public class AdmisServiceTests
    {
        private CentralOpsDbContext _centralOpsContext;
        private DwDbContext _dwContext;
        private AdmisService _service;
        private ThreeDegreesDataSystem.Service.Service.Service _baseService;


        [SetUp]
        public void Setup()
        {
            // In-memory databases for isolation
            var centralOptions = new DbContextOptionsBuilder<CentralOpsDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;
            _centralOpsContext = new CentralOpsDbContext(centralOptions);

            var dwOptions = new DbContextOptionsBuilder<DwDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;
            _dwContext = new DwDbContext(dwOptions);

            // Fix for CS0118: 'Service' is a namespace but is used like a type
            // The issue occurs because 'Service' is being used as a type, but it is actually a namespace.
            // To fix this, replace 'Service' with the correct type name from the 'Service' namespace.

            var _baseLogger = LoggerFactory.Create(builder => builder.AddConsole()).CreateLogger<ThreeDegreesDataSystem.Service.Service.Service>();
            var _admisLogger = LoggerFactory.Create(builder => builder.AddConsole()).CreateLogger<AdmisService>();

            // Pass loggers to AdmisService constructor
            _service = new AdmisService(_centralOpsContext, _dwContext, _baseLogger, _admisLogger);
        }

        [Test]
        public async System.Threading.Tasks.Task UpdateAdmisProductDimensions_WhenNoExistingProducts_CreatesNewProductDim()
        {
            // Arrange: one mapping record, no product dims
            _centralOpsContext.AdmisMappings.Add(new AdmisMapping
            {
                AdmisMappingId = 1,
                AdmisContract = "C1",
                ArtemisProduct = "P1",
                Vintage = "V1",
                CreatedBy = "Test",
                CreatedOn = DateTime.UtcNow,
                LastModifiedBy = "Test",
                LastModifiedOn = DateTime.UtcNow

            });
            _centralOpsContext.SaveChanges();

            // Act
            var result = await _service.UpdateAdmisProductDimensions(taskunId: 99);

            // Assert
            Assert.That(result, Is.EqualTo(StringConstants.Succeeded));
            var dims = _dwContext.DimAdmisProducts.ToList();
            Assert.That(dims, Has.Count.EqualTo(1));

            var dim = dims.First();
            Assert.That(dim.AdmisContractName, Is.EqualTo("C1"));
            Assert.That(dim.ProductName, Is.EqualTo("P1"));
            Assert.That(dim.Vintage, Is.EqualTo("V1"));
            Assert.That(dim.TaskRunId, Is.EqualTo(99));
            Assert.That(dim.ActiveFlag, Is.True);
            Assert.That(dim.ValidFrom.Date, Is.EqualTo(DateTime.UtcNow.Date));
        }

        [Test]
        public async System.Threading.Tasks.Task UpdateAdmisProductDimensions_WhenProductExistsAndUnchanged_DoesNothing()
        {
            // Arrange: mapping matches existing dim exactly
            _centralOpsContext.AdmisMappings.Add(new AdmisMapping
            {
                AdmisMappingId = 1,
                AdmisContract = "C1",
                ArtemisProduct = "P1",
                Vintage = "V1",
                CreatedBy = "Test",
                CreatedOn = DateTime.UtcNow,
                LastModifiedBy = "Test",
                LastModifiedOn = DateTime.UtcNow
            });
            _centralOpsContext.SaveChanges();

            _dwContext.DimAdmisProducts.Add(new DimAdmisProduct
            {
                DimAdmisProductId = 1,
                AdmisContractName = "C1",
                ProductName = "P1",
                Vintage = "V1",
                ActiveFlag = true,
                ValidTo = DateTime.MaxValue,
                CreatedBy = "Test",
                CreatedDate = DateTime.UtcNow,
                LastModifiedBy = "Test",
                LastModifiedDate = DateTime.UtcNow,
                TaskRunId = 0
            });
            _dwContext.SaveChanges();

            // Act
            var result = await _service.UpdateAdmisProductDimensions(taskunId: 5);

            // Assert
            Assert.That(result, Is.EqualTo(StringConstants.Succeeded));
            var dims = _dwContext.DimAdmisProducts.Where(d => d.AdmisContractName == "C1").ToList();
            Assert.That(dims, Has.Count.EqualTo(1));

            var dim = dims.First();
            // Should remain unchanged
            Assert.That(dim.DimAdmisProductId, Is.EqualTo(1));
            Assert.That(dim.TaskRunId, Is.EqualTo(0));
            Assert.That(dim.ActiveFlag, Is.True);
            Assert.That(dim.ValidTo, Is.EqualTo(DateTime.MaxValue));
        }

        [Test]
        public async System.Threading.Tasks.Task UpdateAdmisProductDimensions_WhenProductExistsAndChanged_UpdatesExistingAndCreatesNew()
        {
            // Arrange: mapping differs from existing dim
            _centralOpsContext.AdmisMappings.Add(new AdmisMapping
            {
                AdmisMappingId = 2,
                AdmisContract = "C2",
                ArtemisProduct = "P2",
                Vintage = "V2",
                CreatedBy = "Test",
                CreatedOn = DateTime.UtcNow,
                LastModifiedBy = "Test",
                LastModifiedOn = DateTime.UtcNow
            });
            _centralOpsContext.SaveChanges();

            _dwContext.DimAdmisProducts.Add(new DimAdmisProduct
            {
                DimAdmisProductId = 10,
                AdmisContractName = "C2",
                ProductName = "OldP",
                Vintage = "OldV",
                ActiveFlag = true,
                ValidTo = DateTime.MaxValue,
                CreatedBy = "Test",
                CreatedDate = DateTime.UtcNow,
                LastModifiedBy = "Test",
                LastModifiedDate = DateTime.UtcNow,
                TaskRunId = 0
            });
            _dwContext.SaveChanges();

            // Act
            var result = await _service.UpdateAdmisProductDimensions(taskunId: 77);

            // Assert
            Assert.That(result, Is.EqualTo(StringConstants.Succeeded));
            var dims = _dwContext.DimAdmisProducts.Where(d => d.AdmisContractName == "C2").ToList();
            Assert.That(dims, Has.Count.EqualTo(2));

            // Existing should be marked inactive and updated
            var updated = dims.Single(d => d.DimAdmisProductId == 10);
            Assert.That(updated.ActiveFlag, Is.False);
            Assert.That(updated.LastModifiedBy, Is.EqualTo("UpdateAdmisProductDimensions Task"));
            Assert.That(updated.TaskRunId, Is.EqualTo(77));
            Assert.That(updated.ValidTo.Date, Is.EqualTo(DateTime.UtcNow.Date.AddDays(-1)));

            // New dimension
            var created = dims.Single(d => d.DimAdmisProductId != 10);
            Assert.That(created.AdmisContractName, Is.EqualTo("C2"));
            Assert.That(created.ProductName, Is.EqualTo("P2"));
            Assert.That(created.Vintage, Is.EqualTo("V2"));
            Assert.That(created.ActiveFlag, Is.True);
            Assert.That(created.ValidFrom.Date, Is.EqualTo(DateTime.UtcNow.Date));
            Assert.That(created.TaskRunId, Is.EqualTo(77));
        }


        [TearDown]
        public void TearDown()
        {
            _centralOpsContext.Dispose();
            _dwContext.Dispose();
        }
    }
}
