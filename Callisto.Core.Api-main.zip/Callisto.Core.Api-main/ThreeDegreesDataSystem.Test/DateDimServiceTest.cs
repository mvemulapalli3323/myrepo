﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using ThreeDegreesDataSystem.Service.Service;
using ThreeDegreesDataSystem.Models.Models;
using ThreeDegreesDataSystem.Models.DwModels;
using Microsoft.Extensions.Logging;

namespace ThreeDegreesDataSystem.Test.Service
{
    [TestFixture]
    public class DateDimServiceTests
    {
        private DateDimService _dateDimService;
        private CentralOpsDbContext _context;
        private DwDbContext _dwContext;
        private ILogger<ThreeDegreesDataSystem.Service.Service.Service> _logger;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<CentralOpsDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;
            var dwOptions = new DbContextOptionsBuilder<DwDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDwDatabase")
                .Options;

            _context = new CentralOpsDbContext(options);
            _dwContext = new DwDbContext(dwOptions);
            _dateDimService = new DateDimService(_context,_dwContext,_logger);
        }

        [TearDown]
        public void TearDown()
        {
            _context.Dispose();
            _dwContext.Dispose();
        }

        [Test]
        public async System.Threading.Tasks.Task IsUsBusinessDate_ShouldReturnTrue_WhenDateIsBusinessDay()
        {
            // Arrange
            var testDate = new DateTime(2025, 2, 21);
            _dwContext.DimDates.Add(new Models.DwModels.DimDate { Date = DateOnly.FromDateTime(testDate), UsBusinessDayFlag = true, DayName = testDate.ToString("dddd"), MonthName = testDate.ToString("MMMM"), MonthAbbreviation = testDate.ToString("MMM"), DayAbbreviation = testDate.ToString("ddd") });
            _dwContext.SaveChanges();
            // Act
            var result = await _dateDimService.IsUsBusinessDate(testDate);

            // Assert
            Assert.IsTrue(result);
        }

        [Test]
        public async System.Threading.Tasks.Task IsUsBusinessDate_ShouldReturnFalse_WhenDateIsNotBusinessDay()
        {
            // Arrange
            var testDate = new DateTime(2025, 2, 22);
            _dwContext.DimDates.Add(new Models.DwModels.DimDate { Date = DateOnly.FromDateTime(testDate), UsBusinessDayFlag = false, DayName = testDate.ToString("dddd"), MonthName = testDate.ToString("MMMM"), MonthAbbreviation = testDate.ToString("MMM"), DayAbbreviation = testDate.ToString("ddd") });
            _dwContext.SaveChanges();

            // Act
            var result = await _dateDimService.IsUsBusinessDate(testDate);

            // Assert
            Assert.IsFalse(result);
        }

        [Test]
        public async System.Threading.Tasks.Task IsUsBusinessDate_ShouldReturnFalse_WhenDateDoesNotExist()
        {
            // Arrange
            var testDate = new DateTime(1950, 2, 28);

            // Act
            var result = await _dateDimService.IsUsBusinessDate(testDate);

            // Assert
            Assert.IsFalse(result);
        }
    }
}
